import os
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import traceback

# --- Configuration ---
DB_CONNECTION_STRING = (
)
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"
OUTPUT_FILENAME = "regional_weather.csv"

# --- Main Logic ---

def download_regional_weather_data():
    """
    Downloads regional weather data from the PRODUCTION_L48_REGIONAL_WEATHER table
    and saves it to a CSV file in the 'Update' folder.
    """
    print("\n" + "="*80)
    print("   DOWNLOADING L48 REGIONAL WEATHER DATA")
    print("="*80)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output Directory: {os.path.abspath(OUTPUT_DIR)}")
    print("="*80)
    
    engine = None
    try:
        # --- Database Connection ---
        print("\n[1] Connecting to the database...")
        engine = create_engine(DB_CONNECTION_STRING)
        
        # --- Define and Execute Query ---
        # NOTE: Removed TOP (1000) to fetch all records and added ORDER BY for consistency.
        query = text("""
            SELECT 
                [DATE],
                [CONUS_GW_HDD],
                [CONUS_PW_CDD],
                [MIDWEST_GW_HDD],
                [MIDWEST_PW_CDD],
                [PACIFIC_GW_HDD],
                [PACIFIC_PW_CDD],
                [MOUNTAIN_GW_HDD],
                [MOUNTAIN_PW_CDD],
                [SOUTHCENTRAL_GW_HDD],
                [SOUTHCENTRAL_PW_CDD],
                [EAST_GW_HDD],
                [EAST_PW_CDD]
            FROM [dbo].[PRODUCTION_L48_REGIONAL_WEATHER]
            ORDER BY [DATE] ASC
        """)
        
        print("[2] Executing query to fetch weather data...")
        df = pd.read_sql(query, engine)

        if df.empty:
            print("  ✗ No weather data was returned from the query. Cannot create file.")
            return

        print(f"  ✓ Downloaded {len(df)} records.")

        # --- Save Data to CSV ---
        output_filepath = os.path.join(OUTPUT_DIR, OUTPUT_FILENAME)
        print(f"\n[3] Saving data to: {output_filepath}")
        df.to_csv(output_filepath, index=False)
        print(f"  ✓ Successfully saved weather data.")

    except SQLAlchemyError as e:
        print(f"\n✗ DATABASE ERROR: A database error occurred: {e}")
        traceback.print_exc()
    except Exception as e:
        print(f"\n✗ UNEXPECTED ERROR: An unexpected error occurred: {e}")
        traceback.print_exc()
    finally:
        if engine:
            engine.dispose()
            print("\n    ✓ Database connection closed")

    # --- Final Summary ---
    print("\n" + "="*80)
    print("✅ Script completed!")
    print("="*80)

# --- Execute the Script ---
if __name__ == "__main__":
    download_regional_weather_data()