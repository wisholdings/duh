import json
import sys
import pandas as pd
import numpy as np
import traceback
import time
from datetime import datetime
import warnings
import os

# ####################################################################
# ### [FIXED] UNIFIED AND ROBUST PATH CONFIGURATION                ###
# ####################################################################

# --- Determine Project Root and Add to Path ---
# This is now the single source of truth for all pathing in the script.
try:
    # Get the directory of the currently running script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Go up THREE levels from the script's location to find the project root.
    # .../NHITS_REGIONAL_GAS_DISSEMINATION/ -> .../scripts/ -> .../BestVersion/
    PROJECT_ROOT = os.path.abspath(os.path.join(script_dir, '..', '..'))

    # Add the project root to the Python path for module imports
    if PROJECT_ROOT not in sys.path:
        sys.path.append(PROJECT_ROOT)
    print(f"DEBUG: Project root set to: {PROJECT_ROOT}")
except Exception as e:
    print(f"FATAL: Could not determine project root. Error: {e}")
    sys.exit(1)

# --- Configuration Loading ---
# Now that the path is set, we can import and load files reliably.
try:
    from config.settings import BASE_OUTPUT_DIR
    print(f"SUCCESS: Loaded BASE_OUTPUT_DIR from config: {BASE_OUTPUT_DIR}")
except (ImportError, NameError, FileNotFoundError) as e:
    print(f"WARNING: Could not import BASE_OUTPUT_DIR from 'config.settings' ({e}). Using fallback.")
    BASE_OUTPUT_DIR = "D:\\EIA_STACK"
    print(f"Using fallback BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")

try:
    # Construct the full, absolute path to regions.json using our reliable PROJECT_ROOT
    regions_config_path = os.path.join(PROJECT_ROOT, 'config', 'regions.json')
    print(f"DEBUG: Attempting to load regions config from: {regions_config_path}")
    with open(regions_config_path, 'r') as f:
        regions_config = json.load(f)
    REGIONS = [item['name'] for item in regions_config] if isinstance(regions_config, list) else list(regions_config.keys())
    print(f"SUCCESS: Loaded regions config for: {REGIONS}")
except Exception as e:
    print(f"FATAL: Could not load regions config from '{regions_config_path}'. Error: {e}")
    sys.exit(1)

# ####################################################################
# ### END OF FIX                                                   ###
# ####################################################################


# --- Hardcoded Feature Configuration ---
# (This section is unchanged)
REGION_SPECIFIC_FEATURES = {
    "CALIFORNIA": [
        "CALIFORNIA_LOAD", "CALIFORNIA_NG_MW", "CALIFORNIA_COL_MW", "CALIFORNIA_NUC_MW", "CALIFORNIA_WAT_MW", "CALIFORNIA_SUN_MW", "CALIFORNIA_WND_MW", "CALIFORNIA_INTERCHANGE_MW","CALIFORNIA_OTH_MW","CALIFORNIA_BAT_MW","CALIFORNIA_PS_MW",
        "KBAK_temperature_2m", "KBSW_temperature_2m", "KCIC_temperature_2m", "KEKA_temperature_2m", "KFNO_temperature_2m", "KLAX_temperature_2m", "KPSP_temperature_2m", "KRDD_temperature_2m", "KSAC_temperature_2m", "KSBA_temperature_2m", "KSDG_temperature_2m", "KSFO_temperature_2m", "KSJC_temperature_2m", "KSLO_temperature_2m"
    ],
    "NEWYORK": [
        "NEWYORK_LOAD", "NEWYORK_NG_MW", "NEWYORK_COL_MW", "NEWYORK_NUC_MW", "NEWYORK_WAT_MW", "NEWYORK_WND_MW", "NEWYORK_INTERCHANGE_MW","NEWYORK_OTH_MW",
        "KALB_temperature_2m", "KBUF_temperature_2m", "KFOK_temperature_2m", "KJFK_temperature_2m", "KMGJ_temperature_2m", "KMSS_temperature_2m", "KROC_temperature_2m", "KSLK_temperature_2m", "KSYR_temperature_2m"
    ],
    "CAROLINA": [
        "CAROLINA_LOAD", "CAROLINA_NG_MW", "CAROLINA_COL_MW", "CAROLINA_NUC_MW", "CAROLINA_WAT_MW", "CAROLINA_SUN_MW", "CAROLINA_PS_MW", "CAROLINA_BAT_MW","CAROLINA_OTH_MW", "CAROLINA_INTERCHANGE_MW",
        "KAND_temperature_2m", "KAVL_temperature_2m", "KCHS_temperature_2m", "KCLT_temperature_2m", "KCRE_temperature_2m", "KECG_temperature_2m", "KINT_temperature_2m", "KISO_temperature_2m", "KMRH_temperature_2m", "KNMT_temperature_2m", "KRDU_temperature_2m"
    ],
    "CENTRAL": [
        "CENTRAL_LOAD", "CENTRAL_NG_MW", "CENTRAL_COL_MW", "CENTRAL_NUC_MW", "CENTRAL_WAT_MW", "CENTRAL_SUN_MW", "CENTRAL_WND_MW", "CENTRAL_INTERCHANGE_MW","CENTRAL_OTH_MW",
        "K4O4_temperature_2m", "KANW_temperature_2m", "KATY_temperature_2m", "KBIS_temperature_2m", "KCSM_temperature_2m", "KDIK_temperature_2m", "KFAR_temperature_2m", "KFNB_temperature_2m", "KFSD_temperature_2m", "KGAG_temperature_2m", "KLBF_temperature_2m", "KMOT_temperature_2m", "KOFK_temperature_2m", "KOMA_temperature_2m", "KPHP_temperature_2m", "KRAP_temperature_2m", "KRDR_temperature_2m", "KSCB_temperature_2m", "KTUL_temperature_2m"
    ],
    "FLORIDA": [
        "FLORIDA_LOAD", "FLORIDA_NG_MW", "FLORIDA_COL_MW", "FLORIDA_NUC_MW", "FLORIDA_WAT_MW", "FLORIDA_SUN_MW", "FLORIDA_INTERCHANGE_MW","FLORIDA_OTH_MW",
        "K40J_temperature_2m", "KECP_temperature_2m", "KEYW_temperature_2m", "KFLL_temperature_2m", "KJAX_temperature_2m", "KMLB_temperature_2m", "KOCF_temperature_2m", "KPNS_temperature_2m", "KSGJ_temperature_2m", "KTLH_temperature_2m", "KTPA_temperature_2m"
    ],
    "MIDATLANTIC": [
        "MIDATLANTIC_LOAD", "MIDATLANTIC_NG_MW", "MIDATLANTIC_COL_MW", "MIDATLANTIC_NUC_MW", "MIDATLANTIC_WAT_MW", "MIDATLANTIC_SUN_MW", "MIDATLANTIC_WND_MW","MIDATLANTIC_OTH_MW", "MIDATLANTIC_INTERCHANGE_MW",
        "KABE_temperature_2m", "KAVP_temperature_2m", "KBKW_temperature_2m", "KCKB_temperature_2m", "KDAN_temperature_2m", "KDCA_temperature_2m", "KDOV_temperature_2m", "KDUJ_temperature_2m", "KERI_temperature_2m", "KHGR_temperature_2m", "KHTS_temperature_2m", "KILG_temperature_2m", "KJST_temperature_2m", "KMDT_temperature_2m", "KMGW_temperature_2m", "KORF_temperature_2m", "KOXB_temperature_2m", "KPIT_temperature_2m", "KUNV_temperature_2m"
    ],
    "MIDWEST": [
        "MIDWEST_LOAD", "MIDWEST_NG_MW", "MIDWEST_COL_MW", "MIDWEST_NUC_MW", "MIDWEST_WAT_MW", "MIDWEST_SUN_MW", "MIDWEST_WND_MW", "MIDWEST_BAT_MW","MIDWEST_OTH_MW", "MIDWEST_INTERCHANGE_MW",
        "KAPN_temperature_2m", "KBBG_temperature_2m", "KBJI_temperature_2m", "KBLV_temperature_2m", "KCAK_temperature_2m", "KCDS_temperature_2m", "KCIU_temperature_2m", "KCLE_temperature_2m", "KCVG_temperature_2m", "KDLH_temperature_2m", "KDSM_temperature_2m", "KEVV_temperature_2m", "KFOD_temperature_2m", "KFWA_temperature_2m", "KGPZ_temperature_2m", "KGRB_temperature_2m", "KGRR_temperature_2m", "KHYS_temperature_2m", "KICT_temperature_2m", "KIND_temperature_2m", "KINL_temperature_2m", "KIRK_temperature_2m", "KJKL_temperature_2m", "KLBL_temperature_2m", "KLSE_temperature_2m", "KMCI_temperature_2m", "KMHK_temperature_2m", "KMIE_temperature_2m", "KMKE_temperature_2m", "KMKG_temperature_2m", "KMLI_temperature_2m", "KMOX_temperature_2m", "KMSN_temperature_2m", "KMSP_temperature_2m", "KORD_temperature_2m", "KOWB_temperature_2m", "KPAH_temperature_2m", "KPIA_temperature_2m", "KPLN_temperature_2m", "KRFD_temperature_2m", "KRHI_temperature_2m", "KRST_temperature_2m", "KSAW_temperature_2m", "KSBN_temperature_2m", "KSDF_temperature_2m", "KSGF_temperature_2m", "KSPI_temperature_2m", "KSTC_temperature_2m", "KSTL_temperature_2m", "KSUX_temperature_2m", "KTOP_temperature_2m", "KTVC_temperature_2m", "KZZV_temperature_2m"
    ],
    "NEWENGLAND": [
        "NEWENGLAND_LOAD", "NEWENGLAND_NG_MW", "NEWENGLAND_COL_MW", "NEWENGLAND_NUC_MW", "NEWENGLAND_WAT_MW", "NEWENGLAND_SUN_MW", "NEWENGLAND_WND_MW","NEWENGLAND_OTH_MW", "NEWENGLAND_PS_MW", "NEWENGLAND_BAT_MW", "NEWENGLAND_INTERCHANGE_MW",
        "KACK_temperature_2m", "KBDL_temperature_2m", "KBGR_temperature_2m", "KBOS_temperature_2m", "KBTV_temperature_2m", "KCEF_temperature_2m", "KHVN_temperature_2m", "KMHT_temperature_2m", "KMVL_temperature_2m", "KPQI_temperature_2m", "KPVD_temperature_2m", "KPWM_temperature_2m", "KRKD_temperature_2m", "KRUT_temperature_2m", "KWST_temperature_2m"
    ],
    "NORTHWEST": [
        "NORTHWEST_LOAD", "NORTHWEST_NG_MW", "NORTHWEST_COL_MW", "NORTHWEST_NUC_MW", "NORTHWEST_WAT_MW", "NORTHWEST_SUN_MW", "NORTHWEST_WND_MW","NORTHWEST_OTH_MW", "NORTHWEST_BAT_MW", "NORTHWEST_INTERCHANGE_MW",
        "KAST_temperature_2m", "KBIL_temperature_2m", "KBLI_temperature_2m", "KBOI_temperature_2m", "KCLM_temperature_2m", "KCOD_temperature_2m", "KCOE_temperature_2m", "KCPR_temperature_2m", "KEUG_temperature_2m", "KGDV_temperature_2m", "KGTF_temperature_2m", "KIDA_temperature_2m", "KJAC_temperature_2m", "KLAR_temperature_2m", "KMFR_temperature_2m", "KMSO_temperature_2m", "KOLF_temperature_2m", "KONP_temperature_2m", "KPSC_temperature_2m", "KPUW_temperature_2m", "KRDM_temperature_2m", "KRKS_temperature_2m", "KSEA_temperature_2m", "KSHR_temperature_2m", "KTWF_temperature_2m"
    ],
    "SOUTHEAST": [
        "SOUTHEAST_LOAD", "SOUTHEAST_NG_MW", "SOUTHEAST_COL_MW", "SOUTHEAST_NUC_MW", "SOUTHEAST_WAT_MW", "SOUTHEAST_SUN_MW", "SOUTHEAST_BAT_MW","SOUTHEAST_OTH_MW", "SOUTHEAST_INTERCHANGE_MW",
        "KATL_temperature_2m", "KDHN_temperature_2m", "KELD_temperature_2m", "KFSM_temperature_2m", "KGPT_temperature_2m", "KGWO_temperature_2m", "KHSV_temperature_2m", "KJAN_temperature_2m", "KJBR_temperature_2m", "KLCH_temperature_2m", "KMCN_temperature_2m", "KMOB_temperature_2m", "KMSY_temperature_2m", "KSAV_temperature_2m", "KSHV_temperature_2m", "KTUP_temperature_2m", "KVDI_temperature_2m", "KXNA_temperature_2m"
    ],
    "SOUTHWEST": [
        "SOUTHWEST_LOAD", "SOUTHWEST_NG_MW", "SOUTHWEST_COL_MW", "SOUTHWEST_NUC_MW", "SOUTHWEST_WAT_MW", "SOUTHWEST_SUN_MW", "SOUTHWEST_WND_MW","SOUTHWEST_OTH_MW", "SOUTHWEST_BAT_MW", "SOUTHWEST_INTERCHANGE_MW",
        "KABQ_temperature_2m", "KASE_temperature_2m", "KCNY_temperature_2m", "KDEN_temperature_2m", "KDRO_temperature_2m", "KFMN_temperature_2m", "KGCN_temperature_2m", "KGJT_temperature_2m", "KHOB_temperature_2m", "KIGM_temperature_2m", "KLAS_temperature_2m", "KLGU_temperature_2m", "KLVS_temperature_2m", "KPHX_temperature_2m", "KRNO_temperature_2m", "KSGU_temperature_2m", "KSLC_temperature_2m", "KTPH_temperature_2m", "KTUS_temperature_2m", "KWMC_temperature_2m"
    ],
    "TENNESSEE": [
        "TENNESSEE_LOAD", "TENNESSEE_NG_MW", "TENNESSEE_COL_MW", "TENNESSEE_NUC_MW","TENNESSEE_OTH_MW", "TENNESSEE_WAT_MW", "TENNESSEE_SUN_MW","TENNESSEE_PS_MW", "TENNESSEE_INTERCHANGE_MW",
        "K1A5_temperature_2m", "KBNA_temperature_2m", "KCKV_temperature_2m", "KDYR_temperature_2m", "KHZD_temperature_2m", "KMEM_temperature_2m", "KMMI_temperature_2m", "KTRI_temperature_2m", "KTYS_temperature_2m", "KXNX_temperature_2m"
    ],
    "TEXAS": [
        "TEXAS_LOAD", "TEXAS_NG_MW", "TEXAS_COL_MW", "TEXAS_NUC_MW", "TEXAS_WAT_MW","TEXAS_OTH_MW", "TEXAS_SUN_MW", "TEXAS_WND_MW", "TEXAS_BAT_MW", "TEXAS_INTERCHANGE_MW",
        "K11R_temperature_2m", "KAMA_temperature_2m", "KBGD_temperature_2m", "KBRO_temperature_2m", "KCOT_temperature_2m", "KCRP_temperature_2m", "KDFW_temperature_2m", "KDRT_temperature_2m", "KLHB_temperature_2m", "KLRD_temperature_2m", "KMAF_temperature_2m", "KPRX_temperature_2m", "KSAT_temperature_2m", "KSJT_temperature_2m", "KSPS_temperature_2m"
    ]
}

# --- File Configuration ---
HOURLY_FEATURES_INPUT_FILENAME = "hourly_mw_features.csv"
MONTHLY_GAS_INPUT_FILENAME_PATTERN = "natural_gas_consumption_{region}.csv"

# --- Column Name Definitions ---
BASE_MW_COL = "_NG_MW"
BASE_GAS_COL = "_NG_Consumption_MMcf"

# --- Pandas Options ---
pd.options.mode.chained_assignment = None
warnings.filterwarnings('ignore', category=pd.errors.PerformanceWarning)

# --- Helper Functions ---
def load_local_csv(filepath):
    """Loads a CSV file, parsing the first date-like column."""
    if not os.path.exists(filepath):
        print(f"    WARNING: File not found: {filepath}")
        return pd.DataFrame()
    try:
        df = pd.read_csv(filepath, low_memory=False)
        date_col = next((col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()), None)
        if not date_col:
            print(f"    ERROR: No suitable date column found in {os.path.basename(filepath)}.")
            return pd.DataFrame()
        df.rename(columns={date_col: 'date'}, inplace=True)
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        df.dropna(subset=['date'], inplace=True)
        return df
    except Exception as e:
        print(f"    ERROR loading or parsing '{os.path.basename(filepath)}': {e}"); return pd.DataFrame()

def disaggregate_historical_gas(df_group, mw_col_h, gas_col_m):
    """
    Disaggregates a monthly gas total based on the hourly shape of natural gas generation.
    """
    if df_group[gas_col_m].isnull().all():
        df_group['hourly_gas_burn'] = np.nan
        return df_group

    G_m_used = df_group[gas_col_m].iloc[0]
    hourly_shape = df_group[mw_col_h].clip(lower=0)
    monthly_shape_sum = hourly_shape.sum()

    if monthly_shape_sum > 0 and G_m_used > 0:
        df_group['hourly_gas_burn'] = G_m_used * (hourly_shape / monthly_shape_sum)
    else:
        df_group['hourly_gas_burn'] = 0.0
    
    return df_group

def create_time_features(df):
    """Creates time-based cyclical features."""
    dt = df['date'].dt
    features = {
        'hour_sin': np.sin(2 * np.pi * dt.hour / 24),
        'hour_cos': np.cos(2 * np.pi * dt.hour / 24),
        'weekday_sin': np.sin(2 * np.pi * dt.dayofweek / 7),
        'weekday_cos': np.cos(2 * np.pi * dt.dayofweek / 7),
        'month_sin': np.sin(2 * np.pi * dt.month / 12),
        'month_cos': np.cos(2 * np.pi * dt.month / 12),
        'weekend': dt.dayofweek.isin([5, 6]).astype(int),
        'day_of_year_sin': np.sin(2 * np.pi * dt.dayofyear / 365),
        'day_of_year_cos': np.cos(2 * np.pi * dt.dayofyear / 365)
    }
    time_features_df = pd.DataFrame(features, index=df.index)
    return pd.concat([df, time_features_df], axis=1)

def create_regional_features(df, region_upper):
    """Creates region-specific engineered features."""
    mw_col = f"{region_upper}_NG_MW"
    load_col = f"{region_upper}_LOAD"
    features = {}
    
    if load_col in df.columns:
        features[f'{region_upper}_gas_share'] = (df[mw_col] / df[load_col].clip(lower=1)).fillna(0)
    if mw_col in df.columns:
        features[f'{region_upper}_NG_MW_rolling_24h'] = df[mw_col].rolling(24, min_periods=1).mean()
        features[f'{region_upper}_NG_MW_rolling_168h'] = df[mw_col].rolling(168, min_periods=1).mean()
        features[f'{region_upper}_NG_MW_std_24h'] = df[mw_col].rolling(24, min_periods=1).std().fillna(0)
    
    features[f'{region_upper}_peak_hours'] = df['date'].dt.hour.isin(list(range(7, 12)) + list(range(16, 21))).astype(int)
    
    month = df['date'].dt.month
    cooling_dominant = ['TEXAS', 'FLORIDA', 'SOUTHWEST', 'CALIFORNIA', 'SOUTHEAST','CAROLINA','CENTRAL','MIDWEST','MIDATLANTIC','NEWENGLAND','NEWYORK','NORTHWEST','TENNESSEE']
    if region_upper in cooling_dominant:
        features[f'{region_upper}_cooling_season'] = month.isin([5,6,7,8,9]).astype(int)
        features[f'{region_upper}_shoulder_season'] = month.isin([3,4,10,11]).astype(int)
    else:
        features[f'{region_upper}_heating_season'] = month.isin([11,12,1,2,3]).astype(int)
        features[f'{region_upper}_cooling_season'] = month.isin([6,7,8,9]).astype(int)
    
    features_df = pd.DataFrame(features, index=df.index)
    return pd.concat([df, features_df], axis=1)

# --- Main Processing Function ---
def prepare_regional_datasets():
    print("\n=========================================================")
    print("=== Starting Regional Data Preparation for N-HiTS Models ===")
    print("=========================================================")
    start_total_time = time.time()
    successful_regions = []
    
    for region_name in REGIONS:
        region_upper = region_name.upper()
        print(f"\n--- Processing Region: {region_upper} ---")
        
        region_final_dir = os.path.join(BASE_OUTPUT_DIR, region_name, "final")
        hourly_features_file = os.path.join(region_final_dir, HOURLY_FEATURES_INPUT_FILENAME)
        monthly_gas_file = os.path.join(region_final_dir, MONTHLY_GAS_INPUT_FILENAME_PATTERN.format(region=region_name))

        df_hourly_features = load_local_csv(hourly_features_file)
        df_monthly_gas = load_local_csv(monthly_gas_file)

        if df_hourly_features.empty:
            print(f"  WARNING: No hourly features for {region_upper}. Skipping.")
            continue
            
        mw_col_hourly_in = f"{region_upper}{BASE_MW_COL}"
        gas_col_monthly_in = f"{region_upper}{BASE_GAS_COL}"
        output_col_region = f"{region_upper}_Power_Burn"
        
        df_hourly_features['month'] = df_hourly_features['date'].dt.to_period("M")
        
        if not df_monthly_gas.empty and gas_col_monthly_in in df_monthly_gas.columns:
            df_monthly_gas["month"] = df_monthly_gas['date'].dt.to_period("M")
            df_monthly_gas_agg = df_monthly_gas.groupby("month", as_index=False)[[gas_col_monthly_in]].sum()
            df_hourly_features = pd.merge(df_hourly_features, df_monthly_gas_agg, on="month", how="left")
        else:
            df_hourly_features[gas_col_monthly_in] = np.nan

        print("  Disaggregating historical gas burn...")
        df_processed = df_hourly_features.groupby("month", group_keys=False, as_index=False).apply(
            disaggregate_historical_gas,
            mw_col_h=mw_col_hourly_in,
            gas_col_m=gas_col_monthly_in
        )
        df_processed.rename(columns={'hourly_gas_burn': output_col_region}, inplace=True)
        
        df_processed.drop(columns=[col for col in [gas_col_monthly_in, 'month'] if col in df_processed.columns], inplace=True)
        
        print("  Adding time and regional features...")
        df_processed = create_time_features(df_processed)
        df_processed = create_regional_features(df_processed, region_upper)
        
        base_cols = ['date', output_col_region]
        time_feature_cols = ['hour_sin', 'hour_cos', 'weekday_sin', 'weekday_cos', 'month_sin', 'month_cos', 'weekend', 'day_of_year_sin', 'day_of_year_cos']
        region_specific_cols = REGION_SPECIFIC_FEATURES.get(region_upper, [])
        engineered_cols = [col for col in df_processed.columns if col.startswith(f'{region_upper}_') and col not in [output_col_region] + region_specific_cols]
        cols_to_keep = base_cols + time_feature_cols + region_specific_cols + engineered_cols
        
        existing_cols = [col for col in cols_to_keep if col in df_processed.columns]
        df_final = df_processed[existing_cols].copy()
        
        df_final.sort_values(by='date', inplace=True)
        df_final.reset_index(drop=True, inplace=True)
        
        output_filename = f"NHITS_POWER_{region_upper}.csv"
        output_filepath = os.path.join(BASE_OUTPUT_DIR, output_filename)
        
        print(f"  Saving to: {output_filepath} (Shape: {df_final.shape})")
        df_final.to_csv(output_filepath, index=False, float_format='%.3f', date_format='%Y-%m-%d %H:%M:%S')
        
        successful_regions.append(region_upper)

    end_total_time = time.time()
    print("\n\n=============================================")
    print(f"Processed {len(successful_regions)} regions in {end_total_time - start_total_time:.2f}s.")
    print("=============================================")
    sys.exit(0)

if __name__ == "__main__":
    prepare_regional_datasets()