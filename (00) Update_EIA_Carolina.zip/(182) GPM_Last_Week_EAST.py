import pandas as pd
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import numpy as np
import warnings

# Suppress common pandas warnings for cleaner output
# warnings.filterwarnings('ignore', category=pd.core.common.SettingWithCopyWarning)
warnings.filterwarnings('ignore', category=FutureWarning)

# --- 1. Load and Prepare Data ---
print("Step 1: Loading and preparing data...")

# Define file paths
features_path = r'D:\EIA_STACK\Pricing_RL\PACIFIC\PACIFIC_filtered.csv'
target_path = r'D:\EIA_STACK\granular_storage\pacific.csv'

# Load daily features and weekly target
try:
    df_features_daily = pd.read_csv(features_path)
    df_target_weekly = pd.read_csv(target_path)
except FileNotFoundError as e:
    print(f"Error: Could not find a file. Please check your paths.\nDetails: {e}")
    exit()

# Convert date columns to datetime objects
df_features_daily['date'] = pd.to_datetime(df_features_daily['date'])
df_target_weekly['datetime'] = pd.to_datetime(df_target_weekly['datetime'])

# Set date as the index for time-series operations
df_features_daily.set_index('date', inplace=True)
df_target_weekly.set_index('datetime', inplace=True)


# --- 2. Advanced Feature Engineering (Daily) ---
print("\nStep 2: Engineering rolling features on daily data...")

# Create 7-day rolling averages to smooth out noise and capture recent trends
df_features_daily['synmax_7day_avg'] = df_features_daily['synmaxproductio_DRY_GAS_BCF_DAY'].rolling(window=7).mean()


# --- 3. Aggregate Daily Data to Weekly ---
print("\nStep 3: Aggregating daily data to a weekly cadence...")

# Define aggregation rules for all columns
aggregation_rules = {}
for col in df_features_daily.columns:
    if 'pacificconsolidate_BCF' in col or '_avg' in col:
        # For storage levels and pre-calculated averages, the last value is representative
        aggregation_rules[col] = 'last'
    else:
        # For flows (production, demand) and weather, a weekly sum is best
        aggregation_rules[col] = 'sum'

# Resample to weekly, ending on Friday to align with EIA reports
df_features_weekly = df_features_daily.resample('W-FRI').agg(aggregation_rules)


# --- 4. Merge Data and Engineer Weekly Features ---
print("\nStep 4: Merging data and engineering weekly/seasonal features...")

# Merge aggregated features with the weekly target data
df_merged = pd.merge(df_features_weekly, df_target_weekly, left_index=True, right_index=True, how='inner')

# Create lag features to capture trends and seasonality
df_merged['East_Lag_1_Week'] = df_merged['Pacific'].shift(1) # Previous week's value
df_merged['East_Lag_2_Week'] = df_merged['Pacific'].shift(2) # Value from 2 weeks ago
df_merged['East_Lag_52_Week'] = df_merged['Pacific'].shift(52) # Value from 1 year ago for seasonality

# Create date-based features
df_merged['Week_of_Year'] = df_merged.index.isocalendar().week.astype(int)
df_merged['Month'] = df_merged.index.month

# Drop all rows with any NaN values (created by lags/rolling averages)
# This ensures the model trains on a complete, clean dataset
df_merged.dropna(inplace=True)


# --- 5. Define Final Features (X) and Target (y) ---
# The model will predict the CHANGE, not the absolute level.
y = df_merged['Delta_Change']
X = df_merged.drop(columns=['Pacific', 'Delta_Change'])


# --- 6. Walk-Forward Validation (Backtesting) ---
print("\nStep 6: Starting Walk-Forward Validation (Backtesting)...")

# Define the chronological split point for our backtest
start_date_test = '2024-01-01'
test_indices = X[X.index >= start_date_test].index

# Lists to store the results of our simulation
backtest_results = []

for current_date in test_indices:
    # Train on all data available BEFORE the current week
    X_train = X[X.index < current_date]
    y_train = y[y.index < current_date]
    
    # The "test" set is the single row for the current week we want to predict
    X_test_current = X.loc[[current_date]] # Use .loc to ensure it's a DataFrame
    
    # Get the actual values for this week for later comparison
    actual_delta = y.loc[current_date]
    actual_level = df_merged.loc[current_date, 'Pacific']
    last_week_level = df_merged.loc[current_date, 'East_Lag_1_Week']
    
    # Initialize and train the LightGBM model
    lgbm = lgb.LGBMRegressor(random_state=42, n_estimators=250, learning_rate=0.05, num_leaves=31, verbose=-1)
    lgbm.fit(X_train, y_train)

    # Predict the Delta_Change for the current week
    predicted_delta = lgbm.predict(X_test_current)[0]
    
    # Calculate the predicted storage level
    predicted_level = last_week_level + predicted_delta
    
    # Store all results for this week
    backtest_results.append({
        'Date': current_date.date(),
        'Actual_Level': actual_level,
        'Predicted_Level': predicted_level,
        'Error': actual_level - predicted_level,
        'Actual_Delta': actual_delta,
        'Predicted_Delta': predicted_delta
    })

# --- 7. Analyze Backtest Results ---
print("\nStep 7: Analyzing backtest results...")

results_df = pd.DataFrame(backtest_results).set_index('Date')

# Calculate final performance metrics based on the predicted LEVEL
final_mae = results_df['Error'].abs().mean()
final_r2 = r2_score(results_df['Actual_Level'], results_df['Predicted_Level'])

print("\n--- Backtest Performance Summary ---")
print(f"Mean Absolute Error (MAE) on Storage Level: {final_mae:.2f} BCF")
print(f"R-squared: {final_r2:.2f}")

print("\nWeekly Backtest Results (Level & Delta):")
print(results_df.round(2))

# Plot the backtest results for visualization
results_df[['Actual_Level', 'Predicted_Level']].plot(figsize=(15, 7), marker='o', linestyle='-')
plt.title('Backtest Results: Actual vs. Predicted EIA Storage Level')
plt.xlabel('Date')
plt.ylabel('Storage (BCF)')
plt.legend()
plt.grid(True)
# plt.show()

# --- 8. Train Final Model and Predict NEXT Week ---
print("\nStep 8: Training final model on all data to predict the upcoming week...")

# Train the model one last time on the ENTIRE dataset
lgbm_final = lgb.LGBMRegressor(random_state=42, n_estimators=250, learning_rate=0.05, num_leaves=31, verbose=-1)
lgbm_final.fit(X, y)

# Get the features from the most recent week in our data
last_known_features = X.iloc[[-1]]
last_actual_level = df_merged['Pacific'].iloc[-1]

# Predict the delta for the upcoming week
next_delta_prediction = lgbm_final.predict(last_known_features)[0]

# Calculate the final storage level prediction
next_level_prediction = last_actual_level + next_delta_prediction

print("\n-----------------------------------------------------------------")
print(f"Analysis based on data up to: {X.index.max().date()}")
print(f"Last known actual storage level: {last_actual_level} BCF")
print(f"Model predicts a change (delta) of: {next_delta_prediction:.2f} BCF")
print("-----------------------------------------------------------------")
print(f"Predicted EIA East storage for next week: {next_level_prediction:.2f} BCF")
print("-----------------------------------------------------------------")

# --- 9. (NEW) Update the Long-Term Forecast File with the Newest Prediction ---
print("\nStep 9: Updating the long-term forecast file with this week's prediction...")

# Define the path to the long-term forecast file
long_term_forecast_path = r'D:\EIA_STACK\granular_storage\pacific_long_term_seasonal_forecast.csv'

try:
    # Read the existing long-term forecast CSV file
    df_long_term = pd.read_csv(long_term_forecast_path, index_col='Forecast_Date')

    # Check if the DataFrame is not empty
    if not df_long_term.empty:
        # Get the label for the first row (the first date)
        first_row_index = df_long_term.index[0]

        # --- UPDATE BOTH VALUES USING .loc ---
        # Update the delta for the first week with the new, more accurate prediction
        df_long_term.loc[first_row_index, 'Predicted_Delta'] = next_delta_prediction
        
        # Update the storage level for the first week as well
        df_long_term.loc[first_row_index, 'Projected_Storage_Level'] = next_level_prediction
        
        # Save the updated DataFrame back to the same CSV file
        df_long_term.to_csv(long_term_forecast_path)
        
        print(f"\nSuccessfully updated the first entry in '{long_term_forecast_path}'")
        # Read the newly saved values for confirmation
        print(f"New first week's predicted delta: {df_long_term.iloc[0]['Predicted_Delta']:.2f}")
        print(f"New first week's projected level: {df_long_term.iloc[0]['Projected_Storage_Level']:.2f}")
    else:
        print("\nWarning: The long-term forecast file is empty. No values were updated.")

except FileNotFoundError:
    print(f"\nError: Could not find the long-term forecast file at '{long_term_forecast_path}'.")
    print("Please ensure the first script has been run successfully to generate this file.")
except Exception as e:
    print(f"\nAn unexpected error occurred: {e}")