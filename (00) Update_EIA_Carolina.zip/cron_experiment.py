import os
import subprocess
import time
import sys
from datetime import datetime

# --- Configuration ---
# Set the working directory
BASE_DIR = r"C:\EIA"

# --- Logger Setup ---
# A class to redirect stdout to both the console and a log file.
class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log_file = open(filename, 'a', encoding='utf-8')

    def write(self, message):
        self.terminal.write(message)
        self.log_file.write(message)
        self.flush() # Force flush after every write

    def flush(self):
        # This flush method is needed for compatibility.
        self.terminal.flush()
        self.log_file.flush()

    def close(self):
        self.log_file.close()

# Generate log filename based on the current date
log_filename = f"{datetime.now().strftime('%Y-%m-%d')}.log"

# Redirect stdout and stderr
# All print statements and subprocess output will now go through the Logger.
sys.stdout = Logger(log_filename)
sys.stderr = sys.stdout

print(f"--- Script started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ---")
print(f"--- All output is being logged to: {os.path.join(os.getcwd(), log_filename)} ---")


def set_working_directory():
    try:
        os.chdir(BASE_DIR)
        print(f"Working directory set to: {os.getcwd()}")
        return True
    except FileNotFoundError:
        print(f"Error: Directory '{BASE_DIR}' not found. Exiting.")
        return False
    except Exception as e:
        print(f"Error setting directory: {e}. Exiting.")
        return False

# List of scripts to run (your list here)
scripts = [

    "scripts/(0aa) COUNT.py",
    "scripts/(00) Delete.py",  
    "scripts/(0a) WSI_AESO.py",
    "scripts/(0b) WSI_AESO_Temp_DB.py",
    "scripts/(0c) WSI_AESO_Upload_tyler.py",  
    "scripts/(0d) Delete_Old_Aeco_Forecasts.py",




    "scripts/(00) Update_EIA_Interchange.py",
    "scripts/(00) Update_EIA_Load.py",
    "scripts/(00) Update_EIA_California.py",
    "scripts/(00) Update_EIA_Carolina.py",
    "scripts/(00) Update_EIA_Central.py",
    "scripts/(00) Update_EIA_Florida.py",
    "scripts/(00) Update_EIA_Midatlantic.py",
    "scripts/(00) Update_EIA_Midwest.py",
    "scripts/(00) Update_EIA_Newengland.py",
    "scripts/(00) Update_EIA_Newyork.py",
    "scripts/(00) Update_EIA_Northwest.py",
    "scripts/(00) Update_EIA_Southeast.py",
    "scripts/(00) Update_EIA_Southwest.py",
    "scripts/(00) Update_EIA_Tennessee.py",
    "scripts/(00) Update_EIA_Texas.py",

    "scripts/(1) fetch_weather_regions.py",
    "scripts/(2) merge_weather_data.py",
    "scripts/(3) generate_analogous_forecast.py",
    "scripts/(4) trim_weather_data.py",
    "scripts/(5) merge_load_weather.py",
    "scripts/(6) fetch_energy_data.py",
    "scripts/(7) merge_eia_data.py",
    "scripts/(8) fetch_capability_data.py",
    "scripts/(9) merge_capacity_data.py",
    "scripts/California/(10) California_Specific_Control.py",
    "scripts/California/(11) California_Specific_Control_Extra_Line.py",
    "scripts/California/(12) California_Interchange.py",
    "scripts/California/(13) California_Data_Wrangling.py",
    "scripts/California/(14) California_add_capacity_ratios.py",
    "scripts/California/(15) California_final_trim.py",


    "scripts/Carolina/(10) Carolina_Specific_Control.py",
    "scripts/Carolina/(11) Carolina_Specific_Control_Extra_Line.py",
    "scripts/Carolina/(12) Carolina_Interchange.py",
    "scripts/Carolina/(13) Carolina_Data_Wrangling.py",
    "scripts/Carolina/(14) Carolina_add_capacity_ratios.py",
    "scripts/Carolina/(15) Carolina_final_trim.py",


    "scripts/Central/(10) Central_Specific_Control.py",
    "scripts/Central/(11) Central_Specific_Control_Extra_Line.py",
    "scripts/Central/(12) Central_Interchange.py",
    "scripts/Central/(13) Central_Data_Wrangling.py",
    "scripts/Central/(14) Central_add_capacity_ratios.py",
    "scripts/Central/(15) Central_final_trim.py",

    "scripts/Florida/(10) Florida_Specific_Control.py",
    "scripts/Florida/(11) Florida_Specific_Control_Extra_Line.py",
    "scripts/Florida/(12) Florida_Interchange.py",
    "scripts/Florida/(13) Florida_Data_Wrangling.py",
    "scripts/Florida/(14) Florida_add_capacity_ratios.py",
    "scripts/Florida/(15) Florida_final_trim.py",

    "scripts/Midatlantic/(10) Midatlantic_Specific_Control.py",
    "scripts/Midatlantic/(11) Midatlantic_Specific_Control_Extra_Line.py",
    "scripts/Midatlantic/(12) Midatlantic_Interchange.py",
    "scripts/Midatlantic/(13) Midatlantic_Data_Wrangling.py",
    "scripts/Midatlantic/(14) Midatlantic_add_capacity_ratios.py",
    "scripts/Midatlantic/(15) Midatlantic_final_trim.py",


    "scripts/Midwest/(10) Midwest_Specific_Control.py",
    "scripts/Midwest/(11) Midwest_Specific_Control_Extra_Line.py",
    "scripts/Midwest/(12) Midwest_Interchange.py",
    "scripts/Midwest/(13) Midwest_Data_Wrangling.py",
    "scripts/Midwest/(14) Midwest_add_capacity_ratios.py",
    "scripts/Midwest/(15) Midwest_final_trim.py",

    
    "scripts/Northwest/(10) Northwest_Specific_Control.py",
    "scripts/Northwest/(11) Northwest_Specific_Control_Extra_Line.py",
    "scripts/Northwest/(12) Northwest_Interchange.py",
    "scripts/Northwest/(13) Northwest_Data_Wrangling.py",
    "scripts/Northwest/(14) Northwest_add_capacity_ratios.py",
    "scripts/Northwest/(15) Northwest_final_trim.py",  

    "scripts/Newyork/(10) Newyork_Specific_Control.py",
    "scripts/Newyork/(11) Newyork_Specific_Control_Extra_Line.py",
    "scripts/Newyork/(12) Newyork_Interchange.py",
    "scripts/Newyork/(13) Newyork_Data_Wrangling.py",
    "scripts/Newyork/(14) Newyork_add_capacity_ratios.py",
    "scripts/Newyork/(15) Newyork_final_trim.py",   



    "scripts/Newengland/(10) Newengland_Specific_Control.py",
    "scripts/Newengland/(11) Newengland_Specific_Control_Extra_Line.py",
    "scripts/Newengland/(12) Newengland_Interchange.py",
    "scripts/Newengland/(13) Newengland_Data_Wrangling.py",
    "scripts/Newengland/(14) Newengland_add_capacity_ratios.py",
    "scripts/Newengland/(15) Newengland_final_trim.py",  



    "scripts/Southwest/(10) Southwest_Specific_Control.py",
    "scripts/Southwest/(11) Southwest_Specific_Control_Extra_Line.py",
    "scripts/Southwest/(12) Southwest_Interchange.py",
    "scripts/Southwest/(13) Southwest_Data_Wrangling.py",
    "scripts/Southwest/(14) Southwest_add_capacity_ratios.py",
    "scripts/Southwest/(15) Southwest_final_trim.py",
    

    "scripts/Southeast/(10) Southeast_Specific_Control.py",
    "scripts/Southeast/(11) Southeast_Specific_Control_Extra_Line.py",
    "scripts/Southeast/(12) Southeast_Interchange.py",
    "scripts/Southeast/(13) Southeast_Data_Wrangling.py",
    "scripts/Southeast/(14) Southeast_add_capacity_ratios.py",
    "scripts/Southeast/(15) Southeast_final_trim.py",





    
    "scripts/Tennessee/(10) Tennessee_Specific_Control.py",
    "scripts/Tennessee/(11) Tennessee_Specific_Control_Extra_Line.py",
    "scripts/Tennessee/(12) Tennessee_Interchange.py",
    "scripts/Tennessee/(13) Tennessee_Data_Wrangling.py",
    "scripts/Tennessee/(14) Tennessee_add_capacity_ratios.py",
    "scripts/Tennessee/(15) Tennessee_final_trim.py",  
    "scripts/Texas/(10) Texas_Specific_Control.py",
    "scripts/Texas/(11) Texas_Specific_Control_Extra_Line.py",
    "scripts/Texas/(12) Texas_Interchange.py",
    "scripts/Texas/(13) Texas_Data_Wrangling.py",
    "scripts/Texas/(14) Texas_add_capacity_ratios.py",
    "scripts/Texas/(15) Texas_final_trim.py",  

    "scripts/(16) Final_trim.py",  
    "scripts/(17) split_data.py",
    "scripts/(18a) Duplicate_Extraneous_Columns.py",
    "scripts/(18) Remove_Extraneous_Columns.py",    


    # "utility_scripts/SHAP_California.py",
    # "utility_scripts/SHAP_Carolina.py",
    # "utility_scripts/SHAP_Central.py",
    # "utility_scripts/SHAP_Florida.py",
    # "utility_scripts/SHAP_Midatlantic.py",
    # "utility_scripts/SHAP_Midwest.py",
    # "utility_scripts/SHAP_Newyork.py",
    # "utility_scripts/SHAP_Newengland.py",
    # "utility_scripts/SHAP_Northwest.py",
    # "utility_scripts/SHAP_Southwest.py",
    # "utility_scripts/SHAP_Southeast.py",
    # "utility_scripts/SHAP_Tennessee.py",
    # "utility_scripts/SHAP_Texas.py",


    "scripts/(19) XG_Boost_Load_Decile_Regions.py",
    "scripts/(20) Run_Classifier_Load.py",
    "scripts/(21) XG_Boost_Solar_Decile_Regions.py",
    "scripts/(22) Run_Classifier_Solar.py",
    "scripts/(23) XG_Boost_Wind_Decile_Regions.py",
    "scripts/(24) Run_Classifier_Wind.py",

    "scripts/(25) XG_Boost_Battery_Decile_Regions.py",
    "scripts/(26) Run_Classifier_Battery.py",

    "scripts/(27) XG_Boost_Pumped_Storage_Decile_Regions.py",
    "scripts/(28) Run_Classifier_Pumped_Storage.py",

    "scripts/(29) XG_Boost_Interchange_Decile_Regions.py",
    "scripts/(30) Run_Classifier_Interchange.py",
    "scripts/(30) merge_queries.py",
    "scripts/(31) Nuclear.py",
    "scripts/(32) Nuclear_Replace.py",
    "scripts/(33) Nuclear_Multiply_95.py",
    
    "scripts/(34) XG_Boost_Other_Decile_Regions.py",
    "scripts/(35) Run_Classifier_Other.py",

    "scripts/(36) XG_Boost_Hydro_Decile_Regions.py",


    "scripts/(37) Run_Classifier_Hydro.py",

    "scripts/(38) XG_Boost_Coal_Decile_Regions.py",
    "scripts/(39) Run_Classifier_Coal.py",
    "scripts/(40) XG_Boost_Gas_Decile_Regions.py",
    "scripts/(41) Run_Classifier_Gas.py",
    "scripts/NHITS_LOAD/(35) Nhits_Load_Northwest.py",
    "scripts/NHITS_LOAD/(36) Nhits_Load_Newengland.py",
    "scripts/NHITS_LOAD/(38) Nhits_Load_Southwest.py",
    "scripts/NHITS_LOAD/(39) Nhits_Load_Southeast.py",
    "scripts/NHITS_LOAD/(40) Nhits_Load_Tennessee.py",
    "scripts/NHITS_LOAD/(41) Nhits_Load_Texas.py",
    "scripts/NHITS_LOAD/(29) Nhits_Load_California.py",
    "scripts/NHITS_LOAD/(30) Nhits_Load_Carolina.py",
    "scripts/NHITS_LOAD/(31) Nhits_Load_Central.py",
    "scripts/NHITS_LOAD/(32) Nhits_Load_Florida.py",
    "scripts/NHITS_LOAD/(33) Nhits_Load_Midatlantic.py",
    "scripts/NHITS_LOAD/(34) Nhits_Load_Midwest.py",
    "scripts/NHITS_LOAD/(37) Nhits_Load_Newyork.py",
    "scripts/NHITS_SOLAR/(44) Nhits_Solar_California.py",
    "scripts/NHITS_SOLAR/(45) Nhits_Solar_Carolina.py",
    "scripts/NHITS_SOLAR/(47) Nhits_Solar_Central.py", # Note: Original had 47 then 46
    "scripts/NHITS_SOLAR/(48) Nhits_Solar_Midatlantic.py",
    "scripts/NHITS_SOLAR/(46) Nhits_Solar_Florida.py",
    "scripts/NHITS_SOLAR/(49) Nhits_Solar_Newengland.py",
    "scripts/NHITS_SOLAR/(50) Nhits_Solar_Northwest.py",
    "scripts/NHITS_SOLAR/(51) Nhits_Solar_Southwest.py",
    "scripts/NHITS_SOLAR/(52) Nhits_Solar_Southeast.py",
    "scripts/NHITS_SOLAR/(53) Nhits_Solar_Tennessee.py",
    "scripts/NHITS_SOLAR/(54) Nhits_Solar_Texas.py",
    "scripts/NHITS_SOLAR/(55) Nhits_Solar_Midwest.py",

    "scripts/NHITS_WIND/(58) Nhits_Wind_California.py",
    "scripts/NHITS_WIND/(59) Nhits_Wind_Central.py",
    "scripts/NHITS_WIND/(60) Nhits_Wind_Midatlantic.py",
    "scripts/NHITS_WIND/(61) Nhits_Wind_Midwest.py",
    "scripts/NHITS_WIND/(62) Nhits_Wind_Northwest.py",
    "scripts/NHITS_WIND/(63) Nhits_Wind_Newengland.py",
    "scripts/NHITS_WIND/(64) Nhits_Wind_Newyork.py",
    "scripts/NHITS_WIND/(65) Nhits_Wind_Southwest.py",
    "scripts/NHITS_WIND/(66) Nhits_Wind_Texas.py",


    "scripts/NHITS_OTHER/Nhits_Other_Carolina.py",
    "scripts/NHITS_OTHER/Nhits_Other_California.py",
    "scripts/NHITS_OTHER/Nhits_Other_Newengland.py",
    "scripts/NHITS_OTHER/Nhits_Other_Central.py",
    "scripts/NHITS_OTHER/Nhits_Other_Southwest.py",
    "scripts/NHITS_OTHER/Nhits_Other_Florida.py",
    "scripts/NHITS_OTHER/Nhits_Other_Newyork.py",
    "scripts/NHITS_OTHER/Nhits_Other_Southeast.py",
    "scripts/NHITS_OTHER/Nhits_Other_Midwest.py",
    "scripts/NHITS_OTHER/Nhits_Other_Tennessee.py",
    "scripts/NHITS_OTHER/Nhits_Other_Midatlantic.py",
    "scripts/NHITS_OTHER/Nhits_Other_Northwest.py",
    "scripts/NHITS_OTHER/Nhits_Other_Texas.py",




    
    "scripts/NHITS_HYDRO/Nhits_Hydro_California.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Carolina.py",

    "scripts/NHITS_HYDRO/Nhits_Hydro_Newengland.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Central.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Southwest.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Florida.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Newyork.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Southeast.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Midwest.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Tennessee.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Midatlantic.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Northwest.py",
    "scripts/NHITS_HYDRO/Nhits_Hydro_Texas.py",
    "scripts/NHITS_COAL/(106) Nhits_Coal_California.py",
    "scripts/NHITS_COAL/(107) Nhits_Coal_Tennessee.py",
    "scripts/NHITS_COAL/(108) Nhits_Coal_Midwest.py",
    "scripts/NHITS_COAL/(109) Nhits_Coal_Midatlantic.py",
    "scripts/NHITS_COAL/(110) Nhits_Coal_Northwest.py",
    "scripts/NHITS_COAL/(111) Nhits_Coal_Florida.py",
    "scripts/NHITS_COAL/(112) Nhits_Coal_Central.py",
    "scripts/NHITS_COAL/(113) Nhits_Coal_Texas.py",
    "scripts/NHITS_COAL/(114) Nhits_Coal_Southeast.py",
    "scripts/NHITS_COAL/(115) Nhits_Coal_Southwest.py",
    "scripts/NHITS_COAL/(116) Nhits_Coal_Newengland.py",
    "scripts/NHITS_COAL/(117) Nhits_Coal_Newyork.py",
    "scripts/NHITS_COAL/(118) Nhits_Coal_Carolina.py",




    "scripts/NHITS_GAS/(106) Nhits_Gas_California.py",
    "scripts/NHITS_GAS/(107) Nhits_Gas_Tennessee.py",
    "scripts/NHITS_GAS/(108) Nhits_Gas_Midwest.py",
    "scripts/NHITS_GAS/(109) Nhits_Gas_Midatlantic.py",
    "scripts/NHITS_GAS/(110) Nhits_Gas_Northwest.py",
    "scripts/NHITS_GAS/(111) Nhits_Gas_Florida.py",
    "scripts/NHITS_GAS/(112) Nhits_Gas_Central.py",
    "scripts/NHITS_GAS/(113) Nhits_Gas_Texas.py",
    "scripts/NHITS_GAS/(114) Nhits_Gas_Southeast.py",
    "scripts/NHITS_GAS/(115) Nhits_Gas_Southwest.py",
    "scripts/NHITS_GAS/(116) Nhits_Gas_Newengland.py",
    "scripts/NHITS_GAS/(117) Nhits_Gas_Newyork.py",
    "scripts/NHITS_GAS/(118) Nhits_Gas_Carolina.py",

    "scripts/(42) Check_prediction_files.py",
    "scripts/(43) Create_Nhits.py",
    "scripts/(44) Ratio_MW_Convert.py",
    "scripts/(45) Combine_CSV.py",
    "scripts/(46) Change_to_CSV_Power_Burns.py",
    "scripts/(47) EIA_Power_Gas_Burns.py",
    "scripts/(48a) NHITS_Gas_Burn_Prep.py",
    "scripts/(48b) NHITS_Gas_Burn.py",

    "scripts/(48c) NHITS_Gas_Burn_daily.py",
    "scripts/(48d) NHITS_Upload_MW.py",
    # "scripts/(133) Power_Burns_Hourly_to_Daily.py",
    # "scripts/(134) Daily_to_combined_power_burns.py",
    "scripts/NHITS_REGIONAL_GAS_DISSEMINATION/(48a) NHITS_Gas_Burn_Prep_regional.py",
    "scripts/NHITS_REGIONAL_GAS_DISSEMINATION/(48aa) NHITS_Gas_Burn_Prep_II.py",   
    "scripts/NHITS_REGIONAL_GAS_DISSEMINATION/(48aaa) NHITS_Gas_Burn_Prep_III_NHITS.py",
    "scripts/NHITS_REGIONAL_GAS_DISSEMINATION/(48aaaa) NHITS_Gas_Burn_Prep_IV_Aggregate.py",

    "scripts/(135) Upload_MMCF_Power_Burns.py",
    "scripts/(135) Upload_MMCF_Power_Burns_Regional.py",



    "scripts/(147) Pipeline_Losses_EIA_Pull.py",
    "scripts/(148) EIA_Stats.py",
    "scripts/(149) Lease_Plant_EIA_Pull.py",
    "scripts/(150) res_com_ind_pull.py",
    "scripts/(151) pull_EIA.py",
    "scripts/(152) Create_EIA_Files.py",
    "scripts/(153) Train_Predict.py",
    "scripts/(154) HYBRID_COMMERCIAL_INDUSTRIAL.py",
    "scripts/(154) HYBRID_RESIDENTIAL.py",

    "scripts/(155) NHITS_IND_RES_COMM_AGGREGATION.py",
    "scripts/(156) Pull_MEX_CAD_LNG.py",
    "scripts/(157) Upload_Regional_IND_COM_RES.py",
    "scripts/(159) EIA_Storage_API.py",
    "scripts/(160) EIA_Storage_API_DB.py",

    "scripts/(161) EAST_STORAGE_PULL.py",
    "scripts/(162) EAST_STORAGE_AGGREGATE.py",
    "scripts/(163) MIDWEST_STORAGE_PULL.py",
    "scripts/(164) MIDWEST_STORAGE_AGGREGATE.py",
    "scripts/(167) MOUNTAIN_STORAGE_PULL.py",
    "scripts/(166) MOUNTAIN_STORAGE_AGGREGATE.py",
    "scripts/(170) PACIFIC_STORAGE_PULL.py",
    "scripts/(169) PACIFIC_STORAGE_AGGREGATE.py",
    "scripts/(171) SOUTHCENTRAL_STORAGE_PULL.py",
    "scripts/(172) SOUTHCENTRAL_STORAGE_AGGREGATE.py",
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/(173) Weather_WSI.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/(174) Residential_Commercial_Industrial_Move.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/(175) Storage_Move.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/(176) Power_Burns_Move.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/(177) Synmax_State_Supply.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/(178) Storage_Mechanics.py", 

    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/EAST/(179) East.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/EAST/(180) East_Janitor.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/EAST/(181) GPM_Last_Week_EAST_Forward_Seasonality.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/EAST/(182) GPM_Last_Week_EAST.py", 

    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MIDWEST/(186) Midwest.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MIDWEST/(187) Midwest_Janitor.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MIDWEST/(188) GPM_Last_Week_WEST_Forward_Seasonality.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MIDWEST/(189) GPM_Last_Week_EAST.py", 


    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL/(186) SOUTHCENTRAL.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL/(187) Southcentral_Janitor.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL/(188) GPM_Last_Week_WEST_Forward_Seasonality.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL/(189) GPM_Last_Week_EAST.py", 

    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL_SALTS/(186) SOUTHCENTRAL.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL_SALTS/(187) Southcentral_Janitor.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL_SALTS/(188) GPM_Last_Week_WEST_Forward_Seasonality.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/SOUTHCENTRAL_SALTS/(189) GPM_Last_Week_EAST.py", 

    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MOUNTAIN/(190) Mountain.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MOUNTAIN/(191) Mountain_Janitor.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MOUNTAIN/(192) MOUNTAIN_LONG_LOOK.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/MOUNTAIN/(193) One_Week_Mountain.py",

    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/PACIFIC/(179) Pacific.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/PACIFIC/(180) East_Janitor.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/PACIFIC/(181) GPM_Last_Week_EAST_Forward_Seasonality.py", 
    "scripts/STORAGE_IMPLIED_PIPE_MODELLING/PACIFIC/(182) GPM_Last_Week_EAST.py",

    "scripts/(188) download.py",
    "scripts/(188a) Download.py",
    "scripts/(188b) Download.py",
    "scripts/(188c) Download.py",
    "scripts/(188d) Download.py",
    "scripts/(188e) Effort.py",
    "scripts/(188f) Effort.py",
    "scripts/(188g) Effort.py",
    "scripts/(188h) Effort.py",
    "scripts/(188ha) Effort_additional.py",

    "scripts/(188i) Effort_Storage_Regional.py",
    "scripts/(188j) Effort_Storage_Additional_Mechanics.py",
    "scripts/(188k) Effort_Create_Aggregate_File.py",



    "scripts/(189a) Regional_Data_Analysis_PACIFIC.py",
    "scripts/(189b) Regional_Data_Analysis_PACIFIC_MOVE.py",
    "scripts/(189c) Regional_Data_Analysis_PACIFIC_HTML.py",

    "scripts/(190a) Regional_Data_Analysis_EAST.py",

    "scripts/(190b) Regional_Data_Analysis_EAST_MOVE.py",

    "scripts/(191a) Regional_Data_Analysis_MIDWEST.py",
    "scripts/(191b) Regional_Data_Analysis_MIDWEST_MOVE.py",

    "scripts/(192a) Regional_Data_Analysis_MOUNTAIN.py",
    "scripts/(192b) Regional_Data_Analysis_MOUNTAIN_MOVE.py",





    "scripts/(193a) Regional_Data_Analysis_SC_SALTS.py",
    "scripts/(193b) Regional_Data_Analysis_SC_SALTS_MOVE.py",

    "scripts/(194a) Regional_Data_Analysis_NONSALTS.py",
    "scripts/(194b) Regional_Data_Analysis_NONSALTS_MOVE.py",

    "scripts/(195) Pull_Henry_Hub_Price.py",
    "scripts/(196) Combine_Storage_Pipe_Implied.py",
    
    "scripts/(199) HTML_Comp_Good_Copy.py",
    # "scripts/(200) to_email.py",

    "scripts/(201) move_historical_files.py",
    "scripts/(202) Delete_Historical_Tables.py",





    "scripts/(298) HTML_Power_Forecast.py",
    "scripts/(299) HTML_Power_Burns.py",
    "scripts/(300) HTML_Capacities.py",
    "scripts/(301) HTML_EIA_Actuals.py",
    "scripts/(302) HTML_ResComm_Ind.py",
    "scripts/(303) HTML_Pipe_Loss_Lease.py",
    "scripts/(304) HTML_LNG_MEX.py",
    "scripts/(305) HTML_Historical_Weather.py",
    "scripts/(306) HTML_Future_Weather.py",
    "scripts/(307) Synmax_Production.py",
    "scripts/(308) Cleanup.py",
    "scripts/(309) Cleanup_EIA.py",
    "scripts/(310) Cleanup_Historical_Burns.py",


    "scripts/(311) Cleanup_Weather.py",
    "scripts/(312) Cleanup_Pipelease_LeaseLoss.py",
    "scripts/(313) Cleanup_Supply_Demand_LNGMEX.py",
    "scripts/(314) Cleanup_Synmax.py",
    "scripts/(315) Conus_Weather.py",
    "scripts/(316) Master_HTML.py",
    "scripts/(317) to_email.py"
]

# Main continuous loop wrapped in a try/finally to ensure the log file is closed.
try:
    while True:
        # Ensure we're in the correct directory at the start of each iteration
        if not set_working_directory():
            # If directory can't be set, we should exit.
            # The error is already logged by the function.
            break
        
        # Run each script
        print("==================== Starting Pipeline Execution ====================")
        print("Attempting to run all scripts in sequence...")

        failed_scripts = []
        successful_scripts = []

        for i, script_path in enumerate(scripts, 1):
            print(f"\n[{i}/{len(scripts)}] Attempting to run {script_path}...")
            try:
                # capture_output=False means the script's output will inherit the parent's stdout/stderr,
                # which we have redirected to our Logger.
                # check=False prevents it from raising an exception on non-zero exit codes.
                process = subprocess.run(f"python -u \"{script_path}\"", shell=True, check=False, capture_output=False, text=True)
                
                if process.returncode == 0:
                    print(f"--- Successfully completed: {script_path} ---")
                    successful_scripts.append(script_path)
                else:
                    print(f"--- !!! ERROR executing script: {script_path} !!! ---")
                    print(f"--- Return code: {process.returncode} ---")
                    failed_scripts.append({"script": script_path, "return_code": process.returncode})
                    print(f"--- Continuing to the next script. ---")
                    
            except Exception as e:
                print(f"--- !!! CRITICAL ERROR launching script: {script_path} !!! ---")
                print(f"--- Python exception: {e} ---")
                failed_scripts.append({"script": script_path, "return_code": "N/A - Launch Error", "exception": str(e)})
                print(f"--- Continuing to the next script. ---")

            # --- Pause after each script to ensure logs are written ---
            print("--- Pausing for 2 seconds... ---")
            sys.stdout.flush()  # Explicitly flush all buffered output to the file
            time.sleep(2)


        print("\n==================== Pipeline Execution Finished ====================")

        if successful_scripts:
            print(f"\nSuccessfully executed {len(successful_scripts)} script(s).")
        else:
            print("\nNo scripts were executed successfully.")

        if failed_scripts:
            print(f"\nEncountered errors in {len(failed_scripts)} script(s):")
            for f_script_info in failed_scripts:
                print(f"  - Script: {f_script_info['script']}, Return Code: {f_script_info['return_code']}")
                if "exception" in f_script_info:
                     print(f"    Launch Exception: {f_script_info['exception']}")
            print("\nPlease review the output above for specific error messages from these scripts.")
        else:
            print("\nAll listed scripts were attempted and reported success (or no launch errors occurred).")
        
        print("\n==================== Cycle Complete - Starting Next Iteration ====================")
        print("Press Ctrl+C to stop the continuous loop")
        time.sleep(5)  # Brief pause between cycles

except KeyboardInterrupt:
    print("\n--- Ctrl+C detected. Shutting down the script runner. ---")
finally:
    # This block will run whether the script exits normally or via an exception.
    if 'sys' in globals() and isinstance(sys.stdout, Logger):
        print(f"--- Stopping logger and closing log file: {log_filename} ---")
        sys.stdout.close()
        # Restore original stdout
        sys.stdout = sys.stdout.terminal