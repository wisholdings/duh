import pandas as pd
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import numpy as np
import warnings

# Suppress common pandas warnings for cleaner output
warnings.filterwarnings('ignore', category=FutureWarning)

# --- 1. Load and Prepare Data ---
print("Step 1: Loading and preparing data...")

# UPDATED: Define file paths for the Southcentral region
features_path = r'D:\EIA_STACK\Pricing_RL\SOUTHCENTRAL_SALTS\SOUTHCENTRAL_SALTS_filtered.csv'
target_path = r'D:\EIA_STACK\granular_storage\south_central_salt_region.csv'

# Load daily features and weekly target
try:
    df_features_daily = pd.read_csv(features_path)
    df_target_weekly = pd.read_csv(target_path)
except FileNotFoundError as e:
    print(f"Error: Could not find a file. Please check your paths.\nDetails: {e}")
    exit()

# Convert date columns to datetime objects
df_features_daily['date'] = pd.to_datetime(df_features_daily['date'])
df_target_weekly['datetime'] = pd.to_datetime(df_target_weekly['datetime'])

# Set date as the index for time-series operations
df_features_daily.set_index('date', inplace=True)
df_target_weekly.set_index('datetime', inplace=True)


# --- 2. Advanced Feature Engineering (Daily) ---
print("\nStep 2: Engineering rolling features on daily data...")

# UPDATED: Create rolling averages for Southcentral-specific columns
df_features_daily['synmax_7day_avg'] = df_features_daily['synmaxproductio_DRY_GAS_BCF_DAY'].rolling(window=7).mean()


# --- 3. Aggregate Daily Data to Weekly ---
print("\nStep 3: Aggregating daily data to a weekly cadence...")

# UPDATED: Define more generic aggregation rules to work for any region
aggregation_rules = {}
for col in df_features_daily.columns:
    if '_BCF' in col or '_avg' in col:
        # For storage levels and pre-calculated averages, the last value is representative
        aggregation_rules[col] = 'last'
    else:
        # For flows (production, demand) and weather, a weekly sum is best
        aggregation_rules[col] = 'sum'

# Resample to weekly, ending on Friday to align with EIA reports
df_features_weekly = df_features_daily.resample('W-FRI').agg(aggregation_rules)


# --- 4. Merge Data and Engineer Weekly Features ---
print("\nStep 4: Merging data and engineering weekly/seasonal features...")

# Merge aggregated features with the weekly target data
df_merged = pd.merge(df_features_weekly, df_target_weekly, left_index=True, right_index=True, how='inner')

# UPDATED: Create lag features for the 'Southcentral' column
df_merged['Southcentral_Lag_1_Week'] = df_merged['South Central Salt'].shift(1)
df_merged['Southcentral_Lag_2_Week'] = df_merged['South Central Salt'].shift(2)
df_merged['Southcentral_Lag_52_Week'] = df_merged['South Central Salt'].shift(52)

# Create date-based features
df_merged['Week_of_Year'] = df_merged.index.isocalendar().week.astype(int)
df_merged['Month'] = df_merged.index.month

# Drop all rows with any NaN values to ensure a clean dataset
df_merged.dropna(inplace=True)


# --- 5. Define Final Features (X) and Target (y) ---
y = df_merged['Delta_Change']
# UPDATED: Drop the 'Southcentral' column instead of 'East'
X = df_merged.drop(columns=['South Central Salt', 'Delta_Change'])


# --- 6. Walk-Forward Validation (Backtesting) ---
print("\nStep 6: Starting Walk-Forward Validation (Backtesting)...")

start_date_test = '2024-01-01'
test_indices = X[X.index >= start_date_test].index
backtest_results = []

for current_date in test_indices:
    X_train = X[X.index < current_date]
    y_train = y[y.index < current_date]
    X_test_current = X.loc[[current_date]]
    
    # UPDATED: Get actual values from the 'Southcentral' and 'Southcentral_Lag' columns
    actual_delta = y.loc[current_date]
    actual_level = df_merged.loc[current_date, 'South Central Salt']
    last_week_level = df_merged.loc[current_date, 'Southcentral_Lag_1_Week']
    
    lgbm = lgb.LGBMRegressor(random_state=42, n_estimators=250, learning_rate=0.05, num_leaves=31, verbose=-1)
    lgbm.fit(X_train, y_train)

    predicted_delta = lgbm.predict(X_test_current)[0]
    predicted_level = last_week_level + predicted_delta
    
    backtest_results.append({
        'Date': current_date.date(),
        'Actual_Level': actual_level,
        'Predicted_Level': predicted_level,
        'Error': actual_level - predicted_level,
        'Actual_Delta': actual_delta,
        'Predicted_Delta': predicted_delta
    })

# --- 7. Analyze Backtest Results ---
print("\nStep 7: Analyzing backtest results...")

results_df = pd.DataFrame(backtest_results).set_index('Date')
final_mae = results_df['Error'].abs().mean()
final_r2 = r2_score(results_df['Actual_Level'], results_df['Predicted_Level'])

print("\n--- Backtest Performance Summary ---")
print(f"Mean Absolute Error (MAE) on Storage Level: {final_mae:.2f} BCF")
print(f"R-squared: {final_r2:.2f}")

print("\nWeekly Backtest Results (Level & Delta):")
print(results_df.round(2))

# Plot the backtest results for visualization
results_df[['Actual_Level', 'Predicted_Level']].plot(figsize=(15, 7), marker='o', linestyle='-')
# UPDATED: Plot title is now for Southcentral
plt.title('Backtest Results: Actual vs. Predicted EIA Southcentral Storage Level')
plt.xlabel('Date')
plt.ylabel('Storage (BCF)')
plt.legend()
plt.grid(True)
# plt.show()

# --- 8. Train Final Model and Predict NEXT Week ---
print("\nStep 8: Training final model on all data to predict the upcoming week...")

lgbm_final = lgb.LGBMRegressor(random_state=42, n_estimators=500, learning_rate=0.005, num_leaves=31, verbose=-1)
lgbm_final.fit(X, y)

# Get the features from the most recent week in our data
last_known_features = X.iloc[[-1]]
# UPDATED: Get the last level from the 'Southcentral' column
last_actual_level = df_merged['South Central Salt'].iloc[-1]

next_delta_prediction = lgbm_final.predict(last_known_features)[0]
next_level_prediction = last_actual_level + next_delta_prediction

print("\n-----------------------------------------------------------------")
print(f"Analysis based on data up to: {X.index.max().date()}")
print(f"Last known actual storage level: {last_actual_level} BCF")
print(f"Model predicts a change (delta) of: {next_delta_prediction:.2f} BCF")
print("-----------------------------------------------------------------")
# UPDATED: Print statement now refers to Southcentral
print(f"Predicted EIA Southcentral storage for next week: {next_level_prediction:.2f} BCF")
print("-----------------------------------------------------------------")

# --- 9. Update the Long-Term Forecast File with the Newest Prediction ---
print("\nStep 9: Updating the long-term forecast file with this week's prediction...")

# UPDATED: Define the path to the Southcentral long-term forecast file
long_term_forecast_path = r'D:\EIA_STACK\granular_storage\southcentral_salt_long_term_seasonal_forecast.csv'

try:
    df_long_term = pd.read_csv(long_term_forecast_path, index_col='Forecast_Date')

    if not df_long_term.empty:
        first_row_index = df_long_term.index[0]

        # Update both the delta and the projected level using .loc to avoid warnings
        df_long_term.loc[first_row_index, 'Predicted_Delta'] = next_delta_prediction
        df_long_term.loc[first_row_index, 'Projected_Storage_Level'] = next_level_prediction
        
        df_long_term.to_csv(long_term_forecast_path)
        
        print(f"\nSuccessfully updated the first entry in '{long_term_forecast_path}'")
        print(f"New first week's predicted delta: {df_long_term.iloc[0]['Predicted_Delta']:.2f}")
        print(f"New first week's projected level: {df_long_term.iloc[0]['Projected_Storage_Level']:.2f}")
    else:
        print("\nWarning: The long-term forecast file is empty. No values were updated.")

except FileNotFoundError:
    print(f"\nError: Could not find the long-term forecast file at '{long_term_forecast_path}'.")
    print("Please ensure the first script has been run successfully to generate this file.")
except Exception as e:
    print(f"\nAn unexpected error occurred: {e}")