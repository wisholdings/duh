import os
import sys
import time
import traceback
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.preprocessing import LabelEncoder
import joblib
import warnings
import shutil
import re

# --- Suppress Warnings ---
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.utils.validation")

# --- Core Configuration ---
BASE_OUTPUT_DIR = r"D:\EIA_STACK"
REGIONS = [
    "california", "central","midatlantic", "midwest",
    "newengland", "northwest","southwest","texas"
]
FORCE_RETRAIN_ALL_MODELS = False # Set to True to retrain after updating quantile models

# =============================================================== #
# === PRIMARY SCRIPT SWITCH ===
TARGET_BASE_NAME = "WIND_RATIO"
# =============================================================== #

print(f"✅ Starting Consolidated Classifier & Final Output Generator for: {TARGET_BASE_NAME}")

# Solar ratio should be non-negative (0 to 1)
CLIP_MIN = 0.0
CLIP_MAX = 1.0

# --- Parquet Engine Setup ---
try:
    import pyarrow
    PARQUET_ENGINE = 'pyarrow'
except ImportError:
    PARQUET_ENGINE = 'auto'

# --- Quantile and Class Definitions ---
QUANTILE_CONFIG = {
    0.10: "q10", 0.20: "q20", 0.30: "q30", 0.40: "q40", 0.50: "median",
    0.60: "q60", 0.70: "q70", 0.80: "q80", 0.90: "q90", 0.99: "q99",
}
sorted_quantile_alphas = sorted(QUANTILE_CONFIG.keys())
sorted_quantile_names = [QUANTILE_CONFIG[alpha] for alpha in sorted_quantile_alphas]

DYNAMIC_CLASS_NAMES = {0: f"Below_{sorted_quantile_names[0].capitalize()}"}
for i in range(len(sorted_quantile_names) - 1):
    DYNAMIC_CLASS_NAMES[i+1] = f"{sorted_quantile_names[i].capitalize()}_to_{sorted_quantile_names[i+1].capitalize()}"
DYNAMIC_CLASS_NAMES[len(sorted_quantile_names)] = f"Above_{sorted_quantile_names[-1].capitalize()}"
DYNAMIC_NUM_CLASSES = len(DYNAMIC_CLASS_NAMES)

# --- XGBoost & File Naming ---
DATE_COL = "date"
CLASS_TARGET_COL = f"{TARGET_BASE_NAME.lower()}_quantile_class"
CLASSIFIER_XGB_PARAMS = {
    'objective': 'multi:softprob', 'eval_metric': 'mlogloss', 'random_state': 42, 'n_jobs': -1,
    'learning_rate': 0.08, 'max_depth': 12, 'n_estimators': 800, 'subsample': 0.8,
    'colsample_bytree': 0.8, 'reg_alpha': 0.1, 'reg_lambda': 0.1, 'min_child_weight': 4,
}

def get_target_column(df, region_name, target_base_name):
    """Finds the target column in a dataframe, checking for regional variations."""
    region_upper = region_name.upper()
    possible_names = [f"{region_upper}_{target_base_name}", f"{region_name}_{target_base_name}", 
                      f"{region_name.lower()}_{target_base_name}", target_base_name]
    for col_name in possible_names:
        if col_name in df.columns: return col_name
    target_cols = [col for col in df.columns if col.endswith(f'_{target_base_name}')]
    if target_cols: return target_cols[0]
    return None

def calculate_midpoint_selection(all_data, sorted_quantile_names, target_base_name, class_target_col):
    """Calculates an unbiased point forecast using the midpoint of the predicted quantile bin."""
    print(f"  🎯 Implementing unbiased midpoint selection for {target_base_name}...")
    sel_value_col = f"{target_base_name}_CLASSIFIER_SELECTED"
    all_data[sel_value_col] = np.nan
    for class_int in range(len(sorted_quantile_names) + 1):
        mask = (all_data[class_target_col] == class_int)
        if not mask.any(): continue
        if class_int == 0:
            col_to_select = f"{target_base_name}_{sorted_quantile_names[0]}"
            all_data.loc[mask, sel_value_col] = all_data.loc[mask, col_to_select]
        elif class_int == len(sorted_quantile_names):
            col_to_select = f"{target_base_name}_{sorted_quantile_names[-1]}"
            all_data.loc[mask, sel_value_col] = all_data.loc[mask, col_to_select]
        else:
            lower_q_name, upper_q_name = sorted_quantile_names[class_int - 1], sorted_quantile_names[class_int]
            lower_col, upper_col = f"{target_base_name}_{lower_q_name}", f"{target_base_name}_{upper_q_name}"
            midpoint_values = (all_data.loc[mask, lower_col] + all_data.loc[mask, upper_col]) / 2
            all_data.loc[mask, sel_value_col] = midpoint_values
    all_data[sel_value_col].fillna(0, inplace=True)
    all_data[sel_value_col] = np.clip(all_data[sel_value_col], CLIP_MIN, CLIP_MAX)
    print(f"  🛡️  Final {target_base_name} predictions clipped to [{CLIP_MIN}, {CLIP_MAX}] range")
    return sel_value_col

# --- Main Execution Script ---
if __name__ == "__main__":
    start_time = time.time()
    processed_regions, failed_regions = 0, []
    
    for region_name in REGIONS:
        region_upper = region_name.upper()
        print(f"\n===== Processing Region: {region_upper} for {TARGET_BASE_NAME} =====")
        try:
            # 1. SETUP DYNAMIC PATHS
            target_lower = TARGET_BASE_NAME.lower()
            source_subdir = f"{target_lower}_xgb"
            model_type_dir = f"xgboost_{target_lower.replace('_ratio', '')}rangeclassifier"
            region_dir = os.path.join(BASE_OUTPUT_DIR, region_name.lower())
            input_dir = os.path.join(region_dir, "final", source_subdir)
            model_dir = os.path.join(region_dir, "Models", model_type_dir)
            os.makedirs(model_dir, exist_ok=True)
            model_save_path = os.path.join(model_dir, "classifier_model.ubj")
            le_save_path = os.path.join(model_dir, "label_encoder.joblib")
            features_save_path = os.path.join(model_dir, "feature_list.joblib")
            class_mapping_save_path = os.path.join(model_dir, "class_mapping.joblib")

            # 2. LOAD & COMBINE DATA
            print("  Loading and merging quantile prediction files...")
            median_q_name = QUANTILE_CONFIG.get(0.50, "median")
            base_df_path = os.path.join(input_dir, f"{target_lower}_prediction_{median_q_name}.parquet")
            if not os.path.exists(base_df_path): 
                print(f"  Info: Base prediction file not found for {region_name}, skipping region.")
                continue
            
            all_data = pd.read_parquet(base_df_path, engine=PARQUET_ENGINE)
            all_data.rename(columns={TARGET_BASE_NAME: f"{TARGET_BASE_NAME}_{median_q_name}"}, inplace=True)
            for q_name in sorted_quantile_names:
                if q_name == median_q_name: continue
                q_path = os.path.join(input_dir, f"{target_lower}_prediction_{q_name}.parquet")
                if not os.path.exists(q_path): 
                    raise FileNotFoundError(f"Missing required quantile file: {q_path}")
                q_df = pd.read_parquet(q_path, engine=PARQUET_ENGINE)
                q_df.rename(columns={TARGET_BASE_NAME: f"{TARGET_BASE_NAME}_{q_name}"}, inplace=True)
                all_data = pd.merge(all_data, q_df, on=DATE_COL, how='inner')

            original_train_path = os.path.join(BASE_OUTPUT_DIR, region_name.lower(), 'final', 'train.parquet')
            df_original_train = pd.read_parquet(original_train_path, engine=PARQUET_ENGINE)
            actual_target_col = get_target_column(df_original_train, region_name, TARGET_BASE_NAME)
            if not actual_target_col: 
                print(f"  Info: Target column for '{TARGET_BASE_NAME}' not in train file, skipping region.")
                continue
            
            # 3. DEFINE EXPANDED FEATURE SET AND MERGE DATA
            print(f"  🎯 Using target column: {actual_target_col}")
            
            weather_features = [col for col in df_original_train.columns if re.match(r'^[A-Z]{4}_', col)]
            if weather_features:
                print(f"  🔍 Discovered {len(weather_features)} weather features (e.g., {weather_features[0]}).")
            
            cols_to_merge = [DATE_COL, actual_target_col] + weather_features
            all_data = pd.merge(all_data, df_original_train[cols_to_merge], on=DATE_COL, how='left')

            quantile_features = sorted([f"{TARGET_BASE_NAME}_{name}" for name in sorted_quantile_names])
            model_features = sorted(quantile_features + weather_features)
            print(f"  🧠 Classifier will use {len(model_features)} features in total.")

            # Assign classes based on quantile bins
            conditions = [all_data[actual_target_col] < all_data[quantile_features[0]]]
            for i in range(len(quantile_features) - 1):
                conditions.append((all_data[actual_target_col] >= all_data[quantile_features[i]]) & 
                                (all_data[actual_target_col] < all_data[quantile_features[i+1]]))
            conditions.append(all_data[actual_target_col] >= all_data[quantile_features[-1]])
            all_data[CLASS_TARGET_COL] = np.select(conditions, list(range(DYNAMIC_NUM_CLASSES)), default=np.nan)

            # 4. TRAIN OR LOAD THE CLASSIFIER
            if FORCE_RETRAIN_ALL_MODELS or not os.path.exists(model_save_path):
                print("  🔧 Training new classifier model...")
                df_train_cleaned = all_data.dropna(subset=[CLASS_TARGET_COL] + model_features)
                if df_train_cleaned.empty: 
                    raise ValueError("No valid training rows for classifier.")

                X_train = df_train_cleaned[model_features]
                y_train_raw = df_train_cleaned[CLASS_TARGET_COL].astype(int)
                
                # ### FIXED: Map sparse classes to continuous range for XGBoost ###
                # XGBoost requires classes to be 0, 1, 2, ..., n-1
                # If we have classes [0, 1, 2, 3, 4, 5, 6, 7, 8, 10], we need to map them to [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
                
                unique_classes_in_data = sorted(y_train_raw.unique())
                print(f"  📊 Training data contains classes: {unique_classes_in_data}")
                
                # Create mapping from original classes to continuous range
                class_to_continuous = {orig_class: cont_class for cont_class, orig_class in enumerate(unique_classes_in_data)}
                continuous_to_class = {cont_class: orig_class for orig_class, cont_class in class_to_continuous.items()}
                
                # Apply mapping to get continuous classes for XGBoost
                y_train_continuous = y_train_raw.map(class_to_continuous).values
                num_classes_in_data = len(unique_classes_in_data)
                
                print(f"  📊 Mapped to continuous range [0-{num_classes_in_data-1}] for XGBoost training")
                print(f"  📊 Training with {num_classes_in_data} unique classes using {len(model_features)} features.")
                
                # Set num_class to the actual number of unique classes in the data
                model_params = {**CLASSIFIER_XGB_PARAMS, 'num_class': num_classes_in_data}
                
                model = xgb.XGBClassifier(**model_params)
                model.fit(X_train, y_train_continuous, verbose=False)
                
                print("  💾 Saving model, class mapping, and feature list...")
                model.save_model(model_save_path)
                
                # Save the class mappings for prediction time
                joblib.dump({
                    'class_to_continuous': class_to_continuous,
                    'continuous_to_class': continuous_to_class,
                    'all_possible_classes': list(range(DYNAMIC_NUM_CLASSES))
                }, class_mapping_save_path)
                
                # Save a dummy label encoder for backward compatibility
                identity_encoder = LabelEncoder()
                identity_encoder.classes_ = np.array(unique_classes_in_data)
                joblib.dump(identity_encoder, le_save_path)
                joblib.dump(model_features, features_save_path)
                
            else:
                print("  ✅ Loading existing classifier model and artifacts...")
                model = xgb.XGBClassifier()
                model.load_model(model_save_path)
                
                # Load class mapping
                if os.path.exists(class_mapping_save_path):
                    class_mapping_data = joblib.load(class_mapping_save_path)
                    continuous_to_class = class_mapping_data['continuous_to_class']
                else:
                    # Fallback for backward compatibility
                    identity_encoder = joblib.load(le_save_path)
                    continuous_to_class = {i: c for i, c in enumerate(identity_encoder.classes_)}
                
                model_features = joblib.load(features_save_path)

            # 5. PREDICT FOR THE ENTIRE TIMELINE
            print("  Generating classifier predictions...")
            X_all = all_data[model_features].fillna(0)  # FillNa for any missing weather data
            y_pred_continuous = model.predict(X_all)
            
            # Map predictions back to original class labels
            y_pred_original = np.array([continuous_to_class.get(pred, pred) for pred in y_pred_continuous])
            
            all_data[f'{CLASS_TARGET_COL}_pred'] = y_pred_original
            all_data[CLASS_TARGET_COL] = all_data[CLASS_TARGET_COL].combine_first(all_data[f'{CLASS_TARGET_COL}_pred'])
            
            # 6. CALCULATE FINAL POINT FORECAST
            sel_value_col = calculate_midpoint_selection(all_data, sorted_quantile_names, TARGET_BASE_NAME, CLASS_TARGET_COL)
            
            # 7. INTEGRATE RESULTS AND SAVE
            print("  Updating final predict.parquet file...")
            predict_main_path = os.path.join(region_dir, "final", "predict.parquet")
            if not os.path.exists(predict_main_path): 
                print(f"    SKIPPING integration: Main predict.parquet not found.")
                continue

            df_predict_original = pd.read_parquet(predict_main_path, engine=PARQUET_ENGINE)
            df_predict_original[DATE_COL] = pd.to_datetime(df_predict_original[DATE_COL])
            max_train_date = pd.to_datetime(df_original_train[DATE_COL].max())
            new_predictions = all_data[all_data[DATE_COL] > max_train_date][[DATE_COL, sel_value_col]].copy()
            new_predictions.rename(columns={sel_value_col: actual_target_col}, inplace=True)
            df_predict_updated = df_predict_original.drop(columns=[actual_target_col], errors='ignore')
            df_predict_final = pd.merge(df_predict_updated, new_predictions, on=DATE_COL, how='left')
            
            # Create backup if it doesn't exist
            backup_path = predict_main_path.replace('.parquet', '_backup.parquet')
            if not os.path.exists(backup_path):
                shutil.copy2(predict_main_path, backup_path)
                print(f"    Created backup: {os.path.basename(backup_path)}")

            df_predict_final.to_parquet(predict_main_path, index=False, engine=PARQUET_ENGINE)
            print(f"  ✅ Successfully updated and saved final predict.parquet for {region_upper}.")
            processed_regions += 1

        except Exception as e:
            print(f"  ❌ ERROR processing {region_upper}: {e}")
            traceback.print_exc()
            failed_regions.append(f"{region_upper}_{TARGET_BASE_NAME}")

    # Final summary
    total_time = time.time() - start_time
    print("\n" + "="*60 + f"\nCLASSIFIER PROCESSING SUMMARY for {TARGET_BASE_NAME}\n" + "="*60)
    print(f"Successfully processed regions: {processed_regions}\nFailed regions: {len(failed_regions)}")
    if failed_regions:
        print(f"\nFailed regions:\n" + "\n".join([f"  - {r}" for r in failed_regions]))
        print(f"\nPipeline finished with errors in {total_time:.2f} seconds.")
        sys.exit(1)
    else:
        print(f"\n✅ All regions processed successfully!\nPipeline finished in {total_time:.2f} seconds.")
        sys.exit(0)