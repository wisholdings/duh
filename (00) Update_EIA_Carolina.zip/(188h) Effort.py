# =============================================================================
# IMPLIED STORAGE CALCULATION SCRIPT
# =============================================================================
import pandas as pd
import os
from datetime import datetime
import glob
import numpy as np

# --- CONFIGURATION ---
AGGREGATE_PATH = r"D:\EIA_STACK\Pricing_RL\AGGREGATE"

# =============================================================================
# MAIN FUNCTION
# =============================================================================
def calculate_implied_storage():
    """Calculate implied storage using rolling sum of storage_delta"""
    
    print("\n" + "=" * 80)
    print("IMPLIED STORAGE CALCULATION")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    print(f"Working directory: {AGGREGATE_PATH}")
    
    # Find the most recent L48 file
    print("\n" + "=" * 60)
    print("STEP 1: FINDING L48 FILE")
    print("=" * 60)
    
    pattern = os.path.join(AGGREGATE_PATH, "L48_*.csv")
    l48_files = glob.glob(pattern)
    
    if not l48_files:
        print(f"  ✗ No L48 files found in {AGGREGATE_PATH}")
        return False
    
    l48_files.sort()
    latest_file = l48_files[-1]
    filename = os.path.basename(latest_file)
    
    print(f"  ✓ Found file: {filename}")
    
    # Load the file
    print("\n" + "=" * 60)
    print("STEP 2: LOADING DATA")
    print("=" * 60)
    
    try:
        print(f"  Loading {filename}...")
        df = pd.read_csv(latest_file)
        print(f"  ✓ Loaded {len(df):,} records")
        
        # Check for required columns
        if 'Date' not in df.columns:
            print(f"  ✗ No 'Date' column found")
            return False
        
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date').reset_index(drop=True)
        print(f"  Date range: {df['Date'].min().date()} to {df['Date'].max().date()}")
        
        # Check for storage_delta
        if 'storage_delta' not in df.columns:
            print(f"  ✗ 'storage_delta' column not found")
            print(f"     Please run the storage delta calculation script first")
            return False
        
        # Check for storage_lower_48_bcf
        storage_col = None
        if 'storage_lower_48_bcf' in df.columns:
            storage_col = 'storage_lower_48_bcf'
        elif 'storage_lower_48' in df.columns:
            storage_col = 'storage_lower_48'
        else:
            print(f"  ✗ No storage_lower_48 column found")
            print(f"     Available columns: {list(df.columns)}")
            return False
        
        print(f"  ✓ Found storage column: {storage_col}")
        print(f"  ✓ Found storage_delta column")
        
        # Find the first non-null storage value
        print("\n" + "=" * 60)
        print("STEP 3: CALCULATING IMPLIED STORAGE")
        print("=" * 60)
        
        first_storage_idx = df[storage_col].first_valid_index()
        
        if first_storage_idx is None:
            print(f"  ✗ No valid storage values found in {storage_col}")
            return False
        
        first_storage_value = df.loc[first_storage_idx, storage_col]
        first_storage_date = df.loc[first_storage_idx, 'Date']
        
        print(f"  First storage value: {first_storage_value:.2f} BCF")
        print(f"  First storage date: {first_storage_date.date()}")
        print(f"  Starting at index: {first_storage_idx}")
        
        # Initialize Implied_Storage column
        df['Implied_Storage'] = np.nan
        
        # Set the first value
        df.loc[first_storage_idx, 'Implied_Storage'] = first_storage_value
        
        # Calculate rolling sum starting from the day after first storage value
        print(f"\n  Calculating rolling sum from index {first_storage_idx + 1}...")
        
        for i in range(first_storage_idx + 1, len(df)):
            # Get previous implied storage value
            prev_implied = df.loc[i - 1, 'Implied_Storage']
            
            # Get current storage_delta (use 0 if NaN)
            current_delta = df.loc[i, 'storage_delta']
            if pd.isna(current_delta):
                current_delta = 0
            
            # Calculate new implied storage
            df.loc[i, 'Implied_Storage'] = prev_implied + current_delta
            
            # Show progress every 365 days
            if (i - first_storage_idx) % 365 == 0:
                progress_date = df.loc[i, 'Date']
                progress_value = df.loc[i, 'Implied_Storage']
                print(f"    Progress: {progress_date.date()} - Implied Storage: {progress_value:.2f} BCF")
        
        print(f"  ✓ Implied storage calculated for {len(df) - first_storage_idx} records")
        
        # Calculate statistics
        print("\n" + "=" * 60)
        print("STEP 4: ANALYSIS AND COMPARISON")
        print("=" * 60)
        
        # Compare implied vs actual storage where both exist
        comparison_mask = df[storage_col].notna() & df['Implied_Storage'].notna()
        comparison_df = df[comparison_mask].copy()
        
        if len(comparison_df) > 0:
            comparison_df['Difference'] = comparison_df['Implied_Storage'] - comparison_df[storage_col]
            comparison_df['Pct_Difference'] = (comparison_df['Difference'] / comparison_df[storage_col]) * 100
            
            print(f"  Comparison Statistics (n={len(comparison_df)} points):")
            print(f"    Mean difference: {comparison_df['Difference'].mean():.2f} BCF")
            print(f"    Median difference: {comparison_df['Difference'].median():.2f} BCF")
            print(f"    Std deviation: {comparison_df['Difference'].std():.2f} BCF")
            print(f"    Min difference: {comparison_df['Difference'].min():.2f} BCF")
            print(f"    Max difference: {comparison_df['Difference'].max():.2f} BCF")
            print(f"    Mean % difference: {comparison_df['Pct_Difference'].mean():.2f}%")
            
            # Show sample comparisons
            print(f"\n  Sample Comparisons (first 5):")
            sample = comparison_df.head()
            for idx, row in sample.iterrows():
                print(f"    {row['Date'].date()}: Actual={row[storage_col]:.2f}, Implied={row['Implied_Storage']:.2f}, Diff={row['Difference']:.2f}")
        
        # Overall statistics for Implied_Storage
        print(f"\n  Implied Storage Statistics:")
        print(f"    Mean: {df['Implied_Storage'].mean():.2f} BCF")
        print(f"    Min: {df['Implied_Storage'].min():.2f} BCF")
        print(f"    Max: {df['Implied_Storage'].max():.2f} BCF")
        print(f"    Final value: {df['Implied_Storage'].iloc[-1]:.2f} BCF")
        
        # Save the updated file
        print("\n" + "=" * 60)
        print("STEP 5: SAVING UPDATED FILE")
        print("=" * 60)
        
        df.to_csv(latest_file, index=False)
        
        file_size = os.path.getsize(latest_file) / (1024 * 1024)  # MB
        print(f"  ✓ File saved: {filename}")
        print(f"    Size: {file_size:.2f} MB")
        
        # Verify column was added
        if 'Implied_Storage' in df.columns:
            print(f"  ✓ 'Implied_Storage' column successfully added")
            
            # Show how many values were calculated
            non_null_implied = df['Implied_Storage'].notna().sum()
            print(f"    Non-null implied storage values: {non_null_implied:,} / {len(df):,}")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error processing file: {e}")
        import traceback
        traceback.print_exc()
        return False

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the implied storage calculation"""
    
    success = calculate_implied_storage()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ IMPLIED STORAGE CALCULATION COMPLETE!")
    else:
        print("✗ IMPLIED STORAGE CALCULATION FAILED!")
    print("=" * 80)
    
    if success:
        print("\nSummary:")
        print(f"  The 'Implied_Storage' column has been added")
        print(f"  It starts from the first actual storage value")
        print(f"  Then adds storage_delta cumulatively for each subsequent day")
        print(f"  This represents what storage should be based on supply/demand balance")
        print(f"\nCompare Implied_Storage vs storage_lower_48_bcf to see model accuracy")
    
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()