# -*- coding: utf-8 -*-
import os
import json
import sys
import pandas as pd
import numpy as np
import traceback
import time
from datetime import datetime

# --- Configuration and Setup (Unchanged) ---
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    from config.settings import BASE_OUTPUT_DIR
    print(f"Loaded BASE_OUTPUT_DIR from config: {BASE_OUTPUT_DIR}")
except (ImportError, NameError, FileNotFoundError) as e:
    print(f"Could not import BASE_OUTPUT_DIR from config.settings ({e}). Using default.")
    current_dir_for_default = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
    project_root_for_default = os.path.abspath(os.path.join(current_dir_for_default, '..'))
    BASE_OUTPUT_DIR = os.path.join(project_root_for_default, "EIA_STACK")
    if not os.path.exists(BASE_OUTPUT_DIR):
         BASE_OUTPUT_DIR = os.path.join(project_root_for_default, "EIA_STACK_DEFAULT")
    print(f"Using default/fallback BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")

try:
    script_dir_for_regions = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
    project_root = os.path.abspath(os.path.join(script_dir_for_regions, '..'))
    paths_to_check = [
        os.path.join(project_root, 'config', 'regions.json'),
        os.path.join(script_dir_for_regions, 'config', 'regions.json'),
        os.path.join('config', 'regions.json')
    ]
    regions_config_path = None
    for path in paths_to_check:
        if os.path.exists(path):
            regions_config_path = path
            print(f"Found regions config at: {regions_config_path}")
            break
    if regions_config_path:
        with open(regions_config_path, 'r') as f:
            regions_data = json.load(f)
        print("Successfully loaded regions config.")
    else:
        raise FileNotFoundError("Core regions config file 'config/regions.json' not found.")
except FileNotFoundError as e:
    print(f"Error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"Error loading regions config: {e}")
    traceback.print_exc()
    sys.exit(1)


####################################################################
### [NEW] ROBUST DATE PARSING FUNCTION TO PRESERVE ALL DATA      ###
####################################################################
def robust_to_datetime(series, original_row_count):
    """
    Tries multiple common date formats to convert a series to datetime.
    The goal is to successfully parse all dates and NOT drop any rows.
    """
    # List of common date formats to try
    formats_to_try = [
        'ISO8601',                 # Standard format (e.g., '2023-10-27T10:00:00')
        '%Y-%m-%d %H:%M:%S',       # Common SQL format
        '%m/%d/%Y %H:%M',          # Common US format
        '%m-%d-%Y %H:%M:%S',       # Another common US format
    ]

    original_series = series.copy()
    
    for fmt in formats_to_try:
        print(f"    Attempting to parse dates with format: {fmt}...")
        try:
            # We use `errors='coerce'` to see how many dates fail for a given format
            converted_series = pd.to_datetime(original_series, format=None if fmt == 'ISO8601' else fmt, errors='coerce')
            
            # Check how many values failed to parse with this format
            failed_count = converted_series.isnull().sum()
            
            # If the number of failures is very small (or zero), we consider it a success
            if failed_count < (original_row_count * 0.01): # Success if less than 1% failed
                print(f"    ✅ SUCCESS: Format '{fmt}' successfully parsed the dates with {failed_count} failures.")
                # Now, re-run with errors='raise' on the good format to be sure, or just return this.
                # Returning the coerced one is safer for mixed-format files.
                return converted_series
        except Exception as e:
            print(f"    Format '{fmt}' raised an error: {e}")
            continue

    # If no specific format worked well, fall back to pandas' default flexible parser
    print("    --- No single format worked for all dates. Using pandas' flexible default parser. ---")
    return pd.to_datetime(original_series, errors='coerce')
####################################################################
### END OF NEW FUNCTION                                          ###
####################################################################


# --- Main Processing Function ---
def extract_hourly_features():
    print("\n=====================================================")
    print("=== Starting Hourly MW & Feature Extraction (from CSV) ===")
    print("=====================================================")
    start_total_time = time.time()
    successful_regions = []
    failed_regions = []

    if isinstance(regions_data, dict):
        regions_to_process = list(regions_data.keys())
    elif isinstance(regions_data, list):
        regions_to_process = [item['name'] for item in regions_data]
    else:
        print("Error: Regions configuration is not in an expected format. Exiting.")
        sys.exit(1)

    for region_name in regions_to_process:
        region_upper = region_name.upper()
        print(f"\n\n################ Processing Region: {region_upper} ################")
        start_region_time = time.time()
        region_success = False

        try:
            region_base_dir = os.path.join(BASE_OUTPUT_DIR, region_name)
            final_dir = os.path.join(region_base_dir, "final")
            input_file = os.path.join(final_dir, "combined.csv")
            output_file = os.path.join(final_dir, "hourly_mw_features.csv")

            if not os.path.exists(input_file):
                print(f"  Error: Input file not found: {input_file}. Skipping region.")
                failed_regions.append(f"{region_name} (Input file missing)")
                continue

            print(f"  Reading {input_file}...")
            df_hourly = pd.read_csv(input_file)
            print(f"    Successfully loaded CSV with {len(df_hourly)} rows.")

            date_col_name = 'date'
            if date_col_name not in df_hourly.columns:
                raise ValueError(f"Date column '{date_col_name}' not found.")
            
            initial_rows = len(df_hourly)

            # ####################################################################
            # ### [FIXED] CALL THE ROBUST DATE PARSER HERE                     ###
            # ####################################################################
            df_hourly[date_col_name] = robust_to_datetime(df_hourly[date_col_name], initial_rows)
            
            # NOW we check for any remaining nulls. This number should be ZERO.
            final_nulls = df_hourly[date_col_name].isnull().sum()
            if final_nulls > 0:
                print(f"    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                print(f"    !!! CRITICAL WARNING: After trying all formats, {final_nulls} dates STILL could not be parsed.")
                print(f"    !!! These {final_nulls} rows WILL BE DROPPED. You must investigate the format of these specific dates.")
                print(f"    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                df_hourly.dropna(subset=[date_col_name], inplace=True)
            else:
                print("    ✅ SUCCESS: All date strings were successfully converted to datetime objects. NO DATA WAS LOST.")

            print(f"    Rows remaining after date conversion: {len(df_hourly)} (Original: {initial_rows})")
            # ####################################################################
            # ### END OF FIX                                                   ###
            # ####################################################################

            if df_hourly.empty:
                print(f"  Input DataFrame empty after date processing. Skipping.")
                failed_regions.append(f"{region_name} (Empty Input or all dates invalid)")
                continue
                
            # (The rest of the script for selecting columns remains the same)
            
            # --- Dynamically build the list of columns to select ---
            selected_columns_for_output = [date_col_name]
            load_col_name = f"{region_upper}_LOAD"
            potential_mw_columns = [
                f"{region_upper}_NG_MW", f"{region_upper}_COL_MW", f"{region_upper}_NUC_MW", f"{region_upper}_WAT_MW",
                f"{region_upper}_SUN_MW", f"{region_upper}_WND_MW", f"{region_upper}_PS_MW", f"{region_upper}_BAT_MW",
                f"{region_upper}_OTH_MW", f"{region_upper}_INTERCHANGE_MW"
            ]
            
            if load_col_name in df_hourly.columns:
                selected_columns_for_output.append(load_col_name)
            
            found_mw_columns = [col for col in potential_mw_columns if col in df_hourly.columns]
            selected_columns_for_output.extend(found_mw_columns)
            
            temp_cols_found = sorted([col for col in df_hourly.columns if col.endswith('_temperature_2m')])
            selected_columns_for_output.extend(temp_cols_found)
            
            selected_columns_for_output = list(dict.fromkeys(selected_columns_for_output))
            processed_df = df_hourly[selected_columns_for_output].copy()
            
            numeric_cols_to_convert = [col for col in selected_columns_for_output if col != date_col_name]
            for col in numeric_cols_to_convert:
                processed_df[col] = pd.to_numeric(processed_df[col], errors='coerce')
            
            processed_df.sort_values(by=date_col_name, inplace=True)

            print(f"  💾 Saving hourly MW and features data to: {output_file}")
            os.makedirs(final_dir, exist_ok=True)
            processed_df.to_csv(output_file, index=False, float_format='%.4f', date_format='%Y-%m-%d %H:%M:%S')
            print(f"  ✅ Successfully saved hourly MW and features data for {region_upper}.")
            region_success = True

        except Exception as e:
            print(f"  ❌ ERROR: An unexpected error occurred processing region {region_upper}: {e}")
            traceback.print_exc()
            if not any(region_name in fr for fr in failed_regions):
                failed_regions.append(f"{region_name} (Unexpected Error: {type(e).__name__})")
        finally:
            if region_success:
                successful_regions.append(region_name)
            end_region_time = time.time()
            print(f"  ⏱️  Region processing time: {end_region_time - start_region_time:.2f} seconds.")

    # (The final summary part of the script is unchanged)
    end_total_time = time.time()
    print("\n\n=============================================")
    print("========== Hourly Feature Extraction Summary (from CSV) ==========")
    print(f"Successfully processed regions: {len(successful_regions)}")
    print(f"Failed regions: {len(failed_regions)}")
    if failed_regions:
        print("\n--- Failure Details ---")
        for fr_info in sorted(list(set(failed_regions))):
            print(f"  - {fr_info}")
    print(f"\nTotal execution time: {end_total_time - start_total_time:.2f} seconds.")
    print("=============================================")
    if failed_regions:
        sys.exit(1)

if __name__ == "__main__":
    extract_hourly_features()