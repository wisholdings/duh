import pandas as pd
import os
from datetime import datetime

# Define file paths
east_dir = r'D:\EIA_STACK\Pricing_RL\MIDWEST'
input_file = os.path.join(east_dir, 'MIDWEST_merged_all_outer_with_totals.csv')
output_file = os.path.join(east_dir, 'MIDWEST_filtered.csv')

print("="*60)
print("FILTER EAST MERGED DATA BY DATE RANGE")
print("="*60)
print(f"Input file: {input_file}")
print(f"Date range: 2022-01-01 to 2026-12-31")
print("="*60)

# Load the data
print("\nLoading data...")
try:
    df = pd.read_csv(input_file)
    print(f"✓ Loaded {len(df):,} rows")
    
    # Check if 'date' column exists
    if 'date' not in df.columns:
        print("Error: 'date' column not found in the file")
        print(f"Available columns: {list(df.columns)[:10]}")
        exit()
    
    # Convert date column to datetime
    print("\nConverting date column to datetime...")
    df['date'] = pd.to_datetime(df['date'], errors='coerce')
    
    # Check for invalid dates
    invalid_dates = df['date'].isna().sum()
    if invalid_dates > 0:
        print(f"⚠️ Warning: {invalid_dates} invalid dates found and will be removed")
        df = df.dropna(subset=['date'])
    
    # Show original date range
    print(f"\nOriginal date range:")
    print(f"  Start: {df['date'].min().date()}")
    print(f"  End: {df['date'].max().date()}")
    print(f"  Total rows: {len(df):,}")
    
    # Define filter dates
    start_date = pd.Timestamp('2022-01-01')
    end_date = pd.Timestamp('2026-12-31')
    
    # Apply date filter
    print(f"\nApplying date filter...")
    print(f"  Keeping dates from {start_date.date()} to {end_date.date()}")
    
    # Filter the dataframe
    df_filtered = df[(df['date'] >= start_date) & (df['date'] <= end_date)].copy()
    
    # Sort by date
    df_filtered = df_filtered.sort_values('date')
    
    # Show results
    rows_removed = len(df) - len(df_filtered)
    print(f"\n✓ Filter applied successfully")
    print(f"  Rows removed: {rows_removed:,}")
    print(f"  Rows kept: {len(df_filtered):,}")
    print(f"  Percentage kept: {len(df_filtered)/len(df)*100:.1f}%")
    
    # Show new date range
    print(f"\nFiltered date range:")
    print(f"  Start: {df_filtered['date'].min().date()}")
    print(f"  End: {df_filtered['date'].max().date()}")
    
    # Drop the synmaxproductio_DATA_SOURCE column if it exists
    column_to_drop = 'synmaxproductio_DATA_SOURCE'
    if column_to_drop in df_filtered.columns:
        print(f"\n✓ Dropping column: {column_to_drop}")
        df_filtered = df_filtered.drop(columns=[column_to_drop])
        print(f"  Column dropped successfully")
    else:
        print(f"\n⚠️ Column '{column_to_drop}' not found in the dataframe")
        # Check for similar column names
        similar_cols = [col for col in df_filtered.columns if 'DATA_SOURCE' in col or 'synmax' in col.lower()]
        if similar_cols:
            print(f"  Similar columns found: {similar_cols}")
    
    print(f"\nFinal shape: {df_filtered.shape[0]:,} rows × {df_filtered.shape[1]} columns")
    
    # Check for date gaps
    date_range = pd.date_range(start=df_filtered['date'].min(), end=df_filtered['date'].max(), freq='D')
    missing_dates = date_range.difference(df_filtered['date'])
    if len(missing_dates) > 0:
        print(f"\n⚠️ Warning: {len(missing_dates)} dates are missing in the range")
        if len(missing_dates) <= 10:
            print("  Missing dates:")
            for d in missing_dates:
                print(f"    • {d.date()}")
        else:
            print(f"  First 5 missing: {[d.date() for d in missing_dates[:5]]}")
            print(f"  Last 5 missing: {[d.date() for d in missing_dates[-5:]]}")
    else:
        print("\n✓ No date gaps found - continuous daily data")
    
    # Save the filtered data
    print(f"\nSaving filtered data...")
    df_filtered.to_csv(output_file, index=False)
    
    # Check file size
    file_size = os.path.getsize(output_file)
    if file_size < 1024 * 1024:
        size_str = f"{file_size/1024:.1f} KB"
    else:
        size_str = f"{file_size/(1024*1024):.1f} MB"
    
    print(f"✓ Filtered data saved to: {output_file}")
    print(f"  File size: {size_str}")
    
    # Show sample of data
    print("\n" + "="*60)
    print("DATA PREVIEW")
    print("="*60)
    
    # Show first few rows
    print("\nFirst 3 rows:")
    print("-"*40)
    display_cols = ['date'] + [col for col in df_filtered.columns if 'TOTAL_BCF' in col or 'GRAND_TOTAL' in col]
    if len(display_cols) > 1:
        print(df_filtered[display_cols].head(3).to_string())
    else:
        print(df_filtered.head(3))
    
    # Show last few rows
    print("\nLast 3 rows:")
    print("-"*40)
    if len(display_cols) > 1:
        print(df_filtered[display_cols].tail(3).to_string())
    else:
        print(df_filtered.tail(3))
    
    # Show column summary
    print("\n" + "="*60)
    print("COLUMN SUMMARY")
    print("="*60)
    
    total_cols = [col for col in df_filtered.columns if 'TOTAL_BCF' in col or 'GRAND_TOTAL' in col]
    if total_cols:
        print("\nRegional Total Columns:")
        for col in total_cols:
            non_nan = df_filtered[col].notna().sum()
            mean_val = df_filtered[col].mean()
            print(f"  • {col}: {non_nan:,} non-null values, mean={mean_val:.3f}")
    
    print(f"\nTotal columns in filtered data: {len(df_filtered.columns)}")
    
    # List columns that contain 'synmax' or 'DATA_SOURCE' for verification
    synmax_cols = [col for col in df_filtered.columns if 'synmax' in col.lower() or 'DATA_SOURCE' in col]
    if synmax_cols:
        print(f"\n⚠️ Remaining columns with 'synmax' or 'DATA_SOURCE':")
        for col in synmax_cols:
            print(f"  • {col}")
    
except FileNotFoundError:
    print(f"✗ Error: File not found at {input_file}")
    print("Please ensure the file exists and the path is correct")
except Exception as e:
    print(f"✗ Error loading or processing file: {str(e)}")

print("\n" + "="*60)
print("Filtering complete!")
print("="*60)