import os
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
import traceback

# --- Configuration ---
DB_CONNECTION_STRING = (
)
BASE_OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"
TABLE_NAME = "FORECAST_POWER_BURNS_REGIONAL_ST"

# List of individual regional columns to process from the database table.
REGIONAL_COLUMNS = [
    'california_bcf', 'carolina_bcf', 'central_bcf', 'florida_bcf',
    'midatlantic_bcf', 'midwest_bcf', 'newengland_bcf', 'newyork_bcf',
    'northwest_bcf', 'southeast_bcf', 'southwest_bcf', 'tennessee_bcf',
    'texas_bcf'
]

# --- Main Logic ---

def download_and_process_power_burns():
    """
    Downloads regional power burn forecasts from the last 3 publication dates
    and saves each region to its own specific folder.
    """
    print("\n" + "="*80)
    print("   DOWNLOADING & PROCESSING LATEST POWER BURN FORECASTS (LAST 3 RUNS)")
    print("="*80)
    print(f"Database: gasstosbxarmservus2001")
    print(f"Source Table: {TABLE_NAME}")
    print(f"Base Output Directory: {os.path.abspath(BASE_OUTPUT_DIR)}")
    print("="*80)

    engine = None
    try:
        engine = create_engine(DB_CONNECTION_STRING)
        
        # Step 1: Find the three most recent 'date_published' values
        print("\n1. Finding the three latest forecast publication dates...")
        latest_dates_query = f"""
            SELECT DISTINCT TOP 3 date_published 
            FROM {TABLE_NAME} 
            ORDER BY date_published DESC
        """
        latest_dates_df = pd.read_sql(latest_dates_query, engine)

        if latest_dates_df.empty:
            raise ValueError(f"No publication dates found in table '{TABLE_NAME}'.")
        
        # Convert to datetime before using the .dt accessor to prevent errors
        latest_dates_list = pd.to_datetime(latest_dates_df['date_published']).dt.strftime('%Y-%m-%d').tolist()
        print(f"   ✓ Found publication dates: {', '.join(latest_dates_list)}")

        # Step 2: Fetch all data for those three publication dates
        print("\n2. Downloading all forecast data for these publication dates...")
        
        # Create a string representation of the dates for the SQL IN clause
        dates_for_sql = "','".join(latest_dates_list)
        
        data_query = f"""
            SELECT * 
            FROM {TABLE_NAME} 
            WHERE date_published IN ('{dates_for_sql}')
            ORDER BY date_published, datetime
        """
        df = pd.read_sql(data_query, engine)

        if df.empty:
            raise ValueError("Downloaded DataFrame is empty.")
        
        print(f"   ✓ Downloaded {len(df)} total rows successfully.")

        # Step 3: Process and save data for each individual region
        print("\n3. Saving data for each individual region...")
        for column_name in REGIONAL_COLUMNS:
            if column_name not in df.columns:
                print(f"   - WARNING: Column '{column_name}' not found in data. Skipping.")
                continue

            folder_name = column_name.replace('_bcf', '')
            print(f"   - Processing Region: {folder_name}")
            
            output_folder = os.path.join(BASE_OUTPUT_DIR, folder_name)
            os.makedirs(output_folder, exist_ok=True)
            
            # Create a new DataFrame with datetime, date_published, and the region's data
            # Including date_published is useful for verification
            region_df = df[['datetime', 'date_published', column_name]].copy()
            
            region_df.rename(columns={column_name: 'power_burn_BCF'}, inplace=True)
            
            output_filepath = os.path.join(output_folder, "power_burn_forecast.csv")
            region_df.to_csv(output_filepath, index=False)
            print(f"     ✓ Saved to: {output_filepath}")

    except (SQLAlchemyError, ValueError) as e:
        print(f"\nFATAL ERROR during database operation: {e}")
        traceback.print_exc()
    except Exception as e:
        print(f"\nAn unexpected FATAL ERROR occurred: {e}")
        traceback.print_exc()
    finally:
        if engine:
            engine.dispose()
            print("\n   ✓ Database connection closed")

    print("\n" + "="*80)
    print("✅ Script completed!")
    print("="*80)

# --- Execute the Script ---
if __name__ == "__main__":
    download_and_process_power_burns()