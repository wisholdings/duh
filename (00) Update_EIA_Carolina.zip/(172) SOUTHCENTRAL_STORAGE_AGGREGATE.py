import pandas as pd
import os
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define output directory on D drive
OUTPUT_DIR = r"D:\EIA_STACK\storage_consolidated"

# Define salt cavern facilities
SALT_FACILITIES = {
    'Bistineau',
    'Egan', 
    'Jefferson Island',
    'Moss Bluff',
    'Napoleonville',
    'Petal',
    'Pine Prairie',
    'Tres Palacios'
}

def ensure_output_directory():
    """Create output directory if it doesn't exist"""
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        logging.info(f"Created output directory: {OUTPUT_DIR}")

def process_storage_files_to_consolidated(input_folder="southcentral", 
                                         output_salt_filename=None,
                                         output_nonsalt_filename=None):
    """
    Processes all CSV files in the input folder, splits them into salt and non-salt facilities,
    aggregates scheduled_quantity_sign_adj by eff_gas_day for each facility, 
    and creates two consolidated files.
    
    Args:
        input_folder (str): Folder containing the individual storage facility CSV files
        output_salt_filename (str): Name of the consolidated salt storage output CSV file
        output_nonsalt_filename (str): Name of the consolidated non-salt storage output CSV file
    """
    
    # Ensure output directory exists
    ensure_output_directory()
    
    # Auto-generate output filenames if not provided
    if output_salt_filename is None:
        output_salt_filename = "southcentral_salt_storage.csv"
    if output_nonsalt_filename is None:
        output_nonsalt_filename = "southcentral_nonsalt_storage.csv"
    
    # Full paths for output files
    output_salt_path = os.path.join(OUTPUT_DIR, output_salt_filename)
    output_nonsalt_path = os.path.join(OUTPUT_DIR, output_nonsalt_filename)
    
    # Check if input folder exists
    if not os.path.exists(input_folder):
        logging.error(f"Input folder '{input_folder}' does not exist!")
        return None, None
    
    # Get all CSV files in the folder
    csv_files = [f for f in os.listdir(input_folder) if f.endswith('.csv')]
    
    if not csv_files:
        logging.warning(f"No CSV files found in '{input_folder}' folder!")
        return None, None
    
    logging.info(f"Found {len(csv_files)} CSV files to process")
    
    # Dictionaries to store processed data for salt and non-salt facilities
    salt_facility_data = {}
    nonsalt_facility_data = {}
    
    # Process each CSV file
    for csv_file in csv_files:
        file_path = os.path.join(input_folder, csv_file)
        facility_name = csv_file.replace('.csv', '').replace('_', ' ')  # Clean up facility name
        
        try:
            logging.info(f"Processing {csv_file}...")
            
            # Read the CSV file
            df = pd.read_csv(file_path)
            
            # Check if required columns exist
            if 'eff_gas_day' not in df.columns or 'scheduled_quantity_sign_adj' not in df.columns:
                logging.warning(f"Required columns missing in {csv_file}. Skipping...")
                continue
            
            # Convert eff_gas_day to datetime
            df['eff_gas_day'] = pd.to_datetime(df['eff_gas_day'])
            
            # Handle missing values in scheduled_quantity_sign_adj
            df['scheduled_quantity_sign_adj'] = pd.to_numeric(df['scheduled_quantity_sign_adj'], errors='coerce')
            
            # Group by eff_gas_day and sum scheduled_quantity_sign_adj
            aggregated = df.groupby('eff_gas_day')['scheduled_quantity_sign_adj'].sum().reset_index()
            
            # Determine if facility is salt or non-salt
            # Check if any part of the facility name matches salt facilities
            is_salt = False
            for salt_name in SALT_FACILITIES:
                if salt_name.lower() in facility_name.lower():
                    is_salt = True
                    break
            
            # Store the aggregated data in appropriate dictionary
            if is_salt:
                salt_facility_data[facility_name] = aggregated.set_index('eff_gas_day')['scheduled_quantity_sign_adj']
                logging.info(f"  -> Classified as SALT storage: {facility_name}")
            else:
                nonsalt_facility_data[facility_name] = aggregated.set_index('eff_gas_day')['scheduled_quantity_sign_adj']
                logging.info(f"  -> Classified as NON-SALT storage: {facility_name}")
            
            logging.info(f"Successfully processed {csv_file}: {len(aggregated)} unique dates")
            
        except Exception as e:
            logging.error(f"Error processing {csv_file}: {str(e)}")
            continue
    
    salt_consolidated_df = None
    nonsalt_consolidated_df = None
    
    # Process salt facilities
    if salt_facility_data:
        logging.info(f"\nCreating SALT consolidated DataFrame with {len(salt_facility_data)} facilities...")
        
        # Combine all salt facility data into a single DataFrame
        salt_consolidated_df = pd.DataFrame(salt_facility_data)
        salt_consolidated_df.reset_index(inplace=True)
        salt_consolidated_df.sort_values('eff_gas_day', inplace=True)
        salt_consolidated_df.fillna(0, inplace=True)
        
        # Add a total column
        salt_consolidated_df['TOTAL_SALT'] = salt_consolidated_df.iloc[:, 1:].sum(axis=1)
        
        # Save to CSV in D drive directory
        salt_consolidated_df.to_csv(output_salt_path, index=False)
        
        logging.info(f"Salt storage data saved to '{output_salt_path}'")
        logging.info(f"Salt dataset shape: {salt_consolidated_df.shape}")
        logging.info(f"Salt facilities included: {list(salt_consolidated_df.columns[1:-1])}")  # Skip eff_gas_day and TOTAL columns
    else:
        logging.warning("No salt storage facilities found!")
    
    # Process non-salt facilities
    if nonsalt_facility_data:
        logging.info(f"\nCreating NON-SALT consolidated DataFrame with {len(nonsalt_facility_data)} facilities...")
        
        # Combine all non-salt facility data into a single DataFrame
        nonsalt_consolidated_df = pd.DataFrame(nonsalt_facility_data)
        nonsalt_consolidated_df.reset_index(inplace=True)
        nonsalt_consolidated_df.sort_values('eff_gas_day', inplace=True)
        nonsalt_consolidated_df.fillna(0, inplace=True)
        
        # Add a total column
        nonsalt_consolidated_df['TOTAL_NONSALT'] = nonsalt_consolidated_df.iloc[:, 1:].sum(axis=1)
        
        # Save to CSV in D drive directory
        nonsalt_consolidated_df.to_csv(output_nonsalt_path, index=False)
        
        logging.info(f"Non-salt storage data saved to '{output_nonsalt_path}'")
        logging.info(f"Non-salt dataset shape: {nonsalt_consolidated_df.shape}")
        logging.info(f"Non-salt facilities included: {list(nonsalt_consolidated_df.columns[1:-1])}")  # Skip eff_gas_day and TOTAL columns
    else:
        logging.warning("No non-salt storage facilities found!")
    
    # Display summary statistics
    print("\n=== CONSOLIDATION SUMMARY ===")
    print(f"Total files processed: {len(salt_facility_data) + len(nonsalt_facility_data)}")
    print(f"Output directory: {OUTPUT_DIR}")
    print(f"\nSALT CAVERN FACILITIES ({len(salt_facility_data)}):")
    for facility in sorted(salt_facility_data.keys()):
        print(f"  - {facility}")
    print(f"\nNON-SALT FACILITIES ({len(nonsalt_facility_data)}):")
    for facility in sorted(nonsalt_facility_data.keys()):
        print(f"  - {facility}")
    
    if salt_facility_data:
        print(f"\nSalt storage output: {output_salt_path}")
        print(f"Sample of salt data (first 5 rows):")
        print(salt_consolidated_df[['eff_gas_day', 'TOTAL_SALT']].head())
    
    if nonsalt_facility_data:
        print(f"\nNon-salt storage output: {output_nonsalt_path}")
        print(f"Sample of non-salt data (first 5 rows):")
        print(nonsalt_consolidated_df[['eff_gas_day', 'TOTAL_NONSALT']].head())
    
    return salt_consolidated_df, nonsalt_consolidated_df

if __name__ == "__main__":
    logging.info("=== Starting South Central Region Storage Data Consolidation (Salt/Non-Salt Split) ===")
    
    # Process and split the data
    salt_df, nonsalt_df = process_storage_files_to_consolidated()
    
    if salt_df is not None or nonsalt_df is not None:
        logging.info("=== Consolidation completed successfully ===")
        print(f"\nFiles saved to: {OUTPUT_DIR}")
    else:
        logging.error("=== Consolidation failed ===")