# =============================================================================
# CLEANUP PIPELINE: Storage and Weather Data
# =============================================================================
import pandas as pd
import os
import shutil
import requests
from io import StringIO
from datetime import datetime, timedelta
import json
import time

# --- CONFIGURATION ---
OUTPUT_BASE_PATH = r"D:\EIA_STACK\Pricing_RL"
AGGREGATE_PATH = os.path.join(OUTPUT_BASE_PATH, "AGGREGATE")
REGIONAL_PATH = os.path.join(OUTPUT_BASE_PATH, "REGIONAL")

# Storage file source
STORAGE_SOURCE_FILE = r"D:\EIA_STACK\granular_storage\lower_48_states.csv"

# Weather configuration
MONTH_MAPPING_FILE = r"C:\EIA\config\month_mapping.json"
WEATHER_REGIONS = ['EAST', 'MIDWEST', 'MOUNTAIN', 'PACIFIC', 'SOUTHCENTRAL']

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================
def ensure_directories():
    """Create output directories if they don't exist"""
    for path in [AGGREGATE_PATH, REGIONAL_PATH]:
        if not os.path.exists(path):
            os.makedirs(path)
            print(f"✓ Created directory: {path}")
        else:
            print(f"✓ Directory exists: {path}")

# =============================================================================
# STORAGE DATA COPY
# =============================================================================
def copy_storage_data():
    """Copy lower_48_states.csv to AGGREGATE folder"""
    print("\n📊 Copying Storage Data to AGGREGATE folder...")
    
    try:
        # Check if source file exists
        if not os.path.exists(STORAGE_SOURCE_FILE):
            print(f"  ✗ Source file not found: {STORAGE_SOURCE_FILE}")
            return False
        
        # Define destination
        destination_file = os.path.join(AGGREGATE_PATH, "lower_48_states.csv")
        
        # Copy the file
        shutil.copy2(STORAGE_SOURCE_FILE, destination_file)
        
        # Verify copy and show info
        if os.path.exists(destination_file):
            file_size = os.path.getsize(destination_file) / 1024  # KB
            print(f"  ✓ Copied storage file to: {destination_file}")
            print(f"    File size: {file_size:.1f} KB")
            
            # Read and show basic info
            df = pd.read_csv(destination_file)
            print(f"    Records: {len(df)}")
            if 'Date' in df.columns or 'date' in df.columns:
                date_col = 'Date' if 'Date' in df.columns else 'date'
                df[date_col] = pd.to_datetime(df[date_col])
                print(f"    Date range: {df[date_col].min().date()} to {df[date_col].max().date()}")
            
            return True
        else:
            print(f"  ✗ Failed to copy file")
            return False
            
    except Exception as e:
        print(f"  ✗ Error copying storage data: {e}")
        return False

# =============================================================================
# WEATHER DATA FUNCTIONS
# =============================================================================
def get_historical_weather(site_id, start_date, end_date):
    """Fetch historical weather observations"""
    base_url = "https://www.wsitrader.com/Services/CSVDownloadService.svc/GetHistoricalObservations"
    params = {
        'Account': 'suncor',
        'profile': '',
        'password': '',
        'TempUnits': 'F',
        'HistoricalProductID': 'HISTORICAL_WEIGHTED_DEGREEDAYS',
        'DataTypes[]': ['population_cdd', 'gas_hdd'],
        'StartDate': start_date,
        'EndDate': end_date,
        'IsDisplayDates': 'true',
        'IsDaily': 'true',
        'CityIds[]': site_id
    }
    
    try:
        response = requests.get(base_url, params=params, verify=False)
        if response.status_code == 200:
            data_lines = response.text.split('\n')
            header_index = next((i for i, line in enumerate(data_lines) if "Daily Observed CDD/HDD" in line), -1)
            if header_index != -1:
                modified_data = '\n'.join(data_lines[header_index + 1:])
            else:
                modified_data = response.text
            
            data_io = StringIO(modified_data)
            df = pd.read_csv(data_io, skiprows=1)
            
            df['valid_time'] = pd.to_datetime(df['valid_time'], format='%m/%d/%Y')
            df.rename(columns={'valid_time': 'Date'}, inplace=True)
            df.set_index('Date', inplace=True)
            
            if 'site_id' in df.columns:
                df = df.drop(columns=['site_id'])
            
            return df
        else:
            print(f"    Error fetching historical data: {response.status_code}")
            return None
    except Exception as e:
        print(f"    Exception fetching historical data: {e}")
        return None

def get_forecast_weather(site_id):
    """Fetch forecast weather data"""
    base_url = "https://www.wsitrader.com/Services/CSVDownloadService.svc/GetWeightedDegreeDayForecast"
    params = {
        'Account': 'suncor',
        'Profile': '',
        'Password': '',
        'Region': 'NA',
        'ForecastType': 'Daily',
        'DataTypes[]': ['population_cdd', 'gas_hdd'],
        'Stations[]': site_id,
        'Model': 'WSI',
        'Period': "Daily",
        'BiasCorrected': 'true'
    }
    
    try:
        response = requests.get(base_url, params=params, verify=False)
        if response.status_code == 200:
            df = pd.read_csv(StringIO(response.text), header=1)
            
            columns_to_keep = ['period_start', 'population_cdd', 'gas_hdd']
            df = df[[col for col in columns_to_keep if col in df.columns]]
            
            df.rename(columns={'period_start': 'Date'}, inplace=True)
            df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y')
            df.set_index('Date', inplace=True)
            
            if 'site_id' in df.columns:
                df = df.drop(columns=['site_id'])
            
            return df
        else:
            print(f"    Error fetching forecast data: {response.status_code}")
            return None
    except Exception as e:
        print(f"    Exception fetching forecast data: {e}")
        return None

def fill_weather_nans(weather_df, month_mapping):
    """Fill NaN values using historical analogues"""
    df = weather_df.copy()
    
    if not pd.api.types.is_datetime64_any_dtype(df.index):
        df.index = pd.to_datetime(df.index)
    
    weather_columns = df.columns.tolist()
    mask_has_nan = df[weather_columns].isna().any(axis=1)
    dates_with_nan = df[mask_has_nan].index
    
    if len(dates_with_nan) == 0:
        return df
    
    filled_count = 0
    
    for future_date in dates_with_nan:
        future_month_key = future_date.strftime('%Y-%m')
        
        if future_month_key in month_mapping:
            historical_month = month_mapping[future_month_key]
            historical_year, historical_month_num = historical_month.split('-')
            historical_year = int(historical_year)
            historical_month_num = int(historical_month_num)
            
            try:
                historical_date = pd.Timestamp(year=historical_year, 
                                             month=historical_month_num, 
                                             day=future_date.day)
                
                if historical_date in df.index:
                    historical_data = df.loc[historical_date, weather_columns]
                    if not historical_data.isna().all():
                        df.loc[future_date, weather_columns] = historical_data
                        filled_count += 1
            except ValueError:
                pass
    
    return df

def process_weather_region(region_name, month_mapping):
    """Process weather data for a single region"""
    print(f"\n  Processing weather for {region_name}...")
    
    # Fetch historical data
    start_date = '01/01/2012'
    end_date = (datetime.now() - timedelta(days=1)).strftime('%m/%d/%Y')
    
    historical_df = get_historical_weather(region_name, start_date, end_date)
    if historical_df is None:
        print(f"    ✗ Failed to fetch historical data")
        return False
    
    print(f"    Historical data: {len(historical_df)} days")
    
    # Fetch forecast data
    forecast_df = get_forecast_weather(region_name)
    if forecast_df is None:
        print(f"    ⚠ No forecast data available, using historical only")
        combined_df = historical_df
    else:
        print(f"    Forecast data: {len(forecast_df)} days")
        # Combine historical and forecast
        combined_df = pd.concat([historical_df, forecast_df])
        combined_df = combined_df[~combined_df.index.duplicated(keep='last')]
        combined_df = combined_df.sort_index()
    
    print(f"    Combined: {len(combined_df)} days total")
    
    # Extend to 2027-12-31
    target_end_date = pd.Timestamp('2027-12-31')
    if combined_df.index.max() < target_end_date:
        future_dates = pd.date_range(
            start=combined_df.index.max() + timedelta(days=1),
            end=target_end_date,
            freq='D'
        )
        future_df = pd.DataFrame(index=future_dates, columns=combined_df.columns)
        combined_df = pd.concat([combined_df, future_df])
        print(f"    Extended to {target_end_date.date()}")
    
    # Fill NaNs with historical analogues
    filled_df = fill_weather_nans(combined_df, month_mapping)
    
    # Reset index for saving
    filled_df = filled_df.reset_index()
    filled_df.rename(columns={'index': 'Date'}, inplace=True)
    
    # Save to REGIONAL folder
    output_file = os.path.join(REGIONAL_PATH, f"weather_{region_name.lower()}.csv")
    filled_df.to_csv(output_file, index=False)
    print(f"    ✓ Saved to: {output_file}")
    
    # Special handling for SOUTHCENTRAL - also save as southcentral_salts
    if region_name == 'SOUTHCENTRAL':
        output_file_salts = os.path.join(REGIONAL_PATH, "weather_southcentral_salts.csv")
        filled_df.to_csv(output_file_salts, index=False)
        print(f"    ✓ Also saved to: {output_file_salts}")
    
    return True

def download_weather_data():
    """Download and process weather data for all regions"""
    print("\n📊 Processing Weather Data for REGIONAL folder...")
    
    # Load month mapping
    print(f"  Loading month mapping from: {MONTH_MAPPING_FILE}")
    try:
        with open(MONTH_MAPPING_FILE, 'r') as f:
            month_mapping = json.load(f)
        print(f"  ✓ Loaded {len(month_mapping)} month mappings")
    except Exception as e:
        print(f"  ✗ Error loading month mapping: {e}")
        return False
    
    # Suppress SSL warnings
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    # Process each region
    successful_regions = []
    failed_regions = []
    
    for region in WEATHER_REGIONS:
        try:
            if process_weather_region(region, month_mapping):
                successful_regions.append(region)
            else:
                failed_regions.append(region)
            
            # Add delay between API calls
            if region != WEATHER_REGIONS[-1]:
                time.sleep(2)
                
        except Exception as e:
            print(f"    ✗ Error processing {region}: {e}")
            failed_regions.append(region)
    
    # Summary
    print(f"\n  Weather Data Summary:")
    print(f"    ✓ Successfully processed: {len(successful_regions)} regions")
    if successful_regions:
        for region in successful_regions:
            print(f"      • {region}")
            if region == 'SOUTHCENTRAL':
                print(f"        (Also saved as southcentral_salts)")
    
    if failed_regions:
        print(f"    ✗ Failed: {len(failed_regions)} regions")
        for region in failed_regions:
            print(f"      • {region}")
    
    return len(failed_regions) == 0

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the cleanup pipeline"""
    print("\n" + "=" * 80)
    print("CLEANUP PIPELINE")
    print("Processing Storage and Weather Data")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    
    # Create directories
    ensure_directories()
    
    # Copy storage data
    print("\n" + "=" * 60)
    print("STEP 1: COPYING STORAGE DATA")
    print("=" * 60)
    storage_success = copy_storage_data()
    
    # Download weather data
    print("\n" + "=" * 60)
    print("STEP 2: DOWNLOADING WEATHER DATA")
    print("=" * 60)
    weather_success = download_weather_data()
    
    # Final summary
    print("\n" + "=" * 80)
    print("✅ CLEANUP PIPELINE COMPLETE!")
    print("=" * 80)
    
    print("\nSummary:")
    print(f"  Storage Data: {'✓ Copied' if storage_success else '✗ Failed'}")
    print(f"  Weather Data: {'✓ Downloaded' if weather_success else '✗ Failed'}")
    
    print(f"\nFiles created:")
    
    # List AGGREGATE files
    print(f"\n  AGGREGATE folder:")
    if os.path.exists(AGGREGATE_PATH):
        files = [f for f in os.listdir(AGGREGATE_PATH) if f.endswith('.csv')]
        for file in sorted(files):
            size = os.path.getsize(os.path.join(AGGREGATE_PATH, file)) / 1024
            print(f"    - {file} ({size:.1f} KB)")
    
    # List REGIONAL weather files
    print(f"\n  REGIONAL folder (weather files):")
    if os.path.exists(REGIONAL_PATH):
        weather_files = [f for f in os.listdir(REGIONAL_PATH) if f.startswith('weather_')]
        for file in sorted(weather_files):
            size = os.path.getsize(os.path.join(REGIONAL_PATH, file)) / 1024
            print(f"    - {file} ({size:.1f} KB)")
    
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()