import os
import csv
import re
import shutil
from datetime import datetime

def get_region_info(description):
    """
    Creates a clean filename and a clean column header from the series description.
    Returns a tuple: (filename, column_header)
    """
    # Extract the region name
    match = re.search(r'Weekly (.*?) Region|Weekly (Lower 48 States)', description)
    region_name = "unknown"
    if match:
        region_name = next((group for group in match.groups() if group is not None), "unknown")

    # Create a clean column header
    column_header = region_name.replace('  ', ' ').strip().title()

    # Create a filename, handling specific cases for Salt/Nonsalt
    filename_base = ""
    if "Salt Region" in description:
        filename_base = "south_central_salt_region"
        column_header = "South Central Salt"
    elif "Nonsalt Region" in description:
        filename_base = "south_central_nonsalt_region"
        column_header = "South Central Nonsalt"
    elif "South Central" in description:
        filename_base = "south_central_region"
        column_header = "South Central"
    else:
        filename_base = region_name.lower().replace(' ', '_')

    return f"{filename_base}.csv", column_header


def copy_to_pricing_rl_folders(source_file, filename):
    """
    Copy South Central related files to the appropriate Pricing_RL folders.
    
    Args:
        source_file (str): Full path to the source file
        filename (str): Name of the file
    """
    pricing_rl_base = r"D:\EIA_STACK\Pricing_RL"
    copied_locations = []
    
    # Determine which folders to copy to based on filename
    target_folders = []
    
    if "south_central_salt" in filename:
        # Salt data goes only to SOUTHCENTRAL_SALTS
        target_folders = ["SOUTHCENTRAL_SALTS"]
    elif "south_central_nonsalt" in filename:
        # Nonsalt data goes to both SOUTHCENTRAL and SOUTHCENTRAL_SALTS
        target_folders = ["SOUTHCENTRAL", "SOUTHCENTRAL_SALTS"]
    elif "south_central" in filename:
        # General South Central data goes to both
        target_folders = ["SOUTHCENTRAL", "SOUTHCENTRAL_SALTS"]
    
    # Copy to each target folder
    for folder in target_folders:
        target_dir = os.path.join(pricing_rl_base, folder)
        os.makedirs(target_dir, exist_ok=True)
        
        target_path = os.path.join(target_dir, filename)
        try:
            shutil.copy2(source_file, target_path)
            copied_locations.append(target_path)
            print(f"    → Copied to: {target_path}")
        except Exception as e:
            print(f"    ✗ Error copying to {target_path}: {e}")
    
    return copied_locations


def process_and_transform_files(input_file_path, output_directory):
    """
    Reads a CSV, separates by region, calculates the delta change, renames the
    value column, sorts by date, and writes to separate files.
    For South Central files, also copies them to Pricing_RL folders.

    Args:
        input_file_path (str): The full path to the input CSV file.
        output_directory (str): The path to the directory where files will be saved.
    """
    os.makedirs(output_directory, exist_ok=True)
    
    # Dictionary to hold data. Structure:
    # { 'filename.csv': {'data': [(datetime, value)], 'header_name': 'Region Name'} }
    regions_data = {}
    
    try:
        with open(input_file_path, 'r', newline='') as infile:
            csv_reader = csv.reader(infile)
            next(csv_reader)  # Skip the original header
            
            for row in csv_reader:
                if not row: continue

                date_str, series_description, value_str = row[0], row[3], row[4]
                
                try:
                    date_obj = datetime.strptime(date_str, '%Y-%m-%d')
                    value = int(value_str)
                except (ValueError, IndexError) as e:
                    print(f"Warning: Could not parse row: {row}. Error: {e}. Skipping.")
                    continue
                
                filename, column_header = get_region_info(series_description)
                
                if filename not in regions_data:
                    regions_data[filename] = {
                        'data': [],
                        'header_name': column_header
                    }
                regions_data[filename]['data'].append((date_obj, value))
                
    except FileNotFoundError:
        print(f"Error: The file '{input_file_path}' was not found.")
        return
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
        return
    
    # Track South Central files for additional processing
    south_central_files = []
    
    # --- Sort data, calculate delta, and write to new files ---
    for filename, region_info in regions_data.items():
        
        # Sort data by date in ascending order
        sorted_data = sorted(region_info['data'], key=lambda item: item[0])
        
        output_path = os.path.join(output_directory, filename)
        
        try:
            with open(output_path, 'w', newline='') as f:
                writer = csv.writer(f)
                
                # Write the new, dynamic header
                value_header_name = region_info['header_name']
                writer.writerow(['datetime', value_header_name, 'Delta_Change'])
                
                # Write the data rows with the calculated delta
                previous_value = None
                for date_obj, current_value in sorted_data:
                    delta_change = ''  # Default for the first row
                    
                    if previous_value is not None:
                        delta_change = current_value - previous_value
                    
                    # Write the new row format
                    writer.writerow([date_obj.strftime('%Y-%m-%d'), current_value, delta_change])
                    
                    # Update previous_value for the next iteration
                    previous_value = current_value
                    
            print(f"Successfully processed and created {output_path}")
            
            # Check if this is a South Central file
            if "south_central" in filename:
                south_central_files.append((output_path, filename))
            
        except IOError as e:
            print(f"Error writing to file {output_path}: {e}")
    
    # Copy South Central files to Pricing_RL folders
    if south_central_files:
        print("\n" + "="*60)
        print("COPYING SOUTH CENTRAL FILES TO PRICING_RL FOLDERS")
        print("="*60)
        
        for source_path, filename in south_central_files:
            print(f"\nProcessing: {filename}")
            
            # Determine copy strategy based on filename
            if "salt" in filename.lower():
                print("  Type: Salt data → SOUTHCENTRAL_SALTS only")
            elif "nonsalt" in filename.lower():
                print("  Type: Nonsalt data → SOUTHCENTRAL and SOUTHCENTRAL_SALTS")
            else:
                print("  Type: General South Central → SOUTHCENTRAL and SOUTHCENTRAL_SALTS")
            
            copied_to = copy_to_pricing_rl_folders(source_path, filename)
            
            if copied_to:
                print(f"  ✓ Successfully copied to {len(copied_to)} location(s)")

# --- Main execution ---
if __name__ == "__main__":
    storage_directory = r"D:\EIA_STACK\granular_storage"
    input_file = os.path.join(storage_directory, "eia_granular_natural_gas_storage.csv")

    print("="*60)
    print("EIA STORAGE DATA PROCESSING")
    print("="*60)
    print(f"Input file: {input_file}")
    print(f"Output directory: {storage_directory}")
    print("\nNote: South Central files will also be copied to:")
    print("  • Salt data → SOUTHCENTRAL_SALTS")
    print("  • Nonsalt data → SOUTHCENTRAL and SOUTHCENTRAL_SALTS")
    print("="*60)
    print()

    process_and_transform_files(input_file, storage_directory)
    
    print("\n" + "="*60)
    print("FINAL SUMMARY")
    print("="*60)
    
    # Check what files were created in granular_storage
    if os.path.exists(storage_directory):
        csv_files = [f for f in os.listdir(storage_directory) if f.endswith('.csv')]
        south_central_count = sum(1 for f in csv_files if 'south_central' in f)
        other_count = len(csv_files) - south_central_count - 1  # -1 for the input file
        
        print(f"Files in granular_storage: {len(csv_files)}")
        print(f"  • South Central files: {south_central_count}")
        print(f"  • Other regional files: {other_count}")
    
    # Check Pricing_RL folders
    pricing_rl_base = r"D:\EIA_STACK\Pricing_RL"
    for folder in ["SOUTHCENTRAL", "SOUTHCENTRAL_SALTS"]:
        folder_path = os.path.join(pricing_rl_base, folder)
        if os.path.exists(folder_path):
            storage_files = [f for f in os.listdir(folder_path) 
                           if f.endswith('.csv') and 'south_central' in f]
            if storage_files:
                print(f"\n{folder}/ storage files:")
                for f in storage_files:
                    file_size = os.path.getsize(os.path.join(folder_path, f))
                    print(f"  • {f} ({file_size:,} bytes)")
    
    print("\n" + "="*60)
    print("Processing complete!")
    print("="*60)