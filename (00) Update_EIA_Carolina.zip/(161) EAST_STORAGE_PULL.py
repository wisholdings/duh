import pandas as pd
import psycopg2
import logging
import sys
import os
import re

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# PostgreSQL Database Connection Details
DB_CONFIG = {
    "host": "",
    "database": "",
    "user": "",
    "password": "",
    "port": 443
}

# East Region States (based on typical EIA East region definition)
EAST_REGION_STATES = ["NY", "PA", "NJ", "WV", "MD", "VA", "DE", "CT", "MA", "ME", "NH", "VT", "RI","NC"]

def clean_folder_name(name):
    """Cleans up a string to be used as a folder name."""
    if not isinstance(name, str):
        name = str(name)
    
    # Replace spaces with underscores
    name = name.replace(' ', '_')
    # Remove any characters that are not alphanumeric, underscores, or hyphens
    name = re.sub(r'[^\w-]+', '', name)
    return name

def fetch_and_save_pipeline_data_to_csv(tickers_to_fetch: list, output_csv_name: str, facility_name: str):
    """
    Connects to the PostgreSQL database, fetches pipeline nomination data for
    specified tickers in the East region, and saves it to a CSV file.

    Args:
        tickers_to_fetch (list): A list of ticker strings.
        output_csv_name (str): The name of the CSV file to save the data to.
        facility_name (str): The name of the storage facility for logging purposes.
    """
    if not tickers_to_fetch:
        logging.warning(f"No tickers provided for '{facility_name}'. Skipping data fetch.")
        return

    # Format the Python list of tickers and states for the SQL 'IN' clause
    formatted_tickers = ",".join(f"'{ticker}'" for ticker in tickers_to_fetch)
    formatted_states = ",".join(f"'{state}'" for state in EAST_REGION_STATES)

    # Construct the SQL query for East region states
    SQL_QUERY = f"""
    select
        meta.pipeline_name, meta.tsp, meta.tsp_short, meta.ticker, meta.loc_name, meta.loc, meta.loc_qti_id
        , meta.loc_qti_short, meta.loc_purp_desc, meta.rec_del_sign, meta.loc_zone, meta.category_short, meta.sub_category_desc
        , meta.sub_category_2_desc, meta.country_name, meta.state_name, meta.state_abb, meta.province_name, meta.offshore_block_name
        , meta.county_name, meta.latitude, meta.longitude, meta.connecting_pipeline, meta.connecting_entity, meta.storage_name, meta.storage_calc_flag
        , meta.units, noms.cycle_id, noms.cycle_desc, noms.hourly_cycle_id, noms.eff_gas_day, noms.end_eff_gas_day, noms.design_capacity
        , noms.operating_capacity, noms.scheduled_quantity, noms.scheduled_quantity * meta.rec_del_sign as scheduled_quantity_sign_adj
        , noms.operationally_available, reg.region_name as regions_criterion, reg.eia_ng_regions
    from pipelines.nomination_points noms
    inner join pipelines.metadata meta on meta.metadata_id = noms.metadata_id
    left join pipelines.regions reg on reg.state_name = meta.state_name
    where  (noms.eff_gas_day <= current_date and noms.eff_gas_day >= '1/1/2019')
    and meta.ticker in ({formatted_tickers})
    and meta.state_abb in ({formatted_states})
    order by meta.tsp_short, noms.eff_gas_day, meta.ticker;
    """

    cnxn = None
    try:
        logging.info(f"Attempting to connect to the database for '{facility_name}', file: {output_csv_name}...")
        logging.info(f"Filtering by East region states: {EAST_REGION_STATES}")

        cnxn = psycopg2.connect(**DB_CONFIG)
        logging.info("Database connection successful.")

        logging.info(f"Executing SQL query for {facility_name} with tickers: {tickers_to_fetch}...")

        df = pd.read_sql(SQL_QUERY, cnxn)
        logging.info(f"Successfully loaded {len(df)} rows for {facility_name}.")

        if len(df) == 0:
            logging.warning(f"No data fetched for '{facility_name}'. Skipping CSV creation.")
            return

        # Create the East region directory
        folder_name = "east"
        os.makedirs(folder_name, exist_ok=True)
        logging.info(f"Ensured directory '{folder_name}' exists.")

        # Construct the full output path
        full_output_path = os.path.join(folder_name, output_csv_name)

        df.to_csv(full_output_path, index=False)
        logging.info(f"Data successfully saved to {full_output_path}")

    except psycopg2.Error as e:
        logging.error(f"Database error while processing {facility_name}: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred while processing {facility_name}: {e}")
    finally:
        if cnxn:
            cnxn.close()
            logging.info(f"Database connection closed for {facility_name}.")

if __name__ == "__main__":
    # East Region Storage Facilities Configuration
    # Based on the data you provided, here are all the East region facilities
    east_storage_configs = [
        {
            "facility_name": "Accident",
            "tickers": ["PLNM.073.75131.7", "PLNM.073.75131.8"],
            "output_filename": "Accident.csv"
        },
        {
            "facility_name": "Columbia Gas Storage",
            "tickers": ["PLNM.099.STOR.7", "PLNM.099.STOR.8"],
            "output_filename": "Columbia_Gas_Storage.csv"
        },
        {
            "facility_name": "DTI Storage",
            "tickers": ["PLNM.121.10001.7", "PLNM.121.10001.8"],
            "output_filename": "DTI_Storage.csv"
        },
        {
            "facility_name": "Equitrans",
            "tickers": ["PLNM.148.90002.7", "PLNM.148.90005.7"],
            "output_filename": "Equitrans.csv"
        },
        {
            "facility_name": "Hardy",
            "tickers": ["PLNM.102.STOR.7", "PLNM.102.STOR.8"],
            "output_filename": "Hardy.csv"
        },
        {
            "facility_name": "Honeoye",
            "tickers": [
                "PLNM.016.11106.8", "PLNM.016.20526.7", 
                "PLNM.016.411106.8", "PLNM.016.420526.7"
            ],
            "output_filename": "Honeoye.csv"
        },
        {
            "facility_name": "Leidy",
            "tickers": [
                "PLNM.073.75188.7", "PLNM.073.75188.8",
                "PLNM.073.75931.7", "PLNM.073.75931.8"
            ],
            "output_filename": "Leidy.csv"
        },
        {
            "facility_name": "Lost River",
            "tickers": ["PLNM.099.LOSTRI.7", "PLNM.099.LOSTRI.8"],
            "output_filename": "Lost_River.csv"
        },
        {
            "facility_name": "North Summit",
            "tickers": ["PLNM.073.75821.7", "PLNM.073.75821.8"],
            "output_filename": "North_Summit.csv"
        },
        {
            "facility_name": "Oakford",
            "tickers": ["PLNM.073.75082.7", "PLNM.073.75082.8"],
            "output_filename": "Oakford.csv"
        },
        {
            "facility_name": "Rager Mountain",
            "tickers": ["PLNM.270.76671P.8", "PLNM.270.RMSTOAVC.7"],
            "output_filename": "Rager_Mountain.csv"
        },
        {
            "facility_name": "Saltville",
            "tickers": [
                "PLNM.070.44760.7", "PLNM.070.44766.8",
                "PLNM.070.44770.8", "PLNM.070.44777.7"
            ],
            "output_filename": "Saltville.csv"
        },
        {
            "facility_name": "Seneca Lake Gas",
            "tickers": [
                "PLNM.004.311010.7", "PLNM.004.311010.8",
                "PLNM.032.ASC1020.8", "PLNM.032.ASC1030.8",
                "PLNM.032.ASC1040.8", "PLNM.032.ASC1050.8",
                "PLNM.032.ASC1080.7", "PLNM.032.ASC1090.7",
                "PLNM.032.ASC1091.8"
            ],
            "output_filename": "Seneca_Lake_Gas.csv"
        },
        {
            "facility_name": "Steckman Ridge",
            "tickers": [
                "PLNM.072.46505.7", "PLNM.072.46505.8",
                "PLNM.072.47000.7", "PLNM.072.47000.8"
            ],
            "output_filename": "Steckman_Ridge.csv"
        },
        {
            "facility_name": "UGI",
            "tickers": [
                "PLNM.037.1006326.7", "PLNM.037.1006326.8", "PLNM.037.1006326C.8",
                "PLNM.037.20213.7", "PLNM.037.20213.8", "PLNM.037.20253.7",
                "PLNM.037.20253.8", "PLNM.037.90002.7", "PLNM.037.90002.8",
                "PLNM.037.90008.7", "PLNM.037.90008.8", "PLNM.037.WL88.7"
            ],
            "output_filename": "UGI.csv"
        },
        {
            "facility_name": "Wyckoff",
            "tickers": [
                "PLNM.140.WYCKOFF.7", "PLNM.054.421068.7", "PLNM.054.421068.8"
            ],
            "output_filename": "Wyckoff.csv"
        },
        {
            "facility_name": "NFGSC",
            "tickers": ["PLNM.140.MSTORAGEPT.1", "PLNM.140.MSTORAGEPT.2"],
            "output_filename": "NFGSC.csv"
        },
        {
            "facility_name": "Stagecoach",
            "tickers": ["PLNM.034.201020.7", "PLNM.034.201020.8"],
            "output_filename": "Stagecoach.csv"
        },
        {
            "facility_name": "Ellisburg",
            "tickers": ["PLNM.054.460011.2"],
            "output_filename": "Ellisburg.csv"
        },
        {
            "facility_name": "Steuben",
            "tickers": [
                "PLNM.004.303000.7", "PLNM.004.303000.8",
                "PLNM.231.ASC3010B.8", "PLNM.231.ASC3040B.7"
            ],
            "output_filename": "Steuben.csv"
        },
        {
            "facility_name": "Thomas Corners",
            "tickers": [
                "PLNM.004.302015.7", "PLNM.004.302015.8",
                "PLNM.233.ASC2010B.8", "PLNM.233.ASC2020D.8",
                "PLNM.233.ASC2030B.7", "PLNM.233.ASC2040B.7"
            ],
            "output_filename": "Thomas_Corners.csv"
        },
        {
            "facility_name": "Early Grove",
            "tickers": ["PLNM.070.44009.7", "PLNM.070.44147.8"],
            "output_filename": "Early_Grove.csv"
        },
        {
            "facility_name": "Pine Needle",
            "tickers": ["PLNM.109.1002270.1", "PLNM.109.1002270.2"],
            "output_filename": "Pine_Needle.csv"
        },
        {
            "facility_name": "Unknown East Facility",
            "tickers": ["PLNM.073.71655.8"],
            "output_filename": "Unknown_East_Facility.csv"
        }
    ]

    logging.info("--- Starting East Region Pipeline Data Processing ---")
    
    for config in east_storage_configs:
        facility_name = config.get('facility_name', 'Unknown')
        output_name = config.get('output_filename', 'default.csv')
        tickers = config.get('tickers', [])

        logging.info(f"\nProcessing {facility_name}...")
        logging.info(f"Tickers: {tickers}")
        logging.info(f"Output file: {output_name}")
        
        fetch_and_save_pipeline_data_to_csv(
            tickers,
            output_name,
            facility_name
        )
        
        logging.info(f"Finished processing {facility_name}.\n")

    logging.info("--- East Region Processing Completed ---")