# -*- coding: utf-8 -*-
import pandas as pd
import os
import re
import glob
import traceback
import numpy as np
import sys
# Check for Parquet engine dependency
try:
    import pyarrow
    print("PyArrow engine found.")
except ImportError:
    print("Warning: PyArrow not found. Parquet operations might be slower or fail.")

# --- Configuration ---

# Directory containing the final processed nuclear files (CSVs from previous script)
source_nuclear_dir = r'D:\EIA_STACK\Nuke_Hourly_CSVs'

# Base directory where regional folders are located
base_stack_directory = r'D:\EIA_STACK'

# Subdirectory structure within each region to find the target predict.parquet
target_subdirectory = 'final'
target_filename = 'predict.parquet'

# --- Column Name Configuration ---

# Name of the date/time column in the SOURCE (*_nuclear.csv) files
source_date_col_csv = 'datetime' # This is the aligned 'datetime' column from the previous script

# Name of the date/time column in the TARGET (predict.parquet) files
target_date_col_parquet = 'date' # This is the date column name used in predict.parquet

# Pattern for the columns to transfer from CSV to Parquet
columns_to_transfer_patterns = [
    "{REGION_UPPER}_NUCLEAR_MW",
    "{REGION_UPPER}_NUCLEAR_RATIO"
]

# --- Script Logic ---
print("--- Starting Nuclear Data Integration Script ---")
print(f"Source Nuclear CSV Directory: {source_nuclear_dir}")
print(f"Target Predict Parquet Location: {base_stack_directory}\\[region]\\{target_subdirectory}\\{target_filename}")
print(f"Source CSV Datetime Column (Aligned): '{source_date_col_csv}'")
print(f"Target Parquet Date Column: '{target_date_col_parquet}'")
print(f"Columns to Transfer/Update in Parquet (Patterns): {columns_to_transfer_patterns}")

# Check if source directory exists
if not os.path.isdir(source_nuclear_dir):
    print(f"Error: Source directory '{source_nuclear_dir}' not found. Exiting.")
    exit()

# Find all source nuclear files
source_files_pattern = os.path.join(source_nuclear_dir, '*_nuclear.csv')
source_files = glob.glob(source_files_pattern)

if not source_files:
    print(f"No '*_nuclear.csv' files found in '{source_nuclear_dir}'. Nothing to process.")
    exit()

print(f"\nFound {len(source_files)} source nuclear CSV files to process.")
process_success_count = 0
process_skip_count = 0
process_error_count = 0

# --- Process each source file ---
for source_file_path in source_files:
    try:
        source_filename = os.path.basename(source_file_path)
        if source_filename.endswith('_nuclear.csv'):
            region_base_name_lower = source_filename[:-len('_nuclear.csv')]
            region_base_name_upper = region_base_name_lower.upper()
        else:
            print(f"Skipping unexpected file in source directory: {source_filename}")
            process_skip_count += 1
            continue

        print(f"\n--- Processing Region: {region_base_name_lower} ---")
        print(f"  Source CSV: {source_file_path}")

        target_predict_path = os.path.join(base_stack_directory, region_base_name_lower, target_subdirectory, target_filename)
        print(f"  Target Parquet: {target_predict_path}")

        # 1. Check if target predict.parquet exists
        if not os.path.exists(target_predict_path):
            print(f"  Warning: Target predict.parquet '{target_predict_path}' not found. Skipping region.")
            process_skip_count += 1
            continue

        # Define the specific nuclear columns for THIS region based on patterns
        nuclear_cols_for_region = [
            pattern.format(REGION_UPPER=region_base_name_upper)
            for pattern in columns_to_transfer_patterns
        ]
        required_source_cols = [source_date_col_csv] + nuclear_cols_for_region
        print(f"  Columns to transfer from CSV: {required_source_cols}")

        # 2. Read Source Nuclear CSV
        print(f"  Reading source CSV data: {source_file_path}")
        try:
            # Check if all required columns exist in the CSV header
            temp_df_check = pd.read_csv(source_file_path, nrows=0)
            missing_cols_in_csv = [col for col in required_source_cols if col not in temp_df_check.columns]
            if missing_cols_in_csv:
                print(f"  Error: Source CSV {source_filename} missing required columns: {missing_cols_in_csv}. Skipping.")
                process_error_count += 1
                continue

            # Read only the necessary columns to save memory
            df_source = pd.read_csv(
                source_file_path, usecols=required_source_cols, parse_dates=[source_date_col_csv]
            )

            if df_source.empty:
                print(f"  Warning: Source CSV {source_filename} is empty. Skipping.")
                process_skip_count += 1
                continue

            print(f"  Read {len(df_source)} rows from source CSV.")
            # Optional: Print source date range to confirm
            print(f"  Source CSV Date Range: {df_source[source_date_col_csv].min()} to {df_source[source_date_col_csv].max()}")


        except Exception as e:
            print(f"  Error reading source CSV {source_file_path}: {e}")
            traceback.print_exc()
            process_error_count += 1
            continue

        # 3. Read Target Predict Parquet
        print(f"  Reading target predict.parquet: {target_predict_path}")
        try:
            engine_to_use = 'pyarrow' if 'pyarrow' in sys.modules else 'auto'
            # Read the entire target parquet as we don't know which other columns might be needed downstream
            df_target = pd.read_parquet(target_predict_path, engine=engine_to_use)

            # Ensure the target date column is datetime and localize to None if timezone-aware
            if target_date_col_parquet not in df_target.columns:
                 print(f"  Error: Target parquet '{target_predict_path}' does not contain the expected date column '{target_date_col_parquet}'. Skipping.")
                 process_error_count += 1
                 continue
            df_target[target_date_col_parquet] = pd.to_datetime(df_target[target_date_col_parquet])
            if df_target[target_date_col_parquet].dt.tz is not None:
                df_target[target_date_col_parquet] = df_target[target_date_col_parquet].dt.tz_localize(None)
                print(f"  Removed timezone from target Parquet '{target_date_col_parquet}'.")

            if df_target.empty:
                print(f"  Warning: Target parquet {target_predict_path} is empty. Cannot update. Skipping.")
                process_skip_count += 1
                continue

            print(f"  Read {len(df_target)} rows from target Parquet.")
             # Optional: Print target date range to confirm
            print(f"  Target Parquet Date Range: {df_target[target_date_col_parquet].min()} to {df_target[target_date_col_parquet].max()}")


        except Exception as e:
            print(f"  Error reading target parquet {target_predict_path}: {e}")
            traceback.print_exc()
            process_error_count += 1
            continue

        # 4. Prepare DataFrames for Join (Set Index & Align Datetime)

        # Ensure source date column is datetime and localize to None if timezone-aware
        if df_source[source_date_col_csv].dt.tz is not None:
            df_source[source_date_col_csv] = df_source[source_date_col_csv].dt.tz_localize(None)
            print(f"  Removed timezone from source CSV '{source_date_col_csv}'.")

        # Rename source date column to match target date column name for index alignment
        df_source_renamed = df_source.rename(columns={source_date_col_csv: target_date_col_parquet})

        # Set date columns as index for both DataFrames
        # Handle duplicates in source if necessary (take the last value for a given datetime)
        if df_source_renamed[target_date_col_parquet].duplicated().any():
             print(f"  Warning: Duplicate datetimes found in source CSV. Keeping last occurrence for update.")
             df_source_renamed = df_source_renamed.drop_duplicates(subset=[target_date_col_parquet], keep='last')

        # Use the target date column as the index for the join operation
        df_source_indexed = df_source_renamed.set_index(target_date_col_parquet)
        df_target_indexed = df_target.set_index(target_date_col_parquet)

        # 5. Perform the Join/Update
        # The .join() method on the index is ideal here.
        # It adds columns from the right (source_indexed) to the left (target_indexed)
        # aligning on the index (the date). If columns already exist, it updates.
        # We are joining df_source_indexed (which only has the nuclear columns and date index)
        # onto df_target_indexed (which has all original predict.parquet columns and date index).
        print(f"  Joining source nuclear data onto target parquet data on date index ('{target_date_col_parquet}')...")

        # Select only the nuclear columns from the source to join
        df_nuclear_data_to_join = df_source_indexed[nuclear_cols_for_region]

        # Perform the join. This adds/updates columns in df_target_indexed where index matches
        # Using suffix to help debug if columns names conflict unexpectedly, though they shouldn't here
        df_target_updated_indexed = df_target_indexed.join(df_nuclear_data_to_join, how='left', lsuffix='_left', rsuffix='_right') # Use left join to keep all rows from target parquet

        # Clean up potential suffix issues if join wasn't needed (e.g., columns already existed)
        for col in nuclear_cols_for_region:
            if f'{col}_right' in df_target_updated_indexed.columns:
                 # If the column existed and was joined, the _right one has the data from source
                 df_target_updated_indexed[col] = df_target_updated_indexed[f'{col}_right']
                 df_target_updated_indexed = df_target_updated_indexed.drop(columns=[f'{col}_left', f'{col}_right'])
            elif f'{col}_left' in df_target_updated_indexed.columns and col not in df_target_updated_indexed.columns:
                 # This case means the column existed but wasn't in the source, shouldn't happen with our column selection
                 # But as a safeguard, rename it back if needed. Though ideally df_nuclear_data_to_join ensures only source columns are joined.
                 # If the column was only in the target and wasn't in the source_indexed, join wouldn't add a _right suffix.
                 pass # No action needed, the column is already there with its original name

        # Ensure the nuclear columns are now in the DataFrame, even if they were newly added
        missing_after_join = [col for col in nuclear_cols_for_region if col not in df_target_updated_indexed.columns]
        if missing_after_join:
             # This could happen if the nuclear columns weren't in the source CSV,
             # which should have been caught by the header check earlier.
             # Or if there was an issue with the join itself.
             print(f"  Warning: Expected nuclear columns {missing_after_join} not found in DataFrame after join.")
             # Decide how to handle this - continue and save without them, or error out?
             # For now, let's just warn and proceed to save whatever was successfully joined.


        # 6. Reset Index and Save
        df_target_updated = df_target_updated_indexed.reset_index()

        print(f"  Saving updated target parquet: {target_predict_path}")
        try:
            # Ensure correct engine is used and overwrite the existing file
            engine_to_use = 'pyarrow' if 'pyarrow' in sys.modules else 'auto'
            df_target_updated.to_parquet(target_predict_path, index=False, engine=engine_to_use)
            print(f"  Successfully updated/saved '{target_filename}' for region '{region_base_name_lower}'.")
            process_success_count += 1
        except Exception as write_e:
            print(f"  Error writing target parquet '{target_predict_path}': {write_e}")
            traceback.print_exc()
            process_error_count += 1

    except Exception as outer_e:
        print(f"\nError processing file {source_file_path}: {outer_e}")
        traceback.print_exc()
        process_error_count += 1

# --- Final Summary ---
print("\n--- Nuclear Data Integration Summary ---")
print(f"Successfully processed regions: {process_success_count}")
print(f"Skipped regions (target not found, empty source/target): {process_skip_count}")
print(f"Regions with errors: {process_error_count}")

print("\nScript finished.")