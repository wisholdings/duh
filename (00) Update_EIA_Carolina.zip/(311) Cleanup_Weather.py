import pandas as pd
import os
import traceback
from collections import defaultdict

def organize_weather_data_by_region():
    """
    Reads regional weather files (historical and forecast), disaggregates them
    by region, saves them into regional subfolders, and deletes the original
    source files upon successful completion.
    """
    # --- Configuration ---
    source_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    output_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    
    print("Starting regional weather data organization process.")
    print(f"Source folder: '{os.path.abspath(source_folder)}'")
    print(f"Output folder: '{os.path.abspath(output_folder)}'")

    os.makedirs(output_folder, exist_ok=True)

    files_to_process = [
        'regional_weather.csv',
        'regional_weather_forecast_last_3_days.csv'
    ]

    # --- Processing Loop ---
    for filename in files_to_process:
        file_path = os.path.join(source_folder, filename)
        
        if not os.path.exists(file_path):
            print(f"\n[Info] File not found, skipping: {filename}")
            continue
            
        print(f"\n--- Processing file: {filename} ---")
        
        try:
            # Identify if the file is historical or forecast
            is_forecast = 'forecast' in filename
            
            # Identify date columns based on file type
            date_cols = ['DATE']
            if is_forecast:
                date_cols.append('DATE_PUBLISHED')

            df = pd.read_csv(file_path, parse_dates=date_cols)
            
            # Group columns by region
            regional_columns = defaultdict(list)
            for col in df.columns:
                if col in date_cols:
                    continue
                
                # Assumes format like 'REGION_METRIC_TYPE' (e.g., 'MIDWEST_GW_HDD')
                region = col.split('_')[0]
                regional_columns[region].append(col)

            # Process each region found
            for region, cols in regional_columns.items():
                print(f"  - Processing region: {region}")
                
                # --- Create Regional Subfolder ---
                region_folder_path = os.path.join(output_folder, region)
                os.makedirs(region_folder_path, exist_ok=True)
                
                # --- Create and Save the New DataFrame ---
                # Select date columns + the columns for the current region
                region_df = df[date_cols + cols].copy()
                
                # Rename columns to be generic (e.g., 'MIDWEST_GW_HDD' -> 'GW_HDD')
                rename_dict = {col: '_'.join(col.split('_')[1:]) for col in cols}
                region_df.rename(columns=rename_dict, inplace=True)
                
                # Define the output file path
                output_filename = "weather_forecast.csv" if is_forecast else "weather_historical.csv"
                output_path = os.path.join(region_folder_path, output_filename)
                
                region_df.to_csv(output_path, index=False)
                print(f"    - Saved data to {output_path}")

            # --- Delete the original file after successful processing ---
            os.remove(file_path)
            print(f"  ✓ Successfully processed and deleted original file: {filename}")

        except Exception as e:
            print(f"  [ERROR] Failed to process {filename}. The file will not be deleted. Reason: {e}")
            traceback.print_exc()

    print("\n--- Regional weather data organization complete! ---")
    print(f"All disaggregated files have been saved and source files have been removed.")


# --- Run the script ---
if __name__ == "__main__":
    organize_weather_data_by_region()