import pandas as pd
import json
import os
from datetime import datetime, timedelta
import numpy as np
from scipy import stats
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

# File paths
FEATURES_FILE = r"D:\EIA_STACK\Pricing_RL\PACIFIC\HTML\pacific_features_renamed.csv"
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\PACIFIC\HTML"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "pacific_gas_analytics_dashboard.html")

def load_and_prepare_data():
    """Load and prepare the data with proper date filtering."""
    print("\n" + "="*60)
    print("LOADING AND PREPARING DATA")
    print("="*60)
    
    # Load features data
    df = pd.read_csv(FEATURES_FILE)
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date').reset_index(drop=True)
    
    # Convert storage from MMCF to BCF
    storage_cols = ['Storage_Central_Valley', 'Storage_Gill_Ranch', 'Storage_Jackson_Prairie',
                    'Storage_Lodi', 'Storage_PGE', 'Storage_Socal', 'Storage_Wild_Goose']
    
    for col in storage_cols:
        df[col] = df[col] / 1000  # Convert MMCF to BCF
    
    # Find the date range with actual data (non-zero storage)
    df['total_storage'] = df[storage_cols].sum(axis=1)
    rows_with_data = df[df['total_storage'] > 0]
    
    if len(rows_with_data) > 0:
        start_date = rows_with_data['Date'].min()
        end_date = rows_with_data['Date'].max()
        print(f"Using data from {start_date.date()} to {end_date.date()}")
        df_filtered = df[(df['Date'] >= start_date) & (df['Date'] <= end_date)].copy()
    else:
        print("WARNING: No storage data found, using all data")
        df_filtered = df.copy()
    
    return df_filtered

def calculate_weekly_metrics(df):
    """Calculate weekly averages, 3-year averages, and YoY differences."""
    
    # Define columns to analyze (removed Production_Dry_Gas_BCF)
    demand_cols = ['CA_Commercial_BCF', 'CA_Industrial_BCF', 'CA_Power_Burn_BCF', 
                   'CA_Residential_BCF']
    weather_cols = ['Weather_HDD', 'Weather_Pop_CDD']
    
    all_cols = demand_cols + weather_cols
    
    # Create a proper weekly aggregation with consistent date handling
    df = df.copy()
    df['Year'] = df['Date'].dt.year
    df['Week'] = df['Date'].dt.isocalendar().week
    df['WeekStart'] = df['Date'] - pd.to_timedelta(df['Date'].dt.dayofweek, unit='days')
    
    # Group by week start date to ensure proper ordering
    weekly_data = df.groupby('WeekStart').agg({
        **{col: 'mean' for col in all_cols},
        'Year': 'first',
        'Week': 'first'
    }).reset_index()
    
    # Sort by WeekStart to ensure chronological order
    weekly_data = weekly_data.sort_values('WeekStart').reset_index(drop=True)
    
    # Calculate 3-year rolling averages and YoY differences
    results = {}
    
    for col in all_cols:
        col_data = {
            'dates': [],
            'weekly_values': [],
            'three_year_avg': [],
            'yoy_difference': [],
            'yoy_percentage': []
        }
        
        for idx, row in weekly_data.iterrows():
            current_date = row['WeekStart']
            current_year = row['Year']
            current_week = row['Week']
            current_value = row[col]
            
            # Calculate 3-year average for this week number
            three_year_data = weekly_data[
                (weekly_data['Year'].between(current_year - 3, current_year - 1)) & 
                (weekly_data['Week'] == current_week)
            ][col]
            
            three_year_avg = three_year_data.mean() if len(three_year_data) > 0 else np.nan
            
            # Calculate YoY difference
            last_year_data = weekly_data[
                (weekly_data['Year'] == current_year - 1) & 
                (weekly_data['Week'] == current_week)
            ][col]
            
            if len(last_year_data) > 0:
                last_year_value = last_year_data.iloc[0]
                yoy_diff = current_value - last_year_value
                yoy_pct = (yoy_diff / last_year_value * 100) if last_year_value != 0 else 0
            else:
                yoy_diff = np.nan
                yoy_pct = np.nan
            
            # Use consistent date format (YYYY-MM-DD)
            col_data['dates'].append(current_date.strftime('%Y-%m-%d'))
            col_data['weekly_values'].append(round(current_value, 3))
            col_data['three_year_avg'].append(round(three_year_avg, 3) if not np.isnan(three_year_avg) else None)
            col_data['yoy_difference'].append(round(yoy_diff, 3) if not np.isnan(yoy_diff) else None)
            col_data['yoy_percentage'].append(round(yoy_pct, 1) if not np.isnan(yoy_pct) else None)
        
        results[col] = col_data
    
    return results

def perform_regression_analysis(df):
    """Perform regression analysis on storage vs CA Commercial demand."""
    
    storage_cols = ['Storage_Central_Valley', 'Storage_Gill_Ranch', 'Storage_Jackson_Prairie',
                    'Storage_Lodi', 'Storage_PGE', 'Storage_Socal', 'Storage_Wild_Goose']
    
    # Prepare data for regression
    X = df[['CA_Commercial_BCF']].values
    regression_results = {}
    
    for storage_col in storage_cols:
        y = df[storage_col].values
        
        # Remove NaN values
        mask = ~(np.isnan(X).any(axis=1) | np.isnan(y))
        X_clean = X[mask]
        y_clean = y[mask]
        
        if len(X_clean) > 10:  # Need sufficient data points
            # Perform linear regression
            model = LinearRegression()
            model.fit(X_clean, y_clean)
            
            # Calculate statistics
            y_pred = model.predict(X_clean)
            r2 = model.score(X_clean, y_clean)
            
            # Calculate correlation
            correlation = np.corrcoef(X_clean.flatten(), y_clean)[0, 1]
            
            # Calculate residuals
            residuals = y_clean - y_pred
            
            # Sort by X values for proper line plotting
            sort_idx = np.argsort(X_clean.flatten())
            
            regression_results[storage_col] = {
                'slope': float(model.coef_[0]),
                'intercept': float(model.intercept_),
                'r_squared': float(r2),
                'correlation': float(correlation),
                'x_values': X_clean.flatten()[sort_idx].tolist(),
                'y_values': y_clean[sort_idx].tolist(),
                'predicted': y_pred[sort_idx].tolist(),
                'residuals': residuals[sort_idx].tolist()
            }
        else:
            regression_results[storage_col] = None
    
    return regression_results

def generate_html(weekly_metrics, regression_results, data_summary):
    """Generate the HTML dashboard."""
    
    html_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pacific Gas Analytics Dashboard</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .dashboard-container {
            max-width: 1800px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid #667eea;
        }
        
        h1 {
            color: #2d3748;
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .subtitle {
            color: #718096;
            font-size: 1.1rem;
        }
        
        .section-title {
            font-size: 1.8rem;
            color: #2d3748;
            margin: 40px 0 20px 0;
            padding-left: 15px;
            border-left: 5px solid #667eea;
        }
        
        .chart-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        
        .data-info {
            background: #e6fffa;
            border: 2px solid #38b2ac;
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
            color: #234e52;
            font-weight: 500;
        }
        
        .grid-2 {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(700px, 1fr));
            gap: 30px;
        }
        
        .regression-stats {
            background: #f7fafc;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
        }
        
        .stat-row {
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .stat-label {
            font-weight: 600;
            color: #4a5568;
        }
        
        .stat-value {
            color: #2d3748;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h1>📊 Pacific Gas Analytics Dashboard</h1>
            <div class="subtitle">Weekly Analysis with 3-Year Averages, YoY Comparisons & Regression Analytics</div>
        </div>
        
        <div class="data-info">
            📅 Data Period: ''' + data_summary['start_date'] + ''' to ''' + data_summary['end_date'] + '''<br>
            📊 Total Data Points: ''' + str(data_summary['total_points']) + ''' days (''' + str(data_summary['total_weeks']) + ''' weeks)<br>
            🔍 Analysis includes: Weekly averages, 3-year rolling averages, Year-over-Year comparisons, and regression analysis
        </div>
        
        <!-- California Demand Metrics -->
        <h2 class="section-title">⚡ California Demand Metrics</h2>
        <div id="ca_commercial_charts"></div>
        <div id="ca_industrial_charts"></div>
        <div id="ca_power_charts"></div>
        <div id="ca_residential_charts"></div>
        
        <!-- Weather -->
        <h2 class="section-title">🌡️ Weather Metrics</h2>
        <div class="grid-2">
            <div id="hdd_charts"></div>
            <div id="cdd_charts"></div>
        </div>
        
        <!-- Regression Analysis -->
        <h2 class="section-title">📈 Storage vs CA Commercial Demand Regression</h2>
        <div id="regression_section"></div>
    </div>
    
    <script>
        const weeklyMetrics = ''' + json.dumps(weekly_metrics) + ''';
        const regressionResults = ''' + json.dumps(regression_results) + ''';
        
        function createMetricCharts(metricName, containerId, displayName) {
            const data = weeklyMetrics[metricName];
            if (!data) return;
            
            const container = document.getElementById(containerId);
            container.className = 'chart-container';
            
            // Ensure dates are parsed correctly
            const dates = data.dates.map(d => new Date(d));
            
            // 1. Weekly values with 3-year average
            const trace1 = {
                x: dates,
                y: data.weekly_values,
                name: 'Weekly Average',
                type: 'scatter',
                mode: 'lines+markers',
                line: { color: '#667eea', width: 2 }
            };
            
            const trace2 = {
                x: dates,
                y: data.three_year_avg,
                name: '3-Year Average',
                type: 'scatter',
                mode: 'lines',
                line: { color: '#ef4444', width: 2, dash: 'dash' }
            };
            
            const layout1 = {
                title: displayName + ' - Weekly Values vs 3-Year Average',
                xaxis: { 
                    title: 'Date',
                    type: 'date'
                },
                yaxis: { title: 'BCF/d' },
                height: 400,
                hovermode: 'x unified'
            };
            
            const div1 = document.createElement('div');
            container.appendChild(div1);
            Plotly.newPlot(div1, [trace1, trace2], layout1, {responsive: true});
            
            // 2. YoY Difference
            const trace3 = {
                x: dates,
                y: data.yoy_difference,
                name: 'YoY Difference',
                type: 'bar',
                marker: {
                    color: data.yoy_difference.map(v => v > 0 ? '#10b981' : '#ef4444')
                }
            };
            
            const layout2 = {
                title: displayName + ' - Year-over-Year Difference',
                xaxis: { 
                    title: 'Date',
                    type: 'date'
                },
                yaxis: { title: 'BCF/d Difference' },
                height: 300,
                hovermode: 'x unified'
            };
            
            const div2 = document.createElement('div');
            container.appendChild(div2);
            Plotly.newPlot(div2, [trace3], layout2, {responsive: true});
        }
        
        function createWeatherCharts(metricName, containerId, displayName, unit) {
            const data = weeklyMetrics[metricName];
            if (!data) return;
            
            const container = document.getElementById(containerId);
            container.className = 'chart-container';
            
            // Ensure dates are parsed correctly
            const dates = data.dates.map(d => new Date(d));
            
            const trace1 = {
                x: dates,
                y: data.weekly_values,
                name: 'Weekly Average',
                type: 'scatter',
                mode: 'lines+markers',
                line: { color: '#667eea', width: 2 }
            };
            
            const trace2 = {
                x: dates,
                y: data.three_year_avg,
                name: '3-Year Average',
                type: 'scatter',
                mode: 'lines',
                line: { color: '#ef4444', width: 2, dash: 'dash' }
            };
            
            const layout = {
                title: displayName,
                xaxis: { 
                    title: 'Date',
                    type: 'date'
                },
                yaxis: { title: unit },
                height: 400,
                hovermode: 'x unified'
            };
            
            Plotly.newPlot(container, [trace1, trace2], layout, {responsive: true});
        }
        
        function createRegressionCharts() {
            const container = document.getElementById('regression_section');
            
            Object.entries(regressionResults).forEach(([storage, data]) => {
                if (!data) return;
                
                const chartDiv = document.createElement('div');
                chartDiv.className = 'chart-container';
                container.appendChild(chartDiv);
                
                // Create scatter plot with regression line
                const trace1 = {
                    x: data.x_values,
                    y: data.y_values,
                    mode: 'markers',
                    name: 'Actual',
                    type: 'scatter',
                    marker: { color: '#667eea', size: 6 }
                };
                
                const trace2 = {
                    x: data.x_values,
                    y: data.predicted,
                    mode: 'lines',
                    name: 'Regression Line',
                    type: 'scatter',
                    line: { color: '#ef4444', width: 2 }
                };
                
                const layout = {
                    title: storage.replace(/_/g, ' ') + ' vs CA Commercial Demand',
                    xaxis: { title: 'CA Commercial Demand (BCF/d)' },
                    yaxis: { title: storage.replace(/_/g, ' ') + ' (BCF)' },
                    height: 400
                };
                
                const plotDiv = document.createElement('div');
                chartDiv.appendChild(plotDiv);
                Plotly.newPlot(plotDiv, [trace1, trace2], layout, {responsive: true});
                
                // Add statistics
                const statsDiv = document.createElement('div');
                statsDiv.className = 'regression-stats';
                statsDiv.innerHTML = `
                    <div class="stat-row">
                        <span class="stat-label">R² Score:</span>
                        <span class="stat-value">${data.r_squared.toFixed(4)}</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Correlation:</span>
                        <span class="stat-value">${data.correlation.toFixed(4)}</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Slope:</span>
                        <span class="stat-value">${data.slope.toFixed(4)}</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Intercept:</span>
                        <span class="stat-value">${data.intercept.toFixed(4)}</span>
                    </div>
                `;
                chartDiv.appendChild(statsDiv);
            });
        }
        
        // Initialize all charts
        document.addEventListener('DOMContentLoaded', function() {
            // California Demand Charts
            createMetricCharts('CA_Commercial_BCF', 'ca_commercial_charts', 'CA Commercial Demand');
            createMetricCharts('CA_Industrial_BCF', 'ca_industrial_charts', 'CA Industrial Demand');
            createMetricCharts('CA_Power_Burn_BCF', 'ca_power_charts', 'CA Power Burn');
            createMetricCharts('CA_Residential_BCF', 'ca_residential_charts', 'CA Residential Demand');
            
            // Weather Charts
            createWeatherCharts('Weather_HDD', 'hdd_charts', 'Heating Degree Days', 'HDD');
            createWeatherCharts('Weather_Pop_CDD', 'cdd_charts', 'Cooling Degree Days', 'CDD');
            
            // Regression Charts
            createRegressionCharts();
        });
    </script>
</body>
</html>'''
    
    return html_template

def main():
    """Main function to generate the analytics dashboard."""
    print("="*60)
    print("PACIFIC GAS ANALYTICS DASHBOARD GENERATOR")
    print("="*60)
    
    # Load and prepare data
    df = load_and_prepare_data()
    
    # Calculate weekly metrics
    print("\nCalculating weekly metrics and comparisons...")
    weekly_metrics = calculate_weekly_metrics(df)
    
    # Perform regression analysis
    print("Performing regression analysis...")
    regression_results = perform_regression_analysis(df)
    
    # Prepare data summary
    data_summary = {
        'start_date': df['Date'].min().strftime('%Y-%m-%d'),
        'end_date': df['Date'].max().strftime('%Y-%m-%d'),
        'total_points': len(df),
        'total_weeks': len(df) // 7  # Simple week count
    }
    
    # Generate HTML
    print("Generating HTML dashboard...")
    html_content = generate_html(weekly_metrics, regression_results, data_summary)
    
    # Create output directory if it doesn't exist
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Write HTML file
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print("\n" + "="*60)
    print("✅ Analytics Dashboard generated successfully!")
    print(f"📁 Output file: {OUTPUT_FILE}")
    print(f"📊 Data period: {data_summary['start_date']} to {data_summary['end_date']}")
    print(f"📈 Total weeks analyzed: {data_summary['total_weeks']}")
    print("="*60)

if __name__ == "__main__":
    main()