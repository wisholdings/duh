import os
import pandas as pd
import sys
import glob

# --- Configuration ---
try:
    # This block allows the script to be run from different locations
    # and still find the config file.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    from config.settings import BASE_OUTPUT_DIR
    print(f"Loaded BASE_OUTPUT_DIR from config: {BASE_OUTPUT_DIR}")
except (ImportError, NameError, FileNotFoundError) as e:
    print(f"Could not import BASE_OUTPUT_DIR from config.settings ({e}). Using default.")
    BASE_OUTPUT_DIR = "D:\\EIA_STACK"
    print(f"Using default BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")

# Define the directory where the N-HiTS predictions are stored
PREDICTIONS_DIR = os.path.join(BASE_OUTPUT_DIR, "L48_Power_Burn", "Predictions")

# Define the final output file name - CHANGED to match what the SQL script expects
DAILY_OUTPUT_FILE = os.path.join(BASE_OUTPUT_DIR, "power_burns_daily_small_model.csv")

# The target column name from the N-HiTS output
TARGET_COL = "L48_Power_Burn"

def aggregate_hourly_to_daily():
    """
    Loads the latest hourly power burn forecast, aggregates it to a daily sum,
    and saves the result to a new CSV file with the exact format expected by the SQL upload script.
    """
    print("\n=========================================================")
    print("=== Aggregating Hourly Power Burn Forecast to Daily Sums ===")
    print("=========================================================")

    # 1. Find the most recent hourly prediction file
    print(f"Searching for the latest prediction file in: {PREDICTIONS_DIR}")
    
    # Create a search pattern for the files
    search_pattern = os.path.join(PREDICTIONS_DIR, "predicted_power_burn_*.csv")
    prediction_files = glob.glob(search_pattern)
    
    if not prediction_files:
        print(f"FATAL: No prediction files found matching the pattern '{search_pattern}'.")
        print("Please run the N-HiTS forecasting script first.")
        sys.exit(1)
        
    # Find the most recently modified file
    latest_prediction_file = max(prediction_files, key=os.path.getmtime)
    print(f"Found latest input file: {os.path.basename(latest_prediction_file)}")

    # 2. Load the data
    try:
        print(f"Loading hourly data...")
        df_hourly = pd.read_csv(latest_prediction_file)
        # Ensure the date column is in datetime format
        df_hourly['date'] = pd.to_datetime(df_hourly['date'])
        print(f"  Loaded {len(df_hourly)} hourly records.")
        
        if TARGET_COL not in df_hourly.columns:
            print(f"FATAL: Target column '{TARGET_COL}' not found in the input file.")
            sys.exit(1)
            
    except Exception as e:
        print(f"FATAL: Could not load or parse the input file '{latest_prediction_file}'. Error: {e}")
        sys.exit(1)
        
    # 3. Aggregate to daily sums
    print("Aggregating data to daily sums...")
    
    # Set the 'date' column as the index for resampling
    df_hourly.set_index('date', inplace=True)
    
    # Resample by day ('D') and calculate the sum
    df_daily = df_hourly[TARGET_COL].resample('D').sum().reset_index()
    
    # Round the result for cleaner output
    df_daily[TARGET_COL] = df_daily[TARGET_COL].round(3)
    
    # IMPORTANT: Rename the column to match what the SQL script expects
    df_daily.rename(columns={TARGET_COL: 'L48_Power_Burns'}, inplace=True)
    
    print(f"  Aggregation complete. Result has {len(df_daily)} daily records.")
    print(f"  Column renamed from '{TARGET_COL}' to 'L48_Power_Burns' for SQL compatibility.")

    # 4. Save the final daily file
    try:
        print(f"Saving daily data to: {DAILY_OUTPUT_FILE}")
        df_daily.to_csv(DAILY_OUTPUT_FILE, index=False, date_format='%Y-%m-%d')
        print("Successfully saved the daily power burn file.")
        print(f"File saved with columns: {list(df_daily.columns)}")
    except Exception as e:
        print(f"FATAL: Could not save the output file. Error: {e}")
        sys.exit(1)

    print("\n=========================================================")
    print("=== Script Completed Successfully ===")
    print("=== File is ready for SQL upload script ===")
    print("=========================================================")

if __name__ == "__main__":
    aggregate_hourly_to_daily()