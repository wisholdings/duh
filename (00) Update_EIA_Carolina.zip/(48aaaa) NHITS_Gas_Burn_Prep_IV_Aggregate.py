# -*- coding: utf-8 -*-
import pandas as pd
import os
import sys
from functools import reduce

# --- Configuration ---
# The base directory where all the regional folders are located
BASE_OUTPUT_DIR = "D:\\EIA_STACK"

# The final, combined output file name and path
CONSOLIDATED_OUTPUT_FILE = os.path.join(BASE_OUTPUT_DIR, "consolidated_daily_forecasts.csv")

# List of all regions to find and consolidate
REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "newyork", "northwest", "southeast", "southwest", "tennessee", "texas"
]

# --- Model parameters used to find the correct input files ---
# !!! IMPORTANT: These must EXACTLY match the parameters used in your forecasting script !!!
# If you change N_EPOCHS to 60 in the forecast script, you must change it here too.
INPUT_CHUNK_LENGTH = 168
OUTPUT_CHUNK_LENGTH = 48
N_EPOCHS = 30  # <--- MATCH THIS TO THE FORECAST SCRIPT
LOSS_NAME = "smoothl1"
NUM_STACKS = 3
LAYER_WIDTH = 128


def find_forecast_file(region_name, base_dir):
    """
    Constructs the expected filename for a region's daily forecast CSV.
    This ensures we load the correct version of the forecast.
    """
    region_upper = region_name.upper()
    target_col = f"{region_upper}_Power_Burn"
    predictions_dir = os.path.join(base_dir, region_upper, "Predictions")

    # Recreate the exact suffix from the forecasting script to find the file
    model_version_suffix = (
        f"_{target_col}_I{INPUT_CHUNK_LENGTH}_O{OUTPUT_CHUNK_LENGTH}"
        f"_E{N_EPOCHS}_S{NUM_STACKS}_W{LAYER_WIDTH}_{LOSS_NAME}_LeakageFixed"
    )
    
    expected_file = os.path.join(predictions_dir, f"predicted_power_burn_DAILY{model_version_suffix}.csv")
    
    if os.path.exists(expected_file):
        return expected_file
    
    # Return None if the exact file is not found
    return None


# --- Main Execution Block ---
if __name__ == "__main__":
    print("="*60)
    print("--- Consolidating All Regional Daily Forecasts ---")
    print("="*60)

    all_regional_dfs = []

    # 1. LOAD EACH REGIONAL FORECAST
    print("\n[1] Searching for and loading individual regional forecast files...")
    for region in REGIONS:
        forecast_file_path = find_forecast_file(region, BASE_OUTPUT_DIR)
        
        if forecast_file_path:
            try:
                df_region = pd.read_csv(forecast_file_path, parse_dates=['date'])
                
                # Dynamically find the region's BCF column (e.g., 'CAROLINA_Power_Burn_BCF')
                bcf_col = [col for col in df_region.columns if '_BCF' in col][0]
                
                # Keep only the date and BCF value, and rename the column to just the region name
                df_region_clean = df_region[['date', bcf_col]].rename(columns={bcf_col: region})
                
                all_regional_dfs.append(df_region_clean)
                print(f"    -> Successfully loaded and processed: {region.capitalize()}")
                
            except Exception as e:
                print(f"    -> WARNING: Could not read or process file for {region.capitalize()}. Reason: {e}")
        else:
            print(f"    -> WARNING: Forecast file for {region.capitalize()} not found. Skipping.")

    # 2. MERGE ALL DATAFRAMES INTO ONE
    if not all_regional_dfs:
        print("\nFATAL ERROR: No regional forecast files were found. Exiting.")
        sys.exit(1)
        
    print(f"\n[2] Merging {len(all_regional_dfs)} regional forecasts into a single file...")
    
    # Use 'reduce' to iteratively merge all dataframes in the list on the 'date' column
    # An 'outer' merge handles cases where regions might have slightly different date ranges
    consolidated_df = reduce(lambda left, right: pd.merge(left, right, on='date', how='outer'), all_regional_dfs)
    
    # Sort by date and fill any potential missing values with 0
    consolidated_df = consolidated_df.sort_values('date').reset_index(drop=True)
    consolidated_df = consolidated_df.fillna(0)

    print(f"    -> Merging complete. Consolidated shape: {consolidated_df.shape}")

    # 3. CALCULATE THE TOTAL SUM
    print("\n[3] Calculating the total power burn across all regions...")
    
    # Get a list of all regional columns (i.e., every column except 'date')
    regional_cols = [col for col in consolidated_df.columns if col != 'date']
    
    # Sum across the rows for all regional columns to create the total
    consolidated_df['Total_L48_Power_Burn_BCF'] = consolidated_df[regional_cols].sum(axis=1)
    print("    -> 'Total_L48_Power_Burn_BCF' column created.")

    # 4. SAVE THE FINAL CONSOLIDATED FILE
    print(f"\n[4] Saving the final consolidated file...")
    try:
        consolidated_df.to_csv(CONSOLIDATED_OUTPUT_FILE, index=False, float_format='%.4f')
        print(f"    -> Success! Final file saved to: {CONSOLIDATED_OUTPUT_FILE}")
    except Exception as e:
        print(f"    -> FATAL ERROR: Could not save the final file. Reason: {e}")

    print("\n" + "="*60)
    print("--- Aggregation Script Completed Successfully ---")
    print("="*60)