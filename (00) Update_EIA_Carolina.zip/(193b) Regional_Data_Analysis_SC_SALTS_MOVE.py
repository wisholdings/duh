"""
Script to rename columns in SOUTHCENTRAL_SALTS_filtered.csv to more sensible names
Loads from D:\EIA_STACK\Pricing_RL\SC_SALTS\SOUTHCENTRAL_SALTS_filtered.csv
Outputs to D:\EIA_STACK\Pricing_RL\SC_SALTS\HTML\
"""

import pandas as pd
import os
from datetime import datetime

# Define file paths
INPUT_FILE = r"D:\EIA_STACK\Pricing_RL\SOUTHCENTRAL_SALTS\SOUTHCENTRAL_SALTS_filtered.csv"
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\SOUTHCENTRAL_SALTS\HTML"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "sc_salts_features_renamed.csv")

# Column renaming dictionary
COLUMN_MAPPING = {
    'date': 'Date',
    'southcentralsal_Bistineau': 'Storage_Bistineau',
    'southcentralsal_Egan': 'Storage_Egan',
    'southcentralsal_Jefferson Island': 'Storage_Jefferson_Island',
    'southcentralsal_Moss Bluff': 'Storage_Moss_Bluff',
    'southcentralsal_Napoleonville': 'Storage_Napoleonville',
    'southcentralsal_Petal': 'Storage_Petal',
    'southcentralsal_Pine Prairie': 'Storage_Pine_Prairie',
    'southcentralsal_Tres Palacios': 'Storage_Tres_Palacios',
    'southcentralsal_TOTAL_SALT': 'Storage_Total_Salt_BCF',
    'texascommercial_TEXAS_Commercial_hourly_MMcf_BCF': 'TX_Commercial_BCF',
    'texasindustrial_TEXAS_Industrial_hourly_MMcf_BCF': 'TX_Industrial_BCF',
    'texaspowerburnp_TEXAS_Power_Burn_BCF': 'TX_Power_Burn_BCF',
    'texasresidentia_TEXAS_Residential_hourly_MMcf_BCF': 'TX_Residential_BCF',
    'synmaxproductio_DRY_GAS_BCF_DAY': 'Production_Dry_Gas_BCF',
    'weatherSOUTHCEN_gas_hdd': 'Weather_HDD',
    'weatherSOUTHCEN_population_cdd': 'Weather_Pop_CDD'
}

def main():
    """Main function to rename South Central Salts columns"""
    
    print("="*60)
    print("SOUTH CENTRAL SALTS COLUMN RENAMER")
    print("="*60)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output directory: {OUTPUT_DIR}")
    
    try:
        # 1. Load the data
        print(f"\n1. Loading data from: {INPUT_FILE}")
        df = pd.read_csv(INPUT_FILE)
        print(f"   Loaded {len(df)} rows and {len(df.columns)} columns")
        
        # 2. Display original column names
        print("\n2. Original column names:")
        for i, col in enumerate(df.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 3. Rename columns
        print("\n3. Renaming columns...")
        df_renamed = df.rename(columns=COLUMN_MAPPING)
        
        # 4. Display new column names
        print("\n4. New column names:")
        for i, col in enumerate(df_renamed.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 5. Convert date column to datetime if it exists
        if 'Date' in df_renamed.columns:
            print("\n5. Converting Date column to datetime format...")
            df_renamed['Date'] = pd.to_datetime(df_renamed['Date'])
            print(f"   Date range: {df_renamed['Date'].min().date()} to {df_renamed['Date'].max().date()}")
        
        # 6. Save the renamed file
        print(f"\n6. Saving renamed file to: {OUTPUT_FILE}")
        df_renamed.to_csv(OUTPUT_FILE, index=False, float_format='%.4f')
        print(f"   Successfully saved {len(df_renamed)} rows")
        
        # 7. Print summary statistics
        print("\n" + "="*60)
        print("SUMMARY STATISTICS")
        print("="*60)
        
        # Salt cavern storage facilities
        storage_cols = [col for col in df_renamed.columns if col.startswith('Storage_') and col != 'Storage_Total_Salt_BCF']
        if storage_cols:
            print(f"\nSalt Cavern Storage Facilities ({len(storage_cols)} total):")
            total_storage_avg = 0
            for col in storage_cols:
                mean_val = df_renamed[col].mean()
                total_storage_avg += mean_val
                print(f"  {col}: Avg = {mean_val:.2f}")
            print(f"\n  INDIVIDUAL FACILITIES TOTAL AVG: {total_storage_avg:.2f} BCF")
            
            # Check if total salt column exists
            if 'Storage_Total_Salt_BCF' in df_renamed.columns:
                print(f"  AGGREGATED TOTAL SALT AVG: {df_renamed['Storage_Total_Salt_BCF'].mean():.2f} BCF")
        
        # Texas demand
        tx_cols = [col for col in df_renamed.columns if col.startswith('TX_')]
        if tx_cols:
            print(f"\nTexas Demand Metrics:")
            total_tx_demand = 0
            for col in tx_cols:
                mean_val = df_renamed[col].mean()
                min_val = df_renamed[col].min()
                max_val = df_renamed[col].max()
                total_tx_demand += mean_val
                print(f"  {col}:")
                print(f"    Average: {mean_val:.2f} BCF")
                print(f"    Range: {min_val:.2f} to {max_val:.2f} BCF")
            print(f"\n  TOTAL TEXAS DEMAND AVG: {total_tx_demand:.2f} BCF")
        
        # Production
        if 'Production_Dry_Gas_BCF' in df_renamed.columns:
            print(f"\nProduction:")
            print(f"  Dry Gas Average: {df_renamed['Production_Dry_Gas_BCF'].mean():.2f} BCF/day")
            print(f"  Dry Gas Range: {df_renamed['Production_Dry_Gas_BCF'].min():.2f} to {df_renamed['Production_Dry_Gas_BCF'].max():.2f} BCF/day")
        
        # Weather
        weather_cols = [col for col in df_renamed.columns if col.startswith('Weather_')]
        if weather_cols:
            print("\nWeather Metrics:")
            for col in weather_cols:
                mean_val = df_renamed[col].mean()
                print(f"  {col}: Avg = {mean_val:.2f}")
        
        print("\n" + "="*60)
        print("✅ COLUMN RENAMING COMPLETE!")
        print("="*60)
        
        # Create a mapping reference file
        mapping_file = os.path.join(OUTPUT_DIR, "sc_salts_column_mapping.txt")
        print(f"\n7. Creating column mapping reference: {mapping_file}")
        
        with open(mapping_file, 'w') as f:
            f.write("SOUTH CENTRAL SALTS COLUMN MAPPING REFERENCE\n")
            f.write("=" * 60 + "\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("ORIGINAL COLUMN NAME --> NEW COLUMN NAME\n")
            f.write("-" * 60 + "\n")
            
            for old_name, new_name in COLUMN_MAPPING.items():
                f.write(f"{old_name}\n  --> {new_name}\n\n")
            
            f.write("-" * 60 + "\n")
            f.write(f"Total columns renamed: {len(COLUMN_MAPPING)}\n")
            f.write(f"Input file: {INPUT_FILE}\n")
            f.write(f"Output file: {OUTPUT_FILE}\n")
        
        print("   Column mapping reference saved")
        
        return df_renamed
        
    except FileNotFoundError as e:
        print(f"\n❌ ERROR: File not found - {e}")
        return None
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    # Run the renaming
    renamed_data = main()
    
    if renamed_data is not None:
        print(f"\n✅ Output saved to: {OUTPUT_FILE}")
    else:
        print("\n❌ Script failed. Check error messages above.")