import requests
import pandas as pd
from io import StringIO
from datetime import datetime, timedelta
import os
import time
import json
import numpy as np
import shutil

# ============================================================
# CONFIGURATION
# ============================================================
pricing_rl_dir = r'D:\EIA_STACK\Pricing_RL'
month_mapping_file = r'C:\EIA\config\month_mapping.json'

# Define regions to process
regions = ['EAST', 'MIDWEST', 'MOUNTAIN', 'PACIFIC', 'SOUTHCENTRAL']

# Special handling for SOUTHCENTRAL - also save to SOUTHCENTRAL_SALTS
southcentral_duplicate_folders = ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS']

print("="*60)
print("COMPLETE WEATHER DATA PIPELINE")
print("="*60)
print("Step 1: Fetch WSI Weather Data (Historical + Forecast)")
print("Step 2: Fill Future Dates with Historical Analogues")
print("Note: SOUTHCENTRAL data will be saved to both SOUTHCENTRAL and SOUTHCENTRAL_SALTS folders")
print("="*60)

# ============================================================
# STEP 1: FETCH WSI WEATHER DATA
# ============================================================

def get_historical_data(site_id, start_date, end_date):
    """Fetch historical weather observations for a specific region"""
    base_url = "https://www.wsitrader.com/Services/CSVDownloadService.svc/GetHistoricalObservations"
    params = {
        'Account': 'suncor',
        'profile': '',
        'password': '',
        'TempUnits': 'F',
        'HistoricalProductID': 'HISTORICAL_WEIGHTED_DEGREEDAYS',
        'DataTypes[]': ['population_cdd', 'gas_hdd'],
        'StartDate': start_date,
        'EndDate': end_date,
        'IsDisplayDates': 'true',
        'IsDaily': 'true',
        'CityIds[]': site_id
    }
    
    response = requests.get(base_url, params=params, verify=False)
    if response.status_code == 200:
        data_lines = response.text.split('\n')
        header_index = next((i for i, line in enumerate(data_lines) if "Daily Observed CDD/HDD" in line), -1)
        if header_index != -1:
            modified_data = '\n'.join(data_lines[header_index + 1:])
        else:
            modified_data = response.text
        
        data_io = StringIO(modified_data)
        df = pd.read_csv(data_io, skiprows=1)
        
        df['valid_time'] = pd.to_datetime(df['valid_time'], format='%m/%d/%Y')
        df.rename(columns={'valid_time': 'Date'}, inplace=True)
        df.set_index('Date', inplace=True)
        
        if 'site_id' in df.columns:
            df = df.drop(columns=['site_id'])
            
        print(f"    Historical data fetched: {len(df)} days")
        return df
    else:
        print(f"    Error fetching historical data: {response.status_code}")
        return None

def get_forecast_data(site_id):
    """Fetch forecast weather data for a specific region"""
    base_url = "https://www.wsitrader.com/Services/CSVDownloadService.svc/GetWeightedDegreeDayForecast"
    params = {
        'Account': 'suncor',
        'Profile': '',
        'Password': '',
        'Region': 'NA',
        'ForecastType': 'Daily',
        'DataTypes[]': ['population_cdd', 'gas_hdd'],
        'Stations[]': site_id,
        'Model': 'WSI',
        'Period': "Daily",
        'BiasCorrected': 'true'
    }
    
    response = requests.get(base_url, params=params, verify=False)
    if response.status_code == 200:
        df = pd.read_csv(StringIO(response.text), header=1)
        
        columns_to_keep = ['period_start', 'population_cdd', 'gas_hdd']
        df = df[[col for col in columns_to_keep if col in df.columns]]
        
        df.rename(columns={'period_start': 'Date'}, inplace=True)
        df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y')
        df.set_index('Date', inplace=True)
        
        if 'site_id' in df.columns:
            df = df.drop(columns=['site_id'])
        
        print(f"    Forecast data fetched: {len(df)} days")
        return df
    else:
        print(f"    Error fetching forecast data: {response.status_code}")
        return None

def fetch_wsi_weather_data(region_name, base_output_dir, save_to_multiple_folders=None):
    """Fetch and save WSI weather data for a specific region
    
    Args:
        region_name: Name of the region
        base_output_dir: Base directory for output
        save_to_multiple_folders: List of folder names to save the data to (for SOUTHCENTRAL)
    """
    print(f"\n  Fetching WSI data for {region_name}...")
    
    # Determine folders to save to
    if save_to_multiple_folders:
        folders_to_save = save_to_multiple_folders
    else:
        folders_to_save = [region_name]
    
    # Create all necessary directories
    for folder_name in folders_to_save:
        region_dir = os.path.join(base_output_dir, folder_name)
        if not os.path.exists(region_dir):
            os.makedirs(region_dir)
            print(f"    Created directory: {region_dir}")
    
    start_date = '01/01/2012'
    end_date = (datetime.now() - timedelta(days=1)).strftime('%m/%d/%Y')
    
    print(f"    Fetching historical data from {start_date} to {end_date}...")
    historical_df = get_historical_data(region_name, start_date, end_date)
    
    print(f"    Fetching forecast data...")
    forecast_df = get_forecast_data(region_name)
    
    if historical_df is not None and forecast_df is not None:
        combined_df = pd.concat([historical_df, forecast_df])
        combined_df = combined_df[~combined_df.index.duplicated(keep='last')]
        combined_df = combined_df.sort_index()
        
        print(f"    Combined: {len(combined_df)} days total")
        print(f"    Date range: {combined_df.index.min().date()} to {combined_df.index.max().date()}")
        
        # Extend the dataframe to 2027-12-31 with NaN values
        target_end_date = pd.Timestamp('2027-12-31')
        if combined_df.index.max() < target_end_date:
            future_dates = pd.date_range(
                start=combined_df.index.max() + timedelta(days=1),
                end=target_end_date,
                freq='D'
            )
            future_df = pd.DataFrame(index=future_dates, columns=combined_df.columns)
            combined_df = pd.concat([combined_df, future_df])
            print(f"    Extended with empty dates to {target_end_date.date()}")
        
        # Reset index to make Date a regular column with proper header
        combined_df = combined_df.reset_index()
        combined_df.rename(columns={'index': 'Date'}, inplace=True)
        
        # Save to all specified folders
        for folder_name in folders_to_save:
            output_filename = f'weather_{folder_name}.csv'
            output_path = os.path.join(base_output_dir, folder_name, output_filename)
            combined_df.to_csv(output_path, index=False)
            print(f"    ✓ Data saved to '{output_path}'")
        
        # Set Date back as index for return value
        combined_df.set_index('Date', inplace=True)
        return combined_df
        
    elif historical_df is not None:
        print(f"    Only historical data available for {region_name}")
        
        # Reset index to make Date a regular column
        historical_df = historical_df.reset_index()
        historical_df.rename(columns={'index': 'Date'}, inplace=True)
        
        # Save to all specified folders
        for folder_name in folders_to_save:
            output_filename = f'weather_{folder_name}.csv'
            output_path = os.path.join(base_output_dir, folder_name, output_filename)
            historical_df.to_csv(output_path, index=False)
            print(f"    ✓ Data saved to '{output_path}'")
        
        # Set Date back as index for return value
        historical_df.set_index('Date', inplace=True)
        return historical_df
        
    else:
        print(f"    ✗ Failed to fetch any data for {region_name}")
        return None

# ============================================================
# STEP 2: FILL WITH HISTORICAL ANALOGUES
# ============================================================

def fill_weather_nans_with_analogues(weather_df, month_mapping):
    """Fill NaN values in weather data using historical analogues based on month mapping."""
    df = weather_df.copy()
    
    if not pd.api.types.is_datetime64_any_dtype(df.index):
        df.index = pd.to_datetime(df.index)
    
    weather_columns = df.columns.tolist()
    print(f"    Weather columns: {weather_columns}")
    
    mask_has_nan = df[weather_columns].isna().any(axis=1)
    dates_with_nan = df[mask_has_nan].index
    
    if len(dates_with_nan) == 0:
        print(f"    No NaN values found in weather data")
        return df
    
    print(f"    Found {len(dates_with_nan)} dates with NaN values")
    print(f"    NaN date range: {dates_with_nan.min().date()} to {dates_with_nan.max().date()}")
    
    filled_count = 0
    unmapped_months = set()
    
    for future_date in dates_with_nan:
        future_month_key = future_date.strftime('%Y-%m')
        
        if future_month_key in month_mapping:
            historical_month = month_mapping[future_month_key]
            historical_year, historical_month_num = historical_month.split('-')
            historical_year = int(historical_year)
            historical_month_num = int(historical_month_num)
            
            data_found = False
            
            try:
                historical_date = pd.Timestamp(year=historical_year, 
                                             month=historical_month_num, 
                                             day=future_date.day)
                
                if historical_date in df.index:
                    historical_data = df.loc[historical_date, weather_columns]
                    if not historical_data.isna().all():
                        df.loc[future_date, weather_columns] = historical_data
                        filled_count += 1
                        data_found = True
                
            except ValueError:
                pass
            
            if not data_found:
                month_start = pd.Timestamp(year=historical_year, month=historical_month_num, day=1)
                if historical_month_num == 12:
                    month_end = pd.Timestamp(year=historical_year, month=12, day=31)
                else:
                    month_end = pd.Timestamp(year=historical_year, month=historical_month_num + 1, day=1) - timedelta(days=1)
                
                month_mask = (df.index >= month_start) & (df.index <= month_end)
                month_data = df[month_mask]
                month_data_valid = month_data[~month_data[weather_columns].isna().any(axis=1)]
                
                if not month_data_valid.empty:
                    target_day = future_date.day
                    same_day_data = month_data_valid[month_data_valid.index.day == target_day]
                    if not same_day_data.empty:
                        historical_date = same_day_data.index[0]
                    else:
                        day_diffs = abs(month_data_valid.index.day - target_day)
                        closest_idx = day_diffs.argmin()
                        historical_date = month_data_valid.index[closest_idx]
                    
                    df.loc[future_date, weather_columns] = df.loc[historical_date, weather_columns]
                    filled_count += 1
        else:
            if future_date >= pd.Timestamp('2025-08-01'):
                unmapped_months.add(future_month_key)
    
    if unmapped_months:
        print(f"    Warning: No mapping found for months: {sorted(unmapped_months)}")
    
    print(f"    Filled {filled_count} out of {len(dates_with_nan)} NaN dates with analogues")
    
    remaining_nans = df[weather_columns].isna().any(axis=1).sum()
    if remaining_nans > 0:
        print(f"    Warning: {remaining_nans} dates still have NaN values")
    
    return df

# ============================================================
# MAIN EXECUTION
# ============================================================

# Load month mapping
print(f"\nLoading month mapping from: {month_mapping_file}")
try:
    with open(month_mapping_file, 'r') as f:
        month_mapping = json.load(f)
    print(f"  Loaded {len(month_mapping)} month mappings")
    print(f"  Mapping range: {min(month_mapping.keys())} to {max(month_mapping.keys())}")
except Exception as e:
    print(f"Error loading month mapping: {e}")
    exit()

# Process each region
successful_regions = []
failed_regions = []

for region in regions:
    print(f"\n{'='*50}")
    print(f"Processing {region}")
    print(f"{'='*50}")
    
    try:
        # Determine if this region needs to be saved to multiple folders
        if region == 'SOUTHCENTRAL':
            save_folders = southcentral_duplicate_folders
            print(f"  Note: Will save to multiple folders: {save_folders}")
        else:
            save_folders = None
        
        # Step 1: Fetch WSI weather data
        print(f"\nStep 1: Fetching WSI weather data...")
        weather_df = fetch_wsi_weather_data(region, pricing_rl_dir, save_folders)
        
        if weather_df is None:
            print(f"  ✗ Failed to fetch weather data for {region}")
            failed_regions.append((region, "Failed to fetch WSI data"))
            continue
        
        # Add a small delay between API calls
        if region != regions[-1]:
            time.sleep(2)
        
        # Step 2: Fill NaNs with analogues
        print(f"\nStep 2: Filling NaN values with historical analogues...")
        filled_df = fill_weather_nans_with_analogues(weather_df, month_mapping)
        
        # Reset index to make Date a regular column
        filled_df = filled_df.reset_index()
        filled_df.rename(columns={'index': 'Date'}, inplace=True)
        
        # Save final filled data to all necessary folders
        if region == 'SOUTHCENTRAL':
            for folder_name in southcentral_duplicate_folders:
                weather_file = os.path.join(pricing_rl_dir, folder_name, f'weather_{folder_name}.csv')
                filled_df.to_csv(weather_file, index=False)
                print(f"  ✓ Final weather data saved to: {weather_file}")
        else:
            weather_file = os.path.join(pricing_rl_dir, region, f'weather_{region}.csv')
            filled_df.to_csv(weather_file, index=False)
            print(f"  ✓ Final weather data saved to: {weather_file}")
        
        # Show summary (convert back to having Date as index for calculations)
        filled_df.set_index('Date', inplace=True)
        nan_count_before = weather_df.isna().any(axis=1).sum()
        nan_count_after = filled_df.isna().any(axis=1).sum()
        print(f"\n  Summary:")
        print(f"    Total days: {len(filled_df)}")
        print(f"    Date range: {filled_df.index.min().date()} to {filled_df.index.max().date()}")
        print(f"    NaN dates before: {nan_count_before}")
        print(f"    NaN dates after: {nan_count_after}")
        print(f"    NaN dates filled: {nan_count_before - nan_count_after}")
        
        successful_regions.append(region)
        
    except Exception as e:
        print(f"  ✗ Error processing {region}: {str(e)}")
        failed_regions.append((region, str(e)))

# Final summary
print("\n" + "="*60)
print("FINAL SUMMARY")
print("="*60)

if successful_regions:
    print(f"\n✓ Successfully processed: {len(successful_regions)} regions")
    for region in successful_regions:
        print(f"  • {region}")
        if region == 'SOUTHCENTRAL':
            print(f"    (Saved to both SOUTHCENTRAL and SOUTHCENTRAL_SALTS)")

if failed_regions:
    print(f"\n✗ Failed to process: {len(failed_regions)} regions")
    for region, error in failed_regions:
        print(f"  • {region}: {error}")

print("\n" + "="*60)
print("Complete Weather Pipeline Finished!")
print("="*60)