import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import os
import glob
import sys
from datetime import datetime

# --- CONFIGURATION ---
DATA_PATH = r"D:\EIA_STACK\Pricing_RL"
DATE_COLUMN = 'Date'
RESIDUAL_COLUMN = 'Residual'
EXOG_COLUMN = 'Storage_Difference_Modelling' 
BALANCING_COLUMN = 'Balancing' # We need this to calculate the future predictor
FORECAST_HORIZON_WEEKS = 12

# =============================================================================
# 1. LOAD AND PREPARE DATA FOR ARIMAX
# =============================================================================
def load_and_prepare_data():
    """Finds the latest data file, populates the future predictor, and prepares the data."""
    print(f"📁 Searching for the latest data file in: {DATA_PATH}")
    
    list_of_files = glob.glob(os.path.join(DATA_PATH, 'gas_burns_daily_flat_file_*.csv'))
    if not list_of_files:
        print(f"❌ Error: No data files found in '{DATA_PATH}'.")
        sys.exit()
        
    latest_file = max(list_of_files, key=os.path.getctime)
    print(f"✓ Found latest file: {os.path.basename(latest_file)}")

    df_full = pd.read_csv(latest_file, parse_dates=[DATE_COLUMN])
    
    # --- THIS IS THE FIX ---
    # The ARIMAX model needs future values of the predictor. We will create them.
    # The 'Storage_Difference_Modelling' is the 7-day rolling sum of the 'Balancing' column.
    print("\n🔧 Calculating future values for the predictor variable...")
    if BALANCING_COLUMN not in df_full.columns:
        print(f"❌ Error: Required column '{BALANCING_COLUMN}' not found in the file.")
        sys.exit()
        
    # Calculate the rolling sum for the entire series. This is efficient.
    rolling_sum = df_full[BALANCING_COLUMN].rolling(window=7, min_periods=7).sum()
    
    # Fill in the missing future values of our predictor column with this calculation.
    num_missing_before = df_full[EXOG_COLUMN].isna().sum()
    df_full[EXOG_COLUMN] = df_full[EXOG_COLUMN].fillna(rolling_sum)
    num_missing_after = df_full[EXOG_COLUMN].isna().sum()
    
    print(f"✓ Populated {num_missing_before - num_missing_after} future predictor values.")

    # Now, proceed with the original logic
    df_model_data = df_full[[DATE_COLUMN, RESIDUAL_COLUMN, EXOG_COLUMN]].copy()
    df_model_data.set_index(DATE_COLUMN, inplace=True)
    
    df_weekly = df_model_data.resample('W-FRI').last()
    
    df_historical = df_weekly.dropna(subset=[RESIDUAL_COLUMN])
    df_future_exog = df_weekly[df_weekly[RESIDUAL_COLUMN].isna() & df_weekly[EXOG_COLUMN].notna()]

    print(f"\n✓ Resampled to weekly frequency (W-FRI).")
    print(f"  - Historical observations for modeling: {len(df_historical)}")
    print(f"  - Future periods with predictor found: {len(df_future_exog)}")
    
    return df_historical, df_future_exog, df_full, latest_file

# =============================================================================
# 2. BUILD AND FORECAST WITH ARIMAX MODEL
# =============================================================================
def build_and_forecast_arimax(df_hist, df_future):
    """Builds an ARIMAX model using an external predictor."""
    
    y = df_hist[RESIDUAL_COLUMN]
    X = df_hist[[EXOG_COLUMN]]
    
    test_set_size = 12
    y_train, y_test = y.iloc[:-test_set_size], y.iloc[-test_set_size:]
    X_train, X_test = X.iloc[:-test_set_size], X.iloc[-test_set_size:]
    
    print(f"\n splitting weekly data:")
    print(f"  - Training set size: {len(y_train)}")
    print(f"  - Test set size:     {len(y_test)}")

    order = (1, 1, 1)
    
    print(f"\n building ARIMAX{order} model...")
    
    model = sm.tsa.ARIMA(y_train, exog=X_train, order=order)
    model_fit = model.fit()
    print("✓ Model fitting complete.")
    print(model_fit.summary())

    print(f"\n generating forecasts...")
    X_future = df_future[[EXOG_COLUMN]].head(FORECAST_HORIZON_WEEKS)
    
    test_forecast = model_fit.get_prediction(start=y_test.index[0], end=y_test.index[-1], exog=X_test)
    future_forecast = model_fit.get_forecast(steps=len(X_future), exog=X_future)

    return y_train, y_test, X_train, X_test, test_forecast, future_forecast

# =============================================================================
# 3. SAVE AND MERGE RESULTS
# =============================================================================
def save_and_merge_results(original_df, future_forecast, original_filepath):
    """Saves forecasts and merges them back cleanly."""
    
    predictions = future_forecast.predicted_mean
    predictions.name = "Residual_Predicted"
    
    forecast_filename = os.path.join(DATA_PATH, 'residual_forecast_weekly_arimax.csv')
    predictions.to_csv(forecast_filename, header=True)
    print(f"\n💾 Saved standalone ARIMAX forecast to: {forecast_filename}")

    original_df.set_index(DATE_COLUMN, inplace=True)
    original_df['Residual_Predicted'] = None 
    original_df.update(predictions)
    original_df.reset_index(inplace=True)
    
    original_df.to_csv(original_filepath, index=False)
    print(f"✓ Updated original file with new WEEKLY ARIMAX predictions.")
    
    print("\n--- Sample of updated data with predictions ---")
    verification_df = original_df[
        original_df['Residual'].notna() | original_df['Residual_Predicted'].notna()
    ]
    print(verification_df.tail(15))

# =============================================================================
# 4. VISUALIZE THE RESULTS
# =============================================================================
def plot_results(y_train, y_test, test_forecast, future_forecast):
    """Plots the historical data, model predictions, and future forecast."""
    
    test_pred = test_forecast.predicted_mean
    test_ci = test_forecast.conf_int()
    future_pred = future_forecast.predicted_mean
    future_ci = future_forecast.conf_int()

    plt.style.use('seaborn-v0_8-whitegrid')
    plt.figure(figsize=(15, 8))

    plt.plot(y_train.index, y_train, label='Training Data (Weekly)', color='royalblue', marker='o', linestyle='-')
    plt.plot(y_test.index, y_test, label='Actual Test Data (Weekly)', color='darkorange', marker='o', linestyle='-')
    
    plt.plot(test_pred.index, test_pred, label='ARIMAX Test Forecast', color='green', linestyle='--')
    plt.fill_between(test_ci.index,
                     test_ci.iloc[:, 0],
                     test_ci.iloc[:, 1], color='green', alpha=0.15)
    
    plt.plot(future_pred.index, future_pred, label='ARIMAX Future Forecast', color='red', linestyle='--')
    plt.fill_between(future_ci.index,
                     future_ci.iloc[:, 0],
                     future_ci.iloc[:, 1], color='red', alpha=0.15, label='95% Confidence Interval')

    plt.title('Weekly ARIMAX Model - Residual Forecast', fontsize=16)
    plt.xlabel('Date', fontsize=12)
    plt.ylabel('Residual Value', fontsize=12)
    plt.legend(fontsize=10)
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.tight_layout()
    plt.show()

# =============================================================================
# MAIN EXECUTION
# =============================================================================
if __name__ == "__main__":
    df_hist, df_fut, df_orig, orig_filepath = load_and_prepare_data()
    
    y_tr, y_te, X_tr, X_te, test_fc, future_fc = build_and_forecast_arimax(df_hist, df_fut)
    
    save_and_merge_results(df_orig, future_fc, orig_filepath)
    
    print("\n📈 Displaying forecast plot...")
    plot_results(y_tr, y_te, test_fc, future_fc)
    
    print(f"\n🎉 Final ARIMAX model process complete. Ran at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")