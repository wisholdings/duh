import streamlit as st
import pandas as pd
from datetime import datetime, timedelta, date
from sqlalchemy import create_engine, text
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np

# --- ESTABLISH THE TRUE CURRENT DATE ---
TODAY = date.today()

# --- AZURE SQL DATABASE CONFIGURATION ---
AZURE_DB_CONNECTION_STRING = (
)

# --- Database Connection ---
@st.cache_resource
def get_db_engine():
    """Create and cache database engine for Azure SQL connection."""
    try:
        engine = create_engine(AZURE_DB_CONNECTION_STRING, echo=False, pool_recycle=3600)
        with engine.connect() as connection:
            connection.execute(text("SELECT 1")).scalar()
        return engine
    except Exception as e:
        st.error(f"❌ Database Connection Error: {e}")
        return None

@st.cache_data(ttl=1800)
def load_power_burns_data_with_versions():
    """Load power burns data with publication dates to track forecast versions."""
    engine = get_db_engine()
    if not engine: return None
    try:
        query = text("""
            SELECT datetime, date_published, Daily_MMCF 
            FROM [dbo].[PRODUCTION_POWER_BURNS_ST] 
            WHERE datetime >= '2019-01-01' 
            AND Daily_MMCF IS NOT NULL 
            ORDER BY datetime ASC, date_published DESC
        """)
        df = pd.read_sql_query(query, engine)
        if not df.empty:
            df['datetime'] = pd.to_datetime(df['datetime']).dt.date
            df['date_published'] = pd.to_datetime(df['date_published']).dt.date
            df['Daily_BCF'] = df['Daily_MMCF'] / 1000
            return df
        return None
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

def get_latest_forecast(df, target_date=None):
    """Get the most recent forecast for each date."""
    if target_date is None:
        target_date = TODAY
    
    # For each datetime, get the row with the latest date_published
    latest = df.loc[df.groupby('datetime')['date_published'].idxmax()]
    latest = latest.sort_values('datetime')
    
    # Calculate day-over-day changes
    latest['DoD_Change'] = latest['Daily_BCF'].diff()
    latest['DoD_Pct_Change'] = latest['Daily_BCF'].pct_change() * 100
    
    return latest

def get_forecast_comparison(df, current_publish_date, previous_publish_date, start_date, end_date):
    """Compare forecasts between two publication dates."""
    current = df[df['date_published'] == current_publish_date]
    current = current[(current['datetime'] >= start_date) & (current['datetime'] <= end_date)]
    
    previous = df[df['date_published'] == previous_publish_date]
    previous = previous[(previous['datetime'] >= start_date) & (previous['datetime'] <= end_date)]
    
    # Merge on datetime to compare
    comparison = pd.merge(
        current[['datetime', 'Daily_BCF']], 
        previous[['datetime', 'Daily_BCF']], 
        on='datetime', 
        suffixes=('_current', '_previous'),
        how='outer'
    )
    
    comparison['Forecast_Change'] = comparison['Daily_BCF_current'] - comparison['Daily_BCF_previous']
    comparison['Forecast_Change_Pct'] = (comparison['Forecast_Change'] / comparison['Daily_BCF_previous']) * 100
    
    return comparison.sort_values('datetime')

# --- EIA WEEK LOGIC ---
def get_eia_week_details(dt: date):
    """Calculates the EIA reporting week (Saturday-Friday) for a given date."""
    days_until_friday = (4 - dt.weekday() + 7) % 7
    report_friday = dt + timedelta(days=days_until_friday)
    eia_year = report_friday.year
    first_day_of_year = date(eia_year, 1, 1)
    days_to_first_friday = (4 - first_day_of_year.weekday() + 7) % 7
    first_friday_of_year = first_day_of_year + timedelta(days=days_to_first_friday)
    if report_friday < first_friday_of_year:
        return get_eia_week_details(date(eia_year - 1, 12, 31))
    week_number = ((report_friday - first_friday_of_year).days // 7) + 1
    return eia_year, week_number

# --- FORMATTING HELPERS ---
def format_bcf(value, is_forecast=False):
    if pd.isna(value): return "N/A"
    return f"{value:.2f}{' *' if is_forecast else ''}"

def format_change(value):
    if pd.isna(value): return "N/A"
    return f"{value:+.3f}"

def format_pct(value):
    if pd.isna(value): return "N/A"
    return f"{value:+.1f}%"

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="EIA Power Burns Dashboard", 
    page_icon="⚡",
    layout="wide"
)

# --- PAGE TITLE ---
st.title("⚡ EIA Power Burns Dashboard with Forecast Tracking")
st.markdown("*Natural Gas Power Generation Analysis with Forecast Version Comparison*")

# --- Load and Process Data ---
with st.spinner("Loading all historical and forecast versions..."):
    all_versions_df = load_power_burns_data_with_versions()

if all_versions_df is None or all_versions_df.empty:
    st.error("❌ No data could be loaded from the database.")
    st.stop()

# Get unique publication dates and sort them
publication_dates = sorted(all_versions_df['date_published'].unique(), reverse=True)

# --- SIDEBAR FOR FORECAST VERSION SELECTION ---
st.sidebar.header("📅 Forecast Version Control")
st.sidebar.markdown("---")

# Select current forecast version
current_pub_date = st.sidebar.selectbox(
    "Select Current Forecast Version:",
    publication_dates,
    index=0,
    format_func=lambda x: x.strftime('%Y-%m-%d'),
    help="Choose the forecast publication date to analyze"
)

# Select comparison forecast version
available_previous = [d for d in publication_dates if d < current_pub_date]
if available_previous:
    previous_pub_date = st.sidebar.selectbox(
        "Compare Against Previous Version:",
        available_previous,
        index=0,
        format_func=lambda x: x.strftime('%Y-%m-%d'),
        help="Choose a previous forecast version for comparison"
    )
    show_comparison = st.sidebar.checkbox("Show Forecast Comparison", value=True)
else:
    previous_pub_date = None
    show_comparison = False

st.sidebar.markdown("---")
st.sidebar.markdown("### 📊 Forecast Info")
st.sidebar.info(f"""
**Current Version:** {current_pub_date.strftime('%Y-%m-%d')}
**Days Since Published:** {(TODAY - current_pub_date).days}
**Total Versions Available:** {len(publication_dates)}
""")

# Get the latest forecast data
full_data = get_latest_forecast(all_versions_df)
current_version_data = all_versions_df[all_versions_df['date_published'] == current_pub_date].copy()
current_version_data = current_version_data.sort_values('datetime')
current_version_data['DoD_Change'] = current_version_data['Daily_BCF'].diff()
current_version_data['DoD_Pct_Change'] = current_version_data['Daily_BCF'].pct_change() * 100

# Split into actuals and predictions based on TODAY
actuals_df = full_data[full_data['datetime'] <= TODAY].copy()
predictions_df = full_data[full_data['datetime'] > TODAY].copy()

if actuals_df.empty:
    st.error("❌ No historical data found. Dashboard cannot be rendered.")
    st.stop()

# Get latest actual values
latest_date = actuals_df['datetime'].max()
latest_value = actuals_df.loc[actuals_df['datetime'] == latest_date, 'Daily_BCF'].iloc[0]
latest_dod_change = actuals_df.loc[actuals_df['datetime'] == latest_date, 'DoD_Change'].iloc[0]
latest_dod_pct = actuals_df.loc[actuals_df['datetime'] == latest_date, 'DoD_Pct_Change'].iloc[0]

# --- MAIN METRICS ---
st.subheader("🎯 Current Market Position")

col1, col2, col3, col4, col5 = st.columns(5)
with col1: 
    st.metric(
        "Latest Actual Burn", 
        f"{latest_value:.2f} BCF/d", 
        f"{latest_dod_change:+.2f}",
        help=f"Latest data: {latest_date}"
    )

with col2:
    st.metric(
        "Day-over-Day Change",
        format_change(latest_dod_change) + " BCF/d",
        format_pct(latest_dod_pct),
        help="Absolute and percentage change from previous day"
    )

with col3:
    # Current forecast version metrics
    current_forecast_next7 = current_version_data[
        current_version_data['datetime'].between(TODAY + timedelta(days=1), TODAY + timedelta(days=7))
    ]['Daily_BCF'].mean()
    st.metric(
        f"7-Day Forecast ({current_pub_date.strftime('%m/%d')})",
        f"{current_forecast_next7:.2f} BCF/d" if not pd.isna(current_forecast_next7) else "N/A",
        help=f"Forecast published: {current_pub_date}"
    )

with col4:
    if show_comparison and previous_pub_date:
        previous_version_data = all_versions_df[all_versions_df['date_published'] == previous_pub_date]
        previous_forecast_next7 = previous_version_data[
            previous_version_data['datetime'].between(TODAY + timedelta(days=1), TODAY + timedelta(days=7))
        ]['Daily_BCF'].mean()
        
        forecast_revision = current_forecast_next7 - previous_forecast_next7 if not pd.isna(current_forecast_next7) and not pd.isna(previous_forecast_next7) else np.nan
        
        st.metric(
            "Forecast Revision",
            f"{forecast_revision:+.3f} BCF/d" if not pd.isna(forecast_revision) else "N/A",
            f"vs {previous_pub_date.strftime('%m/%d')}",
            help="Change in 7-day forecast between versions"
        )
    else:
        st.metric("Forecast Revision", "Select comparison version")

with col5:
    # Count of forecast changes
    if show_comparison and previous_pub_date:
        comparison = get_forecast_comparison(
            all_versions_df, 
            current_pub_date, 
            previous_pub_date,
            TODAY + timedelta(days=1),
            TODAY + timedelta(days=14)
        )
        significant_changes = comparison[abs(comparison['Forecast_Change']) > 0.1]
        st.metric(
            "Significant Revisions",
            f"{len(significant_changes)} days",
            help="Days with >0.1 BCF/d forecast change"
        )
    else:
        st.metric("Significant Revisions", "N/A")

st.markdown("---")

# --- FORECAST COMPARISON SECTION ---
if show_comparison and previous_pub_date:
    st.subheader(f"🔄 Forecast Comparison: {current_pub_date.strftime('%Y-%m-%d')} vs {previous_pub_date.strftime('%Y-%m-%d')}")
    
    # Get comparison data
    comparison_df = get_forecast_comparison(
        all_versions_df,
        current_pub_date,
        previous_pub_date,
        TODAY + timedelta(days=1),
        TODAY + timedelta(days=30)
    )
    
    # Create comparison chart
    fig_comp = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.1,
        subplot_titles=("Forecast Levels Comparison", "Forecast Revisions (Current - Previous)"),
        row_heights=[0.6, 0.4]
    )
    
    # Top subplot - Both forecasts
    fig_comp.add_trace(
        go.Scatter(
            x=comparison_df['datetime'],
            y=comparison_df['Daily_BCF_previous'],
            name=f'Previous ({previous_pub_date.strftime("%m/%d")})',
            line=dict(color='gray', width=2, dash='dash'),
            hovertemplate="%{x|%b %d}: <b>%{y:.2f} BCF/d</b><extra></extra>"
        ),
        row=1, col=1
    )
    
    fig_comp.add_trace(
        go.Scatter(
            x=comparison_df['datetime'],
            y=comparison_df['Daily_BCF_current'],
            name=f'Current ({current_pub_date.strftime("%m/%d")})',
            line=dict(color='royalblue', width=3),
            hovertemplate="%{x|%b %d}: <b>%{y:.2f} BCF/d</b><extra></extra>"
        ),
        row=1, col=1
    )
    
    # Bottom subplot - Changes
    colors = ['green' if x >= 0 else 'red' for x in comparison_df['Forecast_Change'].fillna(0)]
    fig_comp.add_trace(
        go.Bar(
            x=comparison_df['datetime'],
            y=comparison_df['Forecast_Change'],
            name='Forecast Revision',
            marker_color=colors,
            hovertemplate="%{x|%b %d}: <b>%{y:+.3f} BCF/d</b> (%{customdata:.1f}%)<extra></extra>",
            customdata=comparison_df['Forecast_Change_Pct']
        ),
        row=2, col=1
    )
    
    # Add zero line to revision subplot
    fig_comp.add_hline(y=0, line_width=1, line_color="gray", opacity=0.3, row=2, col=1)
    
    # Update layout
    fig_comp.update_xaxes(title_text="Date", row=2, col=1)
    fig_comp.update_yaxes(title_text="BCF/d", row=1, col=1)
    fig_comp.update_yaxes(title_text="Revision (BCF/d)", row=2, col=1)
    
    fig_comp.update_layout(
        height=700,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.15, xanchor="center", x=0.5),
        template='plotly_white',
        hovermode='x unified'
    )
    
    st.plotly_chart(fig_comp, use_container_width=True)
    
    # Revision Statistics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### 📊 Revision Statistics")
        avg_revision = comparison_df['Forecast_Change'].mean()
        max_up_revision = comparison_df['Forecast_Change'].max()
        max_down_revision = comparison_df['Forecast_Change'].min()
        
        revision_stats = pd.DataFrame({
            'Metric': ['Average Revision', 'Max Upward', 'Max Downward', 'Total Absolute'],
            'Value': [
                f"{avg_revision:+.3f} BCF/d",
                f"{max_up_revision:+.3f} BCF/d",
                f"{max_down_revision:+.3f} BCF/d",
                f"{abs(comparison_df['Forecast_Change']).sum():.1f} BCF"
            ]
        })
        st.dataframe(revision_stats, hide_index=True, use_container_width=True)
    
    with col2:
        st.markdown("### 📅 Largest Revisions")
        top_revisions = comparison_df.nlargest(5, 'Forecast_Change', keep='all')[['datetime', 'Forecast_Change', 'Forecast_Change_Pct']]
        top_revisions_display = pd.DataFrame({
            'Date': top_revisions['datetime'].apply(lambda x: x.strftime('%Y-%m-%d')),
            'Change': top_revisions['Forecast_Change'].apply(lambda x: f"{x:+.3f}"),
            'Pct': top_revisions['Forecast_Change_Pct'].apply(lambda x: f"{x:+.1f}%")
        })
        st.dataframe(top_revisions_display, hide_index=True, use_container_width=True)
    
    with col3:
        st.markdown("### 📉 Version Drift Analysis")
        days_between = (current_pub_date - previous_pub_date).days
        st.metric("Days Between Versions", days_between)
        
        rmse = np.sqrt((comparison_df['Forecast_Change'] ** 2).mean())
        st.metric("Forecast RMSE", f"{rmse:.3f} BCF/d")
        
        directional_accuracy = (np.sign(comparison_df['Daily_BCF_current'].diff()) == np.sign(comparison_df['Daily_BCF_previous'].diff())).mean() * 100
        st.metric("Directional Agreement", f"{directional_accuracy:.1f}%")

st.markdown("---")

# --- TAB LAYOUT FOR DIFFERENT VIEWS ---
tab1, tab2, tab3, tab4 = st.tabs(["📈 Daily Forecast", "📊 DoD Changes", "🔄 Version History", "📉 Combined View"])

with tab1:
    st.subheader("Daily Forecast Chart")
    st.markdown(f"*Using forecast version: {current_pub_date.strftime('%Y-%m-%d')}*")
    
    chart_start_date = TODAY - timedelta(days=7)
    chart_end_date = TODAY + timedelta(days=14)
    
    # Prepare plot data
    plot_df = current_version_data[
        current_version_data['datetime'].between(chart_start_date, chart_end_date)
    ].copy()
    
    # Add historical reference data
    last_year_data = full_data[full_data['datetime'].apply(lambda d: d.year) == (TODAY.year - 1)].copy()
    last_year_data['month_day'] = last_year_data['datetime'].apply(lambda d: (d.month, d.day))
    plot_df['month_day'] = plot_df['datetime'].apply(lambda d: (d.month, d.day))
    plot_df = pd.merge(plot_df, last_year_data[['month_day', 'Daily_BCF']], on='month_day', 
                       suffixes=('', '_last_year'), how='left')
    
    # Create main forecast chart
    fig1 = go.Figure()
    
    # Last Year line
    fig1.add_trace(go.Scatter(
        x=plot_df['datetime'], 
        y=plot_df['Daily_BCF_last_year'], 
        name=f'{TODAY.year - 1}',
        line=dict(color='seagreen', width=2, dash='dot'),
        hovertemplate="%{x|%b %d}: <b>%{y:.2f} BCF/d</b><extra></extra>"
    ))
    
    # Current forecast line
    actual_plot = plot_df[plot_df['datetime'] <= TODAY]
    forecast_plot = plot_df[plot_df['datetime'] > TODAY]
    
    fig1.add_trace(go.Scatter(
        x=actual_plot['datetime'], 
        y=actual_plot['Daily_BCF'], 
        name=f'{TODAY.year} Actuals',
        line=dict(color='royalblue', width=3),
        hovertemplate="%{x|%b %d}: <b>%{y:.2f} BCF/d</b><extra></extra>"
    ))
    
    fig1.add_trace(go.Scatter(
        x=forecast_plot['datetime'], 
        y=forecast_plot['Daily_BCF'], 
        name=f'{TODAY.year} Forecast',
        line=dict(color='royalblue', width=3, dash='dash'),
        hovertemplate="%{x|%b %d}: <b>%{y:.2f} BCF/d</b> (Forecast)<extra></extra>"
    ))
    
    # Add previous forecast if comparison is enabled
    if show_comparison and previous_pub_date:
        previous_plot = all_versions_df[
            (all_versions_df['date_published'] == previous_pub_date) &
            (all_versions_df['datetime'].between(chart_start_date, chart_end_date))
        ]
        fig1.add_trace(go.Scatter(
            x=previous_plot['datetime'], 
            y=previous_plot['Daily_BCF'], 
            name=f'Previous Forecast ({previous_pub_date.strftime("%m/%d")})',
            line=dict(color='gray', width=2, dash='dot'),
            opacity=0.6,
            hovertemplate="%{x|%b %d}: <b>%{y:.2f} BCF/d</b> (Old)<extra></extra>"
        ))
    
    # Vertical line for Today
    fig1.add_vline(x=TODAY, line_width=1.5, line_dash="dash", line_color="black")
    fig1.add_annotation(
        x=TODAY, y=plot_df['Daily_BCF'].max() * 0.98, text="Today", showarrow=False,
        xshift=15, font=dict(color="black", size=12)
    )
    
    # Add annotation for forecast version
    fig1.add_annotation(
        text=f"Forecast Published: {current_pub_date.strftime('%Y-%m-%d')}",
        xref="paper", yref="paper",
        x=0.02, y=0.98,
        showarrow=False,
        font=dict(size=10, color="gray"),
        bgcolor="white",
        bordercolor="gray",
        borderwidth=1
    )
    
    fig1.update_layout(
        title_text="Daily Natural Gas Consumption for Electricity Generation",
        yaxis_title="Billion Cubic Feet per Day",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hovermode='x unified',
        template='plotly_white',
        height=600
    )
    st.plotly_chart(fig1, use_container_width=True)

with tab2:
    st.subheader("Day-over-Day Change Analysis")
    st.markdown(f"*Showing changes for forecast version: {current_pub_date.strftime('%Y-%m-%d')}*")
    
    # DoD chart data
    dod_chart_data = current_version_data[
        current_version_data['datetime'].between(chart_start_date, chart_end_date)
    ].copy()
    
    # Create DoD bar chart
    fig2 = go.Figure()
    
    # Split data
    actuals_dod = dod_chart_data[dod_chart_data['datetime'] <= TODAY]
    forecast_dod = dod_chart_data[dod_chart_data['datetime'] > TODAY]
    
    # Actuals bars
    fig2.add_trace(go.Bar(
        x=actuals_dod['datetime'],
        y=actuals_dod['DoD_Change'],
        name='Actual DoD Change',
        marker_color=actuals_dod['DoD_Change'].apply(lambda x: 'green' if x >= 0 else 'red'),
        hovertemplate="%{x|%b %d}: <b>%{y:+.3f} BCF/d</b><extra></extra>"
    ))
    
    # Forecast bars
    if not forecast_dod.empty:
        fig2.add_trace(go.Bar(
            x=forecast_dod['datetime'],
            y=forecast_dod['DoD_Change'],
            name='Forecast DoD Change',
            marker_color=forecast_dod['DoD_Change'].apply(lambda x: 'lightgreen' if x >= 0 else 'lightcoral'),
            opacity=0.7,
            hovertemplate="%{x|%b %d}: <b>%{y:+.3f} BCF/d</b> (Forecast)<extra></extra>"
        ))
    
    # Zero line and today marker
    fig2.add_hline(y=0, line_width=1, line_color="black", opacity=0.3)
    fig2.add_vline(x=TODAY, line_width=1.5, line_dash="dash", line_color="black")
    
    fig2.update_layout(
        title_text="Day-over-Day Changes in Power Burns",
        yaxis_title="Change (BCF/d)",
        xaxis_title="Date",
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        template='plotly_white',
        height=500,
        bargap=0.2
    )
    
    st.plotly_chart(fig2, use_container_width=True)

with tab3:
    st.subheader("📜 Forecast Version History")
    st.markdown("*Track how forecasts have evolved over time*")
    
    # Select date range for version history
    col1, col2 = st.columns(2)
    with col1:
        history_start = st.date_input(
            "Start Date for History",
            value=TODAY + timedelta(days=1),
            min_value=TODAY - timedelta(days=365),
            max_value=TODAY + timedelta(days=30)
        )
    with col2:
        history_end = st.date_input(
            "End Date for History",
            value=TODAY + timedelta(days=7),
            min_value=history_start,
            max_value=TODAY + timedelta(days=60)
        )
    
    # Get all versions for the selected date range
    versions_to_show = st.slider(
        "Number of Recent Versions to Display",
        min_value=2,
        max_value=min(10, len(publication_dates)),
        value=min(5, len(publication_dates))
    )
    
    selected_pub_dates = publication_dates[:versions_to_show]
    
    # Create version history chart
    fig_history = go.Figure()
    
    colors = ['royalblue', 'seagreen', 'orange', 'purple', 'red', 'brown', 'pink', 'gray', 'olive', 'cyan']
    
    for idx, pub_date in enumerate(selected_pub_dates):
        version_data = all_versions_df[
            (all_versions_df['date_published'] == pub_date) &
            (all_versions_df['datetime'] >= history_start) &
            (all_versions_df['datetime'] <= history_end)
        ].sort_values('datetime')
        
        if not version_data.empty:
            days_old = (TODAY - pub_date).days
            fig_history.add_trace(go.Scatter(
                x=version_data['datetime'],
                y=version_data['Daily_BCF'],
                name=f'{pub_date.strftime("%Y-%m-%d")} ({days_old}d ago)',
                line=dict(
                    color=colors[idx % len(colors)],
                    width=3 - (idx * 0.3),
                    dash='solid' if idx == 0 else 'dash' if idx < 3 else 'dot'
                ),
                opacity=1.0 - (idx * 0.1),
                hovertemplate=f"Version {pub_date.strftime('%m/%d')}<br>" + 
                             "%{x|%b %d}: <b>%{y:.2f} BCF/d</b><extra></extra>"
            ))
    
    # Add vertical line for today if in range
    if history_start <= TODAY <= history_end:
        fig_history.add_vline(x=TODAY, line_width=1.5, line_dash="dash", line_color="black")
        # --- THIS IS THE CORRECTED LINE ---
        fig_history.add_annotation(
            x=TODAY, text="Today", showarrow=False,
            yref="paper", y=0.02,
            font=dict(color="black", size=12)
        )
    
    fig_history.update_layout(
        title_text=f"Forecast Evolution: {history_start.strftime('%Y-%m-%d')} to {history_end.strftime('%Y-%m-%d')}",
        yaxis_title="BCF/d",
        xaxis_title="Forecast Date",
        height=600,
        template='plotly_white',
        hovermode='x unified',
        legend=dict(
            orientation="v",
            yanchor="top",
            y=1,
            xanchor="left",
            x=1.02
        )
    )
    
    st.plotly_chart(fig_history, use_container_width=True)
    
    # Version comparison matrix
    st.markdown("### 📊 Forecast Convergence Analysis")
    
    # Calculate average forecast for each version over the selected period
    convergence_data = []
    for pub_date in selected_pub_dates[:5]:  # Limit to 5 for clarity
        version_data = all_versions_df[
            (all_versions_df['date_published'] == pub_date) &
            (all_versions_df['datetime'] >= history_start) &
            (all_versions_df['datetime'] <= history_end)
        ]
        if not version_data.empty:
            avg_forecast = version_data['Daily_BCF'].mean()
            convergence_data.append({
                'Publication Date': pub_date.strftime('%Y-%m-%d'),
                'Days Ago': (TODAY - pub_date).days,
                'Avg Forecast': f"{avg_forecast:.3f}",
                'Min': f"{version_data['Daily_BCF'].min():.3f}",
                'Max': f"{version_data['Daily_BCF'].max():.3f}"
            })

    if convergence_data:
        convergence_df = pd.DataFrame(convergence_data)
        st.dataframe(convergence_df, use_container_width=True, hide_index=True)
    else:
        st.info("No forecast versions to compare in the selected date range.")

with tab4:
    st.subheader("Combined View: Burn Levels & Day-over-Day Changes")
    st.markdown(f"*A consolidated view of the forecast from {current_pub_date.strftime('%Y-%m-%d')}*")
    
    # Chart data
    combined_df = current_version_data[
        current_version_data['datetime'].between(chart_start_date, chart_end_date)
    ].copy()

    # Create figure with secondary y-axis
    fig4 = make_subplots(specs=[[{"secondary_y": True}]])

    # Add DoD Change bars (secondary y-axis)
    fig4.add_trace(
        go.Bar(
            x=combined_df['datetime'],
            y=combined_df['DoD_Change'],
            name='DoD Change',
            marker_color=combined_df['DoD_Change'].apply(lambda x: '#d62728' if x < 0 else '#2ca02c'), # Red/Green
            opacity=0.4
        ),
        secondary_y=True,
    )

    # Add Daily Burn line (primary y-axis)
    actual_combined = combined_df[combined_df['datetime'] <= TODAY]
    forecast_combined = combined_df[combined_df['datetime'] > TODAY]

    fig4.add_trace(
        go.Scatter(
            x=actual_combined['datetime'], 
            y=actual_combined['Daily_BCF'],
            name='Actual Burn',
            line=dict(color='navy', width=3)
        ),
        secondary_y=False,
    )

    fig4.add_trace(
        go.Scatter(
            x=forecast_combined['datetime'],
            y=forecast_combined['Daily_BCF'],
            name='Forecast Burn',
            line=dict(color='navy', width=3, dash='dash')
        ),
        secondary_y=False,
    )

    # Add Today line
    fig4.add_vline(x=TODAY, line_width=1.5, line_dash="dash", line_color="black")
    
    # Set titles and labels
    fig4.update_layout(
        title_text='Daily Power Burn with Day-over-Day Changes',
        template='plotly_white',
        hovermode='x unified',
        height=600,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    fig4.update_xaxes(title_text="Date")
    fig4.update_yaxes(title_text="<b>Daily Burn (BCF/d)</b>", secondary_y=False, color='navy')
    fig4.update_yaxes(title_text="<b>DoD Change (BCF/d)</b>", secondary_y=True, color='#d62728', showgrid=False)

    st.plotly_chart(fig4, use_container_width=True)


st.markdown("---")
st.info(f"Dashboard data last refreshed based on internal processes. Current system date: {TODAY.strftime('%Y-%m-%d')}")