#!/usr/bin/env python3
# =============================================================================
# STORAGE TRUE-UP AND PROJECTION RECONCILIATION (IMPROVED VERSION)
# Combines pipe scrape model (weekly EIA) with ML regression model
# Uses an "Anchor and Forward Fill" method for more robust projections.
# =============================================================================
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import glob
import re
import warnings
warnings.filterwarnings('ignore')

# --- CONFIGURATION ---
AGGREGATE_PATH = r"D:\EIA_STACK\Pricing_RL\AGGREGATE"
PIPE_FILE = "lower_48_combined_pipe.csv"
# --- NEW: Configurable blending weights for future projections ---
BLENDING_WEIGHT_PIPE = 0.6  # Weight for the pipe model's delta (e.g., 60%)
BLENDING_WEIGHT_ML = 1.0 - BLENDING_WEIGHT_PIPE # Weight for the ML model's delta (e.g., 40%)


# =============================================================================
# HELPER FUNCTIONS (No changes here)
# =============================================================================
def align_dates(df):
    """Ensure dates are in datetime format and sorted"""
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'])
    elif 'datetime' in df.columns:
        df['Date'] = pd.to_datetime(df['datetime'])
        df = df.drop('datetime', axis=1)
    
    df = df.sort_values('Date').reset_index(drop=True)
    return df

def calculate_seasonal_adjustment(historical_diff, window=91):
    """Calculate seasonal adjustment factors from historical differences"""
    historical_diff['DayOfYear'] = historical_diff['Date'].dt.dayofyear
    seasonal_adj = historical_diff.groupby('DayOfYear')['Difference'].agg(
        [('mean', 'mean'), ('std', 'std'), ('count', 'count')]
    ).reset_index()
    seasonal_adj = seasonal_adj.sort_values('DayOfYear')
    seasonal_adj['smoothed_mean'] = seasonal_adj['mean'].rolling(
        window=15, center=True, min_periods=1
    ).mean()
    return seasonal_adj

def apply_seasonal_correction(df, seasonal_adj):
    """Apply seasonal corrections to storage values"""
    df['DayOfYear'] = df['Date'].dt.dayofyear
    df = df.merge(
        seasonal_adj[['DayOfYear', 'smoothed_mean']], 
        on='DayOfYear', 
        how='left'
    )
    df['smoothed_mean'] = df['smoothed_mean'].fillna(0)
    return df

def find_latest_l48_file(aggregate_path):
    """Find the latest L48_YYYYMMDD.csv file"""
    l48_pattern = os.path.join(aggregate_path, "L48_????????.csv")
    l48_files = glob.glob(l48_pattern)
    date_pattern = re.compile(r'L48_(\d{8})\.csv$')
    valid_files = [f for f in l48_files if date_pattern.match(os.path.basename(f))]
    
    if not valid_files:
        return None, None
        
    latest_file = max(valid_files)
    match = date_pattern.match(os.path.basename(latest_file))
    file_date = match.group(1) if match else None
    
    return latest_file, file_date

# =============================================================================
# MAIN TRUE-UP FUNCTION
# =============================================================================
def perform_storage_trueup():
    """Perform true-up between pipe scrape and ML models"""
    
    print("\n" + "=" * 80)
    print("STORAGE TRUE-UP AND PROJECTION RECONCILIATION (IMPROVED)")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    
    try:
        # --- STEPS 1-4: Data Loading and Analysis (Largely unchanged) ---
        
        # STEP 1: Load Pipe Scrape Data
        print("\n" + "=" * 60)
        print("STEP 1: LOADING PIPE SCRAPE DATA (Weekly EIA)")
        print("=" * 60)
        pipe_path = os.path.join(AGGREGATE_PATH, PIPE_FILE)
        if not os.path.exists(pipe_path):
            print(f"  ✗ Pipe file not found: {pipe_path}"); return False, None
        pipe_df = pd.read_csv(pipe_path)
        pipe_df = align_dates(pipe_df)
        pipe_df = pipe_df.rename(columns={'Lower_48_Total': 'Pipe_Storage', 'Delta_Change': 'Pipe_Delta'})
        print(f"  ✓ Loaded {len(pipe_df)} records from pipe scrape")

        # STEP 2: Load ML Model Data
        print("\n" + "=" * 60)
        print("STEP 2: LOADING ML MODEL DATA")
        print("=" * 60)
        latest_l48, file_date = find_latest_l48_file(AGGREGATE_PATH)
        if latest_l48 is None:
            print(f"  ✗ No L48_YYYYMMDD.csv files found in {AGGREGATE_PATH}"); return False, None
        print(f"  Found L48 file: {os.path.basename(latest_l48)}")
        ml_df = pd.read_csv(latest_l48)
        ml_df = align_dates(ml_df)
        print(f"  ✓ Loaded {len(ml_df)} records from ML model")

        # STEP 3: Merging and Pre-processing
        print("\n" + "=" * 60)
        print("STEP 3: MERGING AND PRE-PROCESSING")
        print("=" * 60)
        merged_df = ml_df.merge(pipe_df[['Date', 'Pipe_Storage', 'Pipe_Delta']], on='Date', how='outer')
        merged_df = merged_df.sort_values('Date').reset_index(drop=True)
        merged_df['ML_Storage'] = merged_df['storage_lower_48_bcf'].fillna(merged_df['Implied_Storage'])
        print(f"  ✓ Merged dataset: {len(merged_df)} total records")
        
        # STEP 4: Calculating Adjustment Factors
        print("\n" + "=" * 60)
        print("STEP 4: CALCULATING SEASONAL ADJUSTMENT FACTORS")
        print("=" * 60)
        comparison_mask = merged_df['Pipe_Storage'].notna() & merged_df['ML_Storage'].notna()
        merged_df['Model_Difference'] = np.nan
        merged_df.loc[comparison_mask, 'Model_Difference'] = merged_df.loc[comparison_mask, 'Pipe_Storage'] - merged_df.loc[comparison_mask, 'ML_Storage']
        historical_diff = merged_df[comparison_mask & merged_df['storage_lower_48_bcf'].notna()][['Date', 'Model_Difference']].rename(columns={'Model_Difference': 'Difference'})

        if len(historical_diff) > 0:
            print(f"  Historical comparison period: {len(historical_diff)} records")
            seasonal_adj = calculate_seasonal_adjustment(historical_diff)
            print(f"  ✓ Calculated seasonal adjustment factors")
        else:
            print(f"  ⚠ No historical overlap for adjustment calculation")
            seasonal_adj = pd.DataFrame({'DayOfYear': range(1, 367), 'smoothed_mean': 0})
        
        merged_df = apply_seasonal_correction(merged_df, seasonal_adj)
        merged_df['ML_Storage_Adjusted'] = merged_df['ML_Storage'] + merged_df['smoothed_mean']

        # --- STEP 5: Creating Historical True-Up ---
        print("\n" + "=" * 60)
        print("STEP 5: CREATING HISTORICAL TRUE-UP (Pre-Projection)")
        print("=" * 60)
        merged_df['Trueup_Storage'] = np.nan
        merged_df['Source'] = 'None'
        
        # Priority 1: Pipe scrape data
        pipe_mask = merged_df['Pipe_Storage'].notna()
        merged_df.loc[pipe_mask, 'Trueup_Storage'] = merged_df.loc[pipe_mask, 'Pipe_Storage']
        merged_df.loc[pipe_mask, 'Source'] = 'Pipe_Scrape'

        # Priority 2: Recent actual EIA data (if not already filled by pipe)
        eia_mask = merged_df['storage_lower_48_bcf'].notna() & merged_df['Trueup_Storage'].isna()
        merged_df.loc[eia_mask, 'Trueup_Storage'] = merged_df.loc[eia_mask, 'storage_lower_48_bcf']
        merged_df.loc[eia_mask, 'Source'] = 'EIA_Actual'

        # Priority 3: Fill any remaining historical gaps with adjusted ML
        ml_historical_mask = merged_df['Trueup_Storage'].isna() & merged_df['ML_Storage_Adjusted'].notna()
        merged_df.loc[ml_historical_mask, 'Trueup_Storage'] = merged_df.loc[ml_historical_mask, 'ML_Storage_Adjusted']
        merged_df.loc[ml_historical_mask, 'Source'] = 'ML_Adjusted_Fill'
        print("  ✓ Populated historical data based on source priority.")

        # --- STEP 6: FORWARD PROJECTION FROM LAST KNOWN ACTUAL (NEW LOGIC) ---
        print("\n" + "=" * 60)
        print("STEP 6: CREATING BLENDED FORWARD PROJECTION")
        print("=" * 60)
        
        # Find the anchor point: the last day with reliable data
        last_actual_mask = merged_df['Trueup_Storage'].notna() & (merged_df['Source'].isin(['Pipe_Scrape', 'EIA_Actual']))
        if not last_actual_mask.any():
            print("  ✗ Cannot create projection: No reliable anchor point found.")
        else:
            anchor_index = merged_df[last_actual_mask].index[-1]
            anchor_date = merged_df.loc[anchor_index, 'Date']
            anchor_value = merged_df.loc[anchor_index, 'Trueup_Storage']
            
            print(f"  Anchor point found:")
            print(f"    Date: {anchor_date.date()}, Value: {anchor_value:,.0f} BCF, Source: {merged_df.loc[anchor_index, 'Source']}")
            
            # --- Blend the DELTAs for all future dates ---
            projection_mask = merged_df.index > anchor_index
            
            # Use ML delta as a base, then blend with pipe delta where available
            ml_delta_col = 'storage_delta' # Assuming this is the delta from the ML model
            
            # Fill NaNs in deltas with 0 to allow for blending
            pipe_delta = merged_df.loc[projection_mask, 'Pipe_Delta'].fillna(0)
            ml_delta = merged_df.loc[projection_mask, ml_delta_col].fillna(0)

            # Calculate the weighted average delta
            blended_delta = (pipe_delta * BLENDING_WEIGHT_PIPE) + (ml_delta * BLENDING_WEIGHT_ML)
            
            # Project forward from the anchor value using the cumulative sum of blended deltas
            projected_values = anchor_value + blended_delta.cumsum()
            
            merged_df.loc[projection_mask, 'Trueup_Storage'] = projected_values
            merged_df.loc[projection_mask, 'Source'] = 'Blended_Projection'
            
            print(f"  ✓ Created blended projection for {projection_mask.sum()} days.")
            print(f"  Projection uses weights: Pipe={BLENDING_WEIGHT_PIPE*100}%, ML={BLENDING_WEIGHT_ML*100}%")

        # --- STEP 7: Finalization and Validation ---
        print("\n" + "=" * 60)
        print("STEP 7: FINALIZING OUTPUT AND VALIDATING")
        print("=" * 60)
        
        # Recalculate all deltas for consistency
        merged_df['Trueup_Delta'] = merged_df['Trueup_Storage'].diff()
        
        # Set Confidence levels
        confidence_map = {
            'Pipe_Scrape': 'High',
            'EIA_Actual': 'High',
            'Blended_Projection': 'Medium-High',
            'ML_Adjusted_Fill': 'Medium',
            'None': 'Low'
        }
        merged_df['Confidence'] = merged_df['Source'].map(confidence_map).fillna('Low')
        
        print("\n  Data Source Summary:")
        print(merged_df['Source'].value_counts().to_string())
        
        # Validation checks
        print("\n  Validation Checks:")
        large_deltas = merged_df[merged_df['Trueup_Delta'].abs() > 50]
        if not large_deltas.empty: print(f"    ⚠ {len(large_deltas)} days with |delta| > 50 BCF")
        else: print("    ✓ All deltas within reasonable range")
        
        gaps = merged_df[merged_df['Date'].diff().dt.days > 1]
        if not gaps.empty: print(f"    ⚠ {len(gaps)} gaps in daily data")
        else: print("    ✓ No gaps in daily sequence")

        # --- STEP 8: Saving Results ---
        print("\n" + "=" * 60)
        print("STEP 8: SAVING TRUE-UP RESULTS")
        print("=" * 60)
        
        save_columns = [
            'Date', 'Trueup_Storage', 'Trueup_Delta', 'Confidence', 'Source',
            'Pipe_Storage', 'Pipe_Delta', 'ML_Storage', 'storage_delta',
            'ML_Storage_Adjusted', 'Model_Difference', 'smoothed_mean',
            'storage_lower_48_bcf', 'Implied_Storage', 'gas_hdd', 'population_cdd',
            'LNG_EXPORTS_BCF', 'MEX_EXPORTS_BCF', 'production_bcf', 'L48_Power_Burns'
        ]
        output_df = merged_df[[col for col in save_columns if col in merged_df.columns]]
        
        output_file = os.path.join(AGGREGATE_PATH, "Blending_Model.csv")
        if os.path.exists(output_file):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(AGGREGATE_PATH, f"Blending_Model_backup_{timestamp}.csv")
            os.rename(output_file, backup_file)
            print(f"  ✓ Renamed existing file to backup: {os.path.basename(backup_file)}")

        output_df.to_csv(output_file, index=False)
        print(f"  ✓ Saved to: Blending_Model.csv")
        
        # (Summary report generation code is omitted for brevity but would be included here)
        
        return True, output_df
    
    except Exception as e:
        print(f"\n  ✗ Error occurred: {str(e)}")
        import traceback
        traceback.print_exc()
        return False, None

# =============================================================================
# MAIN EXECUTION (No changes here)
# =============================================================================
def main():
    """Execute the storage true-up process"""
    
    success, result_df = perform_storage_trueup()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ STORAGE TRUE-UP COMPLETE!")
        print("\nKey Results:")
        print("  • Combined pipe scrape (weekly EIA) with ML model")
        print("  • Applied seasonal adjustments based on historical patterns")
        print("  • Created blended projections anchored to the last known actual value")
        print("  • Generated confidence levels for each data point")
    else:
        print("✗ STORAGE TRUE-UP FAILED!")
    
    print("=" * 80)
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()