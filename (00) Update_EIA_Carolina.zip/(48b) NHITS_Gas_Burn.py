# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from darts import TimeSeries
from darts.models import NHiTSModel
from darts.dataprocessing.transformers import Scaler as DartsScaler
import torch
from pytorch_lightning.callbacks import EarlyStopping
import matplotlib.pyplot as plt
import os
import joblib
import time
import traceback
import sys
import json

# --- Configuration ---
BASE_OUTPUT_DIR = "D:\\EIA_STACK"
TARGET_COL = "L48_Power_Burn"

# --- File Paths ---
INPUT_FILE = os.path.join(BASE_OUTPUT_DIR, "NHITS_POWER.csv")
MODELS_DIR = os.path.join(BASE_OUTPUT_DIR, "L48_Power_Burn", "Models")
PREDICTIONS_DIR = os.path.join(BASE_OUTPUT_DIR, "L48_Power_Burn", "Predictions_Normal")

# --- Model Parameters & Config ---
LOSS_FN_CONFIG = torch.nn.SmoothL1Loss()
LOSS_NAME = "smoothl1"
PATIENCE_CONFIG = 5
INPUT_CHUNK_LENGTH = 168  # Use 1 week of history to predict
OUTPUT_CHUNK_LENGTH = 24  # Predict 3 days at a time
N_EPOCHS = 80
RANDOM_STATE = 42
LEARNING_RATE = 1e-5
BATCH_SIZE = 128
DROPOUT = 0.1
GRADIENT_CLIP_VAL = 0.1

# --- NHiTS Architecture ---
NUM_STACKS = 5
NUM_BLOCKS = 4
NUM_LAYERS = 4
LAYER_WIDTH = 200

# --- Boundary Handling Parameters ---
BRIDGE_HOURS = INPUT_CHUNK_LENGTH  # Use the model's input chunk length for a perfect bridge
BOUNDARY_SMOOTH_HOURS = 24 # Smooth the first 24 hours of the forecast

# --- Output File Naming ---
MODEL_VERSION_SUFFIX = f"_{TARGET_COL}_I{INPUT_CHUNK_LENGTH}_O{OUTPUT_CHUNK_LENGTH}_E{N_EPOCHS}_S{NUM_STACKS}_W{LAYER_WIDTH}_{LOSS_NAME}"
MODEL_SAVE_PATH = os.path.join(MODELS_DIR, f"nhits_model{MODEL_VERSION_SUFFIX}.pt")
OUTPUT_FILE = os.path.join(PREDICTIONS_DIR, f"predicted_power_burn{MODEL_VERSION_SUFFIX}.csv")
PLOT_FILE = os.path.join(PREDICTIONS_DIR, f"predicted_power_burn{MODEL_VERSION_SUFFIX}.png")
TARGET_SCALER_SAVE_PATH = os.path.join(MODELS_DIR, f"target_scaler{MODEL_VERSION_SUFFIX}.pkl")
COVARIATE_SCALER_SAVE_PATH = os.path.join(MODELS_DIR, f"covariate_scaler{MODEL_VERSION_SUFFIX}.pkl")
SCALER_INFO_SAVE_PATH = os.path.join(MODELS_DIR, f"scaler_info{MODEL_VERSION_SUFFIX}.joblib")

# --- General Config ---
FORCE_RETRAIN_NHITS = False # Set to True to always retrain the model

# Ensure directories exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(PREDICTIONS_DIR, exist_ok=True)

# --- Print Configuration ---
print("="*50)
print(f"--- N-HiTS L48 POWER BURN FORECASTING ---")
print("="*50)
print(f"Target Column: {TARGET_COL}")
print(f"Input File: {INPUT_FILE}")
print(f"Model Config: Loss={LOSS_NAME}, Input={INPUT_CHUNK_LENGTH}, Output={OUTPUT_CHUNK_LENGTH}")
print(f"Architecture: Stacks={NUM_STACKS}, Width={LAYER_WIDTH}")
print(f"Training will be forced: {FORCE_RETRAIN_NHITS}")
print("="*50)

# --- Feature Engineering Functions ---
def create_time_features(df, date_col='date'):
    """Creates time-based cyclical and categorical features."""
    dt = df[date_col].dt
    features = {
        'hour_sin': np.sin(2 * np.pi * dt.hour / 24),
        'hour_cos': np.cos(2 * np.pi * dt.hour / 24),
        'weekday_sin': np.sin(2 * np.pi * dt.dayofweek / 7),
        'weekday_cos': np.cos(2 * np.pi * dt.dayofweek / 7),
        'month_sin': np.sin(2 * np.pi * dt.month / 12),
        'month_cos': np.cos(2 * np.pi * dt.month / 12),
        'weekend': dt.dayofweek.isin([5, 6]).astype(int)
    }
    time_features_df = pd.DataFrame(features, index=df.index)
    return pd.concat([df, time_features_df], axis=1)

# --- Main Execution Block ---
if __name__ == "__main__":
    # 1. LOAD AND PREPARE DATA
    print("\n--- Loading and Preparing Data ---")
    try:
        df_full = pd.read_csv(INPUT_FILE)
        df_full['date'] = pd.to_datetime(df_full['date'])
        df_full = df_full.sort_values("date").reset_index(drop=True)
        print(f"Loaded data shape: {df_full.shape}")
    except Exception as e:
        print(f"FATAL: Could not load input file {INPUT_FILE}. Error: {e}"); sys.exit(1)

    # Perform Feature Engineering on the entire dataset
    print("Performing feature engineering...")
    df_full = create_time_features(df_full)

    # Identify covariates (all columns except date and target)
    covariate_cols = [col for col in df_full.columns if col not in ['date', TARGET_COL]]
    print(f"Identified {len(covariate_cols)} covariate features.")

    # Fill any NaNs in covariates using forward-fill then backward-fill
    print("Filling NaNs in covariates...")
    df_full[covariate_cols] = df_full[covariate_cols].ffill().bfill()
    if df_full[covariate_cols].isnull().any().any():
        print("Warning: NaNs still present in covariates after ffill/bfill. Filling with 0.")
        df_full[covariate_cols] = df_full[covariate_cols].fillna(0)

    # 2. SPLIT DATA INTO TRAIN AND PREDICT SETS
    # The split point is the first index where the target is NaN
    first_nan_index = df_full[TARGET_COL].isnull().idxmax()
    if first_nan_index == 0 and not df_full[TARGET_COL].isnull().iloc[0]: # No NaNs found
        print("No future data to predict (target column is fully populated). Exiting.")
        sys.exit(0)
    
    split_point = df_full.index[first_nan_index]
    
    df_train = df_full.iloc[:split_point].copy()
    df_predict = df_full.iloc[split_point:].copy()
    
    train_end_date = df_train['date'].max()
    predict_start_date = df_predict['date'].min()

    print(f"\nData split complete:")
    print(f"  Training data from {df_train['date'].min()} to {train_end_date} ({len(df_train)} hours)")
    print(f"  Prediction period from {predict_start_date} to {df_predict['date'].max()} ({len(df_predict)} hours)")

    # 3. CREATE AND SCALE DARTS TIMESERIES
    print("\n--- Creating and Scaling TimeSeries ---")
    
    # Target Series (only for training data)
    target_series = TimeSeries.from_dataframe(df_train, 'date', TARGET_COL, freq='h')
    
    # Covariate Series (for the entire dataset)
    covariate_series = TimeSeries.from_dataframe(df_full, 'date', covariate_cols, freq='h')

    # Scalers
    target_scaler = DartsScaler(StandardScaler())
    covariate_scaler = DartsScaler(StandardScaler())
    
    # Fit and transform
    target_series_scaled = target_scaler.fit_transform(target_series)
    covariate_series_scaled = covariate_scaler.fit_transform(covariate_series)

    # Save scalers for later use
    joblib.dump(target_scaler, TARGET_SCALER_SAVE_PATH)
    joblib.dump(covariate_scaler, COVARIATE_SCALER_SAVE_PATH)
    print(f"Target and Covariate scalers saved to {MODELS_DIR}")
    
    # 4. TRAIN THE N-HITS MODEL
    model_exists = os.path.exists(MODEL_SAVE_PATH)
    if model_exists and not FORCE_RETRAIN_NHITS:
        print(f"\n--- Loading Existing Model ---")
        model = NHiTSModel.load(MODEL_SAVE_PATH)
        print("Model loaded successfully.")
    else:
        print(f"\n--- Training N-HiTS Model ---")
        if model_exists: print("Force retrain is TRUE. Retraining model.")
        
        early_stopper = EarlyStopping("train_loss", patience=PATIENCE_CONFIG, min_delta=0.0001, verbose=True)
        
        model = NHiTSModel(
            input_chunk_length=INPUT_CHUNK_LENGTH,
            output_chunk_length=OUTPUT_CHUNK_LENGTH,
            n_epochs=N_EPOCHS,
            random_state=RANDOM_STATE,
            num_stacks=NUM_STACKS,
            num_blocks=NUM_BLOCKS,
            num_layers=NUM_LAYERS,
            layer_widths=LAYER_WIDTH,
            dropout=DROPOUT,
            loss_fn=LOSS_FN_CONFIG,
            optimizer_kwargs={"lr": LEARNING_RATE},
            batch_size=BATCH_SIZE,
            pl_trainer_kwargs={
                "accelerator": "auto",
                "callbacks": [early_stopper],
                "gradient_clip_val": GRADIENT_CLIP_VAL
            },
            force_reset=True
        )
        
        start_train_time = time.time()
        model.fit(
            series=target_series_scaled,
            past_covariates=covariate_series_scaled,
            verbose=True
        )
        end_train_time = time.time()
        print(f"Training completed in {(end_train_time - start_train_time)/60:.2f} minutes.")
        
        print(f"Saving model to {MODEL_SAVE_PATH}")
        model.save(MODEL_SAVE_PATH)

    # 5. GENERATE PREDICTIONS
    print("\n--- Generating Predictions ---")
    
    # The number of time steps to predict is the length of the future dataframe
    n_predict = len(df_predict)
    
    # Use the last `input_chunk_length` of the training data as the history for the first prediction
    prediction_series = model.predict(
        n=n_predict,
        series=target_series_scaled,
        past_covariates=covariate_series_scaled,
        verbose=True
    )
    
    # Inverse transform the predictions to get them back to the original scale
    prediction_unscaled = target_scaler.inverse_transform(prediction_series)
    
    # 6. POST-PROCESSING AND SAVING
    print("\n--- Post-processing and Saving Results ---")
    df_pred_output = prediction_unscaled.pd_dataframe()
    df_pred_output.columns = [f"{TARGET_COL}_Predicted"]
    df_pred_output = df_pred_output.reset_index().rename(columns={'date': 'date'})

    # Create the final output dataframe by combining history and prediction
    df_final_output = df_train[['date', TARGET_COL]].copy()
    df_final_output = pd.merge(df_final_output, df_pred_output, on='date', how='outer')
    
    # Fill the target column with predictions where it was originally NaN
    df_final_output[TARGET_COL] = df_final_output[TARGET_COL].fillna(df_final_output[f"{TARGET_COL}_Predicted"])
    
    # Apply boundary smoothing
    print("Applying boundary smoothing for a seamless transition...")
    historical_tail = df_train[TARGET_COL].iloc[-BRIDGE_HOURS:]
    last_historical_value = historical_tail.iloc[-1]
    
    first_predicted_value = df_final_output.loc[df_final_output.index == split_point, TARGET_COL].iloc[0]
    jump = first_predicted_value - last_historical_value
    
    for i in range(min(BOUNDARY_SMOOTH_HOURS, len(df_predict))):
        decay = np.exp(-i / (BOUNDARY_SMOOTH_HOURS / 2)) # Faster decay
        adjustment = jump * decay
        df_final_output.loc[split_point + i, TARGET_COL] -= adjustment
    
    print("Boundary smoothing applied.")
    
    # Save the final results
    final_results_df = df_final_output[['date', TARGET_COL]]
    final_results_df.to_csv(OUTPUT_FILE, index=False, float_format='%.3f')
    print(f"Final predictions saved to {OUTPUT_FILE}")

    # 7. PLOTTING
    print("Generating plot...")
    plt.figure(figsize=(20, 8))
    
    # Plot historical data (last ~2 months for context)
    plot_hist_start = train_end_date - pd.Timedelta(days=60)
    df_plot_hist = df_train[df_train['date'] >= plot_hist_start]
    plt.plot(df_plot_hist['date'], df_plot_hist[TARGET_COL], label='Historical L48 Power Burn', color='black')
    
    # Plot predicted data
    plt.plot(df_pred_output['date'], df_final_output.loc[df_final_output.index >= split_point, TARGET_COL], label='Predicted L48 Power Burn', color='blue')
    
    plt.axvline(x=train_end_date, color='red', linestyle='--', label='Forecast Start')
    plt.title('L48 Power Burn Forecast using N-HiTS')
    plt.xlabel('Date')
    plt.ylabel('Power Burn (MMCF)')
    plt.legend()
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.tight_layout()
    plt.savefig(PLOT_FILE, dpi=300)
    print(f"Plot saved to {PLOT_FILE}")

    end_total_time = time.time()
    print("\n\n=============================================")
    print("========== N-HiTS SCRIPT COMPLETE ==========")

    print("=============================================")
    sys.exit(0)