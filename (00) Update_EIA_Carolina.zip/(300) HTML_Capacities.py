import os
import pandas as pd
from sqlalchemy import create_engine, inspect
import traceback

# --- Configuration ---
DB_CONNECTION_STRING = (
)
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"

# --- Main Logic ---

def fetch_and_process_capacity_data():
    """
    Fetches hourly capacity data from all capability tables,
    calculates monthly averages, and saves them to CSV files.
    """
    print("--- Starting Capacity Data Fetch and Processing ---")

    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output will be saved to: {os.path.abspath(OUTPUT_DIR)}")

    try:
        engine = create_engine(DB_CONNECTION_STRING)
        inspector = inspect(engine)
        all_tables = inspector.get_table_names(schema='dbo')

        # Dynamically find all production capability tables
        capability_tables = [
            tbl for tbl in all_tables if 'CAPABILITY' in tbl.upper() and 'PRODUCTION' in tbl.upper()
        ]
        
        if not capability_tables:
            print("No capability tables found. Please check table names and schema.")
            return

        print(f"Found {len(capability_tables)} capability tables to process.")

        for table_name in capability_tables:
            try:
                print(f"\nProcessing table: {table_name}...")
                
                # Fetch data from the table
                query = f"SELECT * FROM dbo.[{table_name}]"
                df = pd.read_sql(query, engine)

                if df.empty:
                    print(f"  > No data found in {table_name}. Skipping.")
                    continue

                # Set 'Datetime' as index
                if 'Datetime' not in df.columns:
                    print(f"  > 'Datetime' column not found in {table_name}. Skipping.")
                    continue
                
                df['Datetime'] = pd.to_datetime(df['Datetime'])
                df.set_index('Datetime', inplace=True)

                # Calculate monthly averages for all numeric columns
                # Using 'MS' to align the date to the start of the month
                monthly_avg_df = df.resample('MS').mean()

                # Extract a clean energy type name from the table name
                energy_type = table_name.replace('PRODUCTION_', '').replace('_CAPABILITY', '').lower()
                
                # Define output file path
                output_filename = f"monthly_avg_capacity_{energy_type}.csv"
                output_filepath = os.path.join(OUTPUT_DIR, output_filename)

                # Save to CSV
                monthly_avg_df.to_csv(output_filepath)
                print(f"  > Successfully saved monthly averages to: {output_filepath}")

            except Exception as e:
                print(f"  > FAILED to process table {table_name}: {e}")
                traceback.print_exc()

    except Exception as e:
        print(f"An error occurred during database connection or inspection: {e}")
        traceback.print_exc()

    print("\n--- Processing complete. ---")

if __name__ == "__main__":
    fetch_and_process_capacity_data()