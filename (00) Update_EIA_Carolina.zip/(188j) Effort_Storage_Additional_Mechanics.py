import pandas as pd
import os
import numpy as np

# Directory where all files are located
data_dir = r'D:\EIA_STACK\Pricing_RL\AGGREGATE'

# List of all regions to process
region_files = [
    ('east_combined.csv', 'East', 'east_historical_weekly_avg.csv'),
    ('midwest_combined.csv', 'Midwest', 'midwest_historical_weekly_avg.csv'),
    ('mountain_combined.csv', 'Mountain', 'mountain_historical_weekly_avg.csv'),
    ('pacific_combined.csv', 'Pacific', 'pacific_historical_weekly_avg.csv'),
    ('south_central_nonsalt_combined.csv', 'South Central Nonsalt', 'south_central_nonsalt_historical_weekly_avg.csv'),
    ('south_central_salt_combined.csv', 'South Central Salt', 'south_central_salt_historical_weekly_avg.csv')
]

print("="*70)
print("CALCULATING HISTORICAL WEEKLY AVERAGES FOR ALL REGIONS")
print("Using ENTIRE time series - no date restrictions")
print("="*70)

# Process each region
for input_file, storage_column, output_file in region_files:
    print(f"\n{''*50}")
    print(f"Processing: {input_file}")
    print(''*50)
    
    try:
        # Load the combined file
        filepath = os.path.join(data_dir, input_file)
        data = pd.read_csv(filepath)
        
        # Parse dates
        data['datetime'] = pd.to_datetime(data['datetime'])
        
        # Extract week number and year
        data['week'] = data['datetime'].dt.isocalendar().week
        data['year'] = data['datetime'].dt.year
        
        # Show what we're working with
        date_min = data['datetime'].min()
        date_max = data['datetime'].max()
        total_years = data['year'].nunique()
        total_weeks = len(data)
        
        print(f"Data spans: {date_min.date()} to {date_max.date()}")
        print(f"Total records: {total_weeks}")
        print(f"Years covered: {total_years} ({data['year'].min()} to {data['year'].max()})")
        
        # Group by week number and calculate statistics for ENTIRE dataset
        results = []
        
        for week_num in range(1, 54):  # weeks 1-53
            week_data = data[data['week'] == week_num]
            
            if len(week_data) > 0:
                # Calculate statistics with NaN handling
                storage_avg = week_data[storage_column].mean()
                storage_min = week_data[storage_column].min()
                storage_max = week_data[storage_column].max()
                storage_std = week_data[storage_column].std() if len(week_data) > 1 else 0
                
                delta_avg = week_data['Delta_Change'].mean()
                delta_min = week_data['Delta_Change'].min()
                delta_max = week_data['Delta_Change'].max()
                delta_std = week_data['Delta_Change'].std() if len(week_data) > 1 else 0
                
                stats = {
                    'Week': week_num,
                    'Storage_Avg': storage_avg,
                    'Storage_Min': storage_min,
                    'Storage_Max': storage_max,
                    'Storage_StdDev': storage_std,
                    'Delta_Avg': delta_avg,
                    'Delta_Min': delta_min, 
                    'Delta_Max': delta_max,
                    'Delta_StdDev': delta_std,
                    'Sample_Count': len(week_data),
                    'Years_Present': week_data['year'].nunique()
                }
                results.append(stats)
        
        # Create DataFrame from results
        weekly_df = pd.DataFrame(results)
        
        # Handle NaN/inf values before converting to int
        # Replace NaN with 0 for standard deviations
        weekly_df['Storage_StdDev'] = weekly_df['Storage_StdDev'].fillna(0)
        weekly_df['Delta_StdDev'] = weekly_df['Delta_StdDev'].fillna(0)
        
        # Round and convert to appropriate types
        # For storage columns - round and convert to int
        weekly_df['Storage_Avg'] = np.round(weekly_df['Storage_Avg']).fillna(0).astype(int)
        weekly_df['Storage_Min'] = weekly_df['Storage_Min'].fillna(0).astype(int)
        weekly_df['Storage_Max'] = weekly_df['Storage_Max'].fillna(0).astype(int)
        weekly_df['Storage_StdDev'] = np.round(weekly_df['Storage_StdDev']).astype(int)
        
        # For delta columns - round to 1 decimal
        weekly_df['Delta_Avg'] = np.round(weekly_df['Delta_Avg'], 1).fillna(0)
        weekly_df['Delta_Min'] = np.round(weekly_df['Delta_Min'], 1).fillna(0)
        weekly_df['Delta_Max'] = np.round(weekly_df['Delta_Max'], 1).fillna(0)
        weekly_df['Delta_StdDev'] = np.round(weekly_df['Delta_StdDev'], 1).fillna(0)
        
        # Save the results
        output_path = os.path.join(data_dir, output_file)
        weekly_df.to_csv(output_path, index=False)
        
        print(f"✓ SUCCESS: Saved to {output_file}")
        print(f"  - Calculated averages for {len(weekly_df)} weeks")
        print(f"  - Used ALL {total_weeks} data points from {total_years} years")
        print(f"  - Avg storage across all weeks: {weekly_df['Storage_Avg'].mean():.0f}")
        print(f"  - Avg delta across all weeks: {weekly_df['Delta_Avg'].mean():.1f}")
        
    except Exception as e:
        print(f"✗ ERROR: Failed to process {input_file}")
        print(f"  Reason: {str(e)}")
        import traceback
        traceback.print_exc()

print("\n" + "="*70)
print("PROCESSING COMPLETE")
print("="*70)
print(f"\nAll output files saved to: {data_dir}")
print("\nEach file contains weekly statistics calculated from the")
