# -*- coding: utf-8 -*- # Keep encoding declaration
import pandas as pd
import os
import re
import glob # For finding files with patterns
import traceback # For detailed error printing
import numpy as np # For handling division by zero potential
import pyarrow.parquet as pq # To inspect Parquet columns before reading
# Ensure pyarrow is installed for Parquet support: pip install pyarrow

# --- Clean Column Name Function (Unchanged) ---
def clean_column_name(col_name):
    """Cleans the region column name for file/column naming, including specific renames."""
    if col_name == 'SE Outages': return 'southeast'
    elif col_name == 'Mid Atl Outages': return 'midatlantic'
    elif col_name == 'MW Outages': return 'midwest'
    elif col_name == 'NE Outages': return 'newengland'
    elif col_name == 'New York Outages': return 'newyork'
    elif col_name == 'NW Outages': return 'northwest'
    elif col_name == 'SW Outages': return 'southwest'
    else:
        name = col_name.replace(' Outages', '')
        name = name.lower()
        name = re.sub(r'[^a-z0-9]+', '_', name)
        name = re.sub(r'_+', '_', name)
        name = name.strip('_')
        if not name:
             print(f"Warning: Column '{col_name}' resulted in an empty base name after cleaning.")
             return f"unknown_region_{col_name.replace(' ', '_').lower()}"
        return name

# --- Configuration ---
data_query_merged_csv_path = r'C:\EIA\DataQuery_Merged.csv' # New input file
nuclear_output_directory = r'D:\EIA_STACK\Nuke_Hourly_CSVs' # Nuclear CSVs stored here
input_datetime_column = 'date' # The date column name in DataQuery_Merged.csv
base_stack_directory = r'D:\EIA_STACK' # Root directory
target_subdirectory_name = 'Capacity' # Subdirectory for capability Parquets
target_date_column_name = 'date' # Date column in capability Parquets
source_nuclear_datetime_column = 'datetime' # The desired date column name in the output CSVs

# New paths for train and predict Parquets (adjust as needed) - Not used in this script
train_parquet_path = r'D:\EIA_STACK\Train\train.parquet'
predict_parquet_path = r'D:\EIA_STACK\Predict\predict.parquet'


# --- Part 1: Generate Nuclear Outage CSVs from DataQuery_Merged.csv ---
print("--- Starting Part 1: Generating Nuclear Outage CSVs from DataQuery_Merged.csv ---")
try:
    print(f"Reading merged data from '{data_query_merged_csv_path}'...")
    df_merged = pd.read_csv(data_query_merged_csv_path, parse_dates=[input_datetime_column])
    print("DataQuery_Merged.csv read successfully.")
 
    if input_datetime_column not in df_merged.columns:
        raise ValueError(f"Error: Datetime source column '{input_datetime_column}' not found in DataQuery_Merged.csv.")
    
    # Identify region columns: all columns except the datetime_source_column
    region_outage_columns = [col for col in df_merged.columns if col != input_datetime_column]
 
    if not region_outage_columns:
        print("No region-specific outage columns found in DataQuery_Merged.csv.")
    else:
        print(f"Identified {len(region_outage_columns)} region-specific outage columns.")
        os.makedirs(nuclear_output_directory, exist_ok=True)
        print(f"Ensured output directory exists: '{nuclear_output_directory}'")
        for region_col in region_outage_columns:
            print(f"\nProcessing source column: '{region_col}'...")
            # The region_col is already the clean region name (e.g., 'TEXAS', 'CAROLINA')
            base_name = region_col.lower() # Use lowercase for consistency in filenames/column names
            
            output_col_name = f"{base_name}_nuclear" # e.g., 'al_nuclear'
            output_csv_filename = f"{output_col_name}.csv"
            output_file_path = os.path.join(nuclear_output_directory, output_csv_filename)
 
            if input_datetime_column not in df_merged.columns or region_col not in df_merged.columns:
                 print(f"  Error: Required columns ('{input_datetime_column}', '{region_col}') not available in DataFrame. Skipping."); continue
 
            output_df = df_merged[[input_datetime_column, region_col]].copy()
            # Rename columns for compatibility with the rest of the script
            output_df = output_df.rename(columns={input_datetime_column: source_nuclear_datetime_column, region_col: output_col_name})
 
            try:
                output_df.to_csv(output_file_path, index=False, date_format='%Y-%m-%d %H:%M:%S')
                print(f"Successfully created initial CSV: '{output_file_path}' with {len(output_df)} rows.")
            except Exception as write_e:
                 print(f"Error writing initial file '{output_file_path}': {write_e}")
                 traceback.print_exc()
 
except FileNotFoundError: print(f"Error: DataQuery_Merged.csv '{data_query_merged_csv_path}' not found.")
except ValueError as ve: print(ve)
except Exception as e: print(f"An unexpected error occurred during Part 1: {e}"); traceback.print_exc()
print("\n--- Finished Part 1 ---")


# --- Part 2: Merge Nuclear CSVs with Capability Parquets (Time Alignment Included) ---
print("\n--- Starting Part 2: Merging Nuclear CSVs with Capability Parquets ---")
print(f"Looking for nuclear outage CSVs in: {nuclear_output_directory}")
print(f"Expected capability Parquet location: {base_stack_directory}\\[region]\\{target_subdirectory_name}\\[region]_nuclear.parquet")
print("\nNOTE: Applying +1 minute shift and floor('H') to source CSV datetimes before merge for timestamp alignment.")

if not os.path.isdir(nuclear_output_directory):
    print(f"Error: Nuclear CSV directory '{nuclear_output_directory}' not found. Cannot proceed with merge.")
else:
    nuclear_files_pattern = os.path.join(nuclear_output_directory, '*_nuclear.csv')
    source_nuclear_files = glob.glob(nuclear_files_pattern)

    if not source_nuclear_files:
        print(f"No '*_nuclear.csv' files found in '{nuclear_output_directory}'. Nothing to merge.")
    else:
        print(f"Found {len(source_nuclear_files)} nuclear CSV files to process for merging.")
        merge_success_count = 0
        merge_skip_count = 0
        merge_error_count = 0

        for source_file_path in source_nuclear_files: # Source is the regional outage CSV from Part 1
            try:
                source_filename = os.path.basename(source_file_path)
                if source_filename.endswith('_nuclear.csv'):
                    region_base_name = source_filename[:-len('_nuclear.csv')]
                else:
                    print(f"Skipping file '{source_filename}' (doesn’t end with '_nuclear.csv')."); merge_skip_count += 1; continue

                print(f"\n--- Processing merge for: {source_filename} (Region: {region_base_name}) ---")

                # Construct the path to the corresponding regional nuclear capacity Parquet
                regional_capacity_dir = os.path.join(base_stack_directory, region_base_name, target_subdirectory_name)
                target_parquet_filename = f"{region_base_name.lower()}_nuclear.parquet"
                target_file_path = os.path.join(regional_capacity_dir, target_parquet_filename)

                print(f"  Looking for capability Parquet at: {target_file_path}")

                if os.path.exists(target_file_path):
                    print(f"  Found capability Parquet file.")

                    expected_capacity_col_in_parquet = f"{region_base_name.capitalize()}_Total_Capacity_Nuclear"
                    columns_to_extract = [target_date_column_name, expected_capacity_col_in_parquet]

                    print(f"  Reading nuclear outage CSV data from: {source_file_path}")
                    df_source = pd.read_csv(source_file_path, parse_dates=[source_nuclear_datetime_column])
                    print(f"    - Source CSV Shape (Original): {df_source.shape}")
                    if not df_source.empty:
                         print(f"    - Source CSV Date Range (Original): {df_source[source_nuclear_datetime_column].min()} to {df_source[source_nuclear_datetime_column].max()}")
                         print(f"    - Source CSV Datetime Dtype (Original): {df_source[source_nuclear_datetime_column].dtype}")


                    # --- Apply the +1 minute shift and floor('H') to source datetimes for alignment ---
                    if source_nuclear_datetime_column in df_source.columns:
                        print(f"  Applying +1 minute shift and floor('H') to source CSV '{source_nuclear_datetime_column}' column for alignment...")
                        df_source[source_nuclear_datetime_column] = (df_source[source_nuclear_datetime_column] + pd.Timedelta(minutes=1)).dt.floor('H')
                        print(f"    - Source CSV Date Range (After Alignment): {df_source[source_nuclear_datetime_column].min()} to {df_source[source_nuclear_datetime_column].max()}")
                    else:
                         print(f"  Warning: Source datetime column '{source_nuclear_datetime_column}' not found in source CSV. Cannot apply alignment.");


                    # --- Read only necessary columns from Parquet ---
                    print(f"  Reading specific columns '{columns_to_extract}' from capability Parquet: {target_file_path}")

                    df_target = pd.DataFrame()
                    parquet_read_successful = False

                    try:
                        parquet_file = pq.ParquetFile(target_file_path)
                        parquet_columns = parquet_file.schema.names
                        missing_cols = [col for col in columns_to_extract if col not in parquet_columns]
                        if missing_cols:
                            print(f"  Error: Required columns {missing_cols} not found in Parquet schema: {target_file_path}. Skipping merge for this file."); merge_error_count += 1; continue

                        df_target = pd.read_parquet(target_file_path, columns=columns_to_extract, engine='pyarrow')
                        parquet_read_successful = True
                        print(f"  Read capability Parquet data.")
                        print(f"    - Target Parquet Shape: {df_target.shape}")
                        if not df_target.empty:
                             print(f"    - Target Parquet Date Range: {df_target[target_date_column_name].min()} to {df_target[target_date_column_name].max()}")
                             print(f"    - Target Parquet Datetime Dtype: {df_target[target_date_column_name].dtype}")


                    except Exception as parquet_read_e:
                        print(f"  Error reading required columns from Parquet file '{target_file_path}': {parquet_read_e}"); traceback.print_exc(); merge_error_count += 1; continue

                    # Proceed with merge only if Parquet read was successful and not empty
                    if parquet_read_successful and not df_target.empty:

                        if source_nuclear_datetime_column not in df_source.columns:
                            print(f"  Error: '{source_nuclear_datetime_column}' not found in source CSV DataFrame after alignment. Skipping."); merge_error_count += 1; continue

                        merge_on_column = source_nuclear_datetime_column # standard datetime column name in CSV

                        # Rename target date column if it differs from the merge key
                        if target_date_column_name != merge_on_column:
                            if target_date_column_name in df_target.columns:
                               print(f"  Renaming Parquet date column '{target_date_column_name}' to '{merge_on_column}'.")
                               df_target = df_target.rename(columns={target_date_column_name: merge_on_column})
                            else:
                                 print(f"  Error: Parquet date column '{target_date_column_name}' not found in df_target after reading/renaming logic. Skipping merge."); merge_error_count += 1; continue

                        # Ensure timezone compatibility (localize to None for merging)
                        df_source[merge_on_column] = df_source[merge_on_column].dt.tz_localize(None) if df_source[merge_on_column].dt.tz is not None else df_source[merge_on_column]
                        df_target[merge_on_column] = df_target[merge_on_column].dt.tz_localize(None) if df_target[merge_on_column].dt.tz is not None else df_target[merge_on_column]
                        # Added prints back for clarity
                        if df_source[merge_on_column].dt.tz is not None: print(f"  Removed timezone from source CSV '{merge_on_column}' (after alignment).")
                        if df_target[merge_on_column].dt.tz is not None: print(f"  Removed timezone from target Parquet '{merge_on_column}'.")


                        # Drop potential duplicate datetime entries in target *before* merge
                        initial_target_rows = len(df_target)
                        df_target = df_target.drop_duplicates(subset=[merge_on_column])
                        if len(df_target) < initial_target_rows:
                            print(f"  Dropped {initial_target_rows - len(df_target)} duplicate datetime entries from target Parquet data.")

                        # --- Debugging Step: Compare Datetime Indices AFTER Alignment ---
                        source_dates_aligned = pd.Index(df_source[merge_on_column]) # Use column directly after tz_localize
                        target_dates = pd.Index(df_target[merge_on_column]) # Use column directly after tz_localize

                        common_dates = source_dates_aligned.intersection(target_dates)

                        print(f"\n  --- Datetime Comparison (After CSV Alignment) ---")
                        print(f"  Number of unique datetimes in Source CSV (Aligned): {len(source_dates_aligned)}")
                        print(f"  Number of unique datetimes in Target Parquet: {len(target_dates)}")
                        print(f"  Number of datetimes common to both (potential merge matches): {len(common_dates)}")
                        if len(common_dates) > 0:
                            print(f"  Date range of common datetimes: {common_dates.min()} to {common_dates.max()}")
                            print("  Sample common datetimes (Head):\n", common_dates.values[:5])
                            print("  Sample common datetimes (Tail):\n", common_dates.values[-5:])
                        else:
                            print("  No common datetimes found after alignment.")
                        print(f"  --- End Datetime Comparison ---\n")


                        if df_source.empty:
                            print(f"  Warning: Source CSV '{source_filename}' is empty. Skipping merge."); merge_skip_count += 1; continue
                        if df_target.empty:
                            print(f"  Warning: Target Parquet data for '{target_parquet_filename}' is empty or became empty after dropping duplicates. Cannot merge capacity. Skipping merge for this file."); merge_skip_count += 1; continue


                        print(f"  Attempting merge...")
                        # Use LEFT merge to keep all rows from the source CSV
                        merged_df = pd.merge(df_source, df_target, on=merge_on_column, how='left')


                        if merged_df.empty:
                            print("  Warning: Merge resulted in empty DataFrame. This is unexpected for a left merge unless source was empty."); merge_skip_count += 1
                        else:
                            print(f"  Merge successful.")
                            print(f"    - Merged DataFrame Shape: {merged_df.shape}")
                            print(f"    - Merged DataFrame Date Range: {merged_df[merge_on_column].min()} to {merged_df[merge_on_column].max()}")
                            print(f"    - Merged DataFrame Columns: {merged_df.columns.tolist()}")
                            print("    - Merged DataFrame Tail (last 5 rows):\n", merged_df.tail())

                            merged_capacity_col = f"{region_base_name.capitalize()}_Total_Capacity_Nuclear"
                            if merged_capacity_col in merged_df.columns:
                                nan_count = merged_df[merged_capacity_col].isnull().sum()
                                total_rows = len(merged_df)
                                print(f"    - NaN count in '{merged_capacity_col}' column: {nan_count} out of {total_rows} rows.")
                            else:
                                 print(f"    - Warning: Merged capacity column '{merged_capacity_col}' not found in merged DataFrame.")


                            # Save the merged data back to the original CSV file path, overwriting it
                            print(f"  Saving merged data to CSV: {source_file_path}")
                            # The 'datetime' column now contains the ALIGNED times (XX:00:00).
                            merged_df.to_csv(source_file_path, index=False, date_format='%Y-%m-%d %H:%M:%S')
                            print("  Successfully saved merged CSV."); merge_success_count += 1

                    else:
                        print(f"  Skipping merge for region '{region_base_name}' due to issues reading Parquet or empty target data.");
                        merge_skip_count += 1


                else:
                    print(f"  Warning: Capability Parquet not found at '{target_file_path}'. Cannot merge capacity data. Skipping merge for this region."); merge_skip_count += 1

            except Exception as e:
                print(f"  An unexpected error occurred processing '{source_filename}': {e}"); traceback.print_exc(); merge_error_count += 1

        print("\n--- Merge Summary ---")
        print(f"Successfully merged: {merge_success_count} files")
        print(f"Skipped (Parquet not found, empty data, missing columns, read error): {merge_skip_count} files")
        print(f"Errors during processing: {merge_error_count} files")

print("\n--- Finished Part 2 ---")


# --- Part 3: Calculate Net Nuclear Capacity (NUC_MW) ---
print("\n--- Starting Part 3: Calculating Net Nuclear Capacity (NUC_MW) ---")
print(f"Processing CSV files in: {nuclear_output_directory}")
if not os.path.isdir(nuclear_output_directory):
    print(f"Error: Directory '{nuclear_output_directory}' not found.")
else:
    final_nuclear_files_pattern = os.path.join(nuclear_output_directory, '*_nuclear.csv')
    final_nuclear_files = glob.glob(final_nuclear_files_pattern)

    if not final_nuclear_files:
        print(f"No '*_nuclear.csv' files found in '{nuclear_output_directory}'.")
    else:
        print(f"Found {len(final_nuclear_files)} files to calculate NUC_MW.")
        calc_success_count = 0
        calc_skip_count = 0
        calc_error_count = 0
        for file_path in final_nuclear_files:
            try:
                filename = os.path.basename(file_path)
                if filename.endswith('_nuclear.csv'): region_base_name = filename[:-len('_nuclear.csv')]
                else: print(f"Skipping '{filename}' (doesn't end with '_nuclear.csv')."); calc_skip_count += 1; continue
                print(f"\nProcessing: {filename} (Region: {region_base_name}) for NUC_MW")

                # Column names as they should be in the CSV after Part 2 merge
                capacity_col = f"{region_base_name.capitalize()}_Total_Capacity_Nuclear" # Merged from Parquet, possibly with NaNs
                outage_col = f"{region_base_name}_nuclear" # From original Excel, always present
                output_mw_col = f"{region_base_name.upper()}_NUCLEAR_MW"

                print(f"  Reading CSV: {file_path}")
                # Read the CSV saved by Part 2, which now includes the capacity column (or NaNs)
                df_final = pd.read_csv(file_path, parse_dates=[source_nuclear_datetime_column])

                # Check if required columns exist *in the CSV* after Part 2
                if outage_col not in df_final.columns:
                    print(f"  Error: Required column '{outage_col}' missing in CSV. Skipping calculation."); calc_error_count += 1; continue
                if capacity_col not in df_final.columns:
                     # This warning will occur if the Part 2 merge failed to add the capacity column for *this* file
                     print(f"  Warning: Capacity column '{capacity_col}' missing in CSV after merge. Cannot calculate {output_mw_col}. Skipping calculation for this file."); calc_skip_count += 1; continue

                print(f"  Calculating '{output_mw_col}' using '{capacity_col}' and '{outage_col}'...")
                # Use pd.to_numeric with errors='coerce' to handle potential non-numeric values, including NaNs
                capacity_values = pd.to_numeric(df_final[capacity_col], errors='coerce')
                outage_values = pd.to_numeric(df_final[outage_col], errors='coerce')

                # Calculation handles NaNs correctly (NaN - value = NaN, value - NaN = NaN)
                df_final[output_mw_col] = capacity_values - outage_values

                print(f"  Saving updated CSV with '{output_mw_col}'.")
                df_final.to_csv(file_path, index=False, date_format='%Y-%m-%d %H:%M:%S')
                print(f"  Successfully saved updated CSV: {file_path}"); calc_success_count += 1

            except Exception as e:
                print(f"  Error processing '{file_path}': {e}"); traceback.print_exc(); calc_error_count += 1

        print(f"\nSummary (Part 3): Success: {calc_success_count}, Skipped: {calc_skip_count}, Errors: {calc_error_count}")
print("\n--- Finished Part 3 ---")


# --- Part 4: Calculate Nuclear Capacity Ratio ---
print("\n--- Starting Part 4: Calculating Nuclear Capacity Ratio ---")
print(f"Processing CSV files in: {nuclear_output_directory}")
if not os.path.isdir(nuclear_output_directory):
    print(f"Error: Directory '{nuclear_output_directory}' not found.")
else:
    ratio_files = glob.glob(os.path.join(nuclear_output_directory, '*_nuclear.csv'))
    if not ratio_files:
        print(f"No '*_nuclear.csv' files found in '{nuclear_output_directory}'.")
    else:
        print(f"Found {len(ratio_files)} files to calculate ratio.")
        ratio_success_count = 0
        ratio_skip_count = 0
        ratio_error_count = 0

        for file_path in ratio_files:
            try:
                filename = os.path.basename(file_path)
                if filename.endswith('_nuclear.csv'): region_base_name = filename[:-len('_nuclear.csv')]
                else: print(f"Skipping '{filename}'."); ratio_skip_count += 1; continue
                print(f"\nProcessing: {filename} for Ratio")

                # Column names as they should be in the CSV after Part 3
                nuc_mw_col = f"{region_base_name.upper()}_NUCLEAR_MW" # Calculated in Part 3, possibly with NaNs
                capacity_col = f"{region_base_name.capitalize()}_Total_Capacity_Nuclear" # Merged from Parquet, possibly with NaNs
                output_ratio_col = f"{region_base_name.upper()}_NUCLEAR_RATIO"

                print(f"  Reading CSV: {file_path}")
                # Read the CSV updated by Part 3
                df_ratio = pd.read_csv(file_path, parse_dates=[source_nuclear_datetime_column])

                # Check if required columns exist *in the CSV* after Part 3
                if nuc_mw_col not in df_ratio.columns:
                    # This error will occur if Part 3 was skipped or failed for *this* file
                    print(f"  Error: Required column '{nuc_mw_col}' missing in CSV (Part 3 likely skipped/failed). Skipping ratio calculation."); ratio_error_count += 1; continue
                if capacity_col not in df_ratio.columns:
                     # This warning will occur if the Part 2 merge failed to add the capacity column
                     print(f"  Warning: Capacity column '{capacity_col}' missing in CSV. Cannot calculate ratio. Skipping calculation for this file."); ratio_skip_count += 1; continue


                print(f"  Calculating '{output_ratio_col}' using '{nuc_mw_col}' and '{capacity_col}'...")
                # Use pd.to_numeric with errors='coerce' to handle potential non-numeric values or NaNs
                numerator = pd.to_numeric(df_ratio[nuc_mw_col], errors='coerce')
                denominator = pd.to_numeric(df_ratio[capacity_col], errors='coerce')

                # Replace 0 capacity with NaN to avoid division by zero.
                # Division by NaN will result in NaN, which is correct for missing capacity.
                denominator = denominator.replace(0, np.nan)

                # Calculation handles NaNs correctly (value / NaN = NaN, NaN / value = NaN, NaN / NaN = NaN)
                # Also, NaN/NaN will result in NaN.
                df_ratio[output_ratio_col] = numerator / denominator

                print(f"  Saving updated CSV with '{output_ratio_col}'.")
                df_ratio.to_csv(file_path, index=False, date_format='%Y-%m-%d %H:%M:%S')
                print(f"  Successfully saved updated CSV: {file_path}"); ratio_success_count += 1

            except Exception as e:
                print(f"  Error processing '{file_path}': {e}"); traceback.print_exc(); ratio_error_count += 1

        print(f"\nSummary (Part 4): Success: {ratio_success_count}, Skipped: {ratio_skip_count}, Errors: {ratio_error_count}")
print("\n--- Finished Part 4 ---")
