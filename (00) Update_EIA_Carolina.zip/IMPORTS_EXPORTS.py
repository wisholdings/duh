# -*- coding: utf-8 -*-
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta, date
from sqlalchemy import create_engine, text
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="Supply & Demand Daily Changes",
    page_icon="🔄",
    layout="wide"
)

# --- AZURE SQL DATABASE CONFIGURATION ---
AZURE_DB_CONNECTION_STRING = (
)

# --- Database Connection (Reusing your excellent pattern) ---
@st.cache_resource
def get_db_engine():
    """Create and cache database engine for Azure SQL connection."""
    try:
        engine = create_engine(AZURE_DB_CONNECTION_STRING, echo=False, pool_recycle=3600)
        # Test connection
        with engine.connect() as connection:
            connection.execute(text("SELECT 1")).scalar()
        return engine
    except Exception as e:
        st.error(f"❌ Database Connection Error: {e}")
        return None

@st.cache_data(ttl=1800)
def load_supply_demand_data():
    """Load and process daily supply/demand data, calculating day-over-day changes."""
    engine = get_db_engine()
    if not engine:
        return None
    try:
        query = text("""
        SELECT 
            [Date],
            [LNG_IMPORTS],
            [LNG_EXPORTS],
            [MEX_EXPORTS],
            [CAD_NET_FLOW],
            [PIPE_LOSS],
            [PRODUCTION],
            [LEASE_PLANT_LOSS]
        FROM [dbo].[PRODUCTION_PIPE_CAD_MEX_LEASE_L48_CRITERION_HISTORY]
        WHERE [Date] IS NOT NULL
        ORDER BY [Date] ASC
        """)
        df = pd.read_sql_query(query, engine)
        if df.empty:
            return None
        
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date').reset_index(drop=True)
        
        # Identify the numeric columns to calculate differences on
        numeric_cols = df.select_dtypes(include=np.number).columns
        
        # Calculate day-over-day changes for all numeric columns
        for col in numeric_cols:
            df[f'{col}_DoD'] = df[col].diff()
            
        return df
    except Exception as e:
        st.error(f"Error loading Supply & Demand data: {e}")
        return None

# --- PAGE TITLE ---
st.title("🔄 U.S. Natural Gas Supply & Demand Daily Analysis")
st.markdown("*Tracking Day-over-Day Changes in Key Metrics*")

# --- Load and Process Data ---
with st.spinner("Loading L48 historical data from database..."):
    full_data = load_supply_demand_data()

if full_data is None or full_data.empty:
    st.error("❌ No Supply & Demand data could be loaded from the database.")
    st.stop()

# Data summary
date_range = f"{full_data['Date'].min().strftime('%Y-%m-%d')} to {full_data['Date'].max().strftime('%Y-%m-%d')}"
st.info(f"📊 **Data Summary:** {len(full_data):,} daily records | **Date Range:** {date_range}")
st.markdown("---")

# --- USER CONTROLS ---
st.subheader("⚙️ Dashboard Controls")

# Get the list of original variables to analyze
variables = [
    'PRODUCTION', 'LNG_EXPORTS', 'MEX_EXPORTS', 'CAD_NET_FLOW', 
    'PIPE_LOSS', 'LNG_IMPORTS', 'LEASE_PLANT_LOSS'
]

col1, col2, col3 = st.columns([1, 1, 2])

with col1:
    selected_variable = st.selectbox(
        "Select a Metric to Analyze:",
        variables,
        index=0,
        help="Choose a variable to view its historical trend and daily changes."
    )

with col2:
    view_mode = st.radio(
        "Select View Mode:",
        ("Day-over-Day Change", "Daily Values"),
        horizontal=True,
        help="Toggle between viewing the daily changes or the raw daily totals."
    )

with col3:
    # Set default date range to the last 90 days
    end_date = full_data['Date'].max().date()
    start_date = end_date - timedelta(days=90)
    
    selected_dates = st.date_input(
        "Select Date Range:",
        value=(start_date, end_date),
        min_value=full_data['Date'].min().date(),
        max_value=end_date,
    )
    
    try:
        start_date, end_date = selected_dates
    except ValueError:
        st.warning("Please select a start and end date.")
        st.stop()

# Filter data based on date selection
filtered_df = full_data[
    (full_data['Date'].dt.date >= start_date) & 
    (full_data['Date'].dt.date <= end_date)
].copy()

st.markdown("---")

# --- KPI METRICS ---
st.subheader(f"📈 Key Statistics for {selected_variable}")

# Calculate metrics based on the FULL dataset for context
latest_row = full_data.iloc[-1]
thirty_days_ago = full_data['Date'].max() - timedelta(days=30)
recent_data = full_data[full_data['Date'] > thirty_days_ago]

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "Latest Value",
        f"{latest_row[selected_variable]:,.2f}",
        help=f"The most recent value recorded on {latest_row['Date'].strftime('%Y-%m-%d')}"
    )
with col2:
    st.metric(
        "Latest Day-over-Day Change",
        f"{latest_row[selected_variable + '_DoD']:,.2f}",
        help="The change from the previous day."
    )
with col3:
    avg_change = recent_data[selected_variable + '_DoD'].mean()
    st.metric(
        "30-Day Average Change",
        f"{avg_change:,.2f}",
        help="The average daily change over the last 30 days."
    )
with col4:
    max_change = filtered_df[selected_variable + '_DoD'].max()
    st.metric(
        "Max Daily Increase (in range)",
        f"{max_change:,.2f}",
        help=f"The largest single-day increase between {start_date} and {end_date}"
    )

# --- MAIN CHART ---
st.subheader(f"📊 Chart: {selected_variable} - {view_mode}")

if filtered_df.empty:
    st.warning("No data available for the selected date range.")
else:
    if view_mode == "Daily Values":
        fig = px.line(
            filtered_df,
            x='Date',
            y=selected_variable,
            title=f"Daily Values for {selected_variable}",
            template='plotly_white'
        )
        fig.update_traces(line=dict(color='steelblue', width=2))
        fig.update_layout(yaxis_title=f"{selected_variable} (Units)")

    else: # Day-over-Day Change
        change_col = selected_variable + '_DoD'
        filtered_df['color'] = np.where(filtered_df[change_col] < 0, 'crimson', 'forestgreen')
        
        fig = px.bar(
            filtered_df,
            x='Date',
            y=change_col,
            title=f"Day-over-Day Change in {selected_variable}",
            color='color',
            color_discrete_map={'crimson': 'crimson', 'forestgreen': 'forestgreen'},
            template='plotly_white'
        )
        fig.update_layout(
            showlegend=False,
            yaxis_title=f"Daily Change in {selected_variable} (Units)"
        )

    fig.update_layout(
        height=500,
        hovermode='x unified'
    )
    st.plotly_chart(fig, use_container_width=True)

st.markdown("---")

# --- COMPARISON TABLE ---
st.subheader("🌐 All Metrics: Latest Daily Changes")

# Create a summary of the latest day's data for all variables
summary_data = []
for var in variables:
    summary_data.append({
        "Metric": var,
        "Latest Value": latest_row[var],
        "Latest Change (DoD)": latest_row[var + '_DoD'],
        "30-Day Avg Change": full_data[full_data['Date'] > thirty_days_ago][var + '_DoD'].mean()
    })

summary_df = pd.DataFrame(summary_data)

st.dataframe(
    summary_df,
    column_config={
        "Metric": st.column_config.TextColumn("Metric", width="medium"),
        "Latest Value": st.column_config.NumberColumn("Latest Value", format="%.2f"),
        "Latest Change (DoD)": st.column_config.NumberColumn("Latest Change", format="%.2f"),
        "30-Day Avg Change": st.column_config.NumberColumn("30-Day Avg Change", format="%.2f"),
    },
    hide_index=True,
    use_container_width=True
)