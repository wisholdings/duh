import pandas as pd
import os
from datetime import datetime

# Define the directory path
east_dir = r'D:\EIA_STACK\Pricing_RL\EAST'
output_dir = east_dir  # Save in the same directory

print("="*60)
print("INNER MERGE OF ALL CSV FILES IN EAST FOLDER")
print("="*60)
print(f"Directory: {east_dir}")
print("="*60)

# List of all CSV files to merge
csv_files = [
    'carolina_commercial.csv',
    'carolina_industrial.csv',
    'carolina_power_burn_prediction.csv',
    'carolina_residential_final_hybrid_forecast.csv',
    'east_consolidated_storage.csv',
    'florida_commercial.csv',
    'florida_industrial.csv',
    'florida_power_burn_prediction.csv',
    'florida_residential_final_hybrid_forecast.csv',
    'midatlantic_commercial.csv',
    'midatlantic_industrial.csv',
    'midatlantic_power_burn_prediction.csv',
    'midatlantic_residential_final_hybrid_forecast.csv',
    'newengland_commercial.csv',
    'newengland_industrial.csv',
    'newengland_power_burn_prediction.csv',
    'newengland_residential_final_hybrid_forecast.csv',
    'newyork_commercial.csv',
    'newyork_industrial.csv',
    'newyork_power_burn_prediction.csv',
    'newyork_residential_final_hybrid_forecast.csv',
    'southeast_commercial.csv',
    'southeast_industrial.csv',
    'southeast_power_burn_prediction.csv',
    'southeast_residential_final_hybrid_forecast.csv',
    'synmax_production_with_forecast.csv',
    'tennessee_commercial.csv',
    'tennessee_industrial.csv',
    'tennessee_power_burn_prediction.csv',
    'tennessee_residential_final_hybrid_forecast.csv',
    'weather_EAST.csv'
]

# Initialize merged dataframe with None
merged_df = None
successful_merges = []
failed_files = []
date_column_issues = []

print("\nStarting merge process...\n")

for i, csv_file in enumerate(csv_files, 1):
    file_path = os.path.join(east_dir, csv_file)
    
    print(f"[{i}/{len(csv_files)}] Processing: {csv_file}")
    
    try:
        # Read the CSV file
        df = pd.read_csv(file_path)
        
        # Check for date-related columns (case-insensitive)
        date_col = None
        for col in df.columns:
            if col.lower() in ['date', 'datetime', 'eff_gas_day']:
                date_col = col
                break
        
        if date_col is None:
            print(f"  ⚠️ Warning: No date/datetime column found. Available columns: {list(df.columns)[:5]}...")
            date_column_issues.append((csv_file, list(df.columns)))
            continue
        
        # Standardize date column name to 'date'
        if date_col != 'date':
            df = df.rename(columns={date_col: 'date'})
            print(f"  → Renamed '{date_col}' column to 'date'")
        
        # Convert date to datetime for consistency
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        
        # Check for invalid dates
        invalid_dates = df['date'].isna().sum()
        if invalid_dates > 0:
            print(f"  ⚠️ Found {invalid_dates} invalid date entries")
        
        # Drop rows with invalid dates for the merge
        df = df.dropna(subset=['date'])
        
        # Add prefix to columns (except date) to identify source
        # Extract a meaningful prefix from filename
        prefix = csv_file.replace('.csv', '').replace('_', '')[:15]  # Limit prefix length
        columns_to_rename = {col: f"{prefix}_{col}" for col in df.columns if col != 'date'}
        df = df.rename(columns=columns_to_rename)
        
        print(f"  ✓ Loaded: {len(df)} rows, {len(df.columns)} columns")
        
        if merged_df is None:
            # First file becomes the base
            merged_df = df
            print(f"  → Base dataframe initialized with {len(merged_df)} rows")
        else:
            # Inner merge with existing dataframe
            rows_before = len(merged_df)
            merged_df = pd.merge(merged_df, df, on='date', how='outer')
            rows_after = len(merged_df)
            print(f"  → Merged: {rows_before} rows → {rows_after} rows (lost {rows_before - rows_after} rows)")
        
        successful_merges.append(csv_file)
        
    except FileNotFoundError:
        print(f"  ✗ File not found: {file_path}")
        failed_files.append((csv_file, "File not found"))
    except Exception as e:
        print(f"  ✗ Error reading {csv_file}: {str(e)}")
        failed_files.append((csv_file, str(e)))

print("\n" + "="*60)
print("MERGE SUMMARY")
print("="*60)

if merged_df is not None and len(merged_df) > 0:
    print(f"\n✓ Successfully merged {len(successful_merges)} files")
    print(f"  Final dataframe shape: {merged_df.shape[0]} rows × {merged_df.shape[1]} columns")
    
    # Show date range
    print(f"  Date range: {merged_df['date'].min()} to {merged_df['date'].max()}")
    
    # Drop specified columns
    columns_to_drop = [
        'carolinaindustr_CAROLINA_Industrial_hourly_MMcf',
        'carolinapowerbu_CAROLINA_Power_Burn',
        'carolinaresiden_CAROLINA_Residential_hourly_MMcf',
        'floridacommerci_FLORIDA_Commercial_hourly_MMcf',
        'floridaindustri_FLORIDA_Industrial_hourly_MMcf',
        'floridapowerbur_FLORIDA_Power_Burn',
        'floridaresident_FLORIDA_Residential_hourly_MMcf',
        'midatlanticcomm_MIDATLANTIC_Commercial_hourly_MMcf',
        'midatlanticindu_MIDATLANTIC_Industrial_hourly_MMcf',
        'midatlanticpowe_MIDATLANTIC_Power_Burn',
        'midatlanticresi_MIDATLANTIC_Residential_hourly_MMcf',
        'newenglandcomme_NEWENGLAND_Commercial_hourly_MMcf',
        'newenglandindus_NEWENGLAND_Industrial_hourly_MMcf',
        'newenglandindus_NEWENGLAND_Industrial_hourly_MMcf_BCF',
        'newenglandpower_NEWENGLAND_Power_Burn',
        'newenglandpower_NEWENGLAND_Power_Burn_BCF',
        'newenglandresid_NEWENGLAND_Residential_hourly_MMcf',
        'newyorkcommerci_NEWYORK_Commercial_hourly_MMcf',
        'newyorkindustri_NEWYORK_Industrial_hourly_MMcf',
        'newyorkindustri_NEWYORK_Industrial_hourly_MMcf_BCF',
        'newyorkpowerbur_NEWYORK_Power_Burn',
        'newyorkpowerbur_NEWYORK_Power_Burn_BCF',
        'newyorkresident_NEWYORK_Residential_hourly_MMcf',
        'southeastcommer_SOUTHEAST_Commercial_hourly_MMcf',
        'southeastindust_SOUTHEAST_Industrial_hourly_MMcf',
        'southeastpowerb_SOUTHEAST_Power_Burn',
        'southeastreside_SOUTHEAST_Residential_hourly_MMcf',
        'tennesseereside_TENNESSEE_Residential_hourly_MMcf',
        'tennesseeindust_TENNESSEE_Industrial_hourly_MMcf',
        'tennesseecommer_TENNESSEE_Commercial_hourly_MMcf',
        'carolinacommerc_CAROLINA_Commercial_hourly_MMcf',
        'tennesseepowerb_TENNESSEE_Power_Burn'
    ]
    
    # Find which columns to drop that actually exist in the dataframe
    existing_cols_to_drop = [col for col in columns_to_drop if col in merged_df.columns]
    
    if existing_cols_to_drop:
        print(f"\n  Dropping {len(existing_cols_to_drop)} specified columns...")
        merged_df = merged_df.drop(columns=existing_cols_to_drop)
        print(f"  ✓ Dropped columns, new shape: {merged_df.shape[0]} rows × {merged_df.shape[1]} columns")
    
    # Convert storage columns from dekatherms to BCF (divide by 1,000,000)
    # 1 BCF ≈ 1,000,000 dekatherms
    storage_columns_dth = [
        'eastconsolidate_Accident',
        'eastconsolidate_Columbia Gas Storage',
        'eastconsolidate_DTI Storage',
        'eastconsolidate_Early Grove',
        'eastconsolidate_Ellisburg',
        'eastconsolidate_Equitrans',
        'eastconsolidate_Hardy',
        'eastconsolidate_Honeoye',
        'eastconsolidate_Leidy',
        'eastconsolidate_Lost River',
        'eastconsolidate_NFGSC',
        'eastconsolidate_North Summit',
        'eastconsolidate_Oakford',
        'eastconsolidate_Pine Needle',
        'eastconsolidate_Rager Mountain',
        'eastconsolidate_Saltville',
        'eastconsolidate_Seneca Lake Gas',
        'eastconsolidate_Stagecoach',
        'eastconsolidate_Steckman Ridge',
        'eastconsolidate_Steuben',
        'eastconsolidate_Thomas Corners',
        'eastconsolidate_UGI',
        'eastconsolidate_Unknown East Facility',
        'eastconsolidate_Wyckoff'
    ]
    
    # Find which storage columns actually exist in the dataframe
    existing_storage_cols = [col for col in storage_columns_dth if col in merged_df.columns]
    
    if existing_storage_cols:
        print(f"\n  Converting {len(existing_storage_cols)} storage columns from dekatherms to BCF...")
        for col in existing_storage_cols:
            merged_df[col] = merged_df[col] / 1000000
            # Rename column to indicate BCF
            new_col_name = col.replace('eastconsolidate_', 'eastconsolidate_BCF_')
            merged_df = merged_df.rename(columns={col: new_col_name})
        print(f"  ✓ Converted dekatherms to BCF and renamed storage columns")
    
    # =====================================================
    # CREATE REGIONAL SUMMATION COLUMNS
    # =====================================================
    print("\n" + "="*60)
    print("CREATING REGIONAL SUMMATION COLUMNS")
    print("="*60)
    
    # Define regional column groups
    regional_columns = {
        'CAROLINA_TOTAL_BCF': [
            'carolinacommerc_CAROLINA_Commercial_hourly_MMcf_BCF',
            'carolinaindustr_CAROLINA_Industrial_hourly_MMcf_BCF',
            'carolinapowerbu_CAROLINA_Power_Burn_BCF',
            'carolinaresiden_CAROLINA_Residential_hourly_MMcf_BCF'
        ],
        'FLORIDA_TOTAL_BCF': [
            'floridacommerci_FLORIDA_Commercial_hourly_MMcf_BCF',
            'floridaindustri_FLORIDA_Industrial_hourly_MMcf_BCF',
            'floridapowerbur_FLORIDA_Power_Burn_BCF',
            'floridaresident_FLORIDA_Residential_hourly_MMcf_BCF'
        ],
        'MIDATLANTIC_TOTAL_BCF': [
            'midatlanticcomm_MIDATLANTIC_Commercial_hourly_MMcf_BCF',
            'midatlanticindu_MIDATLANTIC_Industrial_hourly_MMcf_BCF',
            'midatlanticpowe_MIDATLANTIC_Power_Burn_BCF',
            'midatlanticresi_MIDATLANTIC_Residential_hourly_MMcf_BCF'
        ],
        'NEWYORK_TOTAL_BCF': [
            'newyorkcommerci_NEWYORK_Commercial_hourly_MMcf_BCF',
            'newyorkindustri_NEWYORK_Industrial_hourly_MMcf_BCF',
            'newyorkpowerbur_NEWYORK_Power_Burn_BCF',
            'newyorkresident_NEWYORK_Residential_hourly_MMcf_BCF'
        ],
        'SOUTHEAST_TOTAL_BCF': [
            'southeastcommer_SOUTHEAST_Commercial_hourly_MMcf_BCF',
            'southeastindust_SOUTHEAST_Industrial_hourly_MMcf_BCF',
            'southeastpowerb_SOUTHEAST_Power_Burn_BCF',
            'southeastreside_SOUTHEAST_Residential_hourly_MMcf_BCF'
        ],
        'NEWENGLAND_TOTAL_BCF': [
            'newenglandcomme_NEWENGLAND_Commercial_hourly_MMcf_BCF',
            'newenglandindus_NEWENGLAND_Industrial_hourly_MMcf_BCF',
            'newenglandpower_NEWENGLAND_Power_Burn_BCF',
            'newenglandresid_NEWENGLAND_Residential_hourly_MMcf_BCF'
        ],
        'TENNESSEE_TOTAL_BCF': [
            'tennesseecommer_TENNESSEE_Commercial_hourly_MMcf_BCF',
            'tennesseeindust_TENNESSEE_Industrial_hourly_MMcf_BCF',
            'tennesseepowerb_TENNESSEE_Power_Burn_BCF',
            'tennesseereside_TENNESSEE_Residential_hourly_MMcf_BCF'
        ]
    }
    
    # Create summation columns for each region
    for region_total, columns in regional_columns.items():
        # Check which columns exist in the dataframe
        existing_cols = [col for col in columns if col in merged_df.columns]
        
        if existing_cols:
            # Sum the existing columns (handling NaN values)
            merged_df[region_total] = merged_df[existing_cols].sum(axis=1, skipna=True)
            print(f"\n✓ Created {region_total}")
            print(f"  Summed {len(existing_cols)} columns:")
            for col in existing_cols:
                print(f"    • {col}")
            
            # Show summary statistics for the new column
            mean_val = merged_df[region_total].mean()
            min_val = merged_df[region_total].min()
            max_val = merged_df[region_total].max()
            print(f"  Statistics: Mean={mean_val:.4f}, Min={min_val:.4f}, Max={max_val:.4f}")
        else:
            print(f"\n⚠️ Warning: No columns found for {region_total}")
            print(f"  Looking for: {columns}")
    
    # Create a grand total column for all regions
    total_columns = [col for col in merged_df.columns if col.endswith('_TOTAL_BCF')]

    
    # =====================================================
    # DROP INDIVIDUAL COMPONENT COLUMNS AFTER SUMMATION
    # =====================================================
    print("\n" + "="*60)
    print("DROPPING INDIVIDUAL COMPONENT COLUMNS")
    print("="*60)
    
    # Collect all individual columns that were used in summations
    columns_to_drop_after_sum = []
    for region_total, columns in regional_columns.items():
        for col in columns:
            if col in merged_df.columns:
                columns_to_drop_after_sum.append(col)
    
    # Drop the individual columns
    if columns_to_drop_after_sum:
        print(f"\nDropping {len(columns_to_drop_after_sum)} individual component columns...")
        merged_df = merged_df.drop(columns=columns_to_drop_after_sum)
        print(f"✓ Dropped individual columns, keeping only regional totals")
        print(f"  New shape: {merged_df.shape[0]} rows × {merged_df.shape[1]} columns")
    
    print("\n" + "="*60)
    
    # Save the merged file
    output_filename = 'EAST_merged_all_inner_with_totals.csv'
    output_path = os.path.join(output_dir, output_filename)
    
    try:
        merged_df.to_csv(output_path, index=False)
        file_size = os.path.getsize(output_path)
        
        if file_size < 1024 * 1024:
            size_str = f"{file_size/1024:.1f} KB"
        else:
            size_str = f"{file_size/(1024*1024):.1f} MB"
            
        print(f"\n✓ Merged file saved as: {output_filename}")
        print(f"  Path: {output_path}")
        print(f"  Size: {size_str}")
        
    except Exception as e:
        print(f"\n✗ Error saving merged file: {str(e)}")
    
    # Display sample of merged data with new columns
    print("\nFirst 5 rows of merged data (showing regional totals):")
    print("-" * 40)
    # Show just date and the regional total columns
    display_cols = ['date'] + [col for col in merged_df.columns if '_TOTAL_BCF' in col]
    print(merged_df[display_cols].head())
    
    print("\nAll column names in merged file:")
    print("-" * 40)
    for i, col in enumerate(merged_df.columns, 1):
        if '_TOTAL_BCF' in col:
            print(f"  {i:3}. {col} *** NEW SUMMATION COLUMN ***")
        else:
            print(f"  {i:3}. {col}")
        if i >= 30 and len(merged_df.columns) > 30:
            print(f"  ... and {len(merged_df.columns) - 30} more columns")
            break
            
elif merged_df is not None:
    print("\n⚠️ Warning: Merged dataframe is empty!")
    print("  This happens when there are no common dates across all files.")
    print("  Consider using 'outer' merge or checking date formats.")
else:
    print("\n✗ No successful merges performed")

if date_column_issues:
    print(f"\n⚠️ Files without date-related columns: {len(date_column_issues)}")
    for file, cols in date_column_issues:
        print(f"  • {file}")
        print(f"    Columns: {cols[:3]}...")

if failed_files:
    print(f"\n✗ Failed to process: {len(failed_files)} files")
    for file, error in failed_files:
        print(f"  • {file}: {error}")

print("\n" + "="*60)
print("Process completed!")
print("="*60)