# =============================================================================
# ENHANCED STORAGE ERROR CORRECTION MODEL WITH SEASONAL CONSTRAINTS
# =============================================================================
import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import glob
from scipy import stats
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# --- CONFIGURATION ---
AGGREGATE_PATH = r"D:\EIA_STACK\Pricing_RL\AGGREGATE"

# Storage bounds (in BCF)
MIN_STORAGE = 500    # Minimum operational storage
MAX_STORAGE = 4100   # Maximum storage capacity
COMFORT_MIN = 1000   # Comfortable minimum for operations
COMFORT_MAX = 3800   # Comfortable maximum before constraints

# =============================================================================
# ENHANCED ERROR CORRECTION FUNCTIONS
# =============================================================================

def get_historical_seasonal_patterns(df, storage_col='storage_lower_48_bcf'):
    """Extract historical seasonal patterns from same weeks across years"""
    
    print("\n  Analyzing Historical Seasonal Patterns...")
    
    # Add week and year columns
    df['week'] = df['Date'].dt.isocalendar().week
    df['year'] = df['Date'].dt.year
    df['month'] = df['Date'].dt.month
    df['day_of_year'] = df['Date'].dt.dayofyear
    
    # Calculate historical patterns by week
    historical_patterns = {}
    
    # Get actual storage values only
    actual_data = df[df[storage_col].notna()].copy()
    
    if len(actual_data) > 0:
        # Calculate weekly averages across years
        weekly_stats = actual_data.groupby('week').agg({
            storage_col: ['mean', 'std', 'min', 'max', 'count'],
            'storage_delta': ['mean', 'std'] if 'storage_delta' in actual_data.columns else ['mean']
        })
        
        # Calculate seasonal storage levels (5-year average if available)
        recent_years = sorted(actual_data['year'].unique())[-5:]
        recent_data = actual_data[actual_data['year'].isin(recent_years)]
        
        seasonal_avg = recent_data.groupby('week')[storage_col].mean()
        seasonal_std = recent_data.groupby('week')[storage_col].std()
        
        # Calculate weather-adjusted patterns if weather data available
        if 'gas_hdd' in df.columns and 'population_cdd' in df.columns:
            weather_patterns = actual_data.groupby('week').agg({
                'gas_hdd': 'mean',
                'population_cdd': 'mean'
            })
            historical_patterns['weather'] = weather_patterns
        
        historical_patterns['weekly_stats'] = weekly_stats
        historical_patterns['seasonal_avg'] = seasonal_avg
        historical_patterns['seasonal_std'] = seasonal_std
        
        print(f"    Found {len(seasonal_avg)} weeks of historical data")
        print(f"    Using {len(recent_years)} years for seasonal patterns")
    
    return historical_patterns

def build_weather_adjustment_model(df, storage_col='storage_lower_48_bcf'):
    """Build a model to adjust storage based on weather patterns"""
    
    print("\n  Building Weather Adjustment Model...")
    
    # Check if weather columns exist
    if 'gas_hdd' not in df.columns or 'population_cdd' not in df.columns:
        print("    No weather data available")
        return None
    
    # Get training data (where we have actual storage and deltas)
    train_mask = df[storage_col].notna() & df['storage_delta'].notna()
    train_df = df[train_mask].copy()
    
    if len(train_df) < 30:
        print("    Insufficient data for weather model")
        return None
    
    # Create features
    features = []
    feature_names = []
    
    # Basic weather features
    if 'gas_hdd' in train_df.columns:
        features.append(train_df['gas_hdd'].fillna(0).values.reshape(-1, 1))
        feature_names.append('gas_hdd')
    
    if 'population_cdd' in train_df.columns:
        features.append(train_df['population_cdd'].fillna(0).values.reshape(-1, 1))
        feature_names.append('population_cdd')
    
    # Add rolling averages if enough data
    if len(train_df) > 14:
        train_df['hdd_7d_avg'] = train_df['gas_hdd'].rolling(7, min_periods=1).mean()
        train_df['cdd_7d_avg'] = train_df['population_cdd'].rolling(7, min_periods=1).mean()
        features.append(train_df['hdd_7d_avg'].fillna(0).values.reshape(-1, 1))
        features.append(train_df['cdd_7d_avg'].fillna(0).values.reshape(-1, 1))
        feature_names.extend(['hdd_7d_avg', 'cdd_7d_avg'])
    
    # Add week of year for seasonality
    train_df['week'] = train_df['Date'].dt.isocalendar().week
    features.append(train_df['week'].values.reshape(-1, 1))
    feature_names.append('week')
    
    # Combine features
    X = np.hstack(features)
    y = train_df['storage_delta'].values
    
    # Build model
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    model = LinearRegression()
    model.fit(X_scaled, y)
    
    # Calculate model performance
    predictions = model.predict(X_scaled)
    rmse = np.sqrt(np.mean((predictions - y) ** 2))
    r2 = model.score(X_scaled, y)
    
    print(f"    Weather model R²: {r2:.3f}")
    print(f"    RMSE: {rmse:.2f} BCF/day")
    print(f"    Features: {', '.join(feature_names)}")
    
    return {
        'model': model,
        'scaler': scaler,
        'feature_names': feature_names,
        'rmse': rmse,
        'r2': r2
    }

def apply_storage_constraints(storage_value, date, historical_patterns, week_num):
    """Apply physical and seasonal constraints to storage predictions"""
    
    # Hard physical constraints
    storage_value = max(MIN_STORAGE, min(MAX_STORAGE, storage_value))
    
    # Apply seasonal constraints if available
    if historical_patterns and 'seasonal_avg' in historical_patterns:
        seasonal_avg = historical_patterns['seasonal_avg']
        seasonal_std = historical_patterns['seasonal_std']
        
        if week_num in seasonal_avg.index:
            expected_storage = seasonal_avg[week_num]
            expected_std = seasonal_std[week_num] if week_num in seasonal_std.index else 200
            
            # Allow 2.5 standard deviations from seasonal normal
            seasonal_min = expected_storage - 2.5 * expected_std
            seasonal_max = expected_storage + 2.5 * expected_std
            
            # Apply soft seasonal constraints (weighted average with hard constraints)
            if storage_value < seasonal_min:
                # Pull towards seasonal minimum
                storage_value = 0.7 * storage_value + 0.3 * seasonal_min
            elif storage_value > seasonal_max:
                # Pull towards seasonal maximum
                storage_value = 0.7 * storage_value + 0.3 * seasonal_max
    
    # Apply comfort zone constraints with gradual adjustment
    if storage_value < COMFORT_MIN:
        # Gradually pull up when below comfort minimum
        adjustment = (COMFORT_MIN - storage_value) * 0.1
        storage_value += adjustment
    elif storage_value > COMFORT_MAX:
        # Gradually pull down when above comfort maximum
        adjustment = (storage_value - COMFORT_MAX) * 0.1
        storage_value -= adjustment
    
    return storage_value

def calculate_enhanced_error_corrected_storage():
    """Enhanced storage correction with seasonal and weather constraints"""
    
    print("\n" + "=" * 80)
    print("ENHANCED STORAGE ERROR CORRECTION MODEL")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    print(f"Working directory: {AGGREGATE_PATH}")
    print(f"Storage bounds: {MIN_STORAGE:,} - {MAX_STORAGE:,} BCF")
    print(f"Comfort zone: {COMFORT_MIN:,} - {COMFORT_MAX:,} BCF")
    
    # Find the most recent L48 file
    print("\n" + "=" * 60)
    print("STEP 1: FINDING L48 FILE")
    print("=" * 60)
    
    pattern = os.path.join(AGGREGATE_PATH, "L48_*.csv")
    l48_files = glob.glob(pattern)
    
    if not l48_files:
        print(f"  ✗ No L48 files found in {AGGREGATE_PATH}")
        return False
    
    l48_files.sort()
    latest_file = l48_files[-1]
    filename = os.path.basename(latest_file)
    
    print(f"  ✓ Found file: {filename}")
    
    # Load the file
    print("\n" + "=" * 60)
    print("STEP 2: LOADING DATA")
    print("=" * 60)
    
    try:
        df = pd.read_csv(latest_file)
        print(f"  ✓ Loaded {len(df):,} records")
        
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date').reset_index(drop=True)
        
        # Identify storage column
        storage_col = 'storage_lower_48_bcf' if 'storage_lower_48_bcf' in df.columns else 'storage_lower_48'
        
        print(f"  Date range: {df['Date'].min().date()} to {df['Date'].max().date()}")
        print(f"  Storage column: {storage_col}")
        
        # Extract historical patterns
        print("\n" + "=" * 60)
        print("STEP 3: ANALYZING HISTORICAL PATTERNS")
        print("=" * 60)
        
        historical_patterns = get_historical_seasonal_patterns(df, storage_col)
        weather_model = build_weather_adjustment_model(df, storage_col)
        
        # Calculate error correction with constraints
        print("\n" + "=" * 60)
        print("STEP 4: CALCULATING CONSTRAINED ERROR CORRECTION")
        print("=" * 60)
        
        # Initialize the corrected storage column
        df['Storage_Corrected'] = np.nan
        df['week'] = df['Date'].dt.isocalendar().week
        
        # Find all indices where we have actual storage values
        actual_storage_indices = df[df[storage_col].notna()].index.tolist()
        
        if len(actual_storage_indices) < 2:
            print(f"  ✗ Not enough actual storage values for correction")
            return False
        
        print(f"  Found {len(actual_storage_indices)} actual storage values")
        
        # Initialize with the first actual storage value
        first_idx = actual_storage_indices[0]
        df.loc[first_idx, 'Storage_Corrected'] = df.loc[first_idx, storage_col]
        
        # Process each segment between actual storage values
        error_history = []
        
        for i in range(len(actual_storage_indices) - 1):
            start_idx = actual_storage_indices[i]
            end_idx = actual_storage_indices[i + 1]
            
            # Get actual values at boundaries
            start_actual = df.loc[start_idx, storage_col]
            end_actual = df.loc[end_idx, storage_col]
            
            # Calculate implied storage at end point
            implied_at_end = df.loc[start_idx, 'Storage_Corrected']
            for j in range(start_idx + 1, end_idx + 1):
                delta = df.loc[j, 'storage_delta']
                if pd.isna(delta):
                    delta = 0
                implied_at_end += delta
            
            # Calculate the error
            error = end_actual - implied_at_end
            days_in_segment = end_idx - start_idx
            error_rate = error / days_in_segment if days_in_segment > 0 else 0
            
            error_history.append({
                'start_date': df.loc[start_idx, 'Date'],
                'end_date': df.loc[end_idx, 'Date'],
                'days': days_in_segment,
                'total_error': error,
                'daily_error_rate': error_rate
            })
            
            # Apply smooth correction with constraints
            correction_curve = np.zeros(days_in_segment + 1)
            for k in range(days_in_segment + 1):
                t = k / days_in_segment if days_in_segment > 0 else 0
                # Fourier-like smooth correction
                linear_component = t * error
                cosine_component = (1 - np.cos(np.pi * t)) / 2 * error
                correction_curve[k] = 0.3 * linear_component + 0.7 * cosine_component
            
            # Apply corrections with constraints
            current_value = df.loc[start_idx, 'Storage_Corrected']
            for j in range(start_idx + 1, end_idx + 1):
                delta = df.loc[j, 'storage_delta']
                if pd.isna(delta):
                    delta = 0
                
                segment_position = j - start_idx
                if segment_position < len(correction_curve):
                    correction_delta = correction_curve[segment_position] - correction_curve[segment_position - 1]
                else:
                    correction_delta = 0
                
                current_value = current_value + delta + correction_delta
                
                # Apply constraints
                week_num = df.loc[j, 'week']
                current_value = apply_storage_constraints(
                    current_value, 
                    df.loc[j, 'Date'],
                    historical_patterns,
                    week_num
                )
                
                df.loc[j, 'Storage_Corrected'] = current_value
            
            # Ensure exact match at actual points
            df.loc[end_idx, 'Storage_Corrected'] = end_actual
            
            print(f"    Segment {i+1}/{len(actual_storage_indices)-1}: {df.loc[start_idx, 'Date'].date()} to {df.loc[end_idx, 'Date'].date()}")
            print(f"      Error: {error:.2f} BCF over {days_in_segment} days")
        
        # Handle forward projection with enhanced constraints
        last_actual_idx = actual_storage_indices[-1]
        if last_actual_idx < len(df) - 1:
            print(f"\n  Enhanced forward projection from last actual value...")
            
            # Calculate adaptive error rate based on seasonal patterns
            if historical_patterns and 'weekly_stats' in historical_patterns:
                weekly_stats = historical_patterns['weekly_stats']
            
            # Use weather model if available
            use_weather = weather_model is not None and weather_model['r2'] > 0.3
            
            current_value = df.loc[last_actual_idx, 'Storage_Corrected']
            
            for j in range(last_actual_idx + 1, len(df)):
                week_num = df.loc[j, 'week']
                
                # Get base delta
                delta = df.loc[j, 'storage_delta']
                if pd.isna(delta):
                    delta = 0
                
                # Apply weather adjustment if model available
                if use_weather:
                    features = []
                    for feat_name in weather_model['feature_names']:
                        if feat_name == 'week':
                            features.append(week_num)
                        elif feat_name in df.columns:
                            features.append(df.loc[j, feat_name] if pd.notna(df.loc[j, feat_name]) else 0)
                        else:
                            features.append(0)
                    
                    X_pred = np.array(features).reshape(1, -1)
                    X_pred_scaled = weather_model['scaler'].transform(X_pred)
                    weather_adjustment = weather_model['model'].predict(X_pred_scaled)[0] - delta
                    
                    # Apply weather adjustment with dampening
                    delta += weather_adjustment * 0.3
                
                # Apply seasonal adjustment based on historical patterns
                if historical_patterns and 'seasonal_avg' in historical_patterns:
                    seasonal_avg = historical_patterns['seasonal_avg']
                    if week_num in seasonal_avg.index and (week_num - 1) in seasonal_avg.index:
                        # Expected weekly change based on seasonality
                        expected_change = seasonal_avg[week_num] - seasonal_avg[week_num - 1]
                        # Blend with actual delta
                        delta = 0.7 * delta + 0.3 * expected_change
                
                # Update storage with constrained delta
                current_value = current_value + delta
                
                # Apply multiple constraint layers
                current_value = apply_storage_constraints(
                    current_value,
                    df.loc[j, 'Date'],
                    historical_patterns,
                    week_num
                )
                
                # Additional check for extreme values
                if current_value > MAX_STORAGE - 100:
                    print(f"    ⚠ Warning: Approaching maximum storage at {df.loc[j, 'Date'].date()}: {current_value:.0f} BCF")
                    current_value = min(current_value, MAX_STORAGE - 50)
                elif current_value < MIN_STORAGE + 100:
                    print(f"    ⚠ Warning: Approaching minimum storage at {df.loc[j, 'Date'].date()}: {current_value:.0f} BCF")
                    current_value = max(current_value, MIN_STORAGE + 50)
                
                df.loc[j, 'Storage_Corrected'] = current_value
            
            print(f"    Projected {len(df) - last_actual_idx - 1} days with constraints")
            print(f"    Final storage level: {current_value:.0f} BCF")
        
        # Validation and statistics
        print("\n" + "=" * 60)
        print("STEP 5: VALIDATION AND ANALYSIS")
        print("=" * 60)
        
        # Check if any values exceed bounds
        violations = df[
            (df['Storage_Corrected'] < MIN_STORAGE) | 
            (df['Storage_Corrected'] > MAX_STORAGE)
        ]
        
        if len(violations) > 0:
            print(f"  ⚠ Found {len(violations)} storage bound violations")
            for idx, row in violations.head(5).iterrows():
                print(f"    {row['Date'].date()}: {row['Storage_Corrected']:.0f} BCF")
        else:
            print(f"  ✓ All storage values within bounds ({MIN_STORAGE:,} - {MAX_STORAGE:,} BCF)")
        
        # Compare with seasonal norms
        if historical_patterns and 'seasonal_avg' in historical_patterns:
            future_mask = df[storage_col].isna() & df['Storage_Corrected'].notna()
            future_df = df[future_mask].copy()
            
            if len(future_df) > 0:
                seasonal_avg = historical_patterns['seasonal_avg']
                future_df['seasonal_expected'] = future_df['week'].map(seasonal_avg)
                future_df['deviation'] = future_df['Storage_Corrected'] - future_df['seasonal_expected']
                
                print(f"\n  Deviation from Seasonal Norms (future projections):")
                print(f"    Mean deviation: {future_df['deviation'].mean():.0f} BCF")
                print(f"    Std deviation: {future_df['deviation'].std():.0f} BCF")
                print(f"    Max deviation: {abs(future_df['deviation']).max():.0f} BCF")
        
        # Save the updated file
        print("\n" + "=" * 60)
        print("STEP 6: SAVING RESULTS")
        print("=" * 60)
        
        # Remove temporary columns before saving
        columns_to_remove = ['week', 'year', 'month', 'day_of_year', 'Correction_Method', 'Last_Updated']
        for col in columns_to_remove:
            if col in df.columns:
                df = df.drop(columns=[col])
        
        df.to_csv(latest_file, index=False)
        
        print(f"  ✓ File saved: {filename}")
        print(f"    Size: {os.path.getsize(latest_file) / (1024 * 1024):.2f} MB")
        
        # Show sample of future projections
        future_sample = df[df[storage_col].isna() & df['Storage_Corrected'].notna()].tail(10)
        if len(future_sample) > 0:
            print(f"\n  Sample Future Projections (last 10 days):")
            for idx, row in future_sample.tail(5).iterrows():
                print(f"    {row['Date'].date()}: {row['Storage_Corrected']:.0f} BCF")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error processing file: {e}")
        import traceback
        traceback.print_exc()
        return False

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the enhanced error correction model"""
    
    success = calculate_enhanced_error_corrected_storage()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ ENHANCED ERROR CORRECTION MODEL COMPLETE!")
    else:
        print("✗ ERROR CORRECTION MODEL FAILED!")
    print("=" * 80)
    
    if success:
        print("\nModel Features:")
        print("  ✓ Fourier-like smooth error correction between actual points")
        print("  ✓ Historical seasonal patterns from same weeks across years")
        print("  ✓ Weather-based adjustments using HDD/CDD data")
        print("  ✓ Hard constraints: Storage bounded to 500-4,100 BCF")
        print("  ✓ Soft constraints: Comfort zone 1,000-3,800 BCF")
        print("  ✓ Seasonal deviation limits (±2.5 standard deviations)")
        print("\nThe model learns from:")
        print("  • Historical storage patterns by week of year")
        print("  • Weather impacts on storage changes")
        print("  • Error patterns between model predictions and actuals")
        print("\nThis provides more realistic storage projections that:")
        print("  • Respect physical storage limitations")
        print("  • Follow seasonal patterns")
        print("  • Adjust for weather conditions")
        print("  • Stay within operational comfort zones")
    
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()