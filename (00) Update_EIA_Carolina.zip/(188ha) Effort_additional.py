# =============================================================================
# RECALCULATE IMPLIED STORAGE FROM LAST KNOWN VALUE
# =============================================================================
import pandas as pd
import os
from datetime import datetime
import glob
import numpy as np

# --- CONFIGURATION ---
AGGREGATE_PATH = r"D:\EIA_STACK\Pricing_RL\AGGREGATE"

# =============================================================================
# MAIN FUNCTION
# =============================================================================
def recalculate_implied_storage():
    """Recalculate implied storage starting from last known storage value"""
    
    print("\n" + "=" * 80)
    print("RECALCULATE IMPLIED STORAGE FROM LAST KNOWN VALUE")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    print(f"Working directory: {AGGREGATE_PATH}")
    
    # Find the most recent L48 file
    print("\n" + "=" * 60)
    print("STEP 1: FINDING L48 FILE")
    print("=" * 60)
    
    pattern = os.path.join(AGGREGATE_PATH, "L48_*.csv")
    l48_files = glob.glob(pattern)
    
    if not l48_files:
        print(f"  ✗ No L48 files found in {AGGREGATE_PATH}")
        return False
    
    l48_files.sort()
    latest_file = l48_files[-1]
    filename = os.path.basename(latest_file)
    
    print(f"  ✓ Found file: {filename}")
    
    # Load the file
    print("\n" + "=" * 60)
    print("STEP 2: LOADING DATA")
    print("=" * 60)
    
    try:
        print(f"  Loading {filename}...")
        df = pd.read_csv(latest_file)
        print(f"  ✓ Loaded {len(df):,} records")
        
        # Check for required columns
        if 'Date' not in df.columns:
            print(f"  ✗ No 'Date' column found")
            return False
        
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date').reset_index(drop=True)
        print(f"  Date range: {df['Date'].min().date()} to {df['Date'].max().date()}")
        
        # Check for storage_delta
        if 'storage_delta' not in df.columns:
            print(f"  ✗ 'storage_delta' column not found")
            print(f"     Please run the storage delta calculation script first")
            return False
        
        # Check for storage_lower_48_bcf
        storage_col = None
        if 'storage_lower_48_bcf' in df.columns:
            storage_col = 'storage_lower_48_bcf'
        elif 'storage_lower_48' in df.columns:
            storage_col = 'storage_lower_48'
        else:
            print(f"  ✗ No storage_lower_48 column found")
            print(f"     Available columns: {list(df.columns)}")
            return False
        
        print(f"  ✓ Found storage column: {storage_col}")
        print(f"  ✓ Found storage_delta column")
        
        # Clear existing columns
        print("\n" + "=" * 60)
        print("STEP 3: CLEARING EXISTING COLUMNS")
        print("=" * 60)
        
        columns_to_clear = ['Implied_Storage', 'Storage_Corrected']
        for col in columns_to_clear:
            if col in df.columns:
                print(f"  Clearing column: {col}")
                df[col] = np.nan
            else:
                print(f"  Creating new column: {col}")
                df[col] = np.nan
        
        print(f"  ✓ Columns cleared/created")
        
        # Find the LAST non-null storage value
        print("\n" + "=" * 60)
        print("STEP 4: FINDING LAST KNOWN STORAGE VALUE")
        print("=" * 60)
        
        last_storage_idx = df[storage_col].last_valid_index()
        
        if last_storage_idx is None:
            print(f"  ✗ No valid storage values found in {storage_col}")
            return False
        
        last_storage_value = df.loc[last_storage_idx, storage_col]
        last_storage_date = df.loc[last_storage_idx, 'Date']
        
        print(f"  Last storage value: {last_storage_value:.2f} BCF")
        print(f"  Last storage date: {last_storage_date.date()}")
        print(f"  Last storage index: {last_storage_idx}")
        print(f"  Records after last storage: {len(df) - last_storage_idx - 1}")
        
        # Calculate Implied Storage
        print("\n" + "=" * 60)
        print("STEP 5: CALCULATING IMPLIED STORAGE")
        print("=" * 60)
        
        # Set the last known value as the starting point
        df.loc[last_storage_idx, 'Implied_Storage'] = last_storage_value
        df.loc[last_storage_idx, 'Storage_Corrected'] = last_storage_value
        
        # Calculate forward from the last known value
        print(f"  Calculating forward from index {last_storage_idx + 1} to {len(df) - 1}...")
        
        current_storage = last_storage_value
        records_calculated = 0
        
        for i in range(last_storage_idx + 1, len(df)):
            # Get current storage_delta (use 0 if NaN)
            current_delta = df.loc[i, 'storage_delta']
            if pd.isna(current_delta):
                current_delta = 0
            
            # Calculate new implied storage
            current_storage = current_storage + current_delta
            df.loc[i, 'Implied_Storage'] = current_storage
            df.loc[i, 'Storage_Corrected'] = current_storage
            
            records_calculated += 1
            
            # Show progress every 30 days
            if records_calculated % 30 == 0:
                progress_date = df.loc[i, 'Date']
                print(f"    Progress: {progress_date.date()} - Storage: {current_storage:.2f} BCF (Delta: {current_delta:.2f})")
        
        print(f"  ✓ Calculated {records_calculated} forward projections")
        
        # Also calculate backwards from the last known value (if there's data before it)
        if last_storage_idx > 0:
            print(f"\n  Calculating backward from index {last_storage_idx - 1} to 0...")
            
            current_storage = last_storage_value
            records_calculated_backward = 0
            
            for i in range(last_storage_idx - 1, -1, -1):
                # Get the NEXT day's delta (since we're going backward)
                next_delta = df.loc[i + 1, 'storage_delta']
                if pd.isna(next_delta):
                    next_delta = 0
                
                # Subtract the delta to get previous day's storage
                current_storage = current_storage - next_delta
                df.loc[i, 'Implied_Storage'] = current_storage
                df.loc[i, 'Storage_Corrected'] = current_storage
                
                records_calculated_backward += 1
                
                # Show progress every 365 days
                if records_calculated_backward % 365 == 0:
                    progress_date = df.loc[i, 'Date']
                    print(f"    Progress: {progress_date.date()} - Storage: {current_storage:.2f} BCF")
            
            print(f"  ✓ Calculated {records_calculated_backward} historical values")
        
        # Calculate statistics
        print("\n" + "=" * 60)
        print("STEP 6: ANALYSIS AND STATISTICS")
        print("=" * 60)
        
        # Overall statistics for Implied_Storage
        implied_stats = df['Implied_Storage'].describe()
        print(f"  Implied Storage Statistics:")
        print(f"    Count: {implied_stats['count']:.0f} non-null values")
        print(f"    Mean: {implied_stats['mean']:.2f} BCF")
        print(f"    Std: {implied_stats['std']:.2f} BCF")
        print(f"    Min: {implied_stats['min']:.2f} BCF")
        print(f"    25%: {implied_stats['25%']:.2f} BCF")
        print(f"    50%: {implied_stats['50%']:.2f} BCF")
        print(f"    75%: {implied_stats['75%']:.2f} BCF")
        print(f"    Max: {implied_stats['max']:.2f} BCF")
        
        # Show recent values
        print(f"\n  Recent Implied Storage Values (last 10 days):")
        recent = df[['Date', 'storage_delta', 'Implied_Storage', 'Storage_Corrected']].tail(10)
        for idx, row in recent.iterrows():
            delta_str = f"{row['storage_delta']:.2f}" if pd.notna(row['storage_delta']) else "NaN"
            implied_str = f"{row['Implied_Storage']:.2f}" if pd.notna(row['Implied_Storage']) else "NaN"
            print(f"    {row['Date'].date()}: Delta={delta_str:>7}, Implied={implied_str:>8}")
        
        # Compare with actual storage where available
        print(f"\n  Comparison with Actual Storage (where available):")
        comparison_mask = df[storage_col].notna() & df['Implied_Storage'].notna()
        comparison_df = df[comparison_mask].copy()
        
        if len(comparison_df) > 0:
            comparison_df['Difference'] = comparison_df['Implied_Storage'] - comparison_df[storage_col]
            
            # Show statistics for periods before and after the last known value
            before_last = comparison_df[comparison_df.index < last_storage_idx]
            at_last = comparison_df[comparison_df.index == last_storage_idx]
            
            if len(before_last) > 0:
                print(f"    Before last known value (n={len(before_last)}):")
                print(f"      Mean difference: {before_last['Difference'].mean():.2f} BCF")
                print(f"      Max abs difference: {before_last['Difference'].abs().max():.2f} BCF")
            
            if len(at_last) > 0:
                print(f"    At last known value:")
                row = at_last.iloc[0]
                print(f"      Date: {row['Date'].date()}")
                print(f"      Actual: {row[storage_col]:.2f} BCF")
                print(f"      Implied: {row['Implied_Storage']:.2f} BCF")
                print(f"      Difference: {row['Difference']:.2f} BCF (should be 0.00)")
        
        # Save the updated file
        print("\n" + "=" * 60)
        print("STEP 7: SAVING UPDATED FILE")
        print("=" * 60)
        
        # Create backup first
        backup_file = latest_file.replace('.csv', '_backup.csv')
        print(f"  Creating backup: {os.path.basename(backup_file)}")
        df_original = pd.read_csv(latest_file)
        df_original.to_csv(backup_file, index=False)
        
        # Save updated file
        df.to_csv(latest_file, index=False)
        
        file_size = os.path.getsize(latest_file) / (1024 * 1024)  # MB
        print(f"  ✓ File saved: {filename}")
        print(f"    Size: {file_size:.2f} MB")
        
        # Verify columns were updated
        verification_cols = ['Implied_Storage', 'Storage_Corrected']
        for col in verification_cols:
            non_null = df[col].notna().sum()
            print(f"  ✓ '{col}': {non_null:,} non-null values")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error processing file: {e}")
        import traceback
        traceback.print_exc()
        return False

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the implied storage recalculation"""
    
    success = recalculate_implied_storage()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ IMPLIED STORAGE RECALCULATION COMPLETE!")
    else:
        print("✗ IMPLIED STORAGE RECALCULATION FAILED!")
    print("=" * 80)
    
    if success:
        print("\nSummary:")
        print("  • Cleared existing Implied_Storage and Storage_Corrected columns")
        print("  • Started from the LAST known storage_lower_48_bcf value")
        print("  • Calculated forward using cumulative storage_delta")
        print("  • Also calculated backward to fill historical values")
        print("  • Both columns now contain the same recalculated values")
        print("\nThis represents storage projections based on:")
        print("  - The most recent actual storage observation")
        print("  - Cumulative supply/demand balance (storage_delta)")
    
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()