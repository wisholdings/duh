import traceback
import pandas as pd
from datetime import datetime, timedelta, date
from sqlalchemy import create_engine, MetaData, Table, Column, DateTime, Date, Float, String, text
from sqlalchemy.exc import SQLAlchemyError
import os
import sys

# --- Main Configuration ---

DB_CONNECTION_STRING = (
)
CSV_FILE_PATH = r"D:\EIA_STACK\NHITS_POWER.csv"  # Raw string for Windows paths

# Define all the upload tasks to be performed by this script.
# This makes it easy to add new forecast types in the future.
TASKS = [
    {
        "name": "Natural Gas Forecast (NG)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_NG",
        "column_suffix": "_NG_MW",
        "upload_method": "merge"  # Uses a highly efficient MERGE statement for upserts.
    },
    {
        "name": "Coal Forecast (COL)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_COL",
        "column_suffix": "_COL_MW",
        "upload_method": "merge"
    },
    {
        "name": "Hydro Forecast (WAT)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_WAT",
        "column_suffix": "_WAT_MW",
        "upload_method": "merge"
    },
    {
        "name": "Nuclear Forecast (NUC)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_NUC",
        "column_suffix": "_NUC_MW",
        "upload_method": "merge"
    },
    {
        "name": "Other Forecast (OTH)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_OTH",
        "column_suffix": "_OTH_MW",
        "upload_method": "merge"
    },
    {
        "name": "Load Forecast (Load)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_LOAD",
        "column_suffix": "_LOAD",
        "upload_method": "merge"
    },
    {
        "name": "Solar Forecast (Solar)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_SUN",
        "column_suffix": "_SUN_MW",
        "upload_method": "merge"
    },
    {
        "name": "Wind Forecast (Wind)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_WND",
        "column_suffix": "_WND_MW",
        "upload_method": "merge"
    },
    {
        "name": "Interchange Forecast (Interchange)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_INTERCHANGE",
        "column_suffix": "_INTERCHANGE_MW",
        "upload_method": "merge"
    },
    {
        "name": "Battery Forecast (Battery)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_BAT",
        "column_suffix": "_BAT_MW",
        "upload_method": "merge"
    },
    {
        "name": "Pumped Storage Forecast (PS)",
        "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_PS",
        "column_suffix": "_PS_MW",
        "upload_method": "merge"
    }
]

REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "newyork", "northwest", "southwest", "southeast", "tennessee", "texas"
]

# --- Database and Table Functions ---

def create_sql_table_if_not_exists(engine, table_name):
    """
    Creates the SQL Server table for forecasts if it doesn't already exist.
    This function is generic and works for any table with the defined schema.
    """
    metadata = MetaData()
    columns = [
        Column('datetime', DateTime, primary_key=True),
        Column('region', String(50), primary_key=True),
        Column('date_published', Date, primary_key=True),
        Column('forecast_mw', Float)
    ]
    table = Table(table_name, metadata, *columns, extend_existing=True)
    try:
        metadata.create_all(engine, tables=[table])
        print(f"Table '{table_name}' is confirmed to exist in SQL Server.")
    except SQLAlchemyError as e:
        print(f"Error creating or verifying table '{table_name}': {e}")
        raise

# --- Data Processing Function ---

def process_forecast_data(df, column_suffix):
    """
    Processes a given DataFrame to extract and reshape forecast data for a specific fuel type.
    Uses the efficient pd.melt for reshaping.
    """
    print(f"Processing data for columns ending with '{column_suffix}'...")
    
    # Identify the relevant region columns based on the suffix
    region_cols = [f"{r.upper()}{column_suffix}" for r in REGIONS]
    cols_to_melt = [col for col in region_cols if col in df.columns]

    if not cols_to_melt:
        print(f"WARNING: No columns with suffix '{column_suffix}' found in the CSV. Skipping.")
        return None

    print(f"Reshaping data for {len(cols_to_melt)} regions using pd.melt...")
    
    # Use pd.melt to transform data from wide to long format efficiently
    final_df = pd.melt(
        df,
        id_vars=['datetime'],
        value_vars=cols_to_melt,
        var_name='region_col',
        value_name='forecast_mw'
    )
    
    # Clean up the region column and add the publication date
    final_df['region'] = final_df['region_col'].str.replace(column_suffix, '', regex=False).str.lower()
    final_df['date_published'] = date.today()
    
    # Clean up and reorder columns
    final_df.drop(columns=['region_col'], inplace=True)
    final_df.dropna(subset=['forecast_mw'], inplace=True)
    final_df = final_df[['datetime', 'region', 'date_published', 'forecast_mw']]

    print(f"Finished processing. Found {len(final_df)} total records for '{column_suffix}'.")
    return final_df

# --- Data Upload Functions ---

def upload_data_with_merge(engine, table_name, df):
    """
    Uploads data using a temporary staging table and a MERGE statement.
    This is an efficient "upsert" (update or insert) operation.
    """
    if df.empty:
        print("No data to upload.")
        return 0

    temp_table_name = f"#Stage_{table_name}_{int(datetime.now().timestamp())}" # Unique temp table
    
    try:
        print(f"Uploading {len(df)} rows to temporary staging table...")
        df.to_sql(name=temp_table_name, con=engine, if_exists='replace', index=False)
        print("Upload to staging table complete.")

        with engine.connect() as connection:
            print("Executing MERGE statement to update/insert into final table...")
            merge_sql = text(f"""
            MERGE INTO {table_name} AS Target
            USING {temp_table_name} AS Source
            ON Target.datetime = Source.datetime
               AND Target.region = Source.region
               AND Target.date_published = Source.date_published
            WHEN MATCHED THEN
                UPDATE SET Target.forecast_mw = Source.forecast_mw
            WHEN NOT MATCHED BY TARGET THEN
                INSERT (datetime, region, date_published, forecast_mw)
                VALUES (Source.datetime, Source.region, Source.date_published, Source.forecast_mw);
            """)
            result = connection.execute(merge_sql)
            connection.commit()
            print(f"MERGE operation complete. {result.rowcount} rows affected.")
            return len(df)

    except SQLAlchemyError as e:
        print(f"Error during MERGE upload process: {e}")
        raise


# --- Main Execution ---

def main():
    """
    Main execution function.
    """
    print("=" * 60)
    print("N-HiTS Power Forecast Upload Script (Unified)")
    print("=" * 60)
    
    try:
        # --- 1. Load and Prepare Base Data ---
        if not os.path.exists(CSV_FILE_PATH):
            print(f"FATAL ERROR: CSV file not found: {CSV_FILE_PATH}")
            sys.exit(1)
            
        print(f"Loading base CSV file: {CSV_FILE_PATH}")
        base_df = pd.read_csv(CSV_FILE_PATH)
        print(f"Loaded {len(base_df)} rows. Columns found: {list(base_df.columns)}")

        # --- CORRECTED SECTION ---
        # Check for 'datetime', 'Date', or 'date' column and standardize it.
        if 'datetime' in base_df.columns:
            print("Found 'datetime' column.")
        elif 'Date' in base_df.columns:
            print("Found 'Date' column, renaming to 'datetime'.")
            base_df.rename(columns={'Date': 'datetime'}, inplace=True)
        elif 'date' in base_df.columns: # This is the new check
            print("Found 'date' column, renaming to 'datetime'.")
            base_df.rename(columns={'date': 'datetime'}, inplace=True)
        else:
            print("FATAL ERROR: Neither 'datetime', 'Date', nor 'date' column found in the CSV.")
            sys.exit(1)
        
        # Convert the standardized 'datetime' column to a datetime object
        base_df['datetime'] = pd.to_datetime(base_df['datetime'])
        # --- END CORRECTED SECTION ---

        # Filter data from two days ago to include all future forecasts
        start_date = datetime.now().date() - timedelta(days=2)
        df_filtered = base_df[base_df['datetime'].dt.date >= start_date].copy()
        print(f"Filtered base data to {len(df_filtered)} rows from {start_date.strftime('%Y-%m-%d')} forward.")
        
        if df_filtered.empty:
            print("No recent data found in the specified date range. Exiting.")
            return

        # --- 2. Connect to Database ---
        print("\nConnecting to database...")
        engine = create_engine(DB_CONNECTION_STRING)

        # --- 3. Loop Through and Execute Each Task ---
        for task in TASKS:
            print("\n" + "=" * 60)
            print(f"STARTING TASK: {task['name']}")
            print("=" * 60)

            # Ensure the target table exists
            create_sql_table_if_not_exists(engine, task['table_name'])
            
            # Process the data for the current task's column suffix
            processed_df = process_forecast_data(df_filtered, task['column_suffix'])
            
            if processed_df is None or processed_df.empty:
                print(f"No data processed for {task['name']}. Skipping upload.")
                continue
            
            # Upload data using the method specified in the task config
            print(f"Uploading data to '{task['table_name']}' using '{task['upload_method']}' method...")
            rows_uploaded = 0
            if task['upload_method'] == 'merge':
                rows_uploaded = upload_data_with_merge(engine, task['table_name'], processed_df)
            else:
                print(f"ERROR: Unknown upload method '{task['upload_method']}' for task '{task['name']}'.")
                continue

            # --- 4. Print Summary for the Task ---
            print("\n" + "-" * 20 + f" {task['name']} UPLOAD SUMMARY " + "-" * 20)
            print(f"  Records processed and uploaded: {rows_uploaded}")
            print(f"  Target table: {task['table_name']}")
            print(f"  Date published: {date.today()}")
            if not processed_df.empty:
                print(f"  Date range: {processed_df['datetime'].min()} to {processed_df['datetime'].max()}")
            print(f"  Task '{task['name']}' completed successfully!")
            print("-" * 60)

    except Exception as e:
        print(f"\nFATAL ERROR: An unexpected error occurred: {e}")
        traceback.print_exc()
        sys.exit(1)
    
    finally:
        if 'engine' in locals():
            engine.dispose()
            print("\nDatabase connection closed.")
        print("\nScript execution finished.")

if __name__ == "__main__":
    main()