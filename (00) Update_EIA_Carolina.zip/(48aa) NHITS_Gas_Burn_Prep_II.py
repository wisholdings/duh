# -*- coding: utf-8 -*-
import pandas as pd
import os
import sys

# --- Configuration ---
# Base directory where all regional files are located
BASE_OUTPUT_DIR = "D:\\EIA_STACK"

# List of all regions to process
REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "newyork", "northwest", "southeast", "southwest", "tennessee", "texas"
]

def process_region(region_name, base_dir):
    """
    Loads a region's data, cleans it, splits it into train/predict sets,
    and saves the output files.
    """
    region_upper = region_name.upper()
    
    # --- Dynamically define file paths and column names ---
    input_file_name = f"NHITS_POWER_{region_upper}.csv"
    target_col = f"{region_upper}_Power_Burn"
    
    input_file = os.path.join(base_dir, input_file_name)
    train_output_file = os.path.join(base_dir, f"{region_name}_train.csv")
    predict_output_file = os.path.join(base_dir, f"{region_name}_predict.csv")

    print("-" * 60)
    print(f"Processing Region: {region_upper}")
    print("-" * 60)

    # 1. LOAD DATA
    print(f"\n[1] Loading data from: {input_file}")
    try:
        df_full = pd.read_csv(input_file, parse_dates=['date'])
        df_full = df_full.sort_values("date").reset_index(drop=True)
        print(f"    -> Successfully loaded. Initial shape: {df_full.shape}")
        
        if target_col not in df_full.columns:
            print(f"    -> FATAL ERROR: Target column '{target_col}' not found. Skipping region.")
            return

    except FileNotFoundError:
        print(f"    -> WARNING: Input file not found. Skipping region.")
        return
    except Exception as e:
        print(f"    -> FATAL ERROR: Could not load the file. Reason: {e}. Skipping region.")
        return

    # 2. CLEAN DATA: REMOVE '_RATIO' COLUMNS
    print("\n[2] Cleaning data: Removing columns containing '_RATIO'...")
    cols_to_drop = [col for col in df_full.columns if '_RATIO' in col.upper()]
    
    if cols_to_drop:
        print(f"    -> Found and removed {len(cols_to_drop)} columns.")
        df_full = df_full.drop(columns=cols_to_drop)
        print(f"    -> Data shape after cleaning: {df_full.shape}")
    else:
        print("    -> No columns with '_RATIO' found.")

    # 3. FIND THE SPLIT POINT
    print(f"\n[3] Finding the first empty value in '{target_col}'...")
    try:
        first_nan_index = df_full[target_col].isnull().idxmax()
        if first_nan_index == 0 and not df_full[target_col].isnull().iloc[0]:
            print("    -> ERROR: No empty values found in target column. Cannot split. Skipping region.")
            return
        print(f"    -> Split point found at index: {first_nan_index}")
    except Exception as e:
        print(f"    -> ERROR: Could not determine split point. Reason: {e}. Skipping region.")
        return

    # 4. SPLIT THE DATAFRAME
    print("\n[4] Splitting the data...")
    df_train = df_full.iloc[:first_nan_index].copy()
    df_predict = df_full.iloc[first_nan_index:].copy()
    print(f"    -> Train set shape: {df_train.shape}")
    print(f"    -> Predict set shape: {df_predict.shape}")

    # 5. SAVE THE FILES
    print("\n[5] Saving the new CSV files...")
    try:
        df_train.to_csv(train_output_file, index=False)
        print(f"    -> Training data saved to: {train_output_file}")
        df_predict.to_csv(predict_output_file, index=False)
        print(f"    -> Prediction data saved to: {predict_output_file}")
    except Exception as e:
        print(f"    -> ERROR: Could not save files. Reason: {e}")

# --- Main Execution ---
if __name__ == "__main__":
    print("="*60)
    print("--- GENERALIZED SCRIPT TO CREATE TRAIN/PREDICT FILES ---")
    print(f"--- Processing {len(REGIONS)} Regions ---")
    print("="*60)

    for region in REGIONS:
        process_region(region, BASE_OUTPUT_DIR)

    print("\n" + "="*60)
    print("--- All Regions Processed Successfully ---")
    print("="*60)