import pandas as pd
import os

# --- Configuration ---

# IMPORTANT: Change this to the name of your source CSV file
source_file = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update\supply_demand_combined.csv'

# Define the mapping of columns to their destination file paths
# Using raw strings (r'...') for Windows paths is a good practice
output_mapping = {
    'LNG_IMPORTS_BCF': r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update\EAST\LNG_IMPORTS_BCF.csv',
    'LNG_EXPORTS_BCF': r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update\EAST\LNG_EXPORTS_BCF.csv',
    'CAD_NET_FLOW_BCF': r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update\EAST\CAD_NET_FLOW_BCF.csv',
    'MEX_EXPORTS_BCF': r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update\SOUTHCENTRAL\MEX_EXPORTS_BCF.csv'
}

# --- Main Logic ---

try:
    # 1. Read the source CSV file into a pandas DataFrame
    print(f"Reading source file: {source_file}...")
    df = pd.read_csv(source_file)
    print("Source file read successfully.")

    # Ensure the 'Date' column is treated as a string to prevent formatting issues,
    # or parse it properly if you need date objects. For this task, keeping it as is is fine.
    # df['Date'] = pd.to_datetime(df['Date']) # Optional: if you need to work with dates

    # 2. Iterate through the mapping to create each new file
    for column_name, destination_path in output_mapping.items():
        print(f"Processing column: {column_name}...")

        # Check if the column exists in the DataFrame
        if column_name not in df.columns:
            print(f"  - WARNING: Column '{column_name}' not found in the source file. Skipping.")
            continue

        # 3. Create a new DataFrame with just the 'Date' and the target column
        # The .copy() is used to avoid SettingWithCopyWarning
        new_df = df[['Date', column_name]].copy()

        # 4. Ensure the destination directory exists
        # os.path.dirname extracts the directory part of the path
        directory = os.path.dirname(destination_path)
        os.makedirs(directory, exist_ok=True) # exist_ok=True prevents an error if the folder already exists

        # 5. Save the new DataFrame to its destination CSV file
        # index=False prevents pandas from writing the DataFrame index as a column
        new_df.to_csv(destination_path, index=False)
        print(f"  - Successfully saved to: {destination_path}")

    print("\nAll tasks completed successfully!")

    # --- 6. Cleanup: Delete the source files ---
    print("\nCleaning up source files...")
    source_directory = os.path.dirname(source_file)
    files_to_delete = [
        'supply_demand_combined.csv',
        'supply_demand_forecast.csv',
        'supply_demand_historical.csv' # Note: The user mentioned 'supply_dmenad_historical.csv', assuming typo for 'historical'
    ]

    for filename in files_to_delete:
        file_path_to_delete = os.path.join(source_directory, filename)
        if os.path.exists(file_path_to_delete):
            try:
                os.remove(file_path_to_delete)
                print(f"  - Deleted: {filename}")
            except OSError as e:
                print(f"  - ERROR deleting {filename}: {e}")
        else:
            print(f"  - Info: File not found for deletion, skipping: {filename}")


except FileNotFoundError:
    print(f"ERROR: The source file '{source_file}' was not found.")
    print("Please make sure the file exists and the filename is correct in the script.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")