import os
import sys
import time
import traceback
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.preprocessing import LabelEncoder
import joblib
import warnings
import shutil
import re # ✅ Added for weather feature detection

# --- Suppress Warnings ---
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.utils.validation")

# --- Core Configuration ---
BASE_OUTPUT_DIR = r"D:\EIA_STACK"
REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "newyork", "northwest", "southeast", "southwest", "tennessee", "texas"
]
FORCE_RETRAIN_ALL_MODELS = False
TARGET_BASE_NAME = "LOAD"

print(f"✅ Starting Consolidated Classifier & Final Output Generator for: {TARGET_BASE_NAME}")

# --- Clipping Configuration ---
USE_RATIO_CLIPPING = TARGET_BASE_NAME.endswith('_RATIO')
if USE_RATIO_CLIPPING:
    CLIP_MIN, CLIP_MAX = 0, 1  # Default for ratios
    print(f"Ratio clipping enabled: final values will be clipped to [{CLIP_MIN}, {CLIP_MAX}]")
else:
    CLIP_MIN, CLIP_MAX = 0, float('inf')
    print(f"LOAD clipping enabled: final values will be clipped to [{CLIP_MIN}, ∞) since load cannot be negative")

# --- Parquet Engine Setup ---
try:
    import pyarrow
    PARQUET_ENGINE = 'pyarrow'
except ImportError:
    PARQUET_ENGINE = 'auto'

# --- Quantile and Class Definitions ---
QUANTILE_CONFIG = {
    0.10: "q10", 0.20: "q20", 0.30: "q30", 0.40: "q40", 0.50: "median",
    0.60: "q60", 0.70: "q70", 0.80: "q80", 0.90: "q90", 0.99: "q99",
}
sorted_quantile_alphas = sorted(QUANTILE_CONFIG.keys())
sorted_quantile_names = [QUANTILE_CONFIG[alpha] for alpha in sorted_quantile_alphas]

DYNAMIC_CLASS_NAMES = {0: f"Below_{sorted_quantile_names[0].capitalize()}"}
for i in range(len(sorted_quantile_names) - 1):
    DYNAMIC_CLASS_NAMES[i+1] = f"{sorted_quantile_names[i].capitalize()}_to_{sorted_quantile_names[i+1].capitalize()}"
DYNAMIC_CLASS_NAMES[len(sorted_quantile_names)] = f"Above_{sorted_quantile_names[-1].capitalize()}"
DYNAMIC_NUM_CLASSES = len(DYNAMIC_CLASS_NAMES)

# --- XGBoost & File Naming ---
DATE_COL = "date"
CLASS_TARGET_COL = f"{TARGET_BASE_NAME.lower()}_quantile_class"
CLASSIFIER_XGB_PARAMS = {
    'objective': 'multi:softprob', 'eval_metric': 'mlogloss', 'random_state': 42, 'n_jobs': 1,
    'learning_rate': 0.04, 'max_depth': 11, 'n_estimators': 700, 'subsample': 0.8,
    'colsample_bytree': 0.8, 'reg_alpha': 0.1, 'reg_lambda': 0.1, 'min_child_weight': 4,
}

def get_target_column(df, region_name, target_base_name):
    """Finds the target column in a dataframe, checking for regional variations."""
    region_upper = region_name.upper()
    possible_names = [f"{region_upper}_{target_base_name}", f"{region_name}_{target_base_name}", f"{region_name.lower()}_{target_base_name}", target_base_name]
    for col_name in possible_names:
        if col_name in df.columns: return col_name
    target_cols = [col for col in df.columns if col.endswith(f'_{target_base_name}')]
    if target_cols: return target_cols[0]
    return None

def calculate_midpoint_selection(all_data, class_predictions, sorted_quantile_names, target_base_name):
    """
    🔧 CRITICAL FIX: Calculate midpoint selection to eliminate systematic bias
    """
    print(f"  🎯 Implementing unbiased midpoint selection for {target_base_name}...")
    sel_value_col = f"{TARGET_BASE_NAME}_CLASSIFIER_SELECTED"
    all_data[sel_value_col] = np.nan
    for class_int in range(len(DYNAMIC_CLASS_NAMES)):
        mask = (class_predictions == class_int)
        if not mask.any(): continue
        if class_int == 0:
            col_to_select = f"{target_base_name}_{sorted_quantile_names[0]}"
            all_data.loc[mask, sel_value_col] = all_data.loc[mask, col_to_select]
        elif class_int == len(sorted_quantile_names):
            col_to_select = f"{target_base_name}_{sorted_quantile_names[-1]}"
            all_data.loc[mask, sel_value_col] = all_data.loc[mask, col_to_select]
        else:
            lower_idx, upper_idx = class_int - 1, class_int
            lower_col = f"{target_base_name}_{sorted_quantile_names[lower_idx]}"
            upper_col = f"{target_base_name}_{sorted_quantile_names[upper_idx]}"
            midpoint_values = (all_data.loc[mask, lower_col] + all_data.loc[mask, upper_col]) / 2
            all_data.loc[mask, sel_value_col] = midpoint_values
    all_data[sel_value_col].fillna(0, inplace=True)
    if USE_RATIO_CLIPPING:
        all_data[sel_value_col] = np.clip(all_data[sel_value_col], CLIP_MIN, CLIP_MAX)
        print(f"  🛡️  Final {target_base_name} predictions clipped to [{CLIP_MIN}, {CLIP_MAX}] range")
    else:
        all_data[sel_value_col] = np.maximum(all_data[sel_value_col], CLIP_MIN)
        print(f"  🛡️  Final {target_base_name} predictions clipped to [{CLIP_MIN}, ∞) range")
    return sel_value_col

if __name__ == "__main__":
    start_time = time.time()
    processed_regions, failed_regions = 0, []
    
    for region_name in REGIONS:
        region_upper = region_name.upper()
        print(f"\n===== Processing Region: {region_upper} for {TARGET_BASE_NAME} =====")
        try:
            # 1. SETUP PATHS
            target_lower = TARGET_BASE_NAME.lower()
            source_subdir = f"{target_lower}_xgb"
            model_type_dir = f"xgboost_{target_lower.replace('_ratio', '')}rangeclassifier"
            region_dir = os.path.join(BASE_OUTPUT_DIR, region_name.lower())
            input_dir = os.path.join(region_dir, "final", source_subdir)
            model_dir = os.path.join(region_dir, "Models", model_type_dir)
            os.makedirs(model_dir, exist_ok=True)
            model_save_path, le_save_path, features_save_path = [os.path.join(model_dir, f) for f in ["classifier_model.ubj", "label_encoder.joblib", "feature_list.joblib"]]
            
            # 2. LOAD & COMBINE DATA
            print("  Loading and merging quantile prediction files...")
            median_q_name = QUANTILE_CONFIG.get(0.50, "median")
            base_df_path = os.path.join(input_dir, f"{target_lower}_prediction_{median_q_name}.parquet")
            if not os.path.exists(base_df_path): print(f"  Info: Base prediction file not found, skipping region."); continue
            
            all_data = pd.read_parquet(base_df_path, engine=PARQUET_ENGINE)
            all_data.rename(columns={TARGET_BASE_NAME: f"{TARGET_BASE_NAME}_{median_q_name}"}, inplace=True)

            for q_name in sorted_quantile_names:
                if q_name == median_q_name: continue
                q_path = os.path.join(input_dir, f"{target_lower}_prediction_{q_name}.parquet")
                if not os.path.exists(q_path): raise FileNotFoundError(f"Missing required quantile file: {q_path}")
                q_df = pd.read_parquet(q_path, engine=PARQUET_ENGINE)
                q_df.rename(columns={TARGET_BASE_NAME: f"{TARGET_BASE_NAME}_{q_name}"}, inplace=True)
                all_data = pd.merge(all_data, q_df, on=DATE_COL, how='inner')

            original_train_path = os.path.join(region_dir, 'final', 'train.parquet')
            df_original_train = pd.read_parquet(original_train_path, engine=PARQUET_ENGINE)
            actual_target_col = get_target_column(df_original_train, region_name, TARGET_BASE_NAME)
            if not actual_target_col: print(f"  Info: Target column for '{TARGET_BASE_NAME}' not in train file, skipping region."); continue
            
            # 3. ✅ DEFINE EXPANDED FEATURE SET AND MERGE DATA
            print(f"  🎯 Using target column: {actual_target_col}")
            
            # ✅ Find weather features using regex (e.g., 'KPHX_temperature_2m')
            weather_features = [col for col in df_original_train.columns if re.match(r'^[A-Z]{4}_', col)]
            if weather_features:
                print(f"  🔍 Discovered {len(weather_features)} weather features (e.g., {weather_features[0]}). Adding to classifier.")
            
            # ✅ Combine all data needed for training and prediction
            cols_to_merge = [DATE_COL, actual_target_col] + weather_features
            all_data = pd.merge(all_data, df_original_train[cols_to_merge], on=DATE_COL, how='left')

            # ✅ Define the full feature list for the model
            quantile_features = sorted([f"{TARGET_BASE_NAME}_{name}" for name in sorted_quantile_names])
            model_features = sorted(quantile_features + weather_features)
            print(f"  🧠 Classifier will use {len(model_features)} features in total.")

            conditions = [all_data[actual_target_col] < all_data[quantile_features[0]]]
            for i in range(len(quantile_features) - 1):
                conditions.append((all_data[actual_target_col] >= all_data[quantile_features[i]]) & (all_data[actual_target_col] < all_data[quantile_features[i+1]]))
            conditions.append(all_data[actual_target_col] >= all_data[quantile_features[-1]])
            all_data[CLASS_TARGET_COL] = np.select(conditions, list(range(DYNAMIC_NUM_CLASSES)), default=np.nan)

            # 4. TRAIN OR LOAD CLASSIFIER
            print("  🔧 Training classifier with robust LabelEncoder handling...")
            df_train_cleaned = all_data.dropna(subset=[CLASS_TARGET_COL] + model_features)
            if df_train_cleaned.empty: raise ValueError("No valid training rows for classifier.");
            
            X_train = df_train_cleaned[model_features]
            y_train_raw = df_train_cleaned[CLASS_TARGET_COL].astype(int)
            le = LabelEncoder().fit(y_train_raw)
            y_train_encoded = le.transform(y_train_raw)
            num_class_for_xgb = len(le.classes_)
            print(f"  📊 Training on {len(le.classes_)} unique classes found in data. XGBoost num_class set to {num_class_for_xgb}.")
            
            model_params = {**CLASSIFIER_XGB_PARAMS, 'num_class': num_class_for_xgb}
            if FORCE_RETRAIN_ALL_MODELS or not os.path.exists(model_save_path):
                print("  Training new classifier model...")
                model = xgb.XGBClassifier(**model_params).fit(X_train, y_train_encoded, verbose=False)
                model.save_model(model_save_path)
                joblib.dump(le, le_save_path)
                joblib.dump(model_features, features_save_path)
            else:
                print("  Loading existing classifier model...")
                model = xgb.XGBClassifier(); model.load_model(model_save_path)
                model_features = joblib.load(features_save_path)
                le = joblib.load(le_save_path)
            
            # 5. PREDICT & DECODE
            print("  Generating classifier predictions...")
            X_all = all_data[model_features].fillna(0) # Fill NaNs for weather data if any
            encoded_predictions = model.predict(X_all)
            original_class_predictions = le.inverse_transform(encoded_predictions)
            all_data[f'{CLASS_TARGET_COL}_pred'] = original_class_predictions
            all_data[CLASS_TARGET_COL] = all_data[CLASS_TARGET_COL].combine_first(all_data[f'{CLASS_TARGET_COL}_pred'])
            
            # 6. UNBIASED MIDPOINT SELECTION
            sel_value_col = calculate_midpoint_selection(all_data, all_data[CLASS_TARGET_COL], sorted_quantile_names, TARGET_BASE_NAME)
            
            # 7. CREATE AND SAVE FINAL PREDICT.PARQUET
            print("  Updating final predict.parquet file...")
            predict_main_path = os.path.join(region_dir, "final", "predict.parquet")
            if not os.path.exists(predict_main_path): print(f"    SKIPPING integration: Main predict.parquet not found."); continue
            
            df_predict_original = pd.read_parquet(predict_main_path, engine=PARQUET_ENGINE)
            df_predict_original[DATE_COL] = pd.to_datetime(df_predict_original[DATE_COL])
            
            max_train_date = pd.to_datetime(df_original_train[DATE_COL].max())
            new_predictions = all_data[all_data[DATE_COL] > max_train_date][[DATE_COL, sel_value_col]].copy()
            new_predictions.rename(columns={sel_value_col: actual_target_col}, inplace=True)
            
            if actual_target_col in df_predict_original.columns:
                df_predict_updated = df_predict_original.drop(columns=[actual_target_col])
            else:
                df_predict_updated = df_predict_original.copy()

            df_predict_final = pd.merge(df_predict_updated, new_predictions, on=DATE_COL, how='left')
            backup_path = predict_main_path.replace('.parquet', '_backup.parquet')
            if not os.path.exists(backup_path):
                shutil.copy2(predict_main_path, backup_path)
                print(f"    Created backup: {os.path.basename(backup_path)}")

            df_predict_final.to_parquet(predict_main_path, index=False, engine=PARQUET_ENGINE)
            print(f"  ✅ Successfully updated and saved final predict.parquet file for {region_upper}.")
            processed_regions += 1

        except Exception as e:
            print(f"  ❌ ERROR processing {region_upper}: {e}")
            traceback.print_exc()
            failed_regions.append(f"{region_upper}_{TARGET_BASE_NAME}")

    # Final summary
    print("\n" + "="*60 + f"\nCLASSIFIER PROCESSING SUMMARY for {TARGET_BASE_NAME}\n" + "="*60)
    print(f"Successfully processed regions: {processed_regions}\nFailed regions: {len(failed_regions)}")
    if failed_regions:
        print(f"\nFailed regions:\n" + "\n".join([f"  - {r}" for r in failed_regions]))
        print(f"\nPipeline finished with errors in {time.time() - start_time:.2f} seconds.")
        sys.exit(1)
    else:
        print(f"\n✅ All regions processed successfully!\nPipeline finished in {time.time() - start_time:.2f} seconds.")
        sys.exit(0)