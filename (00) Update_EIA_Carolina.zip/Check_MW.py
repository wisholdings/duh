import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import os
import glob

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="L48 Supply & Demand Dashboard",
    page_icon="📊",
    layout="wide"
)

# --- FILE CONFIGURATION ---
# IMPORTANT: For this to work, you must place the CSV file in the same directory
# as this script, or provide the correct absolute path.
FLAT_FILE_DIR = r"." # Use current directory for simplicity

def get_latest_flat_file():
    """Get the most recent gas burns flat file from the directory."""
    # Create a dummy file if none exists for demonstration
    dummy_file_path = "gas_burns_daily_flat_file_20250903_120000.csv"
    if not glob.glob(os.path.join(FLAT_FILE_DIR, "gas_burns_daily_flat_file_*.csv")):
        st.warning("Could not find data file. Using sample data. Please place your CSV in the same directory as the script.")
        dummy_data = {
            'Date': pd.to_datetime(pd.date_range(start='2024-01-01', end='2025-09-03')),
            'Is_Historical': [True]*500 + [False]*112,
            'production_bcf': [95 + i*0.01 + 5* (d.month % 3) for i, d in enumerate(pd.date_range(start='2024-01-01', end='2025-09-03'))],
            'lng_exports_bcf': [12 + (d.month % 4) for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'mex_exports_bcf': [6 + (d.dayofweek % 2) for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'can_net_flow_bcf': [-(2 + (d.month % 5)) if d.month in [1,2,11,12] else (2 + (d.month % 5)) for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'lng_imports_bcf': [0.1]*612,
            'pipe_loss_bcf': [0.5]*612,
            'lease_plant_loss_bcf': [1.2]*612,
            'residential_pacific_eia_bcf': [2 + 3 * abs(d.month - 7) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'residential_mountain_eia_bcf': [1 + 2 * abs(d.month - 7) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'residential_midwest_eia_bcf': [5 + 8 * abs(d.month - 7) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'residential_east_eia_bcf': [6 + 10 * abs(d.month - 7) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'residential_south_central_eia_bcf': [3 + 5 * abs(d.month - 7) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'commercial_pacific_eia_bcf': [1]*612, 'commercial_mountain_eia_bcf': [0.8]*612, 'commercial_midwest_eia_bcf': [3]*612, 'commercial_east_eia_bcf': [4]*612, 'commercial_south_central_eia_bcf': [2]*612,
            'industrial_pacific_eia_bcf': [2]*612, 'industrial_mountain_eia_bcf': [1.5]*612, 'industrial_midwest_eia_bcf': [5]*612, 'industrial_east_eia_bcf': [6]*612, 'industrial_south_central_eia_bcf': [8]*612,
            'power_pacific_eia_bcf': [4 + 3 * abs(d.month - 1) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'power_mountain_eia_bcf': [2 + 1.5 * abs(d.month - 1) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'power_midwest_eia_bcf': [8 + 6 * abs(d.month - 1) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'power_east_eia_bcf': [10 + 8 * abs(d.month - 1) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'power_south_central_eia_bcf': [15 + 12 * abs(d.month - 1) / 6 for d in pd.date_range(start='2024-01-01', end='2025-09-03')],
            'storage_forecast_lower_48_bcf': [2000 + i*0.5 for i in range(612)],
            'storage_adjusted_forecast_bcf': [2010 + i*0.55 for i in range(612)],
            'storage_error': [10 - i*0.02 for i in range(612)],
            'daily_error_adjustment': [0.1 - i*0.0002 for i in range(612)]
        }
        pd.DataFrame(dummy_data).to_csv(dummy_file_path, index=False)
        return dummy_file_path

    pattern = os.path.join(FLAT_FILE_DIR, "gas_burns_daily_flat_file_*.csv")
    files = glob.glob(pattern)
    if not files:
        return None
    latest_file = max(files)
    return latest_file

@st.cache_data(ttl=3600)
def load_flat_file_data(file_path):
    """Load the gas burns flat file data."""
    try:
        df = pd.read_csv(file_path)
        df['Date'] = pd.to_datetime(df['Date'])
        df['eia_week'] = df['Date'].apply(get_eia_week_details)
        df['eia_year'] = df['eia_week'].apply(lambda x: x[0])
        df['eia_week_num'] = df['eia_week'].apply(lambda x: x[1])
        df['month'] = df['Date'].dt.month
        df['year'] = df['Date'].dt.year
        df['month_year'] = df['Date'].dt.to_period('M')
        df['L48_Residential'] = (df.filter(like='residential').sum(axis=1))
        df['L48_Commercial'] = (df.filter(like='commercial').sum(axis=1))
        df['L48_Industrial'] = (df.filter(like='industrial').sum(axis=1))
        df['L48_Power'] = (df.filter(like='power').sum(axis=1))
        df['L48_Total_Consumption'] = df[['L48_Residential', 'L48_Commercial', 'L48_Industrial', 'L48_Power']].sum(axis=1)
        return df
    except Exception as e:
        st.error(f"Error loading flat file: {e}")
        return pd.DataFrame()

def get_eia_week_details(dt):
    """Calculates the EIA reporting week (Saturday-Friday) for a given date."""
    days_until_friday = (4 - dt.weekday() + 7) % 7
    report_friday = dt + timedelta(days=days_until_friday)
    eia_year = report_friday.year
    first_day_of_year = pd.Timestamp(f'{eia_year}-01-01')
    days_to_first_friday = (4 - first_day_of_year.weekday() + 7) % 7
    first_friday_of_year = first_day_of_year + timedelta(days=days_to_first_friday)
    if report_friday < first_friday_of_year:
        return get_eia_week_details(pd.Timestamp(f'{eia_year - 1}-12-31'))
    week_number = ((report_friday - first_friday_of_year).days // 7) + 1
    return eia_year, week_number

# --- MAIN APP ---
st.title("📊 Lower 48 Natural Gas Supply & Demand Dashboard")
st.markdown("*Weekly EIA and monthly aggregated supply and demand analysis*")

latest_file = get_latest_flat_file()

if not latest_file:
    st.error(f"❌ No flat file found in directory: {FLAT_FILE_DIR}")
    st.stop()

file_timestamp = os.path.basename(latest_file).replace("gas_burns_daily_flat_file_", "").replace(".csv", "")
st.info(f"📁 Loading data from: {os.path.basename(latest_file)}")

df = load_flat_file_data(latest_file)

if df.empty:
    st.error("❌ Failed to load flat file data.")
    st.stop()

# --- DATE RANGE SELECTOR ---
st.sidebar.markdown("### 📅 Select Date Range")
start_date = st.sidebar.date_input(
    "Start Date",
    value=df['Date'].max() - timedelta(days=365),
    min_value=df['Date'].min().date(),
    max_value=df['Date'].max().date()
)
end_date = st.sidebar.date_input(
    "End Date",
    value=df['Date'].max().date(),
    min_value=df['Date'].min().date(),
    max_value=df['Date'].max().date()
)

mask = (df['Date'].dt.date >= start_date) & (df['Date'].dt.date <= end_date)
filtered_df = df[mask].copy()

# --- ALL THE DATA PROCESSING AND FIGURE CREATION ---

# --- MONTHLY AGGREGATION ---
monthly_agg = filtered_df.groupby('month_year').agg({
    'production_bcf': 'mean', 'lng_exports_bcf': 'mean', 'mex_exports_bcf': 'mean',
    'can_net_flow_bcf': 'mean', 'lng_imports_bcf': 'mean', 'pipe_loss_bcf': 'mean',
    'lease_plant_loss_bcf': 'mean', 'L48_Residential': 'mean', 'L48_Commercial': 'mean',
    'L48_Industrial': 'mean', 'L48_Power': 'mean'
}).round(2)
monthly_display = monthly_agg.copy()
monthly_display.index = monthly_display.index.strftime('%Y-%m')
monthly_display.columns = ['Production', 'LNG Exports', 'Mexico Exports', 'Canada Net Flow', 'LNG Imports', 'Pipe Loss', 'Lease/Plant Loss', 'L48 Residential', 'L48 Commercial', 'L48 Industrial', 'L48 Power']

# --- WEEKLY AGGREGATION ---
weekly_agg = filtered_df.groupby(['eia_year', 'eia_week_num']).agg({
    'production_bcf': 'mean', 'lng_exports_bcf': 'mean', 'mex_exports_bcf': 'mean',
    'can_net_flow_bcf': 'mean', 'lng_imports_bcf': 'mean', 'pipe_loss_bcf': 'mean',
    'lease_plant_loss_bcf': 'mean', 'L48_Total_Consumption': 'mean', 'Date': 'first'
}).reset_index()
weekly_agg['net_balance'] = (weekly_agg['production_bcf'].fillna(0) + weekly_agg['lng_imports_bcf'].fillna(0) + weekly_agg['can_net_flow_bcf'].fillna(0) - weekly_agg['L48_Total_Consumption'].fillna(0) - weekly_agg['lng_exports_bcf'].fillna(0) - weekly_agg['mex_exports_bcf'].fillna(0) - weekly_agg['pipe_loss_bcf'].fillna(0) - weekly_agg['lease_plant_loss_bcf'].fillna(0))
weekly_agg['total_supply'] = (weekly_agg['production_bcf'].fillna(0) + weekly_agg['lng_imports_bcf'].fillna(0) + weekly_agg['can_net_flow_bcf'].apply(lambda x: max(0, x) if pd.notna(x) else 0))
weekly_agg['total_demand'] = (weekly_agg['L48_Total_Consumption'].fillna(0) + weekly_agg['lng_exports_bcf'].fillna(0) + weekly_agg['mex_exports_bcf'].fillna(0) + weekly_agg['can_net_flow_bcf'].apply(lambda x: abs(min(0, x)) if pd.notna(x) else 0) + weekly_agg['pipe_loss_bcf'].fillna(0) + weekly_agg['lease_plant_loss_bcf'].fillna(0))
weekly_agg = weekly_agg.sort_values('Date')

# --- FIGURE 1: SUPPLY VS DEMAND ---
fig_sd = go.Figure()
fig_sd.add_trace(go.Scatter(x=weekly_agg['Date'], y=weekly_agg['total_supply'], mode='lines+markers', name='Total Supply', line=dict(width=2, color='green')))
fig_sd.add_trace(go.Scatter(x=weekly_agg['Date'], y=weekly_agg['total_demand'], mode='lines+markers', name='Total Demand', line=dict(width=2, color='red')))
fig_sd.update_layout(title="Supply vs Demand", xaxis_title="Week Starting Date", yaxis_title="BCF/d (Daily Average)", hovermode='x unified', template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))

# --- FIGURE 2: NET BALANCE ---
fig_net = go.Figure()
fig_net.add_trace(go.Scatter(x=weekly_agg['Date'], y=weekly_agg['net_balance'], mode='lines', name='Net Balance', fill='tozeroy', line=dict(width=2, color='blue'), fillcolor='rgba(0, 100, 255, 0.2)'))
fig_net.add_hline(y=0, line_width=2, line_dash="dash", line_color="black")
fig_net.update_layout(title="Net Balance (Supply - Demand)", xaxis_title="Week Starting Date", yaxis_title="Net Balance BCF/d", hovermode='x unified', template='plotly_white')

# --- FIGURE 3: STORAGE ---
storage_weekly = filtered_df.groupby(['eia_year', 'eia_week_num']).agg({'storage_forecast_lower_48_bcf': 'last', 'storage_adjusted_forecast_bcf': 'last', 'storage_error': 'last', 'daily_error_adjustment': 'mean', 'Date': 'first'}).reset_index().sort_values('Date')
fig_storage = make_subplots(rows=2, cols=1, subplot_titles=('Storage Levels (BCF)', 'Storage Error & Adjustments'), vertical_spacing=0.12, row_heights=[0.6, 0.4])
fig_storage.add_trace(go.Scatter(x=storage_weekly['Date'], y=storage_weekly['storage_forecast_lower_48_bcf'], mode='lines', name='Raw Model Forecast', line=dict(width=2, color='lightblue', dash='dash')), row=1, col=1)
fig_storage.add_trace(go.Scatter(x=storage_weekly['Date'], y=storage_weekly['storage_adjusted_forecast_bcf'], mode='lines+markers', name='Adjusted Forecast', line=dict(width=3, color='darkblue')), row=1, col=1)
fig_storage.add_trace(go.Bar(x=storage_weekly['Date'], y=storage_weekly['storage_error'], name='Weekly Storage Error', marker_color='rgba(255, 0, 0, 0.5)'), row=2, col=1)
fig_storage.add_trace(go.Scatter(x=storage_weekly['Date'], y=storage_weekly['daily_error_adjustment'], mode='lines', name='Daily Error Adjustment', line=dict(width=2, color='orange')), row=2, col=1)
fig_storage.add_hline(y=0, line_width=1, line_dash="dash", line_color="gray", row=2, col=1)
fig_storage.update_layout(height=700, template='plotly_white', hovermode='x unified', showlegend=True, legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5))

# --- FIGURE 4: BALANCE COMPONENTS ---
balance_components_weekly = filtered_df.groupby(['eia_year', 'eia_week_num']).agg({'production_bcf': 'mean', 'lng_imports_bcf': 'mean', 'can_net_flow_bcf': 'mean', 'L48_Residential': 'mean', 'L48_Commercial': 'mean', 'L48_Industrial': 'mean', 'L48_Power': 'mean', 'lng_exports_bcf': 'mean', 'mex_exports_bcf': 'mean', 'pipe_loss_bcf': 'mean', 'lease_plant_loss_bcf': 'mean', 'Date': 'first'}).reset_index().sort_values('Date')
fig_balance = go.Figure()
# Supply
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=balance_components_weekly['production_bcf'], name='Production', marker_color='darkgreen'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=balance_components_weekly['can_net_flow_bcf'].apply(lambda x: max(0,x)), name='Canada Imports', marker_color='mediumseagreen'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=balance_components_weekly['lng_imports_bcf'], name='LNG Imports', marker_color='lightgreen'))
# Demand
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['L48_Power'], name='Power', marker_color='darkred'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['L48_Industrial'], name='Industrial', marker_color='indianred'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['lng_exports_bcf'], name='LNG Exports', marker_color='orange'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['mex_exports_bcf'], name='Mexico Exports', marker_color='darkorange'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['L48_Residential'], name='Residential', marker_color='lightcoral'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['L48_Commercial'], name='Commercial', marker_color='salmon'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=balance_components_weekly['can_net_flow_bcf'].apply(lambda x: min(0,x)), name='Canada Exports', marker_color='peru'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['pipe_loss_bcf'], name='Pipe Loss', marker_color='gray'))
fig_balance.add_trace(go.Bar(x=balance_components_weekly['Date'], y=-balance_components_weekly['lease_plant_loss_bcf'], name='Lease/Plant Loss', marker_color='darkgray'))
fig_balance.add_hline(y=0, line_width=2, line_color="black")
fig_balance.update_layout(title="Weekly Supply & Demand Balance Components", xaxis_title="Week Starting Date", yaxis_title="BCF/d", barmode='relative', hovermode='x unified', height=600, template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=-0.3, xanchor="center", x=0.5), margin=dict(b=150))


# --- HTML EXPORT FUNCTION ---
def generate_html_report(df_monthly, fig1, fig2, fig3, fig4):
    """Generates a single HTML file from the dashboard components."""
    
    # Convert dataframe to HTML table
    table_html = df_monthly.to_html(classes='styled-table')

    # Get HTML for each plot
    fig1_html = fig1.to_html(full_html=False, include_plotlyjs='cdn')
    fig2_html = fig2.to_html(full_html=False, include_plotlyjs='cdn')
    fig3_html = fig3.to_html(full_html=False, include_plotlyjs='cdn')
    fig4_html = fig4.to_html(full_html=False, include_plotlyjs='cdn')

    # Combine into a single HTML string with styling
    html_string = f"""
    <html>
        <head>
            <title>L48 Supply & Demand Report</title>
            <style>
                body {{ font-family: sans-serif; padding: 20px; }}
                h1, h2 {{ color: #333; }}
                .styled-table {{
                    border-collapse: collapse;
                    margin: 25px 0;
                    font-size: 0.9em;
                    font-family: sans-serif;
                    min-width: 400px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                }}
                .styled-table thead tr {{
                    background-color: #009879;
                    color: #ffffff;
                    text-align: left;
                }}
                .styled-table th, .styled-table td {{ padding: 12px 15px; }}
                .styled-table tbody tr {{ border-bottom: 1px solid #dddddd; }}
                .styled-table tbody tr:nth-of-type(even) {{ background-color: #f3f3f3; }}
                .styled-table tbody tr:last-of-type {{ border-bottom: 2px solid #009879; }}
            </style>
        </head>
        <body>
            <h1>📊 Lower 48 Natural Gas Supply & Demand Report</h1>
            <p><strong>Report Generated On:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p><strong>Data File Used:</strong> {os.path.basename(latest_file)}</p>
            
            <h2>📈 Weekly Supply vs Demand</h2>
            {fig1_html}
            
            <h2>📉 Weekly Net Balance</h2>
            {fig2_html}
            
            <h2>📦 Storage Forecast Analysis</h2>
            {fig3_html}
            
            <h2>📊 Weekly Balance Components</h2>
            {fig4_html}

            <h2>📊 Monthly Supply & Demand Components (Mean BCF/d)</h2>
            {table_html}
            
        </body>
    </html>
    """
    return html_string


# --- SIDEBAR EXPORT BUTTON ---
st.sidebar.markdown("---")
st.sidebar.markdown("### 📥 Export Report")
if st.sidebar.button("Generate Standalone HTML Report"):
    html_report = generate_html_report(monthly_display, fig_sd, fig_net, fig_storage, fig_balance)
    with open("L48_Supply_Demand_Report.html", "w", encoding="utf-8") as f:
        f.write(html_report)
    st.sidebar.success("✅ Report saved as L48_Supply_Demand_Report.html")
    with open("L48_Supply_Demand_Report.html", "rb") as f:
        st.sidebar.download_button(
            label="Download HTML Report",
            data=f,
            file_name="L48_Supply_Demand_Report.html",
            mime="text/html"
        )


# --- DISPLAY DASHBOARD IN STREAMLIT APP ---
st.markdown("### 📈 Data Summary")
col1, col2, col3, col4 = st.columns(4)
with col1: st.metric("Total Days in View", len(filtered_df))
with col2: st.metric("Date Range Start", start_date.strftime('%Y-%m-%d'))
with col3: st.metric("Date Range End", end_date.strftime('%Y-%m-%d'))
with col4: st.metric("Historical Data", f"{(filtered_df['Is_Historical'].sum() / len(filtered_df) * 100):.1f}%")

st.markdown("### 📈 Weekly EIA Supply & Demand")
st.plotly_chart(fig_sd, use_container_width=True)

st.markdown("### 📉 Weekly Net Balance")
st.plotly_chart(fig_net, use_container_width=True)

st.markdown("### 📦 Storage Forecast Analysis")
st.plotly_chart(fig_storage, use_container_width=True)

st.markdown("### 📊 Weekly Balance Components")
st.plotly_chart(fig_balance, use_container_width=True)

st.markdown("### 📊 Monthly Supply & Demand Components")
st.dataframe(monthly_display.style.format('{:.2f}'), use_container_width=True, height=400)

st.markdown("---")
st.caption(f"**Dashboard Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M')} | **Data File:** {file_timestamp}")