# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from darts import TimeSeries
from darts.models import NHiTSModel
from darts.dataprocessing.transformers import Scaler as DartsScaler
import torch
from pytorch_lightning.callbacks import EarlyStopping
import matplotlib.pyplot as plt
import seaborn as sns
import os
import joblib
import sys

# --- Configuration ---
BASE_OUTPUT_DIR = "D:\\EIA_STACK"

# List of all regions to process
REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "newyork", "northwest", "southeast", "southwest", "tennessee", "texas"
]

# --- Model Parameters & Config (Applied to all regions) ---
LOSS_FN_CONFIG = torch.nn.SmoothL1Loss()
LOSS_NAME = "smoothl1"
PATIENCE_CONFIG = 10
INPUT_CHUNK_LENGTH = 168
OUTPUT_CHUNK_LENGTH = 48
N_EPOCHS = 30 # Set to a higher value for production runs
RANDOM_STATE = 42
LEARNING_RATE = 5e-4
BATCH_SIZE = 64
DROPOUT = 0.15
GRADIENT_CLIP_VAL = 0.5

# --- SIMPLIFIED NHiTS Architecture ---
NUM_STACKS = 3
NUM_BLOCKS = 3
NUM_LAYERS = 3
LAYER_WIDTH = 128

# --- Boundary Handling Parameters ---
BOUNDARY_SMOOTH_HOURS = 48

# --- General Config ---
# Set to True to retrain all models, False to load existing ones if available.
FORCE_RETRAIN_NHITS = False

def create_time_features(df, date_col='date'):
    """Safely creates time-based features, preventing duplicates."""
    feature_names = ['hour_sin', 'hour_cos', 'weekday_sin', 'weekday_cos', 'month_sin', 'month_cos', 'weekend']
    missing_features = [f for f in feature_names if f not in df.columns]
    if not missing_features:
        return df
    dt = df[date_col].dt
    all_time_features = {
        'hour_sin': np.sin(2 * np.pi * dt.hour / 24), 'hour_cos': np.cos(2 * np.pi * dt.hour / 24),
        'weekday_sin': np.sin(2 * np.pi * dt.dayofweek / 7), 'weekday_cos': np.cos(2 * np.pi * dt.dayofweek / 7),
        'month_sin': np.sin(2 * np.pi * dt.month / 12), 'month_cos': np.cos(2 * np.pi * dt.month / 12),
        'weekend': dt.dayofweek.isin([5, 6]).astype(int)
    }
    features_to_add = {key: val for key, val in all_time_features.items() if key in missing_features}
    return pd.concat([df, pd.DataFrame(features_to_add, index=df.index)], axis=1)

def run_forecast_for_region(region_name, base_dir):
    """
    Executes the entire forecasting pipeline for a single specified region.
    """
    region_upper = region_name.upper()
    print("\n" + "="*80)
    print(f"--- Processing Region: {region_upper} ---")
    print("="*80)

    # --- DYNAMICALLY DEFINE PATHS AND NAMES ---
    target_col = f"{region_upper}_Power_Burn"
    train_file = os.path.join(base_dir, f"{region_name}_train.csv")
    predict_file = os.path.join(base_dir, f"{region_name}_predict.csv")
    models_dir = os.path.join(base_dir, region_upper, "Models")
    predictions_dir = os.path.join(base_dir, region_upper, "Predictions")

    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(predictions_dir, exist_ok=True)
    
    model_version_suffix = f"_{target_col}_I{INPUT_CHUNK_LENGTH}_O{OUTPUT_CHUNK_LENGTH}_E{N_EPOCHS}_S{NUM_STACKS}_W{LAYER_WIDTH}_{LOSS_NAME}_LeakageFixed"
    model_save_path = os.path.join(models_dir, f"nhits_model{model_version_suffix}.pt")
    daily_output_file = os.path.join(predictions_dir, f"predicted_power_burn_DAILY{model_version_suffix}.csv")
    plot_file_daily = os.path.join(predictions_dir, f"plot_DAILY_burn{model_version_suffix}.png")
    plot_file_monthly = os.path.join(predictions_dir, f"plot_MONTHLY_comparison{model_version_suffix}.png")
    target_scaler_save_path = os.path.join(models_dir, f"target_scaler{model_version_suffix}.pkl")
    covariate_scaler_save_path = os.path.join(models_dir, f"covariate_scaler{model_version_suffix}.pkl")

    # 1. LOAD DATA
    print(f"\n[1] Loading data for {region_upper}...")
    try:
        df_train = pd.read_csv(train_file, parse_dates=['date'])
        df_predict = pd.read_csv(predict_file, parse_dates=['date'])
    except FileNotFoundError:
        print(f"    -> WARNING: Train/Predict files for {region_upper} not found. Skipping region.")
        return
    df_full = pd.concat([df_train, df_predict], ignore_index=True).sort_values("date").reset_index(drop=True)

    # 2. FEATURE ENGINEERING & SELECTION
    df_full = create_time_features(df_full)
    weather_cols = [col for col in df_full.columns if '_temp' in col.lower()]
    time_cols = ['hour_sin', 'hour_cos', 'weekday_sin', 'weekday_cos', 'month_sin', 'month_cos', 'weekend']
    covariate_cols = sorted(weather_cols + time_cols)
    safe_columns = ['date', target_col] + covariate_cols
    df_full = df_full[safe_columns]
    df_train = df_full[df_full['date'] < df_predict['date'].min()].copy()
    df_full[covariate_cols] = df_full[covariate_cols].ffill().bfill().fillna(0)

    # 3. SCALING
    print("[2] Scaling data...")
    target_series = TimeSeries.from_dataframe(df_train, 'date', target_col, freq='h')
    covariate_series = TimeSeries.from_dataframe(df_full, 'date', covariate_cols, freq='h')
    target_scaler = DartsScaler(StandardScaler())
    covariate_scaler = DartsScaler(StandardScaler())
    target_series_scaled = target_scaler.fit_transform(target_series)
    covariate_series_scaled = covariate_scaler.fit_transform(covariate_series)
    joblib.dump(target_scaler, target_scaler_save_path)
    joblib.dump(covariate_scaler, covariate_scaler_save_path)
    
    # 4. MODEL TRAINING / LOADING
    model_exists = os.path.exists(model_save_path)
    if model_exists and not FORCE_RETRAIN_NHITS:
        print(f"[3] Loading Existing Model for {region_upper}...")
        model = NHiTSModel.load(model_save_path)
    else:
        print(f"[3] Training N-HiTS Model for {region_upper}...")
        early_stopper = EarlyStopping("train_loss", patience=PATIENCE_CONFIG, min_delta=1e-4, verbose=True)
        model = NHiTSModel(
            input_chunk_length=INPUT_CHUNK_LENGTH, output_chunk_length=OUTPUT_CHUNK_LENGTH, n_epochs=N_EPOCHS,
            random_state=RANDOM_STATE, num_stacks=NUM_STACKS, num_blocks=NUM_BLOCKS, num_layers=NUM_LAYERS,
            layer_widths=LAYER_WIDTH, dropout=DROPOUT, loss_fn=LOSS_FN_CONFIG,
            optimizer_kwargs={"lr": LEARNING_RATE, "weight_decay": 1e-4}, batch_size=BATCH_SIZE,
            pl_trainer_kwargs={"accelerator": "auto", "callbacks": [early_stopper], "gradient_clip_val": GRADIENT_CLIP_VAL},
            force_reset=True)
        model.fit(series=target_series_scaled, past_covariates=covariate_series_scaled, verbose=True)
        model.save(model_save_path)

    # 5. PREDICTION & POST-PROCESSING
    print("[4] Generating and post-processing predictions...")
    prediction_series = model.predict(n=len(df_predict), series=target_series_scaled, past_covariates=covariate_series_scaled, verbose=True)
    prediction_unscaled = target_scaler.inverse_transform(prediction_series)
    df_pred_output = prediction_unscaled.pd_dataframe().reset_index().rename(columns={'date': 'date', target_col: f"{target_col}_Predicted"})
    df_final_output = pd.concat([df_train[['date', target_col]], df_predict[['date', target_col]]], ignore_index=True)
    df_final_output = pd.merge(df_final_output, df_pred_output, on='date', how='left')
    df_final_output[target_col] = df_final_output[target_col].fillna(df_final_output[f"{target_col}_Predicted"])
    
    last_historical_value = df_train[target_col].iloc[-1]
    historical_week_mean = df_train[target_col].tail(168).mean()
    first_predicted_value = df_final_output.loc[df_final_output['date'] == df_predict['date'].min(), target_col].iloc[0]
    jump = first_predicted_value - last_historical_value
    
    if abs(jump) > last_historical_value * 0.10:
        for i in range(min(BOUNDARY_SMOOTH_HOURS, len(df_predict))):
            decay = np.exp(-i / (BOUNDARY_SMOOTH_HOURS / 3))
            current_val = df_final_output.loc[df_train.index[-1] + 1 + i, target_col]
            smoothed_val = current_val * (1 - decay * 0.3) + historical_week_mean * decay * 0.3
            df_final_output.loc[df_train.index[-1] + 1 + i, target_col] = smoothed_val
    
    # 6. DAILY AGGREGATION & SAVING
    print("[5] Aggregating to daily data and saving results...")
    df_daily = df_final_output.set_index('date').resample('D')[target_col].sum().reset_index()
    df_daily[f'{target_col}_BCF'] = df_daily[target_col] / 1000.0
    df_daily.to_csv(daily_output_file, index=False, float_format='%.4f')
    print(f"    -> Daily predictions saved to {daily_output_file}")

    # 7. PLOTTING
    print("[6] Generating plots...")
    forecast_start_date = df_predict['date'].min().date()
    df_daily['date_col'] = pd.to_datetime(df_daily['date']).dt.date
    df_daily_hist = df_daily[df_daily['date_col'] < forecast_start_date]
    df_daily_pred = df_daily[df_daily['date_col'] >= forecast_start_date]

    # Daily Plot
    plt.figure(figsize=(20, 8))
    sns.lineplot(data=df_daily_hist, x='date', y=f'{target_col}_BCF', label=f'Historical Daily Burn', color='black')
    sns.lineplot(data=df_daily_pred, x='date', y=f'{target_col}_BCF', label=f'Predicted Daily Burn', color='blue')
    plt.axvline(x=pd.to_datetime(forecast_start_date), color='red', linestyle='--', label='Forecast Start')
    plt.title(f'{region_upper} Daily Power Burn Forecast (in BCF)')
    plt.ylabel('Daily Power Burn (BCF)'); plt.xlabel('Date'); plt.legend(); plt.grid(True, alpha=0.3)
    plt.savefig(plot_file_daily, dpi=300)
    plt.close()

    # Monthly Plot
    df_daily['year'] = df_daily['date'].dt.year
    df_daily['month'] = df_daily['date'].dt.month
    df_monthly = df_daily.groupby(['year', 'month'])[f'{target_col}_BCF'].sum().reset_index()
    df_monthly['month_name'] = df_monthly['month'].apply(lambda x: pd.to_datetime(str(x), format='%m').strftime('%b'))
    plt.figure(figsize=(20, 8))
    sns.barplot(data=df_monthly, x='month_name', y=f'{target_col}_BCF', hue='year', palette='viridis')
    plt.title(f'{region_upper} Total Monthly Power Burn Comparison (BCF)')
    plt.ylabel('Total Monthly Power Burn (BCF)'); plt.xlabel('Month'); plt.legend(title='Year')
    plt.grid(True, axis='y', linestyle='--', alpha=0.5)
    plt.savefig(plot_file_monthly, dpi=300)
    plt.close()
    
    print(f"    -> Plots saved for {region_upper}.")

# --- Main Execution ---
if __name__ == "__main__":
    print("="*80)
    print("--- GENERALIZED N-HITS FORECASTING PIPELINE ---")
    print(f"--- Will process {len(REGIONS)} regions ---")
    print("="*80)

    for region in REGIONS:
        run_forecast_for_region(region, BASE_OUTPUT_DIR)

    print("\n" + "="*80)
    print("--- All Regions Processed. Pipeline Complete. ---")
    print("="*80)