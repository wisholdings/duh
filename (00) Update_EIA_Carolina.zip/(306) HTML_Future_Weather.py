import os
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import traceback

# --- Configuration ---
DB_CONNECTION_STRING = (
)
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"
OUTPUT_FILENAME = "regional_weather_forecast_last_3_days.csv"

# --- Main Logic ---

def download_recent_weather_forecasts():
    """
    Downloads regional weather forecasts for the three most recent publication dates
    and saves the combined data to a CSV file.
    """
    print("\n" + "="*80)
    print("   DOWNLOADING L48 REGIONAL WEATHER FORECASTS (LAST 3 DAYS)")
    print("="*80)
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output Directory: {os.path.abspath(OUTPUT_DIR)}")
    print("="*80)
    
    engine = None
    try:
        # --- Database Connection ---
        print("\n[1] Connecting to the database...")
        engine = create_engine(DB_CONNECTION_STRING)
        
        # --- Define and Execute Query ---
        # This query gets all records that match one of the top 3 most recent publication dates.
        query = text("""
            WITH LatestThreeDates AS (
                SELECT DISTINCT TOP 3 DATE_PUBLISHED
                FROM [dbo].[PRODUCTION_L48_REGIONAL_WEATHER_ST_FORECAST]
                ORDER BY DATE_PUBLISHED DESC
            )
            SELECT 
                f.[DATE],
                f.[DATE_PUBLISHED],
                f.[CONUS_GW_HDD],
                f.[CONUS_PW_CDD],
                f.[MIDWEST_GW_HDD],
                f.[MIDWEST_PW_CDD],
                f.[PACIFIC_GW_HDD],
                f.[PACIFIC_PW_CDD],
                f.[MOUNTAIN_GW_HDD],
                f.[MOUNTAIN_PW_CDD],
                f.[SOUTHCENTRAL_GW_HDD],
                f.[SOUTHCENTRAL_PW_CDD],
                f.[EAST_GW_HDD],
                f.[EAST_PW_CDD]
            FROM [dbo].[PRODUCTION_L48_REGIONAL_WEATHER_ST_FORECAST] f
            WHERE f.DATE_PUBLISHED IN (SELECT DATE_PUBLISHED FROM LatestThreeDates)
            ORDER BY f.DATE_PUBLISHED DESC, f.DATE ASC
        """)
        
        print("[2] Executing query to fetch recent weather forecasts...")
        df = pd.read_sql(query, engine)

        if df.empty:
            print("  ✗ No weather forecast data was returned from the query.")
            return

        # Convert column to datetime before using the .dt accessor
        df['DATE_PUBLISHED'] = pd.to_datetime(df['DATE_PUBLISHED'])

        publication_dates = df['DATE_PUBLISHED'].dt.date.unique()
        print(f"  ✓ Downloaded {len(df)} records for {len(publication_dates)} publication dates:")
        for pub_date in publication_dates:
            print(f"    - {pub_date.strftime('%Y-%m-%d')}")

        # --- Save Data to CSV ---
        output_filepath = os.path.join(OUTPUT_DIR, OUTPUT_FILENAME)
        print(f"\n[3] Saving data to: {output_filepath}")
        df.to_csv(output_filepath, index=False)
        print(f"  ✓ Successfully saved recent weather forecast data.")

    except SQLAlchemyError as e:
        print(f"\n✗ DATABASE ERROR: A database error occurred: {e}")
        traceback.print_exc()
    except Exception as e:
        print(f"\n✗ UNEXPECTED ERROR: An unexpected error occurred: {e}")
        traceback.print_exc()
    finally:
        if engine:
            engine.dispose()
            print("\n    ✓ Database connection closed")

    # --- Final Summary ---
    print("\n" + "="*80)
    print("✅ Script completed!")
    print("="*80)

# --- Execute the Script ---
if __name__ == "__main__":
    download_recent_weather_forecasts()