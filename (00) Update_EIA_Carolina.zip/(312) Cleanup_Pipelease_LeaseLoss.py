import pandas as pd
import os
import traceback

def process_us_total_losses():
    """
    Processes US total loss files, converts them from MMcf to BCF,
    renames columns, and moves them to a 'CONUS' subfolder.
    """
    # --- Configuration ---
    source_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    output_subfolder = 'CONUS'
    output_folder = os.path.join(source_folder, output_subfolder)
    
    print("Starting US total losses processing.")
    print(f"Source folder: '{os.path.abspath(source_folder)}'")
    print(f"Output folder: '{os.path.abspath(output_folder)}'")

    os.makedirs(output_folder, exist_ok=True)

    # Define the files to process and their new names
    files_to_process = {
        'natural_gas_pipe_losses_us_total.csv': 'pipe_losses.csv',
        'natural_gas_lease_losses_us_total.csv': 'lease_losses.csv'
    }

    # --- Processing Loop ---
    for input_filename, output_filename in files_to_process.items():
        file_path = os.path.join(source_folder, input_filename)
        
        if not os.path.exists(file_path):
            print(f"\n[Info] File not found, skipping: {input_filename}")
            continue
            
        print(f"\n--- Processing file: {input_filename} ---")
        
        try:
            df = pd.read_csv(file_path, parse_dates=['datetime'])
            
            # Identify the value column (the second column)
            value_col = df.columns[1]
            
            # 1. Divide values by 1000
            df[value_col] = df[value_col] / 1000
            print(f"  - Converted '{value_col}' values from MMcf to BCF.")
            
            # 2. Rename the column
            new_col_name = value_col.replace('_MMcf', '_BCF')
            df.rename(columns={value_col: new_col_name}, inplace=True)
            print(f"  - Renamed column to '{new_col_name}'.")
            
            # 3. Save to the CONUS subfolder
            output_path = os.path.join(output_folder, output_filename)
            df.to_csv(output_path, index=False)
            print(f"  - Saved processed data to: {output_path}")

            # 4. Delete the original file after successful processing
            os.remove(file_path)
            print(f"  ✓ Successfully processed and deleted original file: {input_filename}")

        except Exception as e:
            print(f"  [ERROR] Failed to process {input_filename}. The file will not be deleted. Reason: {e}")
            traceback.print_exc()

    print("\n--- US total losses processing complete! ---")

# --- Run the script ---
if __name__ == "__main__":
    process_us_total_losses()