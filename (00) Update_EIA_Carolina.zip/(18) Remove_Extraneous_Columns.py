import pandas as pd
import glob
import os
from pathlib import Path

def filter_columns(df, patterns=['MW', '_Total', 'is_analogous']):
    """
    Remove columns that contain any of the specified patterns
    
    Args:
        df: pandas DataFrame
        patterns: list of patterns to match in column names
    
    Returns:
        DataFrame with filtered columns
    """
    columns_to_keep = []
    columns_removed = []
    
    for col in df.columns:
        keep_column = True
        for pattern in patterns:
            if pattern in col:
                keep_column = False
                columns_removed.append(col)
                break
        
        if keep_column:
            columns_to_keep.append(col)
    
    print(f"    Removed columns: {columns_removed}")
    return df[columns_to_keep]

def process_parquet_files():
    """
    Process all train.parquet and predict.parquet files in EIA_STACK/{region}/final/ directories
    Remove columns and save back to the same files
    """
    # Find all region directories
    base_path = r'D:\EIA_STACK'
    region_dirs = glob.glob(os.path.join(base_path, ''))
    region_dirs = [d for d in region_dirs if os.path.isdir(d)]
    
    if not region_dirs:
        print(f"No region directories found in {base_path}")
        return
    
    print(f"Found {len(region_dirs)} region directories")
    
    for region_dir in region_dirs:
        region_name = os.path.basename(region_dir)
        print(f"\nProcessing region: {region_name}")
        
        # Look for train.parquet and predict.parquet in final subdirectory
        train_file = os.path.join(region_dir, 'final', 'train.parquet')
        predict_file = os.path.join(region_dir, 'final', 'predict.parquet')
        
        # Process training file
        if os.path.exists(train_file):
            print(f"  Processing {train_file}...")
            df = pd.read_parquet(train_file)
            print(f"    Original shape: {df.shape}")
            
            # Filter columns
            filtered_df = filter_columns(df)
            print(f"    Filtered shape: {filtered_df.shape}")
            print(f"    Removed {df.shape[1] - filtered_df.shape[1]} columns")
            
            # Save back to the same file
            filtered_df.to_parquet(train_file, index=False)
            print(f"    Saved filtered data back to {train_file}")
        else:
            print(f"  No train.parquet found at {train_file}")
        
        # Process prediction file
        if os.path.exists(predict_file):
            print(f"  Processing {predict_file}...")
            df = pd.read_parquet(predict_file)
            print(f"    Original shape: {df.shape}")
            
            # Filter columns
            filtered_df = filter_columns(df)
            print(f"    Filtered shape: {filtered_df.shape}")
            print(f"    Removed {df.shape[1] - filtered_df.shape[1]} columns")
            
            # Save back to the same file
            filtered_df.to_parquet(predict_file, index=False)
            print(f"    Saved filtered data back to {predict_file}")
        else:
            print(f"  No predict.parquet found at {predict_file}")

def show_column_info():
    """
    Show information about columns that would be removed
    """
    base_path = r'D:\EIA_STACK'
    region_dirs = glob.glob(os.path.join(base_path, ''))
    region_dirs = [d for d in region_dirs if os.path.isdir(d)]
    
    if not region_dirs:
        print(f"No region directories found in {base_path}")
        return
    
    print("Column analysis:")
    print("================")
    
    patterns = ['MW', '_Total']
    
    for region_dir in region_dirs:
        region_name = os.path.basename(region_dir)
        print(f"\nRegion: {region_name}")
        
        # Check both train and predict files
        for file_type in ['train', 'predict']:
            file_path = os.path.join(region_dir, 'final', f'{file_type}.parquet')
            
            if os.path.exists(file_path):
                df = pd.read_parquet(file_path)
                
                # Find columns that would be removed
                columns_to_remove = []
                for col in df.columns:
                    for pattern in patterns:
                        if pattern in col:
                            columns_to_remove.append(col)
                            break
                
                print(f"  {file_type}.parquet:")
                print(f"    Total columns: {len(df.columns)}")
                print(f"    Columns to remove: {len(columns_to_remove)}")
                if columns_to_remove:
                    print(f"    Will remove: {columns_to_remove}")
                print(f"    Columns to keep: {len(df.columns) - len(columns_to_remove)}")
            else:
                print(f"  {file_type}.parquet: NOT FOUND")

if __name__ == "__main__":
    print("Parquet Column Filter Script")
    print("============================")
    
    # Show what columns would be affected
    show_column_info()
    
    # Process files
    process_parquet_files()
    print("\nProcessing complete!")