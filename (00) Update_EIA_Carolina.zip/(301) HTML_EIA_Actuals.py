import json
import pandas as pd
from sqlalchemy import create_engine, exc as sqlalchemy_exc, text, inspect
import os
import sys
import traceback

# --- Configuration ---
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"
DB_CONNECTION_STRING = (
)

# List of regions to process, with corrected names.
REGIONS = [
    "California", "Carolina", "Central", "Florida", "Midatlantic", 
    "Midwest", "Newengland", "Newyork", "Northwest", "Southeast", 
    "Southwest", "Tennessee", "Texas"
]
# --- EnergyDataFetcher Class Definition (from your script) ---
class EnergyDataFetcher:
    def __init__(self, region, start_date='2019-01-01', db_connection_string=None):
        """
        Initialize the EnergyDataFetcher.
        """
        self.region = region.upper()
        self.start_date = start_date
        self.db_connection_string = db_connection_string or DB_CONNECTION_STRING
        # Handle multi-word region names for table lookup
        self.table_name = f"PRODUCTION_{self.region.replace('-', '').replace(' ', '')}_ENERGY_EIA_HOURLY"

    def get_available_columns(self, engine):
        """
        Dynamically discover all available energy columns for the region.
        """
        try:
            inspector = inspect(engine)
            if not inspector.has_table(self.table_name, schema='dbo'):
                print(f"[ERROR] Table dbo.{self.table_name} does not exist.")
                return []
            columns = inspector.get_columns(self.table_name, schema='dbo')
            column_names = [col['name'] for col in columns]
            energy_columns = [col for col in column_names if col.upper() != 'DATETIME']
            return energy_columns
        except Exception as e:
            print(f"[ERROR] Failed to get columns for {self.table_name}: {e}")
            return []

    def fetch_energy_data(self):
        """Fetch energy data from SQL database."""
        print(f"Connecting to database for region: {self.region}...")
        try:
            engine = create_engine(self.db_connection_string)
            energy_columns = self.get_available_columns(engine)
            
            if not energy_columns:
                print(f"[WARNING] No energy columns found for {self.region}. Skipping.")
                return pd.DataFrame()
            
            all_columns = ['DATETIME'] + energy_columns
            columns_str = ', '.join([f'[{col}]' for col in all_columns])
            query = f"SELECT {columns_str} FROM [dbo].[{self.table_name}] ORDER BY [DATETIME]"
            
            df_energy = pd.read_sql(query, engine)
            print(f"  Fetched {len(df_energy)} records for {self.region}.")
            return df_energy
            
        except Exception as e:
            print(f"[ERROR] Query failed for {self.region}: {e}")
            return pd.DataFrame()

    def process_data(self, df_energy):
        """Rename columns, convert to datetime, and filter by start date."""
        if df_energy.empty:
            return df_energy
        
        try:
            if "DATETIME" in df_energy.columns:
                df_energy.rename(columns={"DATETIME": "date"}, inplace=True)
            
            df_energy["date"] = pd.to_datetime(df_energy["date"], errors='coerce')
            df_energy.dropna(subset=['date'], inplace=True)
            
            start_dt = pd.to_datetime(self.start_date)
            filtered_df = df_energy[df_energy['date'] >= start_dt].copy()
            
            return filtered_df
        except Exception as e:
            print(f"Error during data processing for {self.region}: {e}")
            return pd.DataFrame()

# --- Main Execution Block ---
def main():
    """
    Main function to fetch, combine, aggregate, and save EIA actuals data.
    """
    print("===== Starting EIA Actuals Data Aggregation Process =====")
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output will be saved to: {os.path.abspath(OUTPUT_DIR)}")

    all_regional_dfs = []

    for region_name in REGIONS:
        print(f"\n--- Processing region: {region_name} ---")
        try:
            fetcher = EnergyDataFetcher(region_name)
            
            df_hourly = fetcher.fetch_energy_data()
            if df_hourly.empty:
                continue
            
            df_processed = fetcher.process_data(df_hourly)
            if df_processed.empty:
                continue

            df_processed.set_index('date', inplace=True)

            # Standardize column names to format: 'California_NG_MW'
            # This replaces the uppercase region prefix with the title-cased one from the REGIONS list.
            region_prefix_upper = f"{region_name.upper().replace('-', '').replace(' ', '')}_"
            standardized_cols = {}
            for col in df_processed.columns:
                if col.upper().startswith(region_prefix_upper):
                    # Replace uppercase prefix with the desired title-case prefix
                    new_col_name = col.replace(region_prefix_upper, f"{region_name}_", 1)
                    standardized_cols[col] = new_col_name
            df_processed.rename(columns=standardized_cols, inplace=True)
            
            all_regional_dfs.append(df_processed)

        except Exception as e:
            print(f"[ERROR] Failed to process region {region_name}: {e}")
            traceback.print_exc()

    if not all_regional_dfs:
        print("\nNo data was fetched from any region. Exiting.")
        return

    print("\n--- Combining all regional data ---")
    # Combine all regional dataframes side-by-side
    combined_df = pd.concat(all_regional_dfs, axis=1).fillna(0)

    print("--- Aggregating data into Daily and Monthly summaries ---")
    
    # Aggregate to Daily sums
    daily_summary = combined_df.resample('D').sum()
    daily_output_path = os.path.join(OUTPUT_DIR, "eia_actuals_daily_by_type.csv")
    daily_summary.to_csv(daily_output_path)
    print(f"Successfully saved daily aggregated data to: {daily_output_path}")

    # Aggregate to Monthly sums
    monthly_summary = combined_df.resample('MS').sum()
    monthly_output_path = os.path.join(OUTPUT_DIR, "eia_actuals_monthly_by_type.csv")
    monthly_summary.to_csv(monthly_output_path)
    print(f"Successfully saved monthly aggregated data to: {monthly_output_path}")

    print("\n===== EIA Actuals Data Aggregation Process Finished =====")

if __name__ == "__main__":
    main()