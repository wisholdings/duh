import streamlit as st
import pandas as pd
from datetime import datetime, timedelta, date
from sqlalchemy import create_engine, text
import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="BAT MWH Forecast Dashboard", 
    page_icon="💡",
    layout="wide"
)

# --- ESTABLISH THE TRUE CURRENT DATE ---
TODAY = date.today()

# --- AZURE SQL DATABASE CONFIGURATION ---
AZURE_DB_CONNECTION_STRING = (
)

# --- Database Connection ---
@st.cache_resource
def get_db_engine():
    """Create and cache database engine for Azure SQL connection."""
    try:
        engine = create_engine(AZURE_DB_CONNECTION_STRING, echo=False, pool_recycle=3600)
        with engine.connect() as connection:
            connection.execute(text("SELECT 1")).scalar()
        return engine
    except Exception as e:
        st.error(f"❌ Database Connection Error: {e}")
        return None

@st.cache_data(ttl=1800)
def load_ng_mwh_data():
    """Load all regional BAT MWH forecast data and aggregate to daily resolution."""
    engine = get_db_engine()
    if not engine: 
        return None
    try:
        query = text("""
        SELECT 
            [datetime],
            [region],
            [date_published],
            [forecast_mw]
        FROM [dbo].[PRODUCTION_NHITS_TABLE_FORECAST_BAT]
        WHERE [forecast_mw] IS NOT NULL
        ORDER BY [datetime] ASC, [region] ASC
        """)
        df = pd.read_sql_query(query, engine)
        if not df.empty:
            df['datetime'] = pd.to_datetime(df['datetime'])
            df['date_published'] = pd.to_datetime(df['date_published']).dt.date
            
            # Aggregate hourly data to daily averages
            df['date'] = df['datetime'].dt.date
            daily_df = df.groupby(['date', 'region', 'date_published'], as_index=False).agg({
                'forecast_mw': 'mean'  # Take average of hourly values for each day
            }).round(0)  # Round to nearest MW
            
            # Rename for consistency
            daily_df = daily_df.rename(columns={'date': 'datetime'})
            daily_df['datetime'] = pd.to_datetime(daily_df['datetime'])
            
            return daily_df
        return None
    except Exception as e:
        st.error(f"Error BATing BAT MWH data: {e}")
        return None

def calculate_regional_stats(df, region):
    """Calculate key statistics for a specific region including forecast revisions."""
    region_data = df[df['region'] == region].copy().sort_values(['datetime', 'date_published'])
    
    if region_data.empty:
        return None
    
    # Get the latest 3 publication dates
    publication_dates = sorted(region_data['date_published'].unique(), reverse=True)
    today_pub = publication_dates[0] if len(publication_dates) > 0 else None
    yesterday_pub = publication_dates[1] if len(publication_dates) > 1 else None
    day_before_pub = publication_dates[2] if len(publication_dates) > 2 else None
    
    # Separate historical and forecast data (based on datetime vs today)
    historical = region_data[region_data['datetime'].dt.date <= TODAY]
    forecast = region_data[region_data['datetime'].dt.date > TODAY]
    
    # Get latest forecasts from each publication date for the next 30 days
    next_30_dates = pd.date_range(start=TODAY + timedelta(days=1), periods=30, freq='D')
    
    today_forecasts = region_data[
        (region_data['date_published'] == today_pub) &
        (region_data['datetime'].dt.date.isin(next_30_dates.date)) 
    ] if today_pub else pd.DataFrame()
    
    yesterday_forecasts = region_data[
        (region_data['date_published'] == yesterday_pub) &
        (region_data['datetime'].dt.date.isin(next_30_dates.date))
    ] if yesterday_pub else pd.DataFrame()
    
    day_before_forecasts = region_data[
        (region_data['date_published'] == day_before_pub) &
        (region_data['datetime'].dt.date.isin(next_30_dates.date))
    ] if day_before_pub else pd.DataFrame()
    
    # Calculate average forecast changes
    avg_change_today_vs_yesterday = None
    avg_change_yesterday_vs_day_before = None
    
    if not today_forecasts.empty and not yesterday_forecasts.empty:
        # Merge on datetime to compare same forecast dates
        merged = pd.merge(
            today_forecasts[['datetime', 'forecast_mw']], 
            yesterday_forecasts[['datetime', 'forecast_mw']], 
            on='datetime', 
            suffixes=('_today', '_yesterday')
        )
        if not merged.empty:
            merged['change'] = merged['forecast_mw_today'] - merged['forecast_mw_yesterday']
            avg_change_today_vs_yesterday = merged['change'].mean()
    
    if not yesterday_forecasts.empty and not day_before_forecasts.empty:
        merged = pd.merge(
            yesterday_forecasts[['datetime', 'forecast_mw']], 
            day_before_forecasts[['datetime', 'forecast_mw']], 
            on='datetime', 
            suffixes=('_yesterday', '_day_before')
        )
        if not merged.empty:
            merged['change'] = merged['forecast_mw_yesterday'] - merged['forecast_mw_day_before']
            avg_change_yesterday_vs_day_before = merged['change'].mean()
    
    # Latest historical value
    latest_historical = historical['forecast_mw'].iloc[-1] if not historical.empty else None
    
    # Future averages from latest publication
    latest_pub_forecast = forecast[forecast['date_published'] == today_pub] if today_pub else forecast
    
    next_7_days = latest_pub_forecast[
        latest_pub_forecast['datetime'].dt.date.between(
            TODAY + timedelta(days=1), 
            TODAY + timedelta(days=7)
        )
    ]['forecast_mw'].mean()
    
    next_30_days = latest_pub_forecast[
        latest_pub_forecast['datetime'].dt.date.between(
            TODAY + timedelta(days=1), 
            TODAY + timedelta(days=30)
        )
    ]['forecast_mw'].mean()
    
    # Peak and minimum in next 30 days
    next_30_data = latest_pub_forecast[
        latest_pub_forecast['datetime'].dt.date.between(
            TODAY + timedelta(days=1), 
            TODAY + timedelta(days=30)
        )
    ]
    
    peak_30 = next_30_data['forecast_mw'].max() if not next_30_data.empty else None
    min_30 = next_30_data['forecast_mw'].min() if not next_30_data.empty else None
    
    return {
        'latest_historical': latest_historical,
        'next_7_avg': next_7_days,
        'next_30_avg': next_30_days,
        'peak_30': peak_30,
        'min_30': min_30,
        'avg_change_today_vs_yesterday': avg_change_today_vs_yesterday,
        'avg_change_yesterday_vs_day_before': avg_change_yesterday_vs_day_before,
        'publication_dates': publication_dates[:3],
        'data_count': len(region_data),
        'region_data_with_revisions': region_data
    }

# --- PAGE TITLE ---
st.title("💡 Natural Gas Power Generation Forecast")
st.markdown("*Regional MW Generation Forecasting & Analysis*")

# --- Load and Process Data ---
with st.spinner("Loading regional MW forecast data..."):
    full_data = load_ng_mwh_data()

if full_data is None or full_data.empty:
    st.error("❌ No MW forecast data could be loaded from the database.")
    st.stop()

# Data summary
latest_published = full_data['date_published'].max()
total_records = len(full_data)
date_range = f"{full_data['datetime'].min().strftime('%Y-%m-%d')} to {full_data['datetime'].max().strftime('%Y-%m-%d')}"

st.info(f"📊 **Data Summary:** {total_records:,} daily records | **Date Range:** {date_range} | **Latest Published:** {latest_published} | **Resolution:** Daily Averages")

# --- REGION SELECTION ---
st.subheader("🗺️ Region Selection")

col1, col2 = st.columns([2, 1])

with col1:
    regions = sorted(full_data['region'].unique())
    selected_region = st.selectbox(
        "Select a Region to Analyze:",
        regions,
        index=0,
        help="Choose a region to view detailed forecasts and analysis"
    )

with col2:
    # Show region data info
    region_stats = calculate_regional_stats(full_data, selected_region)
    if region_stats:
        st.metric(
            "Data Points Available", 
            f"{region_stats['data_count']:,}",
            help=f"Total forecast points for {selected_region}"
        )

st.markdown("---")

# --- REGIONAL ANALYSIS ---
if region_stats:
    st.subheader(f"📊 Analysis for {selected_region.title()}")
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        if region_stats['latest_historical']:
            st.metric(
                "Latest Historical", 
                f"{region_stats['latest_historical']:,.0f} MW",
                help="Most recent historical forecast value"
            )
        else:
            st.metric("Latest Historical", "No Data")
    
    with col2:
        if pd.notna(region_stats['next_7_avg']):
            change = region_stats['next_7_avg'] - region_stats['latest_historical'] if region_stats['latest_historical'] else 0
            st.metric(
                "Next 7-Day Avg", 
                f"{region_stats['next_7_avg']:,.0f} MW",
                f"{change:+,.0f} MW vs latest" if change != 0 else None
            )
        else:
            st.metric("Next 7-Day Avg", "No Data")
    
    with col3:
        if pd.notna(region_stats['next_30_avg']):
            change = region_stats['next_30_avg'] - region_stats['latest_historical'] if region_stats['latest_historical'] else 0
            st.metric(
                "Next 30-Day Avg", 
                f"{region_stats['next_30_avg']:,.0f} MW",
                f"{change:+,.0f} MW vs latest" if change != 0 else None
            )
        else:
            st.metric("Next 30-Day Avg", "No Data")
    
    with col4:
        if region_stats['avg_change_today_vs_yesterday'] is not None:
            st.metric(
                "Today vs Yesterday", 
                f"{region_stats['avg_change_today_vs_yesterday']:+,.0f} MW",
                help="Average change in forecasts: Today's publication vs Yesterday's"
            )
        else:
            st.metric("Today vs Yesterday", "No Data")
    
    with col5:
        if region_stats['avg_change_yesterday_vs_day_before'] is not None:
            st.metric(
                "Yesterday vs T-2", 
                f"{region_stats['avg_change_yesterday_vs_day_before']:+,.0f} MW",
                help="Average change in forecasts: Yesterday's publication vs Day Before"
            )
        else:
            st.metric("Yesterday vs T-2", "No Data")
    
    # Show publication dates for context
    if region_stats['publication_dates']:
        pub_dates_str = " | ".join([d.strftime('%m/%d') for d in region_stats['publication_dates']])
        st.caption(f"📅 **Publication Dates:** {pub_dates_str}")
    else:
        st.caption("📅 **Publication Dates:** Not available")

# --- FORECAST CHART ---
st.subheader(f"📈 Forecast Timeline - {selected_region.title()}")

# Filter data for the selected region
region_df = full_data[full_data['region'] == selected_region].copy()

if not region_df.empty:
    # Define chart range: last 14 days and next 30 days only
    chart_start_date = TODAY - timedelta(days=14)
    chart_end_date = TODAY + timedelta(days=30)
    
    plot_df = region_df[
        (region_df['datetime'].dt.date >= chart_start_date) & 
        (region_df['datetime'].dt.date <= chart_end_date)
    ].copy().sort_values(['datetime', 'date_published'])
    
    if not plot_df.empty:
        # Get the latest publication dates for comparison
        pub_dates = sorted(plot_df['date_published'].unique(), reverse=True)
        
        # Create the chart
        fig = go.Figure()
        
        # Show different publication dates with different colors/styles
        colors = ['steelblue', 'orange', 'green', 'purple']
        line_styles = ['solid', 'dash', 'dot', 'dashdot']
        
        for i, pub_date in enumerate(pub_dates[:4]):  # Show up to 4 most recent publications
            pub_data = plot_df[plot_df['date_published'] == pub_date]
            
            # Separate historical and future for this publication
            historical_data = pub_data[pub_data['datetime'].dt.date <= TODAY]
            future_data = pub_data[pub_data['datetime'].dt.date > TODAY]
            
            # Historical data
            if not historical_data.empty:
                fig.add_trace(go.Scatter(
                    x=historical_data['datetime'],
                    y=historical_data['forecast_mw'],
                    mode='lines+markers',
                    name=f'Historical ({pub_date.strftime("%m/%d")})',
                    line=dict(color=colors[i % len(colors)], width=2),
                    marker=dict(size=4),
                    showlegend=(i == 0),  # Only show one historical legend
                    hovertemplate='<b>%{x|%Y-%m-%d}</b><br>' +
                                 'MW (Daily Avg): %{y:,.0f}<br>' +
                                 f'Published: {pub_date.strftime("%m/%d/%Y")}<br>' +
                                 '<extra></extra>'
                ))
            
            # Future data
            if not future_data.empty:
                fig.add_trace(go.Scatter(
                    x=future_data['datetime'],
                    y=future_data['forecast_mw'],
                    mode='lines+markers',
                    name=f'Forecast {pub_date.strftime("%m/%d")}',
                    line=dict(
                        color=colors[i % len(colors)], 
                        width=4 if i == 0 else 2,  # Latest forecast is thicker
                        dash=line_styles[i % len(line_styles)]
                    ),
                    marker=dict(size=5 if i == 0 else 4),
                    opacity=1.0 if i == 0 else 0.7,  # Latest forecast is more opaque
                    hovertemplate='<b>%{x|%Y-%m-%d}</b><br>' +
                                 'MW (Daily Avg): %{y:,.0f}<br>' +
                                 f'Published: {pub_date.strftime("%m/%d/%Y")}<br>' +
                                 '<extra></extra>'
                ))
        
        # Add vertical line for Today
        today_datetime = pd.Timestamp(TODAY)
        fig.add_shape(
            type="line",
            x0=today_datetime,
            x1=today_datetime,
            y0=0,
            y1=1,
            yref="paper",
            line=dict(color="red", width=2, dash="dash")
        )
        
        # Add annotation for "Today"
        fig.add_annotation(
            x=today_datetime,
            y=0.95,
            yref="paper",
            text="Today",
            showarrow=False,
            font=dict(color="red", size=12),
            bgcolor="white",
            bordercolor="red",
            borderwidth=1
        )
        
        fig.update_layout(
            title=f"Daily Average Forecast Revisions: {selected_region.title()} (Last 14d + Next 30d)",
            xaxis_title="Date",
            yaxis_title="Daily Average Megawatts (MW)",
            template='plotly_white',
            hovermode='closest',
            height=500,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Add explanation
        st.caption("💡 **Daily Resolution**: Hourly data has been averaged to daily values to reduce noise. Different publication dates shown with different line styles.")
        
    else:
        st.warning(f"No data available for {selected_region} in the selected date range.")
else:
    st.warning(f"No data available for region: {selected_region}")

st.markdown("---")

# --- REGIONAL COMPARISON ---
st.subheader("🌐 Regional Comparison Dashboard")

with st.spinner("Calculating regional comparisons..."):
    comparison_data = []
    
    for region in regions:
        stats = calculate_regional_stats(full_data, region)
        if stats:
            comparison_data.append({
                "Region": region.title(),
                "Latest Historical (MW)": f"{stats['latest_historical']:,.0f}" if stats['latest_historical'] else "N/A",
                "Next 7-Day Avg (MW)": f"{stats['next_7_avg']:,.0f}" if pd.notna(stats['next_7_avg']) else "N/A",
                "Next 30-Day Avg (MW)": f"{stats['next_30_avg']:,.0f}" if pd.notna(stats['next_30_avg']) else "N/A",
                "30-Day Peak (MW)": f"{stats['peak_30']:,.0f}" if pd.notna(stats['peak_30']) else "N/A",
                "Data Points": f"{stats['data_count']:,}"
            })

if comparison_data:
    df_comparison = pd.DataFrame(comparison_data)
    
    st.dataframe(
        df_comparison,
        column_config={
            "Region": st.column_config.TextColumn("Region", width="medium"),
            "Latest Historical (MW)": st.column_config.TextColumn("Latest Historical (MW)", width="medium"),
            "Next 7-Day Avg (MW)": st.column_config.TextColumn("Next 7-Day Avg (MW)", width="medium"),
            "Next 30-Day Avg (MW)": st.column_config.TextColumn("Next 30-Day Avg (MW)", width="medium"),
            "30-Day Peak (MW)": st.column_config.TextColumn("30-Day Peak (MW)", width="medium"),
            "Data Points": st.column_config.TextColumn("Data Points", width="small")
        },
        hide_index=True,
        use_container_width=True,
        height=400
    )

# --- MULTI-REGION CHART ---
st.subheader("📊 Multi-Region Forecast Comparison (Next 30 Days)")

# Create comparison chart for next 30 days only
comparison_start = TODAY + timedelta(days=1)
comparison_end = TODAY + timedelta(days=30)

fig_multi = go.Figure()

# Use a larger color palette that can handle more regions
colors = px.colors.qualitative.Plotly + px.colors.qualitative.Set3 + px.colors.qualitative.Pastel

for i, region in enumerate(regions):  # Show ALL regions now
    region_data = full_data[
        (full_data['region'] == region) &
        (full_data['datetime'].dt.date >= comparison_start) &
        (full_data['datetime'].dt.date <= comparison_end)
    ]
    
    if not region_data.empty:
        # Get the latest publication date for this region
        latest_pub = region_data['date_published'].max()
        latest_data = region_data[region_data['date_published'] == latest_pub]
        
        fig_multi.add_trace(go.Scatter(
            x=latest_data['datetime'],
            y=latest_data['forecast_mw'],
            mode='lines+markers',
            name=region.title(),
            line=dict(color=colors[i % len(colors)], width=2),
            marker=dict(size=4),
            hovertemplate='<b>%{fullData.name}</b><br>' +
                         'Date: %{x|%Y-%m-%d}<br>' +
                         'Daily Avg MW: %{y:,.0f}<br>' +
                         '<extra></extra>'
        ))

fig_multi.update_layout(
    title=f"30-Day Daily Average Forecast Comparison - All {len(regions)} Regions",
    xaxis_title="Date",
    yaxis_title="Daily Average Megawatts (MW)",
    template='plotly_white',
    hovermode='closest',
    height=600,  # Increased height to accommodate more regions
    legend=dict(
        orientation="v",  # Vertical legend for better space usage
        yanchor="top",
        y=1,
        xanchor="left",
        x=1.02,
        bgcolor="rgba(255,255,255,0.8)",
        bordercolor="rgba(0,0,0,0.2)",
        borderwidth=1
    )
)

st.plotly_chart(fig_multi, use_container_width=True)

st.caption(f"📈 **All {len(regions)} regions shown** with latest publication data. Legend moved to the right for better visibility.")

# --- FOOTER ---
st.markdown("---")
st.caption(f"**Last Data Published:** {latest_published} | **Dashboard Updated:** {TODAY.strftime('%Y-%m-%d %H:%M')} | **Total Regions:** {len(regions)}")

# --- EXPORT OPTIONS ---
with st.expander("📥 Export Data"):
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Export Selected Region Data"):
            export_data = region_df[['datetime', 'forecast_mw', 'date_published']].copy()
            csv = export_data.to_csv(index=False)
            st.download_button(
                f"📊 Download {selected_region.title()} Data (CSV)",
                csv,
                f"ng_forecast_{selected_region}_{TODAY.strftime('%Y%m%d')}.csv",
                "text/csv"
            )
    
    with col2:
        if st.button("Export All Regions Summary"):
            csv = df_comparison.to_csv(index=False) if 'df_comparison' in locals() else "No data available"
            st.download_button(
                "📈 Download Regional Summary (CSV)",
                csv,
                f"ng_forecast_summary_{TODAY.strftime('%Y%m%d')}.csv",
                "text/csv"
            )