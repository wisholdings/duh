import pandas as pd
import psycopg2
import logging
import sys
import os
import re

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# PostgreSQL Database Connection Details
DB_CONFIG = {
    "host": "",
    "database": "",
    "user": "",
    "password": "",
    "port": 443
}

# Midwest Region States (based on typical EIA Midwest region definition)
MIDWEST_REGION_STATES = ["IL", "IN", "IA", "KS", "KY", "MI", "MN", "MO", "NE", "ND", "OH", "SD", "WI"]

def clean_folder_name(name):
    """Cleans up a string to be used as a folder name."""
    if not isinstance(name, str):
        name = str(name)
    
    # Replace spaces with underscores
    name = name.replace(' ', '_')
    # Remove any characters that are not alphanumeric, underscores, or hyphens
    name = re.sub(r'[^\w-]+', '', name)
    return name

def fetch_and_save_pipeline_data_to_csv(tickers_to_fetch: list, output_csv_name: str, facility_name: str):
    """
    Connects to the PostgreSQL database, fetches pipeline nomination data for
    specified tickers in the Midwest region, and saves it to a CSV file.

    Args:
        tickers_to_fetch (list): A list of ticker strings.
        output_csv_name (str): The name of the CSV file to save the data to.
        facility_name (str): The name of the storage facility for logging purposes.
    """
    if not tickers_to_fetch:
        logging.warning(f"No tickers provided for '{facility_name}'. Skipping data fetch.")
        return

    # Format the Python list of tickers and states for the SQL 'IN' clause
    formatted_tickers = ",".join(f"'{ticker}'" for ticker in tickers_to_fetch)
    formatted_states = ",".join(f"'{state}'" for state in MIDWEST_REGION_STATES)

    # Construct the SQL query for Midwest region states
    SQL_QUERY = f"""
    select
        meta.pipeline_name, meta.tsp, meta.tsp_short, meta.ticker, meta.loc_name, meta.loc, meta.loc_qti_id
        , meta.loc_qti_short, meta.loc_purp_desc, meta.rec_del_sign, meta.loc_zone, meta.category_short, meta.sub_category_desc
        , meta.sub_category_2_desc, meta.country_name, meta.state_name, meta.state_abb, meta.province_name, meta.offshore_block_name
        , meta.county_name, meta.latitude, meta.longitude, meta.connecting_pipeline, meta.connecting_entity, meta.storage_name, meta.storage_calc_flag
        , meta.units, noms.cycle_id, noms.cycle_desc, noms.hourly_cycle_id, noms.eff_gas_day, noms.end_eff_gas_day, noms.design_capacity
        , noms.operating_capacity, noms.scheduled_quantity, noms.scheduled_quantity * meta.rec_del_sign as scheduled_quantity_sign_adj
        , noms.operationally_available, reg.region_name as regions_criterion, reg.eia_ng_regions
    from pipelines.nomination_points noms
    inner join pipelines.metadata meta on meta.metadata_id = noms.metadata_id
    left join pipelines.regions reg on reg.state_name = meta.state_name
    where  (noms.eff_gas_day <= current_date and noms.eff_gas_day >= '1/1/2019')
    and meta.ticker in ({formatted_tickers})
    and meta.state_abb in ({formatted_states})
    order by meta.tsp_short, noms.eff_gas_day, meta.ticker;
    """

    cnxn = None
    try:
        logging.info(f"Attempting to connect to the database for '{facility_name}', file: {output_csv_name}...")
        logging.info(f"Filtering by Midwest region states: {MIDWEST_REGION_STATES}")

        cnxn = psycopg2.connect(**DB_CONFIG)
        logging.info("Database connection successful.")

        logging.info(f"Executing SQL query for {facility_name} with tickers: {tickers_to_fetch}...")

        df = pd.read_sql(SQL_QUERY, cnxn)
        logging.info(f"Successfully loaded {len(df)} rows for {facility_name}.")

        if len(df) == 0:
            logging.warning(f"No data fetched for '{facility_name}'. Skipping CSV creation.")
            return

        # Create the Midwest region directory
        folder_name = "midwest"
        os.makedirs(folder_name, exist_ok=True)
        logging.info(f"Ensured directory '{folder_name}' exists.")

        # Construct the full output path
        full_output_path = os.path.join(folder_name, output_csv_name)

        df.to_csv(full_output_path, index=False)
        logging.info(f"Data successfully saved to {full_output_path}")

    except psycopg2.Error as e:
        logging.error(f"Database error while processing {facility_name}: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred while processing {facility_name}: {e}")
    finally:
        if cnxn:
            cnxn.close()
            logging.info(f"Database connection closed for {facility_name}.")

if __name__ == "__main__":
    # Midwest Region Storage Facilities Configuration
    # Based on the data you provided, here are all the Midwest region facilities
    midwest_storage_configs = [
        {
            "facility_name": "ANR Pipeline",
            "tickers": ["PLNM.076.153808.7", "PLNM.076.153808.8"],
            "output_filename": "ANR_Pipeline.csv"
        },
        {
            "facility_name": "ANR Storage",
            "tickers": ["PLNM.001.STOR.7", "PLNM.001.STOR.8"],
            "output_filename": "ANR_Storage.csv"
        },
        {
            "facility_name": "Barnsley",
            "tickers": ["PLNM.114.9404.7", "PLNM.114.9404.8"],
            "output_filename": "Barnsley.csv"
        },
        {
            "facility_name": "Bell River Mills",
            "tickers": [
                "PLNM.080.11771.1", "PLNM.080.720049.2",
                "PLNM.375.N4436.2", "PLNM.118.BR101.7", "PLNM.118.BR101.8"
            ],
            "output_filename": "Bell_River_Mills.csv"
        },
        {
            "facility_name": "Blue Lake",
            "tickers": ["PLNM.006.542526.7", "PLNM.006.542526.8"],
            "output_filename": "Blue_Lake.csv"
        },
        {
            "facility_name": "Bluewater",
            "tickers": [
                "PLNM.007.111111.7", "PLNM.007.111111.8",
                "PLNM.007.1572157.7", "PLNM.007.1572157.8",
                "PLNM.007.222222.7", "PLNM.007.222222.8",
                "PLNM.007.333333.7", "PLNM.007.333333.8",
                "PLNM.007.387249.7", "PLNM.007.387249.8",
                "PLNM.007.388031.7", "PLNM.007.388031.8",
                "PLNM.007.444444.7", "PLNM.007.444444.8"
            ],
            "output_filename": "Bluewater.csv"
        },
        {
            "facility_name": "Lee 8",
            "tickers": ["PLNM.093.LEE8.7", "PLNM.093.LEE8.8"],
            "output_filename": "Lee_8.csv"
        },
        {
            "facility_name": "NGPL",
            "tickers": ["PLNM.049.47422.7", "PLNM.049.47422.8"],
            "output_filename": "NGPL.csv"
        },
        {
            "facility_name": "Ohio Valley Hub",
            "tickers": ["PLNM.126.305591.7", "PLNM.126.305591.8"],
            "output_filename": "Ohio_Valley_Hub.csv"
        },
        {
            "facility_name": "SWGS East",
            "tickers": ["PLNM.095.SWGSE.7", "PLNM.095.SWGSE.8"],
            "output_filename": "SWGS_East.csv"
        },
        {
            "facility_name": "Texas Gas",
            "tickers": [
                "PLNM.114.4800.7", "PLNM.114.4801.7",
                "PLNM.114.5800.8", "PLNM.114.5801.8"
            ],
            "output_filename": "Texas_Gas.csv"
        },
        {
            "facility_name": "Washington 10",
            "tickers": [
                "PLNM.375.N4140.7", "PLNM.375.N4310.8", "PLNM.375.N4440.8",
                "PLNM.375.N4RO1.2", "PLNM.118.RO101.7", "PLNM.118.RO101.8"
            ],
            "output_filename": "Washington_10.csv"
        },
        {
            "facility_name": "White River",
            "tickers": ["PLNM.114.9593.7", "PLNM.114.9593.8"],
            "output_filename": "White_River.csv"
        },
        {
            "facility_name": "Kimball-27",
            "tickers": ["PLNM.007.3215233.7", "PLNM.007.3215233.8"],
            "output_filename": "Kimball_27.csv"
        },
        {
            "facility_name": "Atmos",
            "tickers": ["PLNM.076.153751.7", "PLNM.076.153753.8"],
            "output_filename": "Atmos.csv"
        },
        {
            "facility_name": "Northern Natural Gas",
            "tickers": ["PLNM.134.465.7", "PLNM.134.465.8"],
            "output_filename": "Northern_Natural_Gas.csv"
        },
        {
            "facility_name": "Eaton Rapids",
            "tickers": ["PLNM.412.STOR.7", "PLNM.412.STOR.8"],
            "output_filename": "Eaton_Rapids.csv"
        }
    ]

    logging.info("--- Starting Midwest Region Pipeline Data Processing ---")
    
    for config in midwest_storage_configs:
        facility_name = config.get('facility_name', 'Unknown')
        output_name = config.get('output_filename', 'default.csv')
        tickers = config.get('tickers', [])

        logging.info(f"\nProcessing {facility_name}...")
        logging.info(f"Tickers: {tickers}")
        logging.info(f"Output file: {output_name}")
        
        fetch_and_save_pipeline_data_to_csv(
            tickers,
            output_name,
            facility_name
        )
        
        logging.info(f"Finished processing {facility_name}.\n")

    logging.info("--- Midwest Region Processing Completed ---")