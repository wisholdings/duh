import pandas as pd
import os
from datetime import datetime

# Define the directory path
southcentral_dir = r'D:\EIA_STACK\Pricing_RL\SOUTHCENTRAL_SALTS'
output_dir = southcentral_dir  # Save in the same directory

print("="*60)
print("OUTER MERGE OF ALL CSV FILES IN SOUTHCENTRAL FOLDER")
print("="*60)
print(f"Directory: {southcentral_dir}")
print("="*60)

# List of all CSV files to merge
csv_files = [
    'southcentral_salt_storage.csv',
    'texas_commercial.csv',
    'texas_industrial.csv',
    'texas_power_burn_prediction.csv',
    'texas_residential_final_hybrid_forecast.csv',
    'synmax_production_with_forecast.csv',
    'weather_SOUTHCENTRAL_SALTS.csv'
]

# Initialize merged dataframe with None
merged_df = None
successful_merges = []

print("\nStarting merge process...\n")

for i, csv_file in enumerate(csv_files, 1):
    file_path = os.path.join(southcentral_dir, csv_file)
    print(f"[{i}/{len(csv_files)}] Processing: {csv_file}")
    
    try:
        df = pd.read_csv(file_path)
        date_col = next((col for col in df.columns if col.lower() in ['date', 'datetime', 'eff_gas_day']), None)
        
        if date_col is None:
            print(f"  ⚠️ Warning: No date/datetime column found. Skipping file.")
            continue
        
        if date_col != 'date':
            df = df.rename(columns={date_col: 'date'})
            print(f"  → Renamed '{date_col}' column to 'date'")
        
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        df = df.dropna(subset=['date'])
        
        prefix = csv_file.replace('.csv', '').replace('_', '')[:15]
        columns_to_rename = {col: f"{prefix}_{col}" for col in df.columns if col != 'date'}
        df = df.rename(columns=columns_to_rename)
        
        print(f"  ✓ Loaded: {len(df)} rows, {len(df.columns)} columns")
        
        if merged_df is None:
            merged_df = df
            print(f"  → Base dataframe initialized with {len(merged_df)} rows")
        else:
            rows_before = len(merged_df)
            merged_df = pd.merge(merged_df, df, on='date', how='outer')
            print(f"  → Merged: {rows_before} rows → {len(merged_df)} rows (added {len(merged_df) - rows_before} rows)")
        
        successful_merges.append(csv_file)
        
    except Exception as e:
        print(f"  ✗ Error reading {csv_file}: {str(e)}")

print("\n" + "="*60)
print("MERGE SUMMARY")
print("="*60)

if merged_df is not None and not merged_df.empty:
    merged_df = merged_df.sort_values('date').reset_index(drop=True)
    
    print(f"\n✓ Successfully merged {len(successful_merges)} files")
    print(f"  Final dataframe shape: {merged_df.shape}")
    print(f"  Date range: {merged_df['date'].min().date()} to {merged_df['date'].max().date()}")

    # =====================================================
    # DATA CONVERSIONS (MMcf to BCF)
    # =====================================================
    print("\n" + "="*60)
    print("CONVERTING DEMAND DATA FROM MMcf to BCF")
    print("="*60)

    # Define the demand columns that need conversion from MMcf to BCF
    demand_cols_mmcf = [
        'texascommerci_TEXAS_Commercial_hourly_MMcf',
        'texasindustri_TEXAS_Industrial_hourly_MMcf',
        'texasresident_TEXAS_Residential_hourly_MMcf',
        'texaspowerbur_TEXAS_Power_Burn' # Note: This one is already in BCF based on filename, but we check
    ]
    
    for col in demand_cols_mmcf:
        if col in merged_df.columns:
            # Check if it's MMcf and needs conversion
            if 'MMcf' in col:
                new_bcf_col = col + '_BCF'
                merged_df[new_bcf_col] = merged_df[col] / 1000
                print(f"  ✓ Converted '{col}' to '{new_bcf_col}' (BCF)")
                # Drop the original MMcf column
                merged_df.drop(columns=[col], inplace=True)
                print(f"    → Dropped original MMcf column.")
            else: # Handle the power burn case which is already BCF
                new_bcf_col = col + '_BCF'
                merged_df.rename(columns={col: new_bcf_col}, inplace=True)
                print(f"  ✓ Renamed '{col}' to '{new_bcf_col}' for consistency")

    # =====================================================
    # CREATE REGIONAL SUMMATION COLUMNS
    # =====================================================
    print("\n" + "="*60)
    print("CREATING REGIONAL SUMMATION COLUMNS")
    print("="*60)
    
    regional_columns = {
        'TEXAS_TOTAL_BCF': [
            'texascommerci_TEXAS_Commercial_hourly_MMcf_BCF',
            'texasindustri_TEXAS_Industrial_hourly_MMcf_BCF',
            'texaspowerbur_TEXAS_Power_Burn_BCF',
            'texasresident_TEXAS_Residential_hourly_MMcf_BCF'
        ]
    }
    
    for region_total, columns in regional_columns.items():
        existing_cols = [col for col in columns if col in merged_df.columns]
        if existing_cols:
            merged_df[region_total] = merged_df[existing_cols].sum(axis=1, skipna=False) # Use False to keep NaNs if any part is NaN
            print(f"\n✓ Created {region_total} by summing {len(existing_cols)} columns.")
        else:
            print(f"\n⚠️ Warning: No columns found for {region_total}")

    # Create a grand total column for the entire South Central region
    grand_total_components = ['TEXAS_TOTAL_BCF', 'southcentralnon_TOTAL_NONSALT']
    existing_grand_total_cols = [col for col in grand_total_components if col in merged_df.columns]
    
    if len(existing_grand_total_cols) > 0:
        merged_df['SOUTHCENTRAL_GRAND_TOTAL_BCF'] = merged_df[existing_grand_total_cols].sum(axis=1, skipna=False)
        print(f"\n✓ Created SOUTHCENTRAL_GRAND_TOTAL_BCF by summing {len(existing_grand_total_cols)} regional totals.")

    # =====================================================
    # DROP INDIVIDUAL COMPONENT COLUMNS AFTER SUMMATION
    # =====================================================
    print("\n" + "="*60)
    print("DROPPING INDIVIDUAL COMPONENT COLUMNS")
    print("="*60)
    
    columns_to_drop_after_sum = []
    for region_total, columns in regional_columns.items():
        columns_to_drop_after_sum.extend([col for col in columns if col in merged_df.columns])
    
    if columns_to_drop_after_sum:
        merged_df = merged_df.drop(columns=columns_to_drop_after_sum)
        print(f"✓ Dropped {len(columns_to_drop_after_sum)} individual component columns, keeping only totals.")
    
    if 'synmaxproductio_DATA_SOURCE' in merged_df.columns:
        merged_df = merged_df.drop(columns=['synmaxproductio_DATA_SOURCE'])
        print(f"✓ Dropped column: synmaxproductio_DATA_SOURCE")

    print("\n" + "="*60)
    
    # Save the merged file
    output_filename = 'SOUTHCENTRAL_SALTS_merged_all_outer_with_totals.csv'
    output_path = os.path.join(output_dir, output_filename)
    
    try:
        merged_df.to_csv(output_path, index=False)
        file_size = os.path.getsize(output_path) / 1024
        print(f"\n✓ Merged file saved as: {output_filename}")
        print(f"  Path: {output_path}")
        print(f"  Size: {file_size:.1f} KB")
        
    except Exception as e:
        print(f"\n✗ Error saving merged file: {str(e)}")
    
    print("\nFirst 5 rows of merged data (showing regional totals):")
    print("-" * 40)
    display_cols = ['date'] + [col for col in merged_df.columns if 'TOTAL' in col]
    print(merged_df[display_cols].head().round(2))
    
else:
    print("\n✗ No successful merges performed or final dataframe is empty.")

print("\n" + "="*60)
print("Process completed with OUTER JOIN!")
print("="*60)