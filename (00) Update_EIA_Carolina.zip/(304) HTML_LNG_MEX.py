import os
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import time
import traceback

# --- Configuration ---
DB_CONNECTION_STRING = (
)
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"

# --- Database Functions ---
def get_db_engine():
    """Initializes the database connection engine."""
    try:
        engine = create_engine(DB_CONNECTION_STRING, pool_pre_ping=True)
        # Test connection
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return engine
    except Exception as e:
        print(f"✗ Database Connection Error: {e}")
        return None

def execute_query_with_retry(engine, query, max_retries=3):
    """Execute a query with retry logic for connection issues."""
    if not engine:
        return pd.DataFrame()
    for attempt in range(max_retries):
        try:
            df = pd.read_sql_query(query, engine)
            return df
        except Exception as e:
            if attempt < max_retries - 1:
                print(f"  ⚠ Database query failed (attempt {attempt + 1}/{max_retries}), retrying...")
                time.sleep(2)
            else:
                print(f"  ✗ Database query failed after {max_retries} attempts: {e}")
                return pd.DataFrame()

# --- Main Data Loading Function ---
def download_supply_demand_data():
    """
    Loads historical and forecast supply/demand data, combines them,
    and saves them to the 'Update' folder.
    """
    print("\n" + "="*80)
    print("   DOWNLOADING SUPPLY & DEMAND DATA (HISTORICAL & FORECAST)")
    print("="*80)
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output Directory: {os.path.abspath(OUTPUT_DIR)}")
    print("="*80)

    engine = get_db_engine()
    if not engine:
        print("Could not establish database connection. Aborting.")
        return

    try:
        # --- 1. Load Historical Data ---
        print("\n[1] Loading Historical Supply/Demand Data...")
        query_hist = text("""
            SELECT 
                CAST([Date] AS DATE) as Date,
                AVG([LNG_IMPORTS]) / 1000.0 as LNG_IMPORTS_BCF,
                AVG([LNG_EXPORTS]) / 1000.0 as LNG_EXPORTS_BCF,
                AVG([CAD_NET_FLOW]) / 1000.0 as CAD_NET_FLOW_BCF,
                AVG([MEX_EXPORTS]) / 1000.0 as MEX_EXPORTS_BCF
            FROM [dbo].[PRODUCTION_PIPE_CAD_MEX_LEASE_L48_CRITERION_HISTORY]
            WHERE [Date] IS NOT NULL 
            GROUP BY CAST([Date] AS DATE)
            ORDER BY Date ASC
        """)
        df_hist = execute_query_with_retry(engine, query_hist)

        if df_hist.empty:
            print("  ✗ No historical data found.")
        else:
            print(f"  ✓ Downloaded {len(df_hist)} historical records.")
            df_hist['Date'] = pd.to_datetime(df_hist['Date'])
            hist_output_path = os.path.join(OUTPUT_DIR, "supply_demand_historical.csv")
            df_hist.to_csv(hist_output_path, index=False)
            print(f"  ✓ Saved to: {hist_output_path}")

        # --- 2. Load Forecast Data ---
        print("\n[2] Loading Forecast Supply/Demand Data...")
        query_forecast = text("""
            WITH LatestForecast AS (
                SELECT 
                    CAST([Date] AS DATE) as Date,
                    [LNG_EXPORTS] / 1000.0 as LNG_EXPORTS_BCF,
                    [CAD_NET_FLOW] / 1000.0 as CAD_NET_FLOW_BCF,
                    [MEX_EXPORTS] / 1000.0 as MEX_EXPORTS_BCF,
                    [Date_Published],
                    ROW_NUMBER() OVER(PARTITION BY CAST([Date] AS DATE) 
                                    ORDER BY [Date_Published] DESC) as rn
                FROM [dbo].[PRODUCTION_PIPE_CAD_MEX_LEASE_L48_CRITERION_ST]
                WHERE [Date] IS NOT NULL
            )
            SELECT Date, LNG_EXPORTS_BCF, CAD_NET_FLOW_BCF, MEX_EXPORTS_BCF
            FROM LatestForecast
            WHERE rn = 1
            ORDER BY Date ASC
        """)
        df_forecast = execute_query_with_retry(engine, query_forecast)

        if df_forecast.empty:
            print("  ✗ No forecast data found.")
        else:
            print(f"  ✓ Downloaded {len(df_forecast)} forecast records.")
            df_forecast['Date'] = pd.to_datetime(df_forecast['Date'])
            forecast_output_path = os.path.join(OUTPUT_DIR, "supply_demand_forecast.csv")
            df_forecast.to_csv(forecast_output_path, index=False)
            print(f"  ✓ Saved to: {forecast_output_path}")

        # --- 3. Combine Data ---
        print("\n[3] Combining historical and forecast data...")
        if not df_hist.empty and not df_forecast.empty:
            today = pd.Timestamp.now().normalize()
            
            df_hist_part = df_hist[df_hist['Date'] <= today].copy()
            df_forecast_part = df_forecast[df_forecast['Date'] > today].copy()
            
            # Add missing LNG_IMPORTS_BCF to forecast data and fill with 0
            if 'LNG_IMPORTS_BCF' not in df_forecast_part.columns:
                df_forecast_part['LNG_IMPORTS_BCF'] = 0.0
            
            # Ensure column order matches for concatenation
            df_forecast_part = df_forecast_part[df_hist_part.columns]

            df_combined = pd.concat([df_hist_part, df_forecast_part], ignore_index=True)
            df_combined.sort_values('Date', inplace=True)
            
            combined_output_path = os.path.join(OUTPUT_DIR, "supply_demand_combined.csv")
            df_combined.to_csv(combined_output_path, index=False)
            print(f"  ✓ Combined data created with {len(df_combined)} records.")
            print(f"  ✓ Saved to: {combined_output_path}")
        else:
            print("  ✗ Cannot create combined file as historical or forecast data is missing.")

    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")
        traceback.print_exc()
    finally:
        if engine:
            engine.dispose()
            print("\n    ✓ Database connection closed")

    print("\n" + "="*80)
    print("✅ Script completed!")
    print("="*80)

# --- Execute the Script ---
if __name__ == "__main__":
    download_supply_demand_data()