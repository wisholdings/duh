# -*- coding: utf-8 -*- # Keep encoding declaration
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from darts import TimeSeries
from darts.models import NHiTSModel
from darts.dataprocessing.transformers import Scaler as DartsScaler # Still needed for covariates potentially
from darts.metrics import mae, mse
import torch
from pytorch_lightning.callbacks import EarlyStopping
import matplotlib.pyplot as plt
import os
import joblib
import time
import traceback
import sys
import json # <<< Import json

# --- Configuration ---
# Define Region and Base Directory
REGION = "northwest" # <<< SET THE TARGET REGION HERE >>>
BASE_OUTPUT_DIR = "D:\\EIA_STACK" # <<< Base directory for all regions >>>

# --- File Paths using BASE_OUTPUT_DIR and REGION ---
REGION_BASE_DIR = os.path.join(BASE_OUTPUT_DIR, REGION)
FINAL_DIR = os.path.join(REGION_BASE_DIR, "final")
LOAD_DIR = os.path.join(REGION_BASE_DIR, "solar")
MODELS_DIR = os.path.join(REGION_BASE_DIR, "Models", "Solar_NoTargetScaling")

# Use the final merged files as input - CHANGED TO PARQUET
TRAIN_FILE = os.path.join(FINAL_DIR, "train.parquet")
PREDICT_FILE = os.path.join(FINAL_DIR, "predict.parquet")

# --- Model Parameters & Config ---
WIDTH_CONFIG = 256
LOSS_FN_CONFIG = torch.nn.MSELoss()
LOSS_NAME = "mse"
PATIENCE_CONFIG = 7
INPUT_CHUNK_LENGTH = 144
OUTPUT_CHUNK_LENGTH = 6
N_EPOCHS = 150
RANDOM_STATE = 42
LEARNING_RATE = 5e-6
EARLY_STOPPING_PATIENCE = PATIENCE_CONFIG
GRADIENT_CLIP_VAL = 0.1
BATCH_SIZE = 128
DROPOUT = 0.2

# --- NHiTS Architecture ---
COMPAT_NUM_STACKS = 7
COMPAT_NUM_BLOCKS_PER_STACK = 5
NUM_LAYERS_PER_BLOCK = 5
LAYER_WIDTH = WIDTH_CONFIG

# --- Future Growth Bump Parameters ---
# SET BUMP TO 0 FOR SOLAR RATIO
ANNUAL_BUMP_MW = 0
HOURS_PER_YEAR = 24 * 365.25
HOURLY_BUMP_MW = ANNUAL_BUMP_MW / HOURS_PER_YEAR if HOURS_PER_YEAR > 0 else 0

# --- Boundary Handling Parameters (NEWLY ADDED) ---
BRIDGE_HOURS = 168  # 1 week of historical context
BOUNDARY_SMOOTH_HOURS = 6
ANOMALY_THRESHOLD_STD = 2.0

# --- Output File Naming ---
MODEL_VERSION_SUFFIX = f"_SOLAR_NoTargetScaling"
MODEL_SAVE_PATH = os.path.join(MODELS_DIR, f"nhits_model_final.pt")
OUTPUT_FILE = os.path.join(LOAD_DIR, f"{REGION}_predicted_solar_nhits_final.parquet")
SKLEARN_SCALERS_PATH = os.path.join(MODELS_DIR, f"sklearn_scalers_.joblib")

# --- Config Paths ---
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RETRAIN_CONFIG_FILE = os.path.join(project_root, 'config', 'regions', f"{REGION}_config.json")
if not os.path.exists(RETRAIN_CONFIG_FILE):
    RETRAIN_CONFIG_FILE = os.path.join('..','config', 'regions', f"{REGION}_config.json")
    if not os.path.exists(RETRAIN_CONFIG_FILE):
        RETRAIN_CONFIG_FILE = os.path.join('config', 'regions', f"{REGION}_config.json")

# --- Load Retraining Configuration (UPDATED) ---
FORCE_RETRAIN_NHITS = False
NHITS_RETRAIN_KEY = "force_retrain_NHITS_Final_solar"
BOUNDARY_CONFIG = {
    'enabled': True,
    'bridge_hours': BRIDGE_HOURS,
    'smooth_hours': BOUNDARY_SMOOTH_HOURS,
    'anomaly_threshold': ANOMALY_THRESHOLD_STD
}

print(f"\nAttempting to load retraining configuration from: {RETRAIN_CONFIG_FILE}")
if os.path.exists(RETRAIN_CONFIG_FILE):
    try:
        with open(RETRAIN_CONFIG_FILE, 'r') as f:
            retrain_config = json.load(f)
        FORCE_RETRAIN_NHITS = retrain_config.get(NHITS_RETRAIN_KEY, False)
        if "boundary_handling" in retrain_config:
            BOUNDARY_CONFIG.update(retrain_config["boundary_handling"])
        print(f"  Loaded '{NHITS_RETRAIN_KEY}': {FORCE_RETRAIN_NHITS}")
        print(f"  Boundary handling: {BOUNDARY_CONFIG}")
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from '{RETRAIN_CONFIG_FILE}'. Defaulting to False.")
    except Exception as e:
        print(f"Error reading retrain config: {e}. Defaulting to False.")
        traceback.print_exc()
else:
    print(f"Warning: Retraining config file '{RETRAIN_CONFIG_FILE}' not found. Defaulting to False.")

# Ensure directories exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(LOAD_DIR, exist_ok=True)
os.makedirs(FINAL_DIR, exist_ok=True)

# --- Print Configuration ---
print("="*50)
print(f"--- NHITS FINAL MODEL (SOLAR RATIO - NO TARGET SCALING) FOR REGION: {REGION.upper()} ---")
print("--- Using parquet files and excluding _mw/capacity/ratio features ---")
print("="*50)
print(f"Using Input Files:\n  Train: {TRAIN_FILE}\n  Predict: {PREDICT_FILE}")
print(f"NHiTS Config: I={INPUT_CHUNK_LENGTH}, O={OUTPUT_CHUNK_LENGTH}, Stacks={COMPAT_NUM_STACKS}, Width={WIDTH_CONFIG}")
print(f"Training Params: Loss={LOSS_NAME.upper()}, Epochs={N_EPOCHS}, Patience={EARLY_STOPPING_PATIENCE}, LR={LEARNING_RATE}")
print(f"Target Scaling: OFF")
print(f"Boundary Handling: Enabled={BOUNDARY_CONFIG['enabled']}, Bridge={BOUNDARY_CONFIG['bridge_hours']}h, Smooth={BOUNDARY_CONFIG['smooth_hours']}h")
print(f"Model save path: {MODEL_SAVE_PATH}")
print(f"Output file: {OUTPUT_FILE}")
print(f"Covariate Scalers path: {SKLEARN_SCALERS_PATH}")
print(f"Hourly bump MW: {HOURLY_BUMP_MW:.6f}")
print(f"Force Retrain (from config or default): {FORCE_RETRAIN_NHITS}")
print("="*50)

# -------------------------------------------
# Feature Engineering Functions (Simplified for Solar)
# -------------------------------------------
def create_time_features(df, date_col='date', min_year_train=None):
    if date_col not in df.columns:
        print(f"Error: Date col '{date_col}' missing.")
        return df, []
    df[date_col] = pd.to_datetime(df[date_col])
    if not pd.api.types.is_datetime64_any_dtype(df[date_col]):
        print(f"Warning: '{date_col}' not datetime.")
        return df, []
    features = {}
    try:
        dt = df[date_col].dt
        features['hour_sin'] = np.sin(2 * np.pi * dt.hour / 24)
        features['hour_cos'] = np.cos(2 * np.pi * dt.hour / 24)
        features['weekday_sin'] = np.sin(2 * np.pi * dt.dayofweek / 7)
        features['weekday_cos'] = np.cos(2 * np.pi * dt.dayofweek / 7)
        features['month_sin'] = np.sin(2 * np.pi * dt.month / 12)
        features['month_cos'] = np.cos(2 * np.pi * dt.month / 12)
        features['day_of_year_sin'] = np.sin(2 * np.pi * dt.dayofyear / 365.25)
        features['day_of_year_cos'] = np.cos(2 * np.pi * dt.dayofyear / 365.25)
        features['weekend'] = dt.dayofweek.isin([5, 6]).astype(int)
        if min_year_train:
            features['year_trend'] = dt.year - min_year_train
        time_features_df = pd.DataFrame(features, index=df.index)
        time_feature_cols = list(features.keys())
        cols_to_drop = [col for col in time_features_df.columns if col in df.columns]
        df = pd.concat([df.drop(columns=cols_to_drop, errors='ignore'), time_features_df], axis=1)
        return df, time_feature_cols
    except Exception as e:
        print(f"Error creating time features: {e}")
        return df, []

# -------------------------------------------
# Seamless Data Creation Function (NEWLY ADDED)
# -------------------------------------------
def create_seamless_prediction_data(
    train_file_path: str,
    predict_file_path: str,
    target_col: str,
    date_col: str,
    bridge_hours: int = 168,
    overlap_hours: int = 0
):
    """
    Create a seamless prediction dataset by bridging train and predict files.
    """
    print(f"\n--- Creating Seamless Prediction Data ---")

    # Load both files
    df_train = pd.read_parquet(train_file_path)
    df_predict = pd.read_parquet(predict_file_path)
    
    # Ensure date column is datetime
    df_train[date_col] = pd.to_datetime(df_train[date_col])
    df_predict[date_col] = pd.to_datetime(df_predict[date_col])

    # Sort by date
    df_train = df_train.sort_values(date_col).reset_index(drop=True)
    df_predict = df_predict.sort_values(date_col).reset_index(drop=True)

    # Get time boundaries
    train_end = df_train[date_col].max()
    predict_start = df_predict[date_col].min()

    print(f"Train ends at: {train_end}")
    print(f"Predict starts at: {predict_start}")

    # Check for gap or overlap
    time_diff = (predict_start - train_end).total_seconds() / 3600
    if time_diff > 1:
        print(f"WARNING: {time_diff:.1f} hour gap between train and predict!")
    elif time_diff < -1:
        print(f"Found {-time_diff:.1f} hour overlap between files")

    # Extract bridge data from training set
    bridge_start = train_end - pd.Timedelta(hours=bridge_hours)
    df_bridge = df_train[df_train[date_col] > bridge_start].copy()

    print(f"Extracting {len(df_bridge)} hours of bridge data from training set")

    # Remove overlap from prediction data if needed
    if overlap_hours > 0:
        overlap_cutoff = predict_start + pd.Timedelta(hours=overlap_hours)
        df_predict = df_predict[df_predict[date_col] >= overlap_cutoff].copy()
        print(f"Removed {overlap_hours} hours of overlap from prediction data")

    # Combine datasets
    df_seamless = pd.concat([df_bridge, df_predict], ignore_index=True)
    df_seamless = df_seamless.sort_values(date_col).reset_index(drop=True)

    # Add flags to identify data source
    df_seamless['data_source'] = 'future'
    df_seamless.loc[df_seamless[date_col] <= train_end, 'data_source'] = 'historical'

    # Ensure no duplicates
    df_seamless = df_seamless.drop_duplicates(subset=[date_col], keep='first')

    print(f"Created seamless dataset with {len(df_seamless)} total hours")
    print(f"  - Historical (from train): {(df_seamless['data_source'] == 'historical').sum()} hours")
    print(f"  - Future (from predict): {(df_seamless['data_source'] == 'future').sum()} hours")

    # Calculate actual forecast start (first hour after training data)
    actual_forecast_start = train_end + pd.Timedelta(hours=1)

    return df_seamless, actual_forecast_start

# -------------------------------------------
# Boundary Smoothing Functions (NEWLY ADDED)
# -------------------------------------------
def apply_boundary_smoothing(df_pred, hist_stats, date_col, pred_col,
                           smooth_hours=6, anomaly_threshold=2.0):
    """Apply intelligent smoothing based on historical patterns"""

    if df_pred.empty or pred_col not in df_pred.columns:
        return df_pred

    df_pred = df_pred.sort_values(date_col).reset_index(drop=True)

    # Check for boundary anomaly
    first_pred = df_pred.iloc[0][pred_col]
    last_hist = hist_stats['last_value']
    jump = first_pred - last_hist
    jump_z_score = abs(jump) / hist_stats['std'] if hist_stats['std'] > 0 else 0

    print(f"Boundary jump: {jump:.4f} (z-score: {jump_z_score:.2f})")

    if jump_z_score > anomaly_threshold:
        print(f"Applying boundary smoothing (jump exceeds {anomaly_threshold} std devs)")

        # Exponential smoothing of the jump
        for i in range(min(smooth_hours, len(df_pred))):
            decay = np.exp(-i / (smooth_hours / 3))
            adjustment = jump * decay
            df_pred.loc[i, pred_col] = df_pred.loc[i, pred_col] - adjustment

        # Also apply confidence-based clipping for first 24 hours
        for i in range(min(24, len(df_pred))):
            confidence = i / 24  # 0 to 1 over 24 hours

            # Allowed deviation increases with time
            max_deviation = hist_stats['std'] * (anomaly_threshold + confidence * 2)
            upper_bound = last_hist + max_deviation
            lower_bound = last_hist - max_deviation

            # Add trend component to bounds if available
            if 'recent_trend' in hist_stats and hist_stats['recent_trend'] is not None:
                trend_component = hist_stats['recent_trend'] * (i + 1)
                upper_bound += max(0, trend_component)
                lower_bound += min(0, trend_component)

            # Store original value for comparison
            original = df_pred.loc[i, pred_col]
            clipped = np.clip(original, lower_bound, upper_bound)

            if original != clipped:
                print(f"  Hour {i}: Clipped {original:.4f} to {clipped:.4f}")
                df_pred.loc[i, pred_col] = clipped

    return df_pred
    
# -------------------------------------------
# Data Loading & Preparation
# -------------------------------------------
print(f"\n--- Loading Training Data: {TRAIN_FILE} ---")
try:
    df_train_full = pd.read_parquet(TRAIN_FILE)
    df_train_full['date'] = pd.to_datetime(df_train_full['date'])
    df_train_full = df_train_full.sort_values("date").reset_index(drop=True)
    print(f"Loaded Training Data shape: {df_train_full.shape}")

    # --- Basic Data Checks ---
    target_col_name = f"{REGION.upper()}_SOLAR_RATIO"
    date_col_name = "date"
    if target_col_name not in df_train_full.columns:
        # Fallback to check for _SUN_MW if _SOLAR_RATIO doesn't exist
        fallback_target = f"{REGION.upper()}_SUN_MW"
        if fallback_target in df_train_full.columns:
            print(f"Warning: Target '{target_col_name}' not found, using '{fallback_target}' instead.")
            target_col_name = fallback_target
        else:
            raise ValueError(f"Target column '{target_col_name}' or fallback '{fallback_target}' not found in {TRAIN_FILE}")

    if df_train_full[target_col_name].isnull().any():
        print(f"Warning: NaNs found in target '{target_col_name}'. Interpolating...")
        df_train_full[target_col_name] = df_train_full[target_col_name].interpolate(method='linear').ffill().bfill()
        if df_train_full[target_col_name].isnull().any():
            raise ValueError(f"NaNs persist in target '{target_col_name}' after interpolation.")
    if df_train_full[date_col_name].duplicated().any():
        print("Warning: Duplicate dates found. Keeping first.")
        df_train_full = df_train_full.drop_duplicates(subset=[date_col_name], keep='first')

    # --- Covariate Identification and Filtering ---
    print("Identifying and filtering covariates...")
    all_columns = df_train_full.columns.tolist()
    original_load_col = f"{REGION.upper()}_LOAD"
    cols_to_exclude = [date_col_name, target_col_name]
    if original_load_col in all_columns:
        cols_to_exclude.append(original_load_col)

    potential_covariates = [col for col in all_columns if col not in cols_to_exclude]

    final_covariate_columns = []
    excluded_cols_list = []
    for col in potential_covariates:
        col_lower = col.lower()
        # Exclude _mw, capacity, ratio AND classifier selected load if present
        if (not col_lower.endswith('_mw') and
                'capacity' not in col_lower and
                'ratio' not in col_lower and
                'classifier_selected' not in col_lower):
            final_covariate_columns.append(col)
        else:
            excluded_cols_list.append(col)

    final_covariate_columns = sorted(final_covariate_columns)
    excluded_cols_list = sorted(excluded_cols_list)
    print(f"Identified {len(final_covariate_columns)} covariate columns to use.")
    if excluded_cols_list:
        print(f"Excluded {len(excluded_cols_list)} columns.")

    nan_cov_check = df_train_full[final_covariate_columns].isnull().sum()
    if nan_cov_check.sum() > 0:
        print(f"Found NaNs in selected covariates:\n{nan_cov_check[nan_cov_check > 0]}. Filling with 0.")
        df_train_full[final_covariate_columns] = df_train_full[final_covariate_columns].fillna(0)

    print(f"Final Training Data shape after prep: {df_train_full.shape}")

except Exception as e:
    print(f"ERROR loading/preparing training data: {e}")
    traceback.print_exc()
    sys.exit(1)

min_train_year = df_train_full[date_col_name].dt.year.min()

# --- Create Darts TimeSeries ---
print("Creating Darts TimeSeries objects...")
try:
    cols_for_ts = [target_col_name] + final_covariate_columns
    value_cols_arg = cols_for_ts
    full_darts_ts = TimeSeries.from_dataframe(df_train_full, time_col=date_col_name, value_cols=value_cols_arg, freq="h", fill_missing_dates=False)
    print(f"Full Darts TimeSeries created. Range: {full_darts_ts.start_time()} to {full_darts_ts.end_time()} ({len(full_darts_ts)} points).")
    print(f"Components ({full_darts_ts.width}): {list(full_darts_ts.components)}")
except Exception as e:
    print(f"ERROR creating Darts TimeSeries: {e}")
    traceback.print_exc()
    sys.exit(1)

# --- Scaling ---
print("\n--- Scaling Data ---")
target_scaled_full = None  # Not used
target_scaler = None  # Not used
covariate_series_PRESCALED_full = None
scalers = {}  # Store sklearn scalers

print(f"Target '{target_col_name}' will NOT be scaled.")

# Covariate Scaling (simplified for solar - no temperature-based features)
print("Fitting covariate scalers...")
# For solar, we'll use StandardScaler for all covariates
other_cols_for_scaling = sorted(final_covariate_columns)

df_train_for_scaling = df_train_full

if other_cols_for_scaling:
    other_scaler = StandardScaler()
    try:
        cols_to_fit = [c for c in other_cols_for_scaling if c in df_train_for_scaling.columns]
        if cols_to_fit:
            scalers['other'] = other_scaler.fit(df_train_for_scaling[cols_to_fit])
            print(f"Fitted StandardScaler for features ({len(cols_to_fit)}).")
        else:
            print("No columns found for StandardScaler.")
    except Exception as e:
        print(f"Error fitting scaler: {e}")

if scalers:
    try:
        joblib.dump(scalers, SKLEARN_SCALERS_PATH)
        print(f"Sklearn covariate scalers saved to {SKLEARN_SCALERS_PATH}")
    except Exception as e:
        print(f"ERROR saving covariate scalers: {e}")
else:
    print("No covariate scalers were fitted.")

# Function to apply scaling using the fitted sklearn scalers dictionary
def scale_covariates_from_dict(series: TimeSeries, fitted_scalers_dict: dict, cols_to_scale: list) -> TimeSeries:
    if not isinstance(series, TimeSeries):
        raise ValueError("Input must be TimeSeries.")
    df = series.to_dataframe(copy=True)
    transformed = False
    if 'other' in fitted_scalers_dict and cols_to_scale:
        cols = [c for c in cols_to_scale if c in df.columns]
        if cols:
            try:
                df.loc[:, cols] = fitted_scalers_dict['other'].transform(df[cols])
                transformed = True
            except Exception as e:
                print(f"Err scaling: {e}")
                raise e
    if not transformed:
        print("Warning: No covariates transformed.")
        return series
    if df.isnull().any().any() or np.isinf(df.values).any():
        print("Warning: NaNs/Infs after scaling. Filling 0.")
        df = df.fillna(0).replace([np.inf, -np.inf], 0)
    return TimeSeries.from_dataframe(df, freq=series.freq_str, fill_missing_dates=True, fillna_value=0)

# Apply scaling to the full covariate set
if final_covariate_columns and scalers:
    print("Extracting and transforming full covariate TimeSeries...")
    if set(final_covariate_columns).issubset(set(full_darts_ts.components)):
        covariate_series_full = full_darts_ts[final_covariate_columns]
        try:
            covariate_series_PRESCALED_full = scale_covariates_from_dict(covariate_series_full, scalers, other_cols_for_scaling)
            print(f"Full covariate series scaled ({covariate_series_PRESCALED_full.width} components).")
            if covariate_series_PRESCALED_full.pd_dataframe().isnull().any().any():
                print("ERROR: NaNs in scaled covariates!")
                sys.exit(1)
        except Exception as e:
            print(f"ERROR scaling covariates: {e}")
            traceback.print_exc()
            covariate_series_PRESCALED_full = None
    else:
        print("Warning: Not all filtered covariate columns in TimeSeries. Skipping scaling.")
elif not scalers:
    print("No scalers fitted. Using unscaled covariates (if any).")
    if final_covariate_columns and set(final_covariate_columns).issubset(set(full_darts_ts.components)):
        covariate_series_PRESCALED_full = full_darts_ts[final_covariate_columns]
    else:
        covariate_series_PRESCALED_full = None
else:
    print("No covariates defined. Skipping scaling.")

# -------------------------------------------
# Model Definition (Helper Function)
# -------------------------------------------
def create_nhits_model(input_chunk, output_chunk, n_epochs, patience, loss_fn, lr, grad_clip, batch_size, dropout,
                       num_stacks, num_blocks, num_layers, layer_width, random_state):
    print("Defining N-HiTS model instance...")
    early_stopper = EarlyStopping(monitor="train_loss", patience=patience, min_delta=0.0001, mode='min', verbose=True)
    callbacks_list = [early_stopper]
    try:
        model = NHiTSModel(
            input_chunk_length=input_chunk,
            output_chunk_length=output_chunk,
            num_stacks=num_stacks,
            num_blocks=num_blocks,
            num_layers=num_layers,
            layer_widths=layer_width,
            dropout=dropout,
            n_epochs=n_epochs,
            random_state=random_state,
            loss_fn=loss_fn,
            optimizer_kwargs={"lr": lr},
            pl_trainer_kwargs={
                "accelerator": "auto",
                "callbacks": callbacks_list,
                "gradient_clip_val": grad_clip
            },
            batch_size=batch_size,
            force_reset=True,
            save_checkpoints=False
        )
        return model
    except Exception as e:
        print(f"ERROR initializing NHiTSModel: {e}")
        traceback.print_exc()
        return None

# -------------------------------------------
# Final Model Training (No CV)
# -------------------------------------------
print("\n--- Training Final Model on Full Dataset (No CV) ---")
final_model = None
model_exists = os.path.exists(MODEL_SAVE_PATH)
can_train_final = True

if final_covariate_columns and covariate_series_PRESCALED_full is None:
    print("ERROR: Covariates expected but not scaled/available.")
    can_train_final = False

force_retrain_decision = FORCE_RETRAIN_NHITS

if not can_train_final:
    print("Skipping final model training due to previous errors.")
    if model_exists and not force_retrain_decision:
        try:
            print(f"Loading existing model: {MODEL_SAVE_PATH}...")
            final_model = NHiTSModel.load(MODEL_SAVE_PATH)
            print("Loaded.")
        except Exception as e:
            print(f"Error loading existing model: {e}.")
    else:
        print("Final model cannot be trained/loaded.")
elif model_exists and not force_retrain_decision:
    try:
        print(f"Loading existing model: {MODEL_SAVE_PATH}...")
        final_model = NHiTSModel.load(MODEL_SAVE_PATH)
        print("Loaded.")
    except Exception as e:
        print(f"Error loading model: {e}. Forcing retrain.")
        force_retrain_decision = True
        final_model = None
else:
    if not model_exists:
        print(f"Model not found at {MODEL_SAVE_PATH}. Training.")
    elif force_retrain_decision:
        print(f"Force Retrain is True (from config: {FORCE_RETRAIN_NHITS}). Training.")
    force_retrain_decision = True

if final_model is None and force_retrain_decision and can_train_final:
    print("Instantiating final model...")
    final_model = create_nhits_model(
        input_chunk=INPUT_CHUNK_LENGTH,
        output_chunk=OUTPUT_CHUNK_LENGTH,
        n_epochs=N_EPOCHS,
        patience=EARLY_STOPPING_PATIENCE,
        loss_fn=LOSS_FN_CONFIG,
        lr=LEARNING_RATE,
        grad_clip=GRADIENT_CLIP_VAL,
        batch_size=BATCH_SIZE,
        dropout=DROPOUT,
        num_stacks=COMPAT_NUM_STACKS,
        num_blocks=COMPAT_NUM_BLOCKS_PER_STACK,
        num_layers=NUM_LAYERS_PER_BLOCK,
        layer_width=LAYER_WIDTH,
        random_state=RANDOM_STATE
    )
    if final_model:
        print("Training final model...")
        start_train_time = time.time()
        try:
            # Use UNscaled target for training
            target_series_unscaled = full_darts_ts[target_col_name]
            fit_kwargs = {'series': target_series_unscaled, 'verbose': True}

            if final_covariate_columns and covariate_series_PRESCALED_full:
                fit_kwargs['past_covariates'] = covariate_series_PRESCALED_full
            final_model.fit(**fit_kwargs)
            end_train_time = time.time()
            print(f"Final training took {end_train_time - start_train_time:.2f} sec.")
            print(f"Saving final model: {MODEL_SAVE_PATH}...")
            final_model.save(MODEL_SAVE_PATH)
            print("Saved.")
        except Exception as e:
            print(f"Error training/saving: {e}")
            traceback.print_exc()
            final_model = None
    else:
        print("ERROR: Failed to create final model instance.")

if final_model is None:
    print("FATAL ERROR: No model available for inference.")
    sys.exit(1)

# -------------------------------------------
# Enhanced Inference Function with Seamless Data (REPLACES OLD do_inference)
# -------------------------------------------
def do_inference_seamless(
    model_to_use: NHiTSModel,
    train_file_path: str,
    predict_file_path: str,
    path_to_output_file: str,
    path_to_sklearn_scalers: str,
    target_col_name: str,
    date_col_name: str = "date",
    bridge_hours: int = 168,
    boundary_smooth_hours: int = 6,
    anomaly_threshold: float = 2.0,
    bump_per_hour: float = 0.0,
    cols_for_scaling: list = [],
    min_year_train: int = None
):
    """
    Perform inference using seamless data bridging for smooth predictions.
    """
    print(f"\n--- Starting Enhanced Inference with Seamless Data ---")
    start_time = time.time()

    # Step 1: Create seamless dataset
    df_seamless, actual_forecast_start = create_seamless_prediction_data(
        train_file_path=train_file_path,
        predict_file_path=predict_file_path,
        target_col=target_col_name,
        date_col=date_col_name,
        bridge_hours=bridge_hours
    )

    # Step 2: Load scalers
    local_cov_scalers_dict = {}
    if os.path.exists(path_to_sklearn_scalers):
        try:
            local_cov_scalers_dict = joblib.load(path_to_sklearn_scalers)
            print("Covariate scalers dict loaded.")
        except Exception as e:
            print(f"Warn: Failed load cov scalers: {e}")

    # Step 3: Prepare features for seamless data
    all_covariate_cols = sorted(list(set(cols_for_scaling)))

    # Generate any missing features
    missing_cols = [c for c in all_covariate_cols if c not in df_seamless.columns]
    if missing_cols:
        print(f"Generating missing features: {missing_cols}")
        df_seamless, _ = create_time_features(df_seamless, date_col_name, min_year_train)
        # NOTE: No solar-specific feature function to call here like add_wind_features

        # Check again
        still_missing = [c for c in all_covariate_cols if c not in df_seamless.columns]
        if still_missing:
            print(f"ERROR: Still missing columns after generation: {still_missing}")
            return pd.DataFrame()

    # Fill any NaNs in covariates
    if all_covariate_cols:
        nan_counts = df_seamless[all_covariate_cols].isnull().sum()
        if nan_counts.sum() > 0:
            print("Filling NaNs in covariates...")
            df_seamless[all_covariate_cols] = df_seamless[all_covariate_cols].ffill().bfill().fillna(0)

    # Step 4: Split seamless data into historical and future
    df_historical = df_seamless[df_seamless[date_col_name] < actual_forecast_start].copy()
    df_future = df_seamless[df_seamless[date_col_name] >= actual_forecast_start].copy()

    print(f"\nSplit seamless data at {actual_forecast_start}:")
    print(f"  - Historical (with bridge): {len(df_historical)} hours")
    print(f"  - Future to predict: {len(df_future)} hours")

    # Step 5: Create TimeSeries objects
    # Historical target (includes bridge data)
    hist_target_ts = None
    if target_col_name in df_historical.columns:
        hist_target_ts = TimeSeries.from_dataframe(
            df_historical, date_col_name, target_col_name, freq='h'
        )

    # Covariates for entire span (historical + future)
    seamless_cov_scaled = None
    if all_covariate_cols and local_cov_scalers_dict:
        # Ensure column order matches training
        cols_for_ts = [c for c in all_covariate_cols if c in df_seamless.columns]

        if cols_for_ts:
            seamless_cov_ts = TimeSeries.from_dataframe(
                df_seamless, date_col_name, cols_for_ts, freq='h',
                fill_missing_dates=True, fillna_value=0
            )

            # Apply scalers
            seamless_cov_scaled = scale_covariates_from_dict(
                seamless_cov_ts, local_cov_scalers_dict, 
                cols_for_scaling
            )
            print(f"Scaled seamless covariates: {seamless_cov_scaled.width} components, {len(seamless_cov_scaled)} timesteps")

    # Step 6: Calculate historical statistics for boundary checking
    hist_stats = None
    if target_col_name in df_historical.columns:
        # Get last week of historical data
        week_ago = actual_forecast_start - pd.Timedelta(hours=168)
        recent_history = df_historical[df_historical[date_col_name] >= week_ago][target_col_name]

        if len(recent_history) > 0:
            hist_stats = {
                'mean': recent_history.mean(),
                'std': recent_history.std(),
                'last_value': recent_history.iloc[-1],
                'recent_trend': np.mean(np.diff(recent_history.tail(24))) if len(recent_history) >= 24 else 0
            }
            print(f"\nHistorical stats from bridge data:")
            print(f"  Mean: {hist_stats['mean']:.4f}")
            print(f"  Std: {hist_stats['std']:.4f}")
            print(f"  Last value: {hist_stats['last_value']:.4f}")
            print(f"  Recent trend: {hist_stats['recent_trend']:.6f}/hour")

    # Step 7: Generate predictions
    n_predict = len(df_future)
    print(f"\nGenerating {n_predict} predictions...")

    predictions_unscaled = None
    try:
        # Prepare prediction inputs
        predict_kwargs = {'n': n_predict, 'verbose': True}

        # Add historical series if needed
        if model_to_use.input_chunk_length > 0:
            if hist_target_ts is None:
                raise ValueError("Model requires historical target data but none available")

            # Get the right chunk of history for prediction start
            hist_end = actual_forecast_start - pd.Timedelta(hours=1)
            hist_start = hist_end - pd.Timedelta(hours=model_to_use.input_chunk_length - 1)

            predict_series = hist_target_ts.slice(hist_start, hist_end)
            if len(predict_series) != model_to_use.input_chunk_length:
                raise ValueError(f"Historical chunk wrong size: {len(predict_series)} vs {model_to_use.input_chunk_length}")

            predict_kwargs['series'] = predict_series

        # Add covariates if available
        if seamless_cov_scaled is not None:
            predict_kwargs['past_covariates'] = seamless_cov_scaled

        # Generate predictions
        predictions_unscaled = model_to_use.predict(**predict_kwargs)

    except Exception as e:
        print(f"ERROR during prediction: {e}")
        traceback.print_exc()
        return pd.DataFrame()

    # Step 8: Post-process predictions
    df_output = pd.DataFrame()

    if predictions_unscaled is None:
        print("ERROR: No predictions generated")
        return df_output

    # Convert to dataframe
    df_output = predictions_unscaled.pd_dataframe().reset_index()
    df_output.columns = [date_col_name, 'predicted_solar_base']

    # Add growth bump (should be 0 for solar)
    if bump_per_hour > 0:
        print(f"Adding growth bump of {bump_per_hour:.6f}/hour...")
        start_dt = df_output[date_col_name].min()
        df_output['hours_elapsed'] = (df_output[date_col_name] - start_dt).dt.total_seconds() / 3600
        df_output['growth_bump'] = df_output['hours_elapsed'] * bump_per_hour
        df_output['predicted_solar_final'] = df_output['predicted_solar_base'] + df_output['growth_bump']
    else:
        df_output['predicted_solar_final'] = df_output['predicted_solar_base']

    # Step 9: Apply boundary smoothing if needed
    if hist_stats and boundary_smooth_hours > 0 and BOUNDARY_CONFIG['enabled']:
        print("\nChecking for boundary anomalies...")
        df_output = apply_boundary_smoothing(
            df_output, hist_stats, date_col_name,
            'predicted_solar_final', boundary_smooth_hours, anomaly_threshold
        )

    # Step 10: Add actual values if available
    if target_col_name in df_future.columns:
        df_actuals = df_future[[date_col_name, target_col_name]].copy()
        df_actuals.rename(columns={target_col_name: f'{target_col_name}_actual'}, inplace=True)
        df_output = pd.merge(df_output, df_actuals, on=date_col_name, how='left')

        # Calculate metrics if actuals exist
        actual_col = f'{target_col_name}_actual'
        df_eval = df_output.dropna(subset=['predicted_solar_final', actual_col])
        if len(df_eval) > 0:
            mae_val = np.mean(np.abs(df_eval['predicted_solar_final'] - df_eval[actual_col]))
            rmse_val = np.sqrt(np.mean((df_eval['predicted_solar_final'] - df_eval[actual_col])**2))
            print(f"\nEvaluation on {len(df_eval)} points with actuals:")
            print(f"  MAE: {mae_val:.4f}")
            print(f"  RMSE: {rmse_val:.4f}")

    # Step 11: Save results
    print(f"\nSaving predictions to: {path_to_output_file}")
    try:
        os.makedirs(os.path.dirname(path_to_output_file), exist_ok=True)
        
        # Save to the additional parquet file
        df_output.to_parquet(path_to_output_file, index=False)
        print(f"Predictions saved to additional file: {path_to_output_file}")
        
        # Also update the predict.parquet file with the predictions
        print(f"\nUpdating predict.parquet with predictions...")
        df_predict_original = pd.read_parquet(predict_file_path)
        df_predict_original[date_col_name] = pd.to_datetime(df_predict_original[date_col_name])
        
        # Create a simple dataframe with just date and the final predictions
        df_predictions_to_merge = df_output[[date_col_name, 'predicted_solar_final']].copy()
        
        # Rename predicted_solar_final to the target column name
        df_predictions_to_merge.rename(columns={'predicted_solar_final': target_col_name}, inplace=True)
        
        # Merge predictions, which will overwrite the existing target column
        df_predict_updated = pd.merge(
            df_predict_original.drop(columns=[target_col_name], errors='ignore'),
            df_predictions_to_merge,
            on=date_col_name,
            how='left'
        )
        
        # Ensure column order matches original
        original_cols = list(df_predict_original.columns)
        cols_without_target = [col for col in original_cols if col != target_col_name]
        target_position = original_cols.index(target_col_name) if target_col_name in original_cols else len(original_cols)
        
        # Reconstruct column order
        final_cols = cols_without_target[:target_position] + [target_col_name] + cols_without_target[target_position:]
        final_cols = [col for col in final_cols if col in df_predict_updated.columns]
        df_predict_updated = df_predict_updated[final_cols]
        
        # Save updated predict.parquet
        df_predict_updated.to_parquet(predict_file_path, index=False)
        print(f"Updated predict.parquet file: {predict_file_path}")
        
    except Exception as e:
        print(f"Error saving predictions: {e}")

    end_time = time.time()
    print(f"\nInference completed in {end_time - start_time:.2f} seconds")

    return df_output

# -------------------------------------------
# Main Execution Block (UPDATED)
# -------------------------------------------
if __name__ == "__main__":
    print("\n--- Main Execution: NHITS FINAL MODEL (SOLAR - NO TARGET SCALING) WITH SEAMLESS DATA ---")
    TARGET_COL = f"{REGION.upper()}_SOLAR_RATIO"

    # --- Check if prerequisite files exist ---
    if not os.path.exists(TRAIN_FILE):
        print(f"ERROR: Training file not found: {TRAIN_FILE}")
        sys.exit(1)
    if not os.path.exists(PREDICT_FILE):
        print(f"ERROR: Prediction file not found: {PREDICT_FILE}")
        sys.exit(1)
    if final_model is None:
        print("FATAL ERROR: final_model was not created/loaded.")
        sys.exit(1)
    if 'df_train_full' not in locals() or df_train_full.empty:
        print("FATAL ERROR: df_train_full needed for start date.")
        sys.exit(1)
    if target_col_name not in full_darts_ts.components:
        print(f"FATAL ERROR: Target column '{target_col_name}' not found in final TimeSeries components.")
        sys.exit(1)

    # --- Run Enhanced Inference with Seamless Data ---
    df_predictions_output = do_inference_seamless(
        model_to_use=final_model,
        train_file_path=TRAIN_FILE,
        predict_file_path=PREDICT_FILE,
        path_to_output_file=OUTPUT_FILE,
        path_to_sklearn_scalers=SKLEARN_SCALERS_PATH,
        target_col_name=TARGET_COL,
        date_col_name=date_col_name,
        bridge_hours=BOUNDARY_CONFIG['bridge_hours'],
        boundary_smooth_hours=BOUNDARY_CONFIG['smooth_hours'],
        anomaly_threshold=BOUNDARY_CONFIG['anomaly_threshold'],
        bump_per_hour=HOURLY_BUMP_MW,
        cols_for_scaling=other_cols_for_scaling if 'other_cols_for_scaling' in locals() else [],
        min_year_train=min_train_year
    )

    # --- Plotting Results ---
    print("\n--- Plotting Results ---")
    if df_predictions_output is not None and not df_predictions_output.empty:
        plt.figure(figsize=(16, 8))
        plot_success = False
        actual_col_plot = f"{TARGET_COL}_actual"
        final_pred_col = "predicted_solar_final"
        base_pred_col = "predicted_solar_base"

        try:
            # Create seamless data for plotting to show smooth transition
            df_plot_seamless, _ = create_seamless_prediction_data(
                TRAIN_FILE, PREDICT_FILE, TARGET_COL, date_col_name,
                bridge_hours=72  # Show 3 days of history in plot
            )

            # Plot historical data from seamless dataset
            df_hist_plot = df_plot_seamless[df_plot_seamless['data_source'] == 'historical']
            if TARGET_COL in df_hist_plot.columns and len(df_hist_plot) > 0:
                plt.plot(df_hist_plot[date_col_name], df_hist_plot[TARGET_COL],
                        'k-', label='Historical', linewidth=1.5)
                plot_success = True

            # Plot predictions
            if final_pred_col in df_predictions_output.columns:
                plt.plot(df_predictions_output[date_col_name],
                        df_predictions_output[final_pred_col],
                        'purple', label='Prediction', linewidth=2)
                plot_success = True

            # Plot actuals if available
            if actual_col_plot in df_predictions_output.columns:
                df_actuals_plot = df_predictions_output.dropna(subset=[actual_col_plot])
                if len(df_actuals_plot) > 0:
                    plt.plot(df_actuals_plot[date_col_name],
                            df_actuals_plot[actual_col_plot],
                            'b--', label='Actual', linewidth=1.5)
                    plot_success = True

            # Add vertical line at forecast start
            forecast_start = df_predictions_output[date_col_name].min()
            plt.axvline(x=forecast_start, color='red', linestyle=':', alpha=0.7,
                       label='Forecast Start')

        except Exception as e:
            print(f"Error during plotting: {e}")
            traceback.print_exc()

        if plot_success:
            plt.title(f"N-HiTS Solar Forecast with Seamless Data - {REGION.upper()}\n" +
                     f"Model: {MODEL_VERSION_SUFFIX}\n" +
                     f"Bridge: {BOUNDARY_CONFIG['bridge_hours']}h, Smooth: {BOUNDARY_CONFIG['smooth_hours']}h")
            plt.xlabel("Date")
            plt.ylabel("Solar Ratio")
            plt.legend(loc='best')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()

            plot_filename = os.path.splitext(OUTPUT_FILE)[0] + "_seamless.png"
            try:
                plt.savefig(plot_filename, dpi=150)
                print(f"Plot saved: {plot_filename}")
            except Exception as e:
                print(f"Error saving plot: {e}")

            plt.close()
        else:
            print("No data to plot.")
            plt.close()
    else:
        print("No predictions generated, skipping plot.")

    print("\n--- Script Completed Successfully ---")