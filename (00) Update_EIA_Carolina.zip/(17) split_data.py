# Combined Data Splitter Script

import json
import os
import sys
import pandas as pd
import numpy as np
import traceback
import gc # Import garbage collector
from typing import Dict, Optional, Tuple # Import Tuple

# Ensure pyarrow is installed: pip install pyarrow

# --- Path Setup ---
# Get the absolute path of the directory containing the script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Assuming the script is located at project_root/scripts/your_script.py
# and config/src are located at project_root/config/ or project_root/src/
# The project root is the parent directory of the script directory.
# os.path.join(script_dir, '..') goes up one level from 'scripts/' to the project root.
project_root = os.path.abspath(os.path.join(script_dir, '..'))

# Add the project root directory to sys.path
# This makes 'config', 'src', etc. importable as packages
# Check if it's already in sys.path to avoid duplicates if this script is imported elsewhere
if project_root not in sys.path:
    sys.path.append(project_root)

print(f"Script directory: {script_dir}")
print(f"Calculated project root (parent of script dir): {project_root}")
print(f"sys.path updated to include: {project_root}")


# --- Configuration Loading ---
# Initialize variables to None or empty in case of import/load errors
BASE_OUTPUT_DIR = None
regions = {}

try:
    # Now attempt to import config.settings - it should be found because project_root is in sys.path
    from config.settings import BASE_OUTPUT_DIR
    print("Successfully imported BASE_OUTPUT_DIR from config.settings.")

    # Construct the path to regions.json relative to the project root
    config_dir = os.path.join(project_root, 'config')
    regions_config_path = os.path.join(config_dir, 'regions.json')

    if not os.path.exists(regions_config_path):
         raise FileNotFoundError(f"Regions config not found at: {regions_config_path}")

    with open(regions_config_path, 'r') as f:
        regions = json.load(f)
    print(f"Successfully loaded region configuration from {regions_config_path}")

    # --- Load Column Mapping (defined directly in the original runner) ---
    load_column_mapping: Dict[str, str] = {
        "california": "CALIFORNIA_LOAD",
        "carolina": "CAROLINA_LOAD",
        "central": "CENTRAL_LOAD",
        "florida": "FLORIDA_LOAD",
        "midwest": "MIDWEST_LOAD",
        "midatlantic": "MIDATLANTIC_LOAD",
        "northwest": "NORTHWEST_LOAD",
        "southeast": "SOUTHEAST_LOAD",
        "southwest": "SOUTHWEST_LOAD",
        "tennessee": "TENNESSEE_LOAD",
        "texas": "TEXAS_LOAD",
        "newyork": "NEWYORK_LOAD",
        "newengland": "NEWENGLAND_LOAD",
    }
    print(f"Defined load column mapping for {len(load_column_mapping)} regions.")


except ImportError as e:
    print(f"Error: Could not import BASE_OUTPUT_DIR from config.settings.")
    print(f"Details: {e}")
    print(f"Please ensure config/settings.py exists at '{os.path.join(project_root, 'config', 'settings.py')}'")
    print("and that the directory '{os.path.join(project_root, 'config')}' contains an '__init__.py' file.")
    # Exit if essential config cannot be loaded
    sys.exit(1)
except FileNotFoundError as e:
    print(f"Error loading configuration file: {e}")
    print(f"Please ensure regions.json exists in '{os.path.join(project_root, 'config')}/'.")
    sys.exit(1)
except json.JSONDecodeError as e:
    print(f"Error decoding JSON configuration file: {e}")
    print("Please check the format of regions.json.")
    sys.exit(1)
except Exception as e:
    print(f"An unexpected error occurred during configuration loading: {e}")
    print(traceback.format_exc())
    sys.exit(1)

# Ensure BASE_OUTPUT_DIR is valid after loading
if not BASE_OUTPUT_DIR or BASE_OUTPUT_DIR == ".":
     print("Error: BASE_OUTPUT_DIR is not properly configured (is None, empty, or '.'). Cannot proceed.")
     sys.exit(1)
print(f"Using Base Output Directory for data: {BASE_OUTPUT_DIR}")


# --- Constants and Date Ranges ---
# Hardcoded date ranges and fill cutoff date as in the original script
START_DATE_STR = '2019-01-01 00:00:00'
END_DATE_STR = '2026-12-31 23:00:00'
FILL_CUTOFF_DATE_STR = '2025-03-25 00:00:00'
DATE_COL = "date" # Consistent date column name

print(f"Using overall date range: {START_DATE_STR} to {END_DATE_STR}")
print(f"Using data fill cutoff date: {FILL_CUTOFF_DATE_STR}")


# --- DataSplitter Class Definition ---
class DataSplitter:
    def __init__(self,
                 region: str,
                 load_column: str,
                 start_date_str: str = START_DATE_STR, # Default uses global constant
                 end_date_str: str = END_DATE_STR,   # Default uses global constant
                 fill_cutoff_date_str: str = FILL_CUTOFF_DATE_STR, # Default uses global constant
                 base_dir: str = BASE_OUTPUT_DIR): # Default uses global constant
        """
        Initialize the DataSplitter using Parquet files.

        Args:
            region: Region name (e.g., 'ss', 'california').
            load_column: Load column name (e.g., 'CALIFORNIA_LOAD').
            start_date_str: Start of the time range (default: global START_DATE_STR).
            end_date_str: End of the time range (default: global END_DATE_STR).
            fill_cutoff_date_str: Cutoff date for filling data (default: global FILL_CUTOFF_DATE_STR).
            base_dir: Base directory for file paths (default: BASE_OUTPUT_DIR).
        """
        if not isinstance(region, str) or not region: raise ValueError("region must be a non-empty string.")
        if not isinstance(load_column, str) or not load_column: raise ValueError("load_column must be a non-empty string.")
        if not isinstance(base_dir, str) or not base_dir: raise ValueError("base_dir must be a non-empty string.")

        self.region = region.lower()
        self.load_column = load_column # Assumes load_column is correctly cased as in the data
        self.base_dir = base_dir
        self.final_dir = os.path.join(self.base_dir, self.region, "final")

        # Convert date strings to pandas Timestamps *once*
        try:
            self.start_date = pd.Timestamp(start_date_str)
            self.end_date = pd.Timestamp(end_date_str)
            self.fill_cutoff_date = pd.Timestamp(fill_cutoff_date_str)
        except ValueError as e:
             raise ValueError(f"Invalid date string format: {e}. Please use 'YYYY-MM-DD HH:MM:SS'.")


        # File paths for Parquet I/O
        self.input_file = os.path.join(self.final_dir, f"{self.region}_complete_finished.parquet")
        self.train_file = os.path.join(self.final_dir, "train.parquet")
        self.predict_file = os.path.join(self.final_dir, "predict.parquet")

        self.date_col = DATE_COL # Use the global constant

        # Ensure the final output directory exists
        os.makedirs(self.final_dir, exist_ok=True)


    def load_data(self) -> Optional[pd.DataFrame]:
        """Load and preprocess the input Parquet file."""
        if not os.path.exists(self.input_file):
            print(f"ERROR: Input Parquet file not found: {self.input_file}. Cannot split data.")
            return None

        print(f"Loading data from Parquet: {self.input_file}")
        df: Optional[pd.DataFrame] = None # Initialize DataFrame variable
        try:
            # Read from Parquet using pyarrow engine
            df = pd.read_parquet(self.input_file, engine='pyarrow', use_nullable_dtypes=True)

            print(f"  Loaded {len(df)} rows and {len(df.columns)} columns.")

            # Basic validation after load - Ensure 'date' column exists and attempt conversion if not datetime
            if self.date_col not in df.columns:
                print(f"ERROR: '{self.date_col}' column not found in input file.")
                return None

            if not pd.api.types.is_datetime64_any_dtype(df[self.date_col]):
                print(f"Warning: '{self.date_col}' column not datetime type, attempting conversion.")
                initial_rows = len(df)
                try:
                    # Use errors='coerce' during conversion from other types in the DataFrame
                    df[self.date_col] = pd.to_datetime(df[self.date_col], errors='coerce')
                    df.dropna(subset=[self.date_col], inplace=True) # Drop if conversion failed
                    if len(df) < initial_rows:
                         print(f"  Dropped {initial_rows - len(df)} rows with invalid dates during conversion.")
                    if not pd.api.types.is_datetime64_any_dtype(df[self.date_col]): # Check again
                        raise ValueError("Conversion to datetime failed")
                    print(f"  Successfully converted '{self.date_col}' column to datetime.")
                except Exception as conv_e:
                    print(f"ERROR: Could not convert '{self.date_col}' column to datetime: {conv_e}")
                    if df is not None: del df
                    gc.collect()
                    return None

            # Original sorting and dropping duplicates logic
            df.sort_values(self.date_col, inplace=True)
            rows_before_drop = len(df)
            df = df.drop_duplicates(subset=[self.date_col])
            rows_after_drop = len(df)
            if rows_before_drop > rows_after_drop:
                print(f"  Dropped {rows_before_drop - rows_after_drop} duplicate date rows.")
            print(f"  Rows after sorting and dropping duplicates: {len(df)}")

            if df.empty:
                 print("Warning: DataFrame is empty after cleaning and deduplication.")

            return df # Returns DataFrame (potentially empty)

        except Exception as e:
            print(f"ERROR: Failed to load or preprocess Parquet file {self.input_file}: {e}")
            traceback.print_exc()
            if df is not None: del df # Clean up if partially loaded
            gc.collect()
            return None # Indicate failure

    def reindex_to_full_range(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DatetimeIndex]:
        """Reindex DataFrame to a continuous hourly range defined by self.start_date and self.end_date."""
        if df is None or df.empty:
             print("Warning: Cannot reindex empty or None DataFrame.")
             # Return an empty dataframe and an empty index
             return pd.DataFrame(columns=[self.date_col]), pd.DatetimeIndex([])

        # Use 'h' for frequency to avoid FutureWarning
        full_index = pd.date_range(start=self.start_date, end=self.end_date, freq='h')
        print(f"Full index length: {len(full_index)} (from {self.start_date} to {self.end_date})")

        # Ensure timezone consistency before reindexing
        # Assume source data and desired index are timezone-naive
        if df[self.date_col].dt.tz is not None:
             print("Warning: Data has timezone. Making data timezone-naive.")
             df[self.date_col] = df[self.date_col].dt.tz_localize(None)
        if full_index.tz is not None:
             print("Warning: Full index has timezone. Making index timezone-naive.")
             full_index = full_index.tz_localize(None)


        df_reindexed = df.set_index(self.date_col).reindex(full_index).reset_index()
        df_reindexed = df_reindexed.rename(columns={'index': self.date_col}) # Rename the new index column back to date_col
        print(f"Rows after reindexing to full range: {len(df_reindexed)}")

        return df_reindexed, full_index # Return reindexed DF and the full index

    def fill_data_before_cutoff(self, df: pd.DataFrame) -> pd.DataFrame:
        """Forward and backfill all columns for data before self.fill_cutoff_date."""
        if df is None or df.empty:
             print("Skipping data fill for empty or None DataFrame.")
             return pd.DataFrame() # Return empty DataFrame

        print(f"Filling all columns for data before {self.fill_cutoff_date}...")

        # Ensure cutoff date timezone matches data's date column timezone (should be naive now)
        cutoff_date_to_compare = self.fill_cutoff_date.tz_localize(None) if df[self.date_col].dt.tz is None else self.fill_cutoff_date.tz_localize(df[self.date_col].dt.tz)

        before_cutoff_mask = df[self.date_col] < cutoff_date_to_compare
        # No need for after_cutoff_mask if just working on the 'before' part
        # after_cutoff_mask = df[self.date_col] >= cutoff_date_to_compare # Not used directly

        # Work on copies to avoid modifying slices directly and potential warnings
        before_df = df.loc[before_cutoff_mask].copy()
        after_df = df.loc[~before_cutoff_mask].copy() # Select rows NOT before cutoff

        if before_df.empty:
             print(f"  No data found before cutoff date {cutoff_date_to_compare}. Skipping fill.")
             # Just return the original dataframe as no filling was needed before cutoff
             return df

        print(f"  Applying ffill/bfill to {len(before_df)} rows before cutoff...")
        initial_nans = before_df.isna().sum().sum()
        # Infer object types before filling to avoid warnings
        before_df = before_df.infer_objects(copy=False)
        before_df = before_df.ffill().bfill()
        remaining_nans = before_df.isna().sum().sum()
        print(f"  Before {cutoff_date_to_compare.date()}: Filled {initial_nans - remaining_nans} NaNs across all columns with ffill/bfill.")

        if remaining_nans > 0:
            print(f"  Warning: {remaining_nans} NaNs remain in data before {cutoff_date_to_compare.date()} after ffill/bfill.")
            print("  Attempting linear interpolation on numeric columns...")
            # Infer object types before interpolating
            before_df = before_df.infer_objects(copy=False)
            # Interpolate only numeric columns to avoid errors
            numeric_cols = before_df.select_dtypes(include=np.number).columns
            # Use .loc for assignment to avoid SettingWithCopyWarning
            before_df.loc[:, numeric_cols] = before_df[numeric_cols].interpolate(method='linear', limit_direction='both') # Interpolate in both directions

            # Fill remaining NaNs after interpolation (edges)
            print("  Applying final ffill/bfill after interpolation...")
            # Infer types again just in case
            before_df = before_df.infer_objects(copy=False)
            before_df = before_df.ffill().bfill()
            final_nans = before_df.isna().sum().sum()

            if final_nans > 0:
                print(f"  Warning: {final_nans} NaNs *still* remain in data before {cutoff_date_to_compare.date()} after interpolation and final fill.")
                # Optional: Print columns with remaining NaNs
                cols_with_nans = before_df.columns[before_df.isna().any()].tolist()
                print(f"  Columns with remaining NaNs: {cols_with_nans}")
            else:
                 print(f"  All NaNs successfully filled in data before {cutoff_date_to_compare.date()}.")


        # Combine back
        # Ensure order before concatenation
        # Sorting by date guarantees correct order after concat
        df_filled = pd.concat([before_df, after_df], ignore_index=True)
        df_filled.sort_values(by=self.date_col, inplace=True, ignore_index=True) # Ensure correct order
        print(f"Data shape after filling: {df_filled.shape}")
        return df_filled


    def split_data(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Split data into training (non-NaN load) and prediction (NaN load) sets based on the load column."""
        if df is None or df.empty:
            print("Skipping split for empty or None DataFrame.")
            return pd.DataFrame(columns=[self.date_col]), pd.DataFrame(columns=[self.date_col]) # Return empty DFs

        # Ensure load column exists
        if self.load_column not in df.columns:
             print(f"ERROR: Load column '{self.load_column}' not found in DataFrame. Cannot split.")
             # Return empty dataframes but with *all* original columns + date
             # This preserves schema structure even if splitting failed.
             # Create empty DFs with columns from the input df
             empty_train = pd.DataFrame(columns=df.columns)
             empty_predict = pd.DataFrame(columns=df.columns)
             return empty_train, empty_predict


        # Find the first position where the load column is NaN
        # Using isna() and idxmax() is efficient
        nan_mask = df[self.load_column].isna()
        first_nan_index_label = nan_mask.idxmax() if nan_mask.any() else None

        # Determine the split point (index position)
        split_loc = len(df) # Default to splitting after the last row (all train)
        if first_nan_index_label is not None:
            try:
                 # Get the integer position of the first NaN index label
                 split_loc = df.index.get_loc(first_nan_index_label)
                 print(f"First NaN in '{self.load_column}' found at date {first_nan_index_label} (index position {split_loc}).")
            except KeyError:
                 # This could happen if index is not unique, or if df was not sorted
                 # Assuming df is sorted and index is unique after reindex step
                 print(f"Warning: Could not find index {first_nan_index_label} in DataFrame index. Falling back to iterative search.")
                 # Fallback to a less efficient search if get_loc fails unexpectedly
                 for i, val in enumerate(df[self.load_column].isna()):
                      if val:
                           split_loc = i
                           print(f"First NaN in '{self.load_column}' found iteratively at index position {split_loc} (date: {df.iloc[split_loc][self.date_col]}).")
                           break
                 else: # No NaN found during iterative search (shouldn't happen if nan_mask.any() was true)
                      split_loc = len(df)
                      print("Warning: NaN mask indicated NaN exists, but iterative search found none. Using entire dataset as train.")


        # Split the DataFrame using integer location
        # .iloc handles integer slicing correctly
        df_train = df.iloc[:split_loc].copy()
        df_predict = df.iloc[split_loc:].copy()

        # --- Post-Split Cleaning ---

        # Train data: Ensure no NaNs in the load column
        rows_before_drop = len(df_train)
        # Drop rows from train where the load column is NaN
        df_train = df_train.dropna(subset=[self.load_column])
        if len(df_train) < rows_before_drop:
            print(f"  Dropped {rows_before_drop - len(df_train)} rows with NaN in '{self.load_column}' from training data.")
        print(f"Training data rows: {len(df_train)}")


        # Prediction data: Fill NaNs in the load column with 0
        # This assumes the only NaNs in the prediction load column *should* be filled with 0.
        # This is often the case for future forecast periods where load is unknown.
        if self.load_column in df_predict.columns: # Ensure column exists
            initial_nan_predict = df_predict[self.load_column].isna().sum()
            if initial_nan_predict > 0:
                 print(f"  Filling {initial_nan_predict} NaN values in '{self.load_column}' in prediction data with 0.")
                 # Infer objects before fillna to avoid FutureWarning/errors
                 df_predict = df_predict.infer_objects(copy=False)
                 df_predict.loc[:, self.load_column] = df_predict[self.load_column].fillna(0) # Use .loc for assignment


        print(f"Prediction data rows: {len(df_predict)}")
        print("Split data into train and predict sets.")
        return df_train, df_predict

    # --- verify_timesteps method MODIFIED ---
    def verify_timesteps(self, df: pd.DataFrame, expected_range: pd.DatetimeIndex, data_type: str) -> pd.DataFrame:
        """Verify and fix missing timesteps in the dataset."""
        # Added checks for None inputs and empty dataframe
        if df is None:
            print(f"Warning: Cannot verify timesteps for {data_type} due to None DataFrame.")
            return pd.DataFrame(columns=[self.date_col]) # Return empty DF if input is None
        if df.empty:
             print(f"Note: {data_type} dataframe is empty, no timesteps to verify.")
             return df # Return empty dataframe

        # Ensure 'date' is the index for reindexing (or is the column we can set as index)
        if self.date_col not in df.columns:
            print(f"ERROR: '{self.date_col}' column missing in {data_type} dataframe for verification.")
            return df # Cannot proceed without date column
        # Ensure date column is datetime type before setting index
        if not pd.api.types.is_datetime64_any_dtype(df[self.date_col]):
             print(f"Warning: '{self.date_col}' column in {data_type} is not datetime, attempting conversion for verification.")
             df.loc[:, self.date_col] = pd.to_datetime(df[self.date_col], errors='coerce')
             df.dropna(subset=[self.date_col], inplace=True)
             if df.empty:
                 print(f"Warning: {data_type} dataframe empty after date conversion.")
                 return pd.DataFrame(columns=[self.date_col])

        df_indexed = df.set_index(self.date_col) # Set index temporarily

        # Ensure timezone compatibility (should be naive now after load/reindex)
        if df_indexed.index.tz != expected_range.tz:
             print(f"Warning: Mismatched timezones during {data_type} verification. Localizing index to None.")
             df_indexed.index = df_indexed.index.tz_localize(None)
             expected_range = expected_range.tz_localize(None)


        if not df_indexed.index.equals(expected_range): # Check if indices actually match
            print(f"Warning: Missing or mismatched timesteps in {data_type} data. Expected {len(expected_range)}, got {len(df_indexed)}. Reindexing...")
            # Reindex using the correct date range
            df_indexed = df_indexed.reindex(expected_range)
            df_indexed.index.name = self.date_col # Ensure index name is set


            # Fill potentially introduced NaNs after reindex
            print(f"  Forward/backward filling columns in {data_type} data after reindex...")
            # Infer types before filling
            df_indexed = df_indexed.infer_objects(copy=False)
            df_indexed = df_indexed.ffill().bfill()

            # Specific fill for prediction load column if needed after reindex introduces NaNs
            if data_type == "prediction" and self.load_column in df_indexed.columns:
                initial_nan_predict = df_indexed[self.load_column].isna().sum()
                if initial_nan_predict > 0:
                     print(f"  Filling {initial_nan_predict} NaN values in '{self.load_column}' in {data_type} data after reindex with 0.")
                     df_indexed.loc[:, self.load_column] = df_indexed[self.load_column].fillna(0) # Use .loc

            nans_after_fill = df_indexed.isna().sum().sum()
            if nans_after_fill > 0:
                 print(f"  Warning: {nans_after_fill} NaNs remain in {data_type} data after reindex and filling.")
                 # Optional: print columns with remaining NaNs
                 cols_with_rem_nans = df_indexed.columns[df_indexed.isna().any()].tolist()
                 print(f"  Columns with remaining NaNs in {data_type}: {cols_with_rem_nans}")


            print(f"  {data_type.capitalize()} data reindexed and filled to {len(df_indexed)} rows.")

        return df_indexed.reset_index() # Reset index before returning

    # --- save_data method MODIFIED ---
    def save_data(self, df_train: Optional[pd.DataFrame], df_predict: Optional[pd.DataFrame]) -> bool:
        """Save training and prediction datasets to Parquet. Returns True if at least one file was saved successfully."""
        save_successful_train = False
        save_successful_predict = False

        try:
            # Output directory created in __init__
            # os.makedirs(self.final_dir, exist_ok=True) # Redundant here

            if df_train is not None and not df_train.empty:
                print(f"Saving training data ({len(df_train)} rows) to {self.train_file}...")
                try:
                    # Optional: Round floats before saving
                    float_cols_train = df_train.select_dtypes(include=['float64', 'float32']).columns
                    if not float_cols_train.empty:
                         # Use .loc for assignment to avoid SettingWithCopyWarning
                         df_train.loc[:, float_cols_train] = df_train[float_cols_train].round(6)
                         print(f"  Rounded {len(float_cols_train)} columns in training data.")

                    df_train.to_parquet(self.train_file, index=False, engine='pyarrow')
                    print("  Training data saved successfully.")
                    save_successful_train = True
                except Exception as e:
                    print(f"ERROR: Failed to save training Parquet file {self.train_file}: {e}")
                    traceback.print_exc()
                    save_successful_train = False
            else:
                print("Skipping saving empty training data.")


            if df_predict is not None and not df_predict.empty:
                print(f"Saving prediction data ({len(df_predict)} rows) to {self.predict_file}...")
                try:
                    # Optional: Round floats before saving
                    float_cols_predict = df_predict.select_dtypes(include=['float64', 'float32']).columns
                    if not float_cols_predict.empty:
                         # Use .loc for assignment to avoid SettingWithCopyWarning
                         df_predict.loc[:, float_cols_predict] = df_predict[float_cols_predict].round(6)
                         print(f"  Rounded {len(float_cols_predict)} columns in prediction data.")

                    df_predict.to_parquet(self.predict_file, index=False, engine='pyarrow')
                    print("  Prediction data saved successfully.")
                    save_successful_predict = True
                except Exception as e:
                    print(f"ERROR: Failed to save prediction Parquet file {self.predict_file}: {e}")
                    traceback.print_exc()
                    save_successful_predict = False
            else:
                 print("Skipping saving empty prediction data.")

        except Exception as e:
             # Catch any unexpected error during the saving process itself
             print(f"ERROR: An unexpected error occurred during the overall save process: {e}")
             traceback.print_exc()
             # Individual save attempts already set their status, just ensure this error is logged
             pass # Don't overwrite individual success status unless it was already False


        # Return True if *at least one* file was successfully saved
        return save_successful_train or save_successful_predict


    # --- validate_output method MODIFIED ---
    def validate_output(self, df_train: Optional[pd.DataFrame], df_predict: Optional[pd.DataFrame], full_index: pd.DatetimeIndex):
        """Validate the output for NaNs and total row count."""
        print("\nValidating output data...")
        validation_passed = True

        # Validate Training Data
        if df_train is not None and not df_train.empty:
            print(f"  Validating Training data ({len(df_train)} rows)...")
            if self.load_column in df_train.columns:
                if df_train[self.load_column].isna().any():
                    print(f"  ERROR: NaNs remain in '{self.load_column}' in the training data!")
                    validation_passed = False
                else:
                    print(f"  '{self.load_column}' column in training data has no NaNs.")
            else:
                 print(f"  Warning: Load column '{self.load_column}' not found in training data for NaN validation.")

            # Basic timestep check for train set
            # Check if min/max dates cover expected range or if any steps are missing
            if self.date_col in df_train.columns and pd.api.types.is_datetime64_any_dtype(df_train[self.date_col]):
                 train_min_date = df_train[self.date_col].min()
                 train_max_date = df_train[self.date_col].max()
                 print(f"  Train date range: {train_min_date} to {train_max_date}")
                 expected_train_len = (train_max_date - train_min_date).total_seconds() / 3600 + 1 if train_min_date <= train_max_date else 0
                 if abs(len(df_train) - expected_train_len) > 1: # Allow for off-by-one due to calculation
                      print(f"  Warning: Training data row count ({len(df_train)}) doesn't match expected based on range ({expected_train_len}). Missing steps?")
                      validation_passed = False # Consider timestep mismatch a failure
                 else:
                      print("  Training data timestep count matches its date range.")
            else:
                 print("  Warning: Cannot validate training data timesteps, 'date' column missing or invalid.")


        elif df_train is None:
             print("  Training data is None, cannot validate.")
        else: # df_train is empty
             print("  Training data is empty, considered valid.")

        # Validate Prediction Data
        if df_predict is not None and not df_predict.empty:
            print(f"  Validating Prediction data ({len(df_predict)} rows)...")
            if self.load_column in df_predict.columns:
                 # NaNs in load column should have been filled with 0
                 if df_predict[self.load_column].isna().any():
                      print(f"  ERROR: NaNs remain in '{self.load_column}' in the prediction data!")
                      validation_passed = False
                 else:
                      print(f"  '{self.load_column}' column in prediction data has no NaNs (after filling).")
            else:
                 print(f"  Warning: Load column '{self.load_column}' not found in final prediction data for NaN validation.")

            # Basic timestep check for predict set
            if self.date_col in df_predict.columns and pd.api.types.is_datetime64_any_dtype(df_predict[self.date_col]):
                 predict_min_date = df_predict[self.date_col].min()
                 predict_max_date = df_predict[self.date_col].max()
                 print(f"  Prediction date range: {predict_min_date} to {predict_max_date}")
                 expected_predict_len = (predict_max_date - predict_min_date).total_seconds() / 3600 + 1 if predict_min_date <= predict_max_date else 0
                 if abs(len(df_predict) - expected_predict_len) > 1: # Allow for off-by-one
                      print(f"  Warning: Prediction data row count ({len(df_predict)}) doesn't match expected based on range ({expected_predict_len}). Missing steps?")
                      validation_passed = False # Consider timestep mismatch a failure
                 else:
                      print("  Prediction data timestep count matches its date range.")
            else:
                 print("  Warning: Cannot validate prediction data timesteps, 'date' column missing or invalid.")

        elif df_predict is None:
             print("  Prediction data is None, cannot validate.")
        else: # df_predict is empty
             print("  Prediction data is empty, considered valid.")


        # Total row count validation
        len_train = len(df_train) if df_train is not None else 0
        len_predict = len(df_predict) if df_predict is not None else 0
        total_rows = len_train + len_predict

        if total_rows != len(full_index):
            print(f"  ERROR: Final total rows ({total_rows}) do not match expected full index length ({len(full_index)}). Check split/reindex logic.")
            validation_passed = False # Total count mismatch is a failure
        else:
            print(f"  Validation Info: Total rows ({total_rows}) match expected full range.")

        if validation_passed:
             print("  Output validation completed: PASSED.")
        else:
             print("  Output validation completed: FAILED.")
             # Decide if you want to raise an error here
             # raise RuntimeError("Output validation failed.")


    def run(self):
        """Execute the full data splitting process."""
        print(f"\n--- Running Data Splitter for: {self.region.upper()} (Parquet) ---")
        df: Optional[pd.DataFrame] = None # Initialize input DataFrame variable
        df_reindexed: Optional[pd.DataFrame] = None
        df_filled: Optional[pd.DataFrame] = None
        df_train: Optional[pd.DataFrame] = None
        df_predict: Optional[pd.DataFrame] = None
        full_index: pd.DatetimeIndex = pd.DatetimeIndex([]) # Initialize empty index


        try:
            # 1. Load Data
            df = self.load_data()
            # df is None or DataFrame (potentially empty)

            if df is None or df.empty:
                print(f"ERROR: Failed to load data or loaded data is empty for {self.region}. Aborting.")
                return # Stop processing this region

            # 2. Reindex to full range
            df_reindexed, full_index = self.reindex_to_full_range(df)
            # df_reindexed is a DataFrame (potentially empty), full_index is DatetimeIndex

            if df_reindexed is None or df_reindexed.empty:
                 print(f"ERROR: Reindexing resulted in an empty DataFrame for {self.region}. Aborting.")
                 return # Stop processing this region

            # 3. Fill data before cutoff date
            df_filled = self.fill_data_before_cutoff(df_reindexed)
            # df_filled is a DataFrame (potentially empty)

            if df_filled is None or df_filled.empty:
                 print(f"ERROR: Filling data resulted in an empty DataFrame for {self.region}. Aborting.")
                 return # Stop processing this region


            # 4. Split data into train and predict sets
            df_train, df_predict = self.split_data(df_filled)
            # df_train, df_predict are DataFrames (potentially empty)

            # 5. Verify timesteps after splitting (this might reindex again if needed)
            # It's better to pass the expected range derived from the original full index
            # but filtered by the min/max dates *after* the split occurred.
            # Let's derive the expected ranges here based on the split data's actual range.
            expected_train_range = None
            if df_train is not None and not df_train.empty and self.date_col in df_train.columns:
                 train_min_date = df_train[self.date_col].min()
                 train_max_date = df_train[self.date_col].max()
                 # Ensure timezone consistency before creating range
                 if train_min_date.tz is not None: train_min_date = train_min_date.tz_localize(None)
                 if train_max_date.tz is not None: train_max_date = train_max_date.tz_localize(None)
                 expected_train_range = pd.date_range(start=train_min_date, end=train_max_date, freq='h', name=self.date_col).tz_localize(None)


            expected_predict_range = None
            if df_predict is not None and not df_predict.empty and self.date_col in df_predict.columns:
                 predict_min_date = df_predict[self.date_col].min()
                 predict_max_date = df_predict[self.date_col].max()
                  # Ensure timezone consistency before creating range
                 if predict_min_date.tz is not None: predict_min_date = predict_min_date.tz_localize(None)
                 if predict_max_date.tz is not None: predict_max_date = predict_max_date.tz_localize(None)
                 expected_predict_range = pd.date_range(start=predict_min_date, end=predict_max_date, freq='h', name=self.date_col).tz_localize(None)


            df_train = self.verify_timesteps(df_train, expected_train_range, "training")
            df_predict = self.verify_timesteps(df_predict, expected_predict_range, "prediction")

            # 6. Save Data
            save_successful = self.save_data(df_train, df_predict) # Saves Parquet, returns bool

            # 7. Validate Output
            # Pass the DFs *after* verify_timesteps (which might have reindexed them)
            # Pass the original full_index for total count check
            self.validate_output(df_train, df_predict, full_index) # Validation logic is file-format agnostic


            if save_successful:
                print(f"\n--- Completed processing successfully for region: {self.region} ---")
            else:
                 print(f"\n--- Processing for region {self.region} completed, but no files were saved or save failed. ---")


        except Exception as e:
             print(f"ERROR: An unhandled exception occurred during run for {self.region}: {e}")
             traceback.print_exc()
        finally:
             # Explicit memory cleanup regardless of success or failure
             # Check if variables are defined and not None before deleting
             if 'df' in locals() and df is not None: del df
             if 'df_reindexed' in locals() and df_reindexed is not None: del df_reindexed
             if 'df_filled' in locals() and df_filled is not None: del df_filled
             if 'df_train' in locals() and df_train is not None: del df_train
             if 'df_predict' in locals() and df_predict is not None: del df_predict
             # No need to delete full_index, it's just an index object
             gc.collect() # Run garbage collection
             print(f"\n--- Data Splitter finished for {self.region} ---")


# --- Main Execution Block ---
if __name__ == "__main__":
    # This block runs only when the script is executed directly

    print("===== Starting Data Splitting Process =====")

    # Configuration and Constants loading are handled at the top of the script.
    # BASE_OUTPUT_DIR, regions, load_column_mapping, START_DATE_STR, END_DATE_STR,
    # FILL_CUTOFF_DATE_STR, DATE_COL are available.

    if not regions:
        print("No regions loaded from config/regions.json. Nothing to process.")
        sys.exit(0)

    # BASE_OUTPUT_DIR validity is checked after loading config at the top

    regions_with_errors = []
    # Also check if regions is actually a dict with keys as expected
    if not isinstance(regions, dict) or not all(isinstance(k, str) for k in regions.keys()):
        print(f"Error: Expected regions config to be a dictionary with string keys, but got {type(regions)}. Exiting.")
        sys.exit(1)

    print(f"Found {len(regions)} regions in config: {list(regions.keys())}")
    print(f"Base Output Directory for data: {BASE_OUTPUT_DIR}")
    print(f"Splitting range: {START_DATE_STR} to {END_DATE_STR}")
    print(f"Fill cutoff date: {FILL_CUTOFF_DATE_STR}")


    # Process each region
    for region_name in regions.keys():
        print(f"\n{'='*20} Processing Region: {region_name.upper()} {'='*20}")
        splitter: Optional[DataSplitter] = None # Initialize variable

        try:
            # Get the load column name for the region
            load_column = load_column_mapping.get(region_name)
            if not load_column:
                 print(f"Warning: No load column mapping found for region '{region_name}'. Skipping this region.")
                 regions_with_errors.append(f"{region_name} (No Load Column Mapping)")
                 continue # Skip to the next region

            print(f"Using load column: {load_column}")

            # Instantiate the splitter, passing loaded variables/constants
            splitter = DataSplitter(
                region=region_name,
                load_column=load_column,
                start_date_str=START_DATE_STR,
                end_date_str=END_DATE_STR,
                fill_cutoff_date_str=FILL_CUTOFF_DATE_STR,
                base_dir=BASE_OUTPUT_DIR
            )

            # Execute the splitting process
            splitter.run()

        except ValueError as e:
             # Handle specific initialization errors from __init__ (e.g., bad date string)
             error_msg = f"{region_name.upper()} (Config/Init Error)"
             print(f"\n---!!! {error_msg}: {e} !!!---")
             traceback.print_exc()
             regions_with_errors.append(error_msg)
        except Exception as e:
             # Catch any other critical unhandled errors per region
             error_msg = f"{region_name.upper()} (Critical Unhandled Error)"
             print(f"\n---!!! {error_msg}: {e} !!!---")
             traceback.print_exc()
             regions_with_errors.append(error_msg)
        finally:
             # Explicitly delete splitter object if it was created
             if splitter is not None:
                  del splitter
             gc.collect()


    print("\n" + "="*60)
    print("--- Data Splitting Process Complete ---")
    if regions_with_errors:
        print(f"Regions encountering errors or skipped ({len(regions_with_errors)}):")
        for region_err in regions_with_errors: print(f"  - {region_err}")
    else:
        print("All configured regions processed successfully.")
    print("="*60)