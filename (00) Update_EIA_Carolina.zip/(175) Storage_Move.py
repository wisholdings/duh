import pandas as pd
import os
import shutil
from datetime import datetime

# Define paths
storage_consolidated_dir = r'D:\EIA_STACK\storage_consolidated'
pricing_rl_dir = r'D:\EIA_STACK\Pricing_RL'

print("="*60)
print("COPYING CONSOLIDATED STORAGE FILES TO WEATHER FOLDERS")
print("="*60)

# Define the mapping between storage files and their destination regions
# Both SOUTHCENTRAL files will go to the SOUTHCENTRAL folder
region_mappings = {
    'PACIFIC': ['pacific_consolidated_storage.csv'],
    'MOUNTAIN': ['mountain_consolidated_storage.csv'],
    'MIDWEST': ['midwest_consolidated_storage.csv'],
    'EAST': ['east_consolidated_storage.csv'],
    'SOUTHCENTRAL': ['southcentral_nonsalt_storage.csv'],
    'SOUTHCENTRAL_SALTS': ['southcentral_salt_storage.csv'],

}

# Track success/failure
successful_copies = []
failed_copies = []
not_found = []

# Process each region
for region, storage_filenames in region_mappings.items():
    print(f"\n{'='*50}")
    print(f"Processing {region}")
    print(f"{'='*50}")
    
    # Destination folder
    dest_folder = os.path.join(pricing_rl_dir, region)
    
    # Process each file for this region
    for storage_filename in storage_filenames:
        # Source path
        source_path = os.path.join(storage_consolidated_dir, storage_filename)
        
        # Destination path
        dest_path = os.path.join(dest_folder, storage_filename)
        
        # Check if source file exists
        if not os.path.exists(source_path):
            print(f"  ✗ Source file not found: {storage_filename}")
            not_found.append((region, storage_filename))
            continue
        
        try:
            # Create destination folder if it doesn't exist
            if not os.path.exists(dest_folder):
                os.makedirs(dest_folder)
                print(f"  Created folder: {dest_folder}")
            
            # Copy the file
            shutil.copy2(source_path, dest_path)
            print(f"  ✓ Copied: {storage_filename}")
            print(f"    From: {source_path}")
            print(f"    To:   {dest_path}")
            
            # Verify the copy by checking file size
            source_size = os.path.getsize(source_path)
            dest_size = os.path.getsize(dest_path)
            if source_size == dest_size:
                print(f"    File size verified: {source_size:,} bytes")
                successful_copies.append((region, storage_filename))
            else:
                print(f"    ⚠️ Warning: File sizes don't match!")
                print(f"    Source: {source_size:,} bytes, Destination: {dest_size:,} bytes")
                
        except Exception as e:
            print(f"  ✗ Error copying {storage_filename}: {str(e)}")
            failed_copies.append((region, storage_filename, str(e)))

# Final summary
print("\n" + "="*60)
print("FINAL SUMMARY")
print("="*60)

if successful_copies:
    print(f"\n✓ Successfully copied: {len(successful_copies)} files")
    for region, filename in successful_copies:
        print(f"  • {region}: {filename}")

if not_found:
    print(f"\n⚠️ Files not found: {len(not_found)}")
    for region, filename in not_found:
        print(f"  • {region}: {filename}")
    print("\n  Note: Check if the storage_consolidated files exist with these exact names.")
    print("  Looking in:", storage_consolidated_dir)
    
    # List actual files in the directory
    if os.path.exists(storage_consolidated_dir):
        actual_files = [f for f in os.listdir(storage_consolidated_dir) if f.endswith('.csv')]
        if actual_files:
            print("\n  Actual CSV files found in storage_consolidated:")
            for f in actual_files:
                print(f"    - {f}")

if failed_copies:
    print(f"\n✗ Failed to copy: {len(failed_copies)} files")
    for region, filename, error in failed_copies:
        print(f"  • {region}: {filename} - Error: {error}")

print("\nExpected final structure:")
print(f"{pricing_rl_dir}")
for region, storage_files in region_mappings.items():
    print(f"├── {region}/")
    print(f"│   ├── weather_{region}.csv")
    for storage_file in storage_files:
        if any(r == region and f == storage_file for r, f in successful_copies):
            print(f"│   ├── {storage_file} ✓")
        else:
            print(f"│   ├── {storage_file} ✗")

print("\n" + "="*60)
print("Process completed!")
print("="*60)