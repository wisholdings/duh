import sys
from datetime import datetime, timedelta
from sqlalchemy import create_engine, text

# --- Configuration ---
# Database connection string for the specified server
DB_CONNECTION_STRING = (
)

# List of tables to process
TABLE_NAMES = [
    "PRODUCTION_AECO_NORMALS_PDD_FORECAST",
    "PRODUCTION_CONUS_NORMALS_PDD_FORECAST",
    "PRODUCTION_EAST_NORMALS_PDD_FORECAST",
    "PRODUCTION_GASCONSEAST_NORMALS_PDD_FORECAST",
    "PRODUCTION_GASCONSWEST_NORMALS_PDD_FORECAST",
    "PRODUCTION_GASPRODUCING_NORMALS_PDD_FORECAST",
    "PRODUCTION_MIDWEST_NORMALS_PDD_FORECAST",
    "PRODUCTION_MOUNTAIN_NORMALS_PDD_FORECAST",
    "PRODUCTION_PACIFIC_NORMALS_PDD_FORECAST",
    "PRODUCTION_SOUTHCENTRAL_NORMALS_PDD_FORECAST",
    "PRODUCTION_SOUTHEAST_NORMALS_PDD_FORECAST",
]

def delete_old_forecasts_from_tables():
    """
    Connects to the database and deletes rows from a list of tables
    where 'Date_Modified' is older than 3 days from the current date.
    """
    print("--- Starting Bulk Deletion Process ---")

    # Calculate the cutoff date (3 days ago from today)
    cutoff_date = datetime.now().date() - timedelta(days=3)
    print(f"-> Deleting all records with a 'Date_Modified' older than: {cutoff_date.strftime('%Y-%m-%d')}")

    engine = None
    total_deleted_rows = 0
    failed_tables = []

    try:
        print("\n[1] Establishing database connection...")
        engine = create_engine(DB_CONNECTION_STRING)

        with engine.connect() as connection:
            print("    ✓ Connection successful.")

            for table_name in TABLE_NAMES:
                print(f"\n--- Processing table: {table_name} ---")
                try:
                    # Begin a transaction for each table to ensure atomicity
                    with connection.begin() as transaction:
                        # Prepare the DELETE statement
                        delete_statement = text(
                            f"DELETE FROM [dbo].[{table_name}] WHERE [Date_Modified] < :cutoff_date"
                        )

                        # Execute the statement
                        result = connection.execute(delete_statement, {"cutoff_date": cutoff_date})
                        
                        deleted_count = result.rowcount
                        total_deleted_rows += deleted_count
                        
                        print(f"    ✓ Deletion complete. {deleted_count} row(s) were deleted.")
                        # Transaction is automatically committed on successful exit of 'with' block
                
                except Exception as e:
                    print(f"    ✗ ERROR processing table '{table_name}': {e}", file=sys.stderr)
                    failed_tables.append(table_name)
                    # Transaction is automatically rolled back on exception

    except Exception as e:
        print(f"\n--- ✗ A critical error occurred during connection or setup ---", file=sys.stderr)
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1) # Exit with an error code
    finally:
        if engine:
            engine.dispose()
            print("\n[Final] Database connection closed.")

    # --- Final Summary ---
    print("\n" + "="*50)
    print("--- Bulk Deletion Process Finished ---")
    print(f"Total rows deleted across all tables: {total_deleted_rows}")
    
    if failed_tables:
        print(f"\nWarning: {len(failed_tables)} table(s) failed to process:")
        for table in failed_tables:
            print(f"  - {table}")
        sys.exit(1) # Exit with an error code if any table failed
    else:
        print("\nAll tables processed successfully.")


if __name__ == "__main__":
    delete_old_forecasts_from_tables()