# =============================================================================
# ADDITIONAL DATA PIPELINE: Storage, Sector Burns, and Supply/Demand
# =============================================================================
import pandas as pd
import numpy as np
from sqlalchemy import create_engine, text
from datetime import datetime, timedelta
import os
import sys
import time

# --- CONFIGURATION ---
AZURE_DB_CONNECTION_STRING = (
)

# Output folders
OUTPUT_BASE_PATH = r"D:\EIA_STACK\Pricing_RL"
AGGREGATE_PATH = os.path.join(OUTPUT_BASE_PATH, "AGGREGATE")
REGIONAL_PATH = os.path.join(OUTPUT_BASE_PATH, "REGIONAL")

# Choose which forecasts to use
USE_HYBRID_FORECASTS = True  # Set to True for hybrid, False for NHITS

# =============================================================================
# DATABASE CONNECTION FUNCTIONS
# =============================================================================
def ensure_directories():
    """Create output directories if they don't exist"""
    for path in [AGGREGATE_PATH, REGIONAL_PATH]:
        if not os.path.exists(path):
            os.makedirs(path)
            print(f"✓ Created directory: {path}")
        else:
            print(f"✓ Directory exists: {path}")

def get_db_engine():
    """Initializes the database connection engine."""
    try:
        engine = create_engine(
            AZURE_DB_CONNECTION_STRING,
            echo=False,
            pool_recycle=1800,
            pool_pre_ping=True,
            connect_args={
                'timeout': 30,
                'login_timeout': 30
            }
        )
        with engine.connect() as connection:
            connection.execute(text("SELECT 1")).scalar()
        return engine
    except Exception as e:
        print(f"✗ Database Connection Error: {e}")
        return None

def execute_query_with_retry(query, max_retries=3):
    """Execute a query with retry logic for connection issues."""
    engine = get_db_engine()
    if not engine:
        return pd.DataFrame()

    for attempt in range(max_retries):
        try:
            df = pd.read_sql_query(query, engine)
            return df
        except Exception as e:
            if attempt < max_retries - 1:
                print(f"⚠ Database query failed (attempt {attempt + 1}/{max_retries}), retrying...")
                time.sleep(2)
            else:
                print(f"✗ Database query failed after {max_retries} attempts: {e}")
                return pd.DataFrame()
    
    engine.dispose()

# =============================================================================
# EIA STORAGE DATA
# =============================================================================
def load_eia_storage_data():
    """Loads EIA storage data - LOWER_48 only."""
    print("\n📊 Loading EIA Storage Data...")
    query = text("""
        SELECT 
            CAST([date] AS DATE) as Date, 
            [LOWER_48] as storage_lower_48_bcf
        FROM [dbo].[EIA_STORAGE_WIDE]
        WHERE [LOWER_48] IS NOT NULL
        ORDER BY Date ASC
    """)
    df = execute_query_with_retry(query)
    if not df.empty:
        df['Date'] = pd.to_datetime(df['Date'])
        
        # Save to AGGREGATE folder
        output_file = os.path.join(AGGREGATE_PATH, "eia_storage_lower48.csv")
        df.to_csv(output_file, index=False)
        print(f"  ✓ Saved {len(df)} records to {output_file}")
        
        return df
    else:
        print(f"  ✗ No EIA storage data found")
        return pd.DataFrame()

# =============================================================================
# SECTOR GAS BURNS DATA - BOTH AGGREGATE AND REGIONAL
# =============================================================================
def load_sector_gas_burns_aggregate():
    """Loads gas burns data for non-power sectors, summed to L48 totals (AGGREGATE)."""
    
    # Determine which tables to use based on configuration
    model_type = "HYBRID" if USE_HYBRID_FORECASTS else "NHITS"
    print(f"\n📊 Loading {model_type} forecast data (non-power sectors - AGGREGATE)...")
    
    if USE_HYBRID_FORECASTS:
        data_sources = {
            "residential": {"table": "FORECAST_RESIDENTIAL_BURNS_REGIONAL_HYBRID"},
            "commercial": {"table": "FORECAST_COMMERCIAL_BURNS_REGIONAL_HYBRID"},
            "industrial": {"table": "FORECAST_INDUSTRIAL_BURNS_REGIONAL_HYBRID"}
        }
    else:
        data_sources = {
            "residential": {"table": "FORECAST_RESIDENTIAL_BURNS_REGIONAL_ST"},
            "commercial": {"table": "FORECAST_COMMERCIAL_BURNS_REGIONAL_ST"},
            "industrial": {"table": "FORECAST_INDUSTRIAL_BURNS_REGIONAL_ST"}
        }

    for data_type, config in data_sources.items():
        # Check if table exists first
        check_query = text(f"""
            SELECT COUNT(*) as count
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_NAME = '{config['table']}'
        """)
        
        result = execute_query_with_retry(check_query)
        
        if result.empty or result.iloc[0]['count'] == 0:
            print(f"  ⚠ Table {config['table']} not found, trying fallback...")
            fallback_table = config['table'].replace('_HYBRID', '_ST')
            config['table'] = fallback_table
        
        # Query to sum all regions into L48 total
        query = text(f"""
            WITH LatestDailyForecast AS (
                SELECT 
                    CAST([datetime] AS DATE) as Date, 
                    [california_bcf] + [carolina_bcf] + [central_bcf] + [florida_bcf] +
                    [midatlantic_bcf] + [midwest_bcf] + [newengland_bcf] + [newyork_bcf] +
                    [northwest_bcf] + [southeast_bcf] + [southwest_bcf] + [tennessee_bcf] + 
                    [texas_bcf] as {data_type}_bcf,
                    [date_published],
                    ROW_NUMBER() OVER(PARTITION BY CAST([datetime] AS DATE) 
                                    ORDER BY [date_published] DESC) as rn
                FROM [dbo].[{config['table']}]
            )
            SELECT Date, {data_type}_bcf
            FROM LatestDailyForecast 
            WHERE rn = 1
            ORDER BY Date ASC
        """)
        
        df = execute_query_with_retry(query)
        if not df.empty:
            df['Date'] = pd.to_datetime(df['Date'])
            
            # Save to AGGREGATE folder
            output_file = os.path.join(AGGREGATE_PATH, f"{data_type}_burns_aggregate.csv")
            df.to_csv(output_file, index=False)
            print(f"  ✓ Saved {data_type}: {len(df)} records to {output_file}")
        else:
            print(f"  ✗ No data found for {data_type}")

def load_sector_gas_burns_regional():
    """Loads gas burns data for non-power sectors by region (REGIONAL)."""
    
    model_type = "HYBRID" if USE_HYBRID_FORECASTS else "NHITS"
    print(f"\n📊 Loading {model_type} forecast data (non-power sectors - REGIONAL)...")
    
    if USE_HYBRID_FORECASTS:
        data_sources = {
            "residential": {"table": "FORECAST_RESIDENTIAL_BURNS_REGIONAL_HYBRID"},
            "commercial": {"table": "FORECAST_COMMERCIAL_BURNS_REGIONAL_HYBRID"},
            "industrial": {"table": "FORECAST_INDUSTRIAL_BURNS_REGIONAL_HYBRID"}
        }
    else:
        data_sources = {
            "residential": {"table": "FORECAST_RESIDENTIAL_BURNS_REGIONAL_ST"},
            "commercial": {"table": "FORECAST_COMMERCIAL_BURNS_REGIONAL_ST"},
            "industrial": {"table": "FORECAST_INDUSTRIAL_BURNS_REGIONAL_ST"}
        }

    # Regional columns mapping
    region_columns = {
        'california': 'california_bcf',
        'carolina': 'carolina_bcf',
        'central': 'central_bcf',
        'florida': 'florida_bcf',
        'midatlantic': 'midatlantic_bcf',
        'midwest': 'midwest_bcf',
        'newengland': 'newengland_bcf',
        'newyork': 'newyork_bcf',
        'northwest': 'northwest_bcf',
        'southeast': 'southeast_bcf',
        'southwest': 'southwest_bcf',
        'tennessee': 'tennessee_bcf',
        'texas': 'texas_bcf'
    }

    for data_type, config in data_sources.items():
        # Check if table exists
        check_query = text(f"""
            SELECT COUNT(*) as count
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_NAME = '{config['table']}'
        """)
        
        result = execute_query_with_retry(check_query)
        
        if result.empty or result.iloc[0]['count'] == 0:
            print(f"  ⚠ Table {config['table']} not found, trying fallback...")
            fallback_table = config['table'].replace('_HYBRID', '_ST')
            config['table'] = fallback_table
        
        # Query to get all regional data
        query = text(f"""
            WITH LatestDailyForecast AS (
                SELECT 
                    CAST([datetime] AS DATE) as Date,
                    [california_bcf],
                    [carolina_bcf],
                    [central_bcf],
                    [florida_bcf],
                    [midatlantic_bcf],
                    [midwest_bcf],
                    [newengland_bcf],
                    [newyork_bcf],
                    [northwest_bcf],
                    [southeast_bcf],
                    [southwest_bcf],
                    [tennessee_bcf],
                    [texas_bcf],
                    [date_published],
                    ROW_NUMBER() OVER(PARTITION BY CAST([datetime] AS DATE) 
                                    ORDER BY [date_published] DESC) as rn
                FROM [dbo].[{config['table']}]
            )
            SELECT *
            FROM LatestDailyForecast 
            WHERE rn = 1
            ORDER BY Date ASC
        """)
        
        df = execute_query_with_retry(query)
        if not df.empty:
            df['Date'] = pd.to_datetime(df['Date'])
            
            # Save each region as a separate file
            for region_name, column_name in region_columns.items():
                if column_name in df.columns:
                    region_df = df[['Date', column_name]].copy()
                    region_df.columns = ['Date', f'{data_type}_bcf']
                    
                    # Create filename
                    output_file = os.path.join(REGIONAL_PATH, f"{data_type}_{region_name}.csv")
                    region_df.to_csv(output_file, index=False)
                    print(f"    ✓ Saved {data_type}_{region_name}: {len(region_df)} records")
            
            # Also save a combined file with all regions
            df_combined = df[['Date'] + list(region_columns.values())]
            output_file_all = os.path.join(REGIONAL_PATH, f"{data_type}_all_regions.csv")
            df_combined.to_csv(output_file_all, index=False)
            print(f"  ✓ Saved {data_type} all regions combined to {output_file_all}")
            
        else:
            print(f"  ✗ No data found for {data_type}")

# =============================================================================
# SUPPLY AND DEMAND DATA
# =============================================================================
def load_supply_demand_data():
    """Loads supply and demand data - saves to AGGREGATE folder."""
    print("\n📊 Loading Supply and Demand Data...")
    
    # Historical
    query_hist = text("""
        SELECT 
            CAST([Date] AS DATE) as Date,
            AVG([LNG_IMPORTS]) / 1000.0 as LNG_IMPORTS_BCF,
            AVG([LNG_EXPORTS]) / 1000.0 as LNG_EXPORTS_BCF,
            AVG([CAD_NET_FLOW]) / 1000.0 as CAD_NET_FLOW_BCF,
            AVG([MEX_EXPORTS]) / 1000.0 as MEX_EXPORTS_BCF
        FROM [dbo].[PRODUCTION_PIPE_CAD_MEX_LEASE_L48_CRITERION_HISTORY]
        WHERE [Date] IS NOT NULL 
        GROUP BY CAST([Date] AS DATE)
        ORDER BY Date ASC
    """)
    df_hist = execute_query_with_retry(query_hist)

    # Forecast
    query_forecast = text("""
        WITH LatestForecast AS (
            SELECT 
                CAST([Date] AS DATE) as Date,
                [LNG_EXPORTS] / 1000.0 as LNG_EXPORTS_BCF,
                [CAD_NET_FLOW] / 1000.0 as CAD_NET_FLOW_BCF,
                [MEX_EXPORTS] / 1000.0 as MEX_EXPORTS_BCF,
                [Date_Published],
                ROW_NUMBER() OVER(PARTITION BY CAST([Date] AS DATE) 
                                ORDER BY [Date_Published] DESC) as rn
            FROM [dbo].[PRODUCTION_PIPE_CAD_MEX_LEASE_L48_CRITERION_ST]
            WHERE [Date] IS NOT NULL
        )
        SELECT Date, LNG_EXPORTS_BCF, CAD_NET_FLOW_BCF, MEX_EXPORTS_BCF
        FROM LatestForecast
        WHERE rn = 1
        ORDER BY Date ASC
    """)
    df_forecast = execute_query_with_retry(query_forecast)

    # Save historical data
    if not df_hist.empty:
        df_hist['Date'] = pd.to_datetime(df_hist['Date'])
        output_file = os.path.join(AGGREGATE_PATH, "supply_demand_historical.csv")
        df_hist.to_csv(output_file, index=False)
        print(f"  ✓ Saved historical supply/demand: {len(df_hist)} records to {output_file}")

    # Save forecast data
    if not df_forecast.empty:
        df_forecast['Date'] = pd.to_datetime(df_forecast['Date'])
        output_file = os.path.join(AGGREGATE_PATH, "supply_demand_forecast.csv")
        df_forecast.to_csv(output_file, index=False)
        print(f"  ✓ Saved forecast supply/demand: {len(df_forecast)} records to {output_file}")

    # Combine historical and forecast (use forecast for future dates)
    if not df_hist.empty and not df_forecast.empty:
        today = pd.Timestamp.now().normalize()
        
        # Use historical up to today
        df_combined = df_hist[df_hist['Date'] <= today].copy()
        
        # Add forecast for future dates
        df_future = df_forecast[df_forecast['Date'] > today]
        
        # For LNG_IMPORTS, we only have historical, so we'll forward fill if needed
        if 'LNG_IMPORTS_BCF' not in df_future.columns:
            df_future['LNG_IMPORTS_BCF'] = 0  # or use last historical value
        
        df_combined = pd.concat([df_combined, df_future], ignore_index=True)
        df_combined = df_combined.sort_values('Date')
        
        output_file = os.path.join(AGGREGATE_PATH, "supply_demand_combined.csv")
        df_combined.to_csv(output_file, index=False)
        print(f"  ✓ Saved combined supply/demand: {len(df_combined)} records to {output_file}")

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the additional data pipeline"""
    model_type = "HYBRID" if USE_HYBRID_FORECASTS else "NHITS"
    
    print("\n" + "=" * 80)
    print("ADDITIONAL DATA PIPELINE")
    print(f"Processing Storage, Sector Burns ({model_type}), and Supply/Demand")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    
    try:
        # Create directories
        ensure_directories()
        
        print("\n" + "=" * 60)
        print("DOWNLOADING STORAGE DATA")
        print("=" * 60)
        load_eia_storage_data()
        
        print("\n" + "=" * 60)
        print("DOWNLOADING SECTOR GAS BURNS - AGGREGATE")
        print("=" * 60)
        load_sector_gas_burns_aggregate()
        
        print("\n" + "=" * 60)
        print("DOWNLOADING SECTOR GAS BURNS - REGIONAL")
        print("=" * 60)
        load_sector_gas_burns_regional()
        
        print("\n" + "=" * 60)
        print("DOWNLOADING SUPPLY & DEMAND DATA")
        print("=" * 60)
        load_supply_demand_data()
        
        print("\n" + "=" * 80)
        print("✅ ADDITIONAL DATA PIPELINE COMPLETE!")
        print("=" * 80)
        
        # List files created
        print("\nFiles created in AGGREGATE folder:")
        aggregate_files = [f for f in os.listdir(AGGREGATE_PATH) if f.endswith('.csv')]
        for file in sorted(aggregate_files):
            size = os.path.getsize(os.path.join(AGGREGATE_PATH, file)) / 1024  # KB
            print(f"  - {file} ({size:.1f} KB)")
        
        print("\nFiles created in REGIONAL folder:")
        regional_files = [f for f in os.listdir(REGIONAL_PATH) if f.endswith('.csv')]
        
        # Group by sector
        sectors = ['residential', 'commercial', 'industrial']
        for sector in sectors:
            sector_files = [f for f in regional_files if f.startswith(sector)]
            if sector_files:
                print(f"\n  {sector.capitalize()} files:")
                for file in sorted(sector_files):
                    size = os.path.getsize(os.path.join(REGIONAL_PATH, file)) / 1024
                    print(f"    - {file} ({size:.1f} KB)")
        
        # Other regional files
        other_files = [f for f in regional_files if not any(f.startswith(s) for s in sectors)]
        if other_files:
            print(f"\n  Other regional files:")
            for file in sorted(other_files):
                size = os.path.getsize(os.path.join(REGIONAL_PATH, file)) / 1024
                print(f"    - {file} ({size:.1f} KB)")
        
        print(f"\nTotal files created: {len(aggregate_files) + len(regional_files)}")
        print(f"Completed: {datetime.now()}")
        
    except Exception as e:
        print(f"\n✗ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()