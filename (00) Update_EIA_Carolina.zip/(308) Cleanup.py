import pandas as pd
import os
import traceback

def organize_capacity_data_by_region():
    """
    Reads multiple capacity CSV files from a source folder, disaggregates them
    into separate files for each region and fuel type, and then deletes the
    original source file upon successful completion.
    """
    # --- Configuration ---
    source_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update' 
    output_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    
    print(f"Starting data organization process.")
    print(f"Source folder: '{os.path.abspath(source_folder)}'")
    print(f"Output folder: '{os.path.abspath(output_folder)}'")

    os.makedirs(output_folder, exist_ok=True)
    print(f"Ensured output directory '{output_folder}' exists.")

    files_to_process = [
        'monthly_avg_capacity_nuclear.csv',
        'monthly_avg_capacity_naturalgas.csv',
        'monthly_avg_capacity_hydroelectric.csv',
        'monthly_avg_capacity_geothermal.csv',
        'monthly_avg_capacity_coal.csv',
        'monthly_avg_capacity_biomass.csv',
        'monthly_avg_capacity_batteries.csv',
        'monthly_avg_capacity_wind.csv',
        'monthly_avg_capacity_solar.csv',
        'monthly_avg_capacity_solar_batteries.csv',
        'monthly_avg_capacity_pumped_storage.csv',
        'monthly_avg_capacity_other.csv',
        'monthly_avg_capacity_oil.csv'
    ]

    # --- Processing Loop ---
    for filename in files_to_process:
        file_path = os.path.join(source_folder, filename)
        
        if not os.path.exists(file_path):
            print(f"\n[Info] File not found, skipping: {filename}")
            continue
            
        print(f"\n--- Processing file: {filename} ---")
        
        try:
            df = pd.read_csv(file_path, parse_dates=['Datetime'])
            
            for column_name in df.columns:
                if column_name == 'Datetime':
                    continue
                
                parts = column_name.split('_')
                region = parts[0]
                
                try:
                    capacity_index = -1
                    for i, part in enumerate(parts):
                        if 'capacity' in part.lower():
                            capacity_index = i
                            break
                    
                    if capacity_index == -1:
                         print(f"  [Warning] 'Capacity' not found in column name '{column_name}'. Skipping.")
                         continue

                    fuel_type_parts = parts[capacity_index + 1:]
                    fuel_type = '_'.join(fuel_type_parts)
                except (ValueError, IndexError):
                    print(f"  [Warning] Could not parse column name '{column_name}'. Skipping.")
                    continue

                region_folder_path = os.path.join(output_folder, region)
                os.makedirs(region_folder_path, exist_ok=True)
                
                regional_df = df[['Datetime', column_name]].copy()
                regional_df.rename(columns={column_name: 'Capacity_MW'}, inplace=True)
                
                output_filename = f"{fuel_type}.csv"
                output_path = os.path.join(region_folder_path, output_filename)
                
                regional_df.to_csv(output_path, index=False)
                print(f"  - Saved data for '{region}' -> '{fuel_type}' to {output_path}")

            # --- Delete the original file after successful processing ---
            os.remove(file_path)
            print(f"  ✓ Successfully processed and deleted original file: {filename}")

        except Exception as e:
            print(f"  [ERROR] Failed to process {filename}. The file will not be deleted. Reason: {e}")
            traceback.print_exc()

    print("\n--- Data organization complete! ---")
    print(f"All disaggregated files have been saved and source files have been removed.")


# --- Run the script ---
if __name__ == "__main__":
    organize_capacity_data_by_region()