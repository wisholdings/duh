import os
import sys
import logging
import pandas as pd
from datetime import date, datetime, timedelta
import calendar
import httpx
import ssl
import traceback

# ==============================================================================
# WARNING: MONKEY-PATCH TO DISABLE SSL VERIFICATION
# This is insecure and should only be used in a trusted environment for debugging.
# ==============================================================================
_original_httpx_client_init = httpx.Client.__init__

def new_httpx_client_init(self, *args, **kwargs):
    kwargs['verify'] = False
    _original_httpx_client_init(self, *args, **kwargs)

httpx.Client.__init__ = new_httpx_client_init
# ==============================================================================

# --- Configuration ---
try:
    from synmax.hyperion.v4 import HyperionApiClient
except ImportError:
    print("Error: synmax.hyperion.v4 not found.")
    print("Please ensure the Synmax Hyperion API client is installed.")
    sys.exit(1)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

ACCESS_TOKEN = ""
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"
START_DATE = '2022-01-01'
END_DATE = date.today().strftime('%Y-%m-%d')
FORECAST_END_DATE = (date.today() + timedelta(days=700)).strftime('%Y-%m-%d')

# --- Data Fetching and Processing Functions ---

def expand_monthly_to_daily(df, value_column='DRY_GAS_BCF_DAY'):
    """Expands monthly data to daily data."""
    if df.empty:
        return df
    
    daily_records = []
    for _, row in df.iterrows():
        month_date = pd.to_datetime(row['DATE'])
        year, month = month_date.year, month_date.month
        days_in_month = calendar.monthrange(year, month)[1]
        daily_value = row[value_column]
        
        for day in range(1, days_in_month + 1):
            daily_record = row.copy()
            daily_record['DATE'] = datetime(year, month, day)
            daily_record[value_column] = daily_value
            daily_records.append(daily_record)
            
    return pd.DataFrame(daily_records)

def fetch_daily_production(client):
    """Fetches historical daily production data from the Synmax API."""
    try:
        logging.info(f"Fetching historical production from {START_DATE} to {END_DATE}...")
        result = client.daily_production()
        data_list = list(result)
        
        if not data_list:
            logging.warning("No historical records found.")
            return pd.DataFrame()
            
        df = pd.DataFrame(data_list)
        df['date_prod'] = pd.to_datetime(df['date_prod'])
        df = df[(df['date_prod'] >= pd.to_datetime(START_DATE)) & (df['date_prod'] <= pd.to_datetime(END_DATE))]
        
        rename_map = {
            'date_prod': 'DATE',
            'prod_dry_gas_bcf_day': 'DRY_GAS_BCF_DAY',
            'region_natgas': 'REGION'
        }
        df.rename(columns=rename_map, inplace=True)
        df['DATA_SOURCE'] = 'historical'
        logging.info(f"✓ Fetched {len(df)} historical records.")
        return df[['DATE', 'DRY_GAS_BCF_DAY', 'REGION', 'DATA_SOURCE']]
        
    except Exception as e:
        logging.error(f"Error in fetch_daily_production: {e}")
        return pd.DataFrame()

def fetch_production_forecast(client):
    """Fetches long-term production forecast data from the Synmax API."""
    try:
        today = date.today()
        date_min = today.strftime('%Y-%m-%d')
        logging.info(f"Fetching forecast production from {date_min} to {FORECAST_END_DATE}...")
        
        if hasattr(client, 'long_term_forecast'):
            result = client.long_term_forecast(date_prod_min=date_min, date_prod_max=FORECAST_END_DATE)
        elif hasattr(client, 'longtermforecast'):
            result = client.longtermforecast(date_prod_min=date_min, date_prod_max=FORECAST_END_DATE)
        else:
            logging.warning("longtermforecast method not found on client.")
            return pd.DataFrame()
            
        data_list = list(result)
        if not data_list:
            logging.warning("No forecast records found.")
            return pd.DataFrame()
            
        df = pd.DataFrame(data_list)
        rename_map = {
            'date_prod': 'DATE',
            'prod_dry_gas_bcf_day': 'DRY_GAS_BCF_DAY',
            'region_natgas': 'REGION'
        }
        df.rename(columns=rename_map, inplace=True)
        
        df['DATE'] = pd.to_datetime(df['DATE'])
        if df['DATE'].dt.day.nunique() == 1 and df['DATE'].dt.day.unique()[0] == 1:
            logging.info("Forecast is monthly, expanding to daily...")
            df = expand_monthly_to_daily(df)
            
        df = df[df['DATE'] > pd.Timestamp(today)]
        df['DATA_SOURCE'] = 'forecast'
        logging.info(f"✓ Fetched and processed {len(df)} forecast records.")
        return df[['DATE', 'DRY_GAS_BCF_DAY', 'REGION', 'DATA_SOURCE']]
        
    except Exception as e:
        logging.error(f"Error in fetch_production_forecast: {e}")
        return pd.DataFrame()

# --- Main Execution ---
def main():
    """
    Main execution function to download Synmax data and save it by region.
    """
    print("\n" + "="*80)
    print("   DOWNLOADING SYNMAX REGIONAL PRODUCTION DATA (HISTORICAL & FORECAST)")
    print("="*80)
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    logging.info(f"Output Directory: {os.path.abspath(OUTPUT_DIR)}")
    
    try:
        logging.info("Initializing Synmax API client...")
        client = HyperionApiClient(access_token=ACCESS_TOKEN)
        
        df_historical = fetch_daily_production(client)
        df_forecast = fetch_production_forecast(client)
        
        if df_historical.empty and df_forecast.empty:
            logging.error("No data retrieved from API. Exiting.")
            return
            
        df_combined = pd.concat([df_historical, df_forecast], ignore_index=True)
        logging.info(f"Combined total records: {len(df_combined)}")
        
        # Aggregate data by region and date
        df_agg = df_combined.groupby(['DATE', 'REGION', 'DATA_SOURCE']).agg(
            DRY_GAS_BCF_DAY=('DRY_GAS_BCF_DAY', 'sum')
        ).reset_index()
        
        # Save a separate file for each region
        regions = df_agg['REGION'].unique()
        logging.info(f"\nFound {len(regions)} regions to save: {', '.join(regions)}")
        
        for region in regions:
            region_df = df_agg[df_agg['REGION'] == region].copy()
            region_df.sort_values('DATE', inplace=True)
            
            # Ensure continuous dates for the region
            date_range = pd.date_range(start=region_df['DATE'].min(), end=region_df['DATE'].max(), freq='D')
            df_continuous = pd.DataFrame({'DATE': date_range})
            df_final = pd.merge(df_continuous, region_df, on='DATE', how='left')
            
            # Forward-fill any gaps
            df_final[['REGION', 'DATA_SOURCE']] = df_final[['REGION', 'DATA_SOURCE']].ffill()
            df_final['DRY_GAS_BCF_DAY'] = df_final['DRY_GAS_BCF_DAY'].ffill().bfill()
            
            output_filename = f"synmax_production_{region.lower()}.csv"
            output_filepath = os.path.join(OUTPUT_DIR, output_filename)
            
            df_final[['DATE', 'DRY_GAS_BCF_DAY', 'DATA_SOURCE']].to_csv(output_filepath, index=False)
            logging.info(f"✓ Saved {len(df_final)} records to: {output_filepath}")

    except Exception as e:
        logging.error(f"A critical error occurred in the main process: {e}")
        traceback.print_exc()

    print("\n" + "="*80)
    print("✅ Script completed!")
    print("=*8G0")

if __name__ == "__main__":
    main()