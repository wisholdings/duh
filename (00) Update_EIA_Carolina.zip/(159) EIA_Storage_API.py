import os
import sys
import pandas as pd
import traceback
import time
from datetime import datetime
import requests
import warnings

# --- Configuration Loading ---
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    from config.settings import BASE_OUTPUT_DIR
    print(f"Loaded BASE_OUTPUT_DIR from config: {BASE_OUTPUT_DIR}")
except (ImportError, NameError, FileNotFoundError) as e:
    print(f"Could not import BASE_OUTPUT_DIR from config.settings ({e}). Using default.")
    BASE_OUTPUT_DIR = "D:\\EIA_STACK"
    print(f"Using default BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")

# --- EIA API Configuration ---
API_KEY = "" # Replace with your actual EIA API Key
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

def fetch_granular_storage_data(api_key):
    """
    Fetches weekly granular natural gas storage data from the EIA API.
    """
    api_url = "https://api.eia.gov/v2/natural-gas/stor/wkly/data/"
    offset = 0
    limit = 5000
    combined_df = pd.DataFrame()
    today_date_str = datetime.now().strftime("%Y-%m-%d")
    print("  Fetching granular weekly storage data from EIA...")

    while True:
        params = {
            "api_key": api_key,
            "frequency": "weekly",
            "data[0]": "value",
            "start": "2019-01-01",
            "end": today_date_str,
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "offset": offset,
            "length": limit
        }
        try:
            response = requests.get(api_url, params=params, verify=False, timeout=90)
            if response.status_code == 200:
                data = response.json()
                page_data = data.get('response', {}).get('data', [])
                if not page_data:
                    print("    No more data found from API.")
                    break
                df = pd.DataFrame(page_data)
                print(f"    Fetched {len(df)} records (offset {offset})...")
                combined_df = pd.concat([combined_df, df], ignore_index=True)
                offset += limit
            else:
                print(f"    ERROR: Failed to fetch data. Status: {response.status_code}, Response: {response.text}")
                break
        except Exception as e:
             print(f"    ERROR: An unexpected error occurred during fetch: {e}")
             traceback.print_exc()
             break

    print(f"  Finished fetching. Total rows fetched: {len(combined_df)}")
    return combined_df

# --- Main Processing Logic ---
def main():
    print("\n==========================================================")
    print("=== Starting EIA Granular Natural Gas Storage Processing ===")
    print("==========================================================")
    start_time = time.time()

    try:
        # --- 1. Fetch Data ---
        raw_df = fetch_granular_storage_data(API_KEY)
        if raw_df.empty:
            print("No data was fetched from the API. Exiting.")
            sys.exit(1)

        print("\nAPI Response Columns:", raw_df.columns.tolist())

        # --- 2. Process Data by Renaming Correct Columns ---
        print("\nProcessing and cleaning data...")

        # --- CORRECTED LOGIC ---
        # Rename the columns provided by the API to match our database schema.
        # 'duoarea' is the area code (R31, R33, etc.)
        # 'process' is the process code (SNO, SWO, etc.)
        df_processed = raw_df.rename(columns={
            'period': 'datetime',
            'duoarea': 'area_id',
            'process': 'process_id',
            'series-description': 'series_description'
        })
        # --- END CORRECTED LOGIC ---
        
        # Define the final set of columns needed for the database table
        final_columns = ['datetime', 'area_id', 'process_id', 'series_description', 'value', 'units']

        # Check that all the columns we need now exist after renaming
        for col in final_columns:
            if col not in df_processed.columns:
                print(f"FATAL: Expected column '{col}' not found in the dataframe after processing.")
                print(f"Available columns: {df_processed.columns.tolist()}")
                sys.exit(1)

        # Select only the columns we need for the final output
        df_to_save = df_processed[final_columns]

        # Convert data types for database compatibility
        df_to_save['datetime'] = pd.to_datetime(df_to_save['datetime'], errors='coerce')
        df_to_save['value'] = pd.to_numeric(df_to_save['value'], errors='coerce')
        df_to_save.dropna(subset=['datetime', 'value', 'area_id', 'process_id'], inplace=True)

        # --- 3. Save to CSV ---
        output_dir = os.path.join(BASE_OUTPUT_DIR, "granular_storage")
        os.makedirs(output_dir, exist_ok=True)
        output_filepath = os.path.join(output_dir, "eia_granular_natural_gas_storage.csv")

        print(f"\nSaving processed data to: {output_filepath}")
        df_to_save.to_csv(output_filepath, index=False, float_format='%.3f')
        print("  Successfully saved data.")

    except Exception as e:
        print(f"\nFATAL ERROR during processing: {e}")
        traceback.print_exc()
        sys.exit(1)

    finally:
        end_time = time.time()
        print("\n=============================================")
        print(f"Total execution time: {end_time - start_time:.2f} seconds.")
        print("=============================================")
        sys.exit(0)

if __name__ == "__main__":
    main()