# =============================================================================
# REORGANIZED PIPELINE: Separate AGGREGATE and REGIONAL Data Streams
# =============================================================================
import pandas as pd
import numpy as np
from sqlalchemy import create_engine, text
from datetime import datetime, timedelta
import os
import sys
import time
import calendar

# --- CONFIGURATION ---
AZURE_DB_CONNECTION_STRING = (
)

# Base paths
PIPE_LEASE_FILES_PATH = r"D:\EIA_STACK\us_total\final"
OUTPUT_BASE_PATH = r"D:\EIA_STACK\Pricing_RL"

# Output folders
AGGREGATE_PATH = os.path.join(OUTPUT_BASE_PATH, "AGGREGATE")
REGIONAL_PATH = os.path.join(OUTPUT_BASE_PATH, "REGIONAL")

# Synmax configuration
SYNMAX_ACCESS_TOKEN = (
    ""
    ""
    ""
    ""
    ""
    ""
)

# Date ranges
START_DATE = '2022-01-01'
END_DATE = datetime.now().strftime('%Y-%m-%d')
FORECAST_END_DATE = (datetime.now() + timedelta(days=700)).strftime('%Y-%m-%d')

# =============================================================================
# DATABASE CONNECTION FUNCTIONS
# =============================================================================
def ensure_directories():
    """Create output directories if they don't exist"""
    for path in [AGGREGATE_PATH, REGIONAL_PATH]:
        if not os.path.exists(path):
            os.makedirs(path)
            print(f"✓ Created directory: {path}")
        else:
            print(f"✓ Directory exists: {path}")

def get_db_engine():
    """Initializes the database connection engine."""
    try:
        engine = create_engine(
            AZURE_DB_CONNECTION_STRING,
            echo=False,
            pool_recycle=1800,
            pool_pre_ping=True,
            connect_args={
                'timeout': 30,
                'login_timeout': 30
            }
        )
        with engine.connect() as connection:
            connection.execute(text("SELECT 1")).scalar()
        return engine
    except Exception as e:
        print(f"✗ Database Connection Error: {e}")
        return None

def execute_query_with_retry(query, max_retries=3):
    """Execute a query with retry logic for connection issues."""
    engine = get_db_engine()
    if not engine:
        return pd.DataFrame()

    for attempt in range(max_retries):
        try:
            df = pd.read_sql_query(query, engine)
            return df
        except Exception as e:
            if attempt < max_retries - 1:
                print(f"⚠ Database query failed (attempt {attempt + 1}/{max_retries}), retrying...")
                time.sleep(2)
            else:
                print(f"✗ Database query failed after {max_retries} attempts: {e}")
                return pd.DataFrame()
    
    engine.dispose()

# =============================================================================
# AGGREGATE DATA FUNCTIONS
# =============================================================================
def download_aggregate_power_burns():
    """Copy L48 aggregate power burns from local file"""
    print("\n📊 Copying AGGREGATE Power Burns from local file...")
    
    source_file = r"D:\EIA_STACK\power_burns_daily_small_model.csv"
    
    try:
        # Read the source file
        df = pd.read_csv(source_file)
        
        # Ensure Date column is datetime
        if 'Date' in df.columns:
            df['Date'] = pd.to_datetime(df['Date'])
        elif 'date' in df.columns:
            df.rename(columns={'date': 'Date'}, inplace=True)
            df['Date'] = pd.to_datetime(df['Date'])
        elif 'datetime' in df.columns:
            df.rename(columns={'datetime': 'Date'}, inplace=True)
            df['Date'] = pd.to_datetime(df['Date'])
        df['L48_Power_Burns'] = df['L48_Power_Burns'] / 1000
        # Copy to AGGREGATE folder
        output_file = os.path.join(AGGREGATE_PATH, "power_burns_aggregate.csv")
        df.to_csv(output_file, index=False)
        print(f"  ✓ Copied {len(df)} records from {source_file}")
        print(f"  ✓ Saved to {output_file}")
        return df
    except FileNotFoundError:
        print(f"  ✗ Source file not found: {source_file}")
        return pd.DataFrame()
    except Exception as e:
        print(f"  ✗ Error reading power burns file: {e}")
        return pd.DataFrame()

def download_aggregate_synmax():
    """Download SYNMAX production data (aggregate)"""
    print("\n📊 Downloading AGGREGATE SYNMAX Production...")
    query = text("""
        WITH LatestDaily AS (
            SELECT 
                CAST([Date] AS DATE) as Date, 
                [Gas_Value] as production_bcf,
                [Date_Published],
                ROW_NUMBER() OVER(PARTITION BY CAST([Date] AS DATE) 
                                ORDER BY [Date_Published] DESC) as rn
            FROM [dbo].[PRODUCTION_SYNMAX_DAILY_PRODUCTION]
            WHERE [Gas_Value] IS NOT NULL
        )
        SELECT Date, production_bcf
        FROM LatestDaily
        WHERE rn = 1
        ORDER BY Date ASC
    """)
    
    df = execute_query_with_retry(query)
    if not df.empty:
        df['Date'] = pd.to_datetime(df['Date'])
        output_file = os.path.join(AGGREGATE_PATH, "synmax_production_aggregate.csv")
        df.to_csv(output_file, index=False)
        print(f"  ✓ Saved {len(df)} records to {output_file}")
        return df
    else:
        print(f"  ✗ No SYNMAX data found")
        return pd.DataFrame()

def download_pipe_lease_losses():
    """Download pipe and lease losses - save to both AGGREGATE and REGIONAL"""
    print("\n📊 Processing Pipe and Lease Losses...")
    
    try:
        # Load pipe losses
        pipe_file = os.path.join(PIPE_LEASE_FILES_PATH, "natural_gas_pipe_losses_us_total.csv")
        lease_file = os.path.join(PIPE_LEASE_FILES_PATH, "natural_gas_lease_losses_us_total.csv")

        # Process pipe losses
        df_pipe = pd.read_csv(pipe_file)
        df_pipe['datetime'] = pd.to_datetime(df_pipe['datetime'])
        df_pipe['days_in_month'] = df_pipe['datetime'].dt.days_in_month
        df_pipe['pipe_loss_bcf'] = (df_pipe['US_Pipe_Other_Losses_MMcf'] / 1000) / df_pipe['days_in_month']

        # Process lease losses
        df_lease = pd.read_csv(lease_file)
        df_lease['datetime'] = pd.to_datetime(df_lease['datetime'])
        df_lease['days_in_month'] = df_lease['datetime'].dt.days_in_month
        df_lease['lease_loss_bcf'] = (df_lease['US_Lease_Other_Losses_MMcf'] / 1000) / df_lease['days_in_month']

        # Find last available dates
        last_pipe_date = df_pipe['datetime'].max()
        last_lease_date = df_lease['datetime'].max()
        
        print(f"  Last pipe loss data: {last_pipe_date.strftime('%Y-%m')}")
        print(f"  Last lease loss data: {last_lease_date.strftime('%Y-%m')}")

        # Create month mapping for forward filling
        last_year_pipe = df_pipe[df_pipe['datetime'] >= (last_pipe_date - pd.DateOffset(months=12))]
        last_year_lease = df_lease[df_lease['datetime'] >= (last_lease_date - pd.DateOffset(months=12))]
        
        pipe_month_map = {}
        for _, row in last_year_pipe.iterrows():
            pipe_month_map[row['datetime'].month] = row['pipe_loss_bcf']
        
        lease_month_map = {}
        for _, row in last_year_lease.iterrows():
            lease_month_map[row['datetime'].month] = row['lease_loss_bcf']

        # Expand to daily
        all_dates = []
        all_pipe_losses = []
        for _, row in df_pipe.iterrows():
            month_dates = pd.date_range(start=row['datetime'].replace(day=1), 
                                       periods=row['days_in_month'], 
                                       freq='D')
            all_dates.extend(month_dates)
            all_pipe_losses.extend([row['pipe_loss_bcf']] * len(month_dates))
        
        df_pipe_daily = pd.DataFrame({'Date': all_dates, 'pipe_loss_bcf': all_pipe_losses})
        
        all_dates = []
        all_lease_losses = []
        for _, row in df_lease.iterrows():
            month_dates = pd.date_range(start=row['datetime'].replace(day=1), 
                                       periods=row['days_in_month'], 
                                       freq='D')
            all_dates.extend(month_dates)
            all_lease_losses.extend([row['lease_loss_bcf']] * len(month_dates))
        
        df_lease_daily = pd.DataFrame({'Date': all_dates, 'lease_plant_loss_bcf': all_lease_losses})
        
        # Merge
        losses_daily = pd.merge(df_pipe_daily, df_lease_daily, on='Date', how='outer')
        losses_daily = losses_daily.sort_values('Date').drop_duplicates(subset=['Date'])
        
        # Forward fill to 2026
        max_existing_date = losses_daily['Date'].max()
        future_end_date = pd.Timestamp('2026-12-31')
        
        if max_existing_date < future_end_date:
            future_dates = pd.date_range(start=max_existing_date + timedelta(days=1),
                                        end=future_end_date, freq='D')
            
            future_data = []
            for date in future_dates:
                month = date.month
                future_data.append({
                    'Date': date,
                    'pipe_loss_bcf': pipe_month_map.get(month, 0),
                    'lease_plant_loss_bcf': lease_month_map.get(month, 0)
                })
            
            df_future = pd.DataFrame(future_data)
            losses_daily = pd.concat([losses_daily, df_future], ignore_index=True)

        # Save to both AGGREGATE and REGIONAL
        for folder in [AGGREGATE_PATH, REGIONAL_PATH]:
            output_file = os.path.join(folder, "pipe_lease_losses.csv")
            losses_daily.to_csv(output_file, index=False)
            print(f"  ✓ Saved {len(losses_daily)} records to {output_file}")

        return losses_daily

    except Exception as e:
        print(f"✗ Error loading pipe/lease losses: {e}")
        return pd.DataFrame()

# =============================================================================
# REGIONAL DATA FUNCTIONS - SYNMAX API
# =============================================================================
def download_regional_synmax_data():
    """Download regional SYNMAX data using API"""
    print("\n📊 Downloading REGIONAL SYNMAX Production Data...")
    
    try:
        from synmax.hyperion.v4 import HyperionApiClient
    except ImportError:
        print("  ✗ Synmax API client not installed. Skipping regional SYNMAX data.")
        return None
    
    try:
        # Initialize client
        client = HyperionApiClient(access_token=SYNMAX_ACCESS_TOKEN)
        
        # Fetch historical daily production
        print("  Fetching historical production...")
        result = client.daily_production()
        
        data_list = []
        for record in result:
            data_list.append(record)
        
        if not data_list:
            print("  ✗ No historical records found")
            return None
        
        # Convert to DataFrame
        df_hist = pd.DataFrame(data_list)
        
        # Filter date range
        df_hist['date_prod'] = pd.to_datetime(df_hist['date_prod'])
        start_dt = pd.to_datetime(START_DATE)
        end_dt = pd.to_datetime(END_DATE)
        df_hist = df_hist[(df_hist['date_prod'] >= start_dt) & (df_hist['date_prod'] <= end_dt)]
        
        print(f"  ✓ Loaded {len(df_hist)} historical records")
        
        # Fetch forecast
        print("  Fetching forecast production...")
        today = datetime.now().date()
        
        if hasattr(client, 'long_term_forecast'):
            result = client.long_term_forecast(
                date_prod_min=today.strftime('%Y-%m-%d'),
                date_prod_max=FORECAST_END_DATE
            )
        elif hasattr(client, 'longtermforecast'):
            result = client.longtermforecast(
                date_prod_min=today.strftime('%Y-%m-%d'),
                date_prod_max=FORECAST_END_DATE
            )
        else:
            print("  ✗ Forecast method not found")
            result = []
        
        forecast_list = []
        for record in result:
            forecast_list.append(record)
        
        if forecast_list:
            df_forecast = pd.DataFrame(forecast_list)
            df_forecast['date_prod'] = pd.to_datetime(df_forecast['date_prod'])
            
            # Check if monthly and expand if needed
            dates = df_forecast['date_prod'].dt.day.unique()
            if len(dates) == 1 and dates[0] == 1:
                print("  Expanding monthly forecast to daily...")
                df_forecast = expand_monthly_to_daily(df_forecast)
            
            df_forecast = df_forecast[df_forecast['date_prod'] > pd.Timestamp(today)]
            print(f"  ✓ Loaded {len(df_forecast)} forecast records")
        else:
            print("  ✗ No forecast records found")
            df_forecast = pd.DataFrame()
        
        # Combine historical and forecast
        if not df_hist.empty and not df_forecast.empty:
            df_combined = pd.concat([df_hist, df_forecast], ignore_index=True)
        elif not df_hist.empty:
            df_combined = df_hist
        else:
            df_combined = df_forecast if not df_forecast.empty else pd.DataFrame()
        
        if df_combined.empty:
            print("  ✗ No data to save")
            return None
        
        # Rename columns for consistency
        df_combined.rename(columns={
            'date_prod': 'Date',
            'prod_dry_gas_bcf_day': 'DRY_GAS_BCF_DAY',
            'region_natgas': 'REGION',
            'sub_region_natgas': 'SUB_REGION'
        }, inplace=True)
        
        # Save each region as a separate CSV file
        regions = df_combined['REGION'].unique()
        print(f"  Found {len(regions)} regions to save separately")
        
        for region in regions:
            # Filter data for this region
            region_df = df_combined[df_combined['REGION'] == region].copy()
            
            # Aggregate sub-regions if they exist
            if 'SUB_REGION' in region_df.columns:
                region_agg = region_df.groupby(['Date', 'REGION']).agg({
                    'DRY_GAS_BCF_DAY': 'sum'
                }).reset_index()
            else:
                region_agg = region_df[['Date', 'REGION', 'DRY_GAS_BCF_DAY']].copy()
            
            # Sort by date
            region_agg = region_agg.sort_values('Date')
            
            # Create filename (clean the region name for filesystem)
            clean_region_name = region.lower().replace(' ', '_').replace('/', '_')
            output_file = os.path.join(REGIONAL_PATH, f"synmax_{clean_region_name}.csv")
            
            # Save to CSV
            region_agg.to_csv(output_file, index=False)
            print(f"    ✓ Saved {region}: {len(region_agg)} records to synmax_{clean_region_name}.csv")
        
        # Also save a combined file with all regions (optional - can remove if not needed)
        df_all_regions = df_combined.groupby(['Date', 'REGION']).agg({
            'DRY_GAS_BCF_DAY': 'sum'
        }).reset_index()
        
        output_file_all = os.path.join(REGIONAL_PATH, "synmax_all_regions_summary.csv")
        df_all_regions.to_csv(output_file_all, index=False)
        print(f"  ✓ Saved summary of all regions to {output_file_all}")
        
        return df_combined
        
    except Exception as e:
        print(f"  ✗ Error downloading regional SYNMAX data: {e}")
        import traceback
        traceback.print_exc()
        return None

def expand_monthly_to_daily(df, value_column='prod_dry_gas_bcf_day'):
    """Expand monthly data to daily"""
    if df.empty:
        return df
    
    daily_records = []
    
    for _, row in df.iterrows():
        month_date = pd.to_datetime(row['date_prod'])
        year = month_date.year
        month = month_date.month
        days_in_month = calendar.monthrange(year, month)[1]
        
        for day in range(1, days_in_month + 1):
            daily_record = row.copy()
            daily_record['date_prod'] = datetime(year, month, day)
            daily_records.append(daily_record)
    
    return pd.DataFrame(daily_records)

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the reorganized pipeline"""
    print("\n" + "=" * 80)
    print("REORGANIZED DATA PIPELINE")
    print("Separating AGGREGATE and REGIONAL Data Streams")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    
    try:
        # Create directories
        ensure_directories()
        
        print("\n" + "=" * 60)
        print("DOWNLOADING AGGREGATE DATA")
        print("=" * 60)
        
        # Download aggregate data
        download_aggregate_power_burns()
        download_aggregate_synmax()
        
        print("\n" + "=" * 60)
        print("DOWNLOADING SHARED DATA (AGGREGATE & REGIONAL)")
        print("=" * 60)
        
        # Download data that goes to both folders
        download_pipe_lease_losses()
        
        print("\n" + "=" * 60)
        print("DOWNLOADING REGIONAL DATA")
        print("=" * 60)
        
        # Download regional SYNMAX data
        download_regional_synmax_data()
        
        print("\n" + "=" * 80)
        print("✅ PIPELINE COMPLETE!")
        print("=" * 80)
        print(f"\nData saved to:")
        print(f"  AGGREGATE: {AGGREGATE_PATH}")
        print(f"  REGIONAL: {REGIONAL_PATH}")
        
        # List files created
        print("\nFiles created:")
        print("\nAGGREGATE folder:")
        for file in os.listdir(AGGREGATE_PATH):
            if file.endswith('.csv'):
                print(f"  - {file}")
        
        print("\nREGIONAL folder:")
        for file in os.listdir(REGIONAL_PATH):
            if file.endswith('.csv'):
                print(f"  - {file}")
        
        print(f"\nCompleted: {datetime.now()}")
        
    except Exception as e:
        print(f"\n✗ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()