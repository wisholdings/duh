import pandas as pd
import os
from datetime import datetime

# Define the directory path
midwest_dir = r'D:\EIA_STACK\Pricing_RL\MIDWEST'
output_dir = midwest_dir  # Save in the same directory

print("="*60)
print("OUTER MERGE OF ALL CSV FILES IN MIDWEST FOLDER")
print("="*60)
print(f"Directory: {midwest_dir}")
print("="*60)

# List of all CSV files to merge
csv_files = [
    'midwest_consolidated_storage.csv',
    'central_commercial.csv',
    'central_industrial.csv',
    'central_power_burn_prediction.csv',
    'central_residential_final_hybrid_forecast.csv',
    'synmax_production_with_forecast.csv',
    'midwest_commercial.csv',
    'midwest_industrial.csv',
    'midwest_power_burn_prediction.csv',
    'midwest_residential_final_hybrid_forecast.csv',
    'weather_MIDWEST.csv'
]

# Initialize merged dataframe with None
merged_df = None
successful_merges = []
failed_files = []
date_column_issues = []

print("\nStarting merge process...\n")

for i, csv_file in enumerate(csv_files, 1):
    file_path = os.path.join(midwest_dir, csv_file)
    
    print(f"[{i}/{len(csv_files)}] Processing: {csv_file}")
    
    try:
        # Read the CSV file
        df = pd.read_csv(file_path)
        
        # Check for date-related columns (case-insensitive)
        date_col = None
        for col in df.columns:
            if col.lower() in ['date', 'datetime', 'eff_gas_day']:
                date_col = col
                break
        
        if date_col is None:
            print(f"  ⚠️ Warning: No date/datetime column found. Available columns: {list(df.columns)[:5]}...")
            date_column_issues.append((csv_file, list(df.columns)))
            continue
        
        # Standardize date column name to 'date'
        if date_col != 'date':
            df = df.rename(columns={date_col: 'date'})
            print(f"  → Renamed '{date_col}' column to 'date'")
        
        # Convert date to datetime for consistency
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        
        # Check for invalid dates
        invalid_dates = df['date'].isna().sum()
        if invalid_dates > 0:
            print(f"  ⚠️ Found {invalid_dates} invalid date entries")
        
        # Drop rows with invalid dates for the merge
        df = df.dropna(subset=['date'])
        
        # Add prefix to columns (except date) to identify source
        # Extract a meaningful prefix from filename
        prefix = csv_file.replace('.csv', '').replace('_', '')[:15]  # Limit prefix length
        columns_to_rename = {col: f"{prefix}_{col}" for col in df.columns if col != 'date'}
        df = df.rename(columns=columns_to_rename)
        
        print(f"  ✓ Loaded: {len(df)} rows, {len(df.columns)} columns")
        
        if merged_df is None:
            # First file becomes the base
            merged_df = df
            print(f"  → Base dataframe initialized with {len(merged_df)} rows")
        else:
            # OUTER merge with existing dataframe
            rows_before = len(merged_df)
            unique_dates_before = merged_df['date'].nunique()
            
            merged_df = pd.merge(merged_df, df, on='date', how='outer')
            
            rows_after = len(merged_df)
            unique_dates_after = merged_df['date'].nunique()
            
            print(f"  → Merged: {rows_before} rows → {rows_after} rows (added {rows_after - rows_before} rows)")
            print(f"    Unique dates: {unique_dates_before} → {unique_dates_after}")
        
        successful_merges.append(csv_file)
        
    except FileNotFoundError:
        print(f"  ✗ File not found: {file_path}")
        failed_files.append((csv_file, "File not found"))
    except Exception as e:
        print(f"  ✗ Error reading {csv_file}: {str(e)}")
        failed_files.append((csv_file, str(e)))

print("\n" + "="*60)
print("MERGE SUMMARY")
print("="*60)

if merged_df is not None and len(merged_df) > 0:
    # Sort by date for better readability
    merged_df = merged_df.sort_values('date')
    
    print(f"\n✓ Successfully merged {len(successful_merges)} files")
    print(f"  Final dataframe shape: {merged_df.shape[0]} rows × {merged_df.shape[1]} columns")
    
    # Show date range
    print(f"  Date range: {merged_df['date'].min()} to {merged_df['date'].max()}")
    
    # Count NaN values to show data coverage
    total_cells = merged_df.shape[0] * (merged_df.shape[1] - 1)  # Exclude date column
    nan_cells = merged_df.iloc[:, 1:].isna().sum().sum()
    coverage_pct = (1 - nan_cells/total_cells) * 100
    print(f"  Data coverage: {coverage_pct:.1f}% ({nan_cells:,} NaN values out of {total_cells:,} cells)")
    
    # Drop specified columns (these are the non-BCF versions)
    columns_to_drop = [
        'centralindustri_CENTRAL_Industrial_hourly_MMcf',
        'centralpowerbur_CENTRAL_Power_Burn',
        'centralresident_CENTRAL_Residential_hourly_MMcf',
        'centralcommerci_CENTRAL_Commercial_hourly_MMcf',
        'midwestresidenti_MIDWEST_Residential_hourly_MMcf',
        'midwestindustri_MIDWEST_Industrial_hourly_MMcf',
        'midwestcommerci_MIDWEST_Commercial_hourly_MMcf',
        'midwestpowerbur_MIDWEST_Power_Burn',
        'midwestresident_MIDWEST_Residential_hourly_MMcf',
    ]
    
    # Find which columns to drop that actually exist in the dataframe
    existing_cols_to_drop = [col for col in columns_to_drop if col in merged_df.columns]
    
    if existing_cols_to_drop:
        print(f"\n  Dropping {len(existing_cols_to_drop)} specified columns...")
        merged_df = merged_df.drop(columns=existing_cols_to_drop)
        print(f"  ✓ Dropped columns, new shape: {merged_df.shape[0]} rows × {merged_df.shape[1]} columns")
    
    # Convert storage columns from dekatherms to BCF (divide by 1,000,000)
    storage_columns_dth = [
        'midwestconsolid_ANR Pipeline',
        'midwestconsolid_ANR Storage',
        'midwestconsolid_Atmos',
        'midwestconsolid_Barnsley',
        'midwestconsolid_Bell River Mills',
        'midwestconsolid_Bluewater',
        'midwestconsolid_Blue Lake',
        'midwestconsolid_Eaton Rapids',
        'midwestconsolid_Kimball 27',
        'midwestconsolid_Lee 8',
        'midwestconsolid_NGPL',
        'midwestconsolid_Northern Natural Gas',
        'midwestconsolid_Ohio Valley Hub',
        'midwestconsolid_SWGS East',
        'midwestconsolid_Texas Gas',
        'midwestconsolid_Washington 10',
        'midwestconsolid_White River'
    ]
    
    # Find which storage columns actually exist in the dataframe
    existing_storage_cols = [col for col in storage_columns_dth if col in merged_df.columns]
    
    if existing_storage_cols:
        print(f"\n  Converting {len(existing_storage_cols)} storage columns from dekatherms to BCF...")
        for col in existing_storage_cols:
            merged_df[col] = merged_df[col] / 1000000
            # Rename column to indicate BCF
            new_col_name = col.replace('midwestconsolid_', 'midwestconsolid_BCF_')
            merged_df = merged_df.rename(columns={col: new_col_name})
        print(f"  ✓ Converted dekatherms to BCF and renamed storage columns")
    
    # =====================================================
    # CREATE REGIONAL SUMMATION COLUMNS
    # =====================================================
    print("\n" + "="*60)
    print("CREATING REGIONAL SUMMATION COLUMNS")
    print("="*60)
    
    # Define regional column groups - FIXED to match actual column names
    regional_columns = {
        'CENTRAL_TOTAL_BCF': [
            'centralcommerci_CENTRAL_Commercial_hourly_MMcf_BCF',
            'centralindustri_CENTRAL_Industrial_hourly_MMcf_BCF',
            'centralpowerbur_CENTRAL_Power_Burn_BCF',
            'centralresident_CENTRAL_Residential_hourly_MMcf_BCF'
        ],
        'MIDWEST_TOTAL_BCF': [
            'midwestcommerci_MIDWEST_Commercial_hourly_MMcf_BCF',
            'midwestindustri_MIDWEST_Industrial_hourly_MMcf_BCF',
            'midwestpowerbur_MIDWEST_Power_Burn_BCF',
            'midwestresidenti_MIDWEST_Residential_hourly_MMcf_BCF'
        ]
    }
    
    # Create summation columns for each region
    for region_total, columns in regional_columns.items():
        # Check which columns exist in the dataframe
        existing_cols = [col for col in columns if col in merged_df.columns]
        
        if existing_cols:
            # Sum the existing columns (handling NaN values)
            merged_df[region_total] = merged_df[existing_cols].sum(axis=1, skipna=True)
            
            # Replace 0 with NaN where all component columns were NaN
            all_nan_mask = merged_df[existing_cols].isna().all(axis=1)
            merged_df.loc[all_nan_mask, region_total] = pd.NA
            
            print(f"\n✓ Created {region_total}")
            print(f"  Summed {len(existing_cols)} columns:")
            for col in existing_cols:
                print(f"    • {col}")
            
            # Show summary statistics for the new column
            non_nan_count = merged_df[region_total].notna().sum()
            mean_val = merged_df[region_total].mean()
            min_val = merged_df[region_total].min()
            max_val = merged_df[region_total].max()
            print(f"  Statistics: Mean={mean_val:.4f}, Min={min_val:.4f}, Max={max_val:.4f}")
            print(f"  Coverage: {non_nan_count}/{len(merged_df)} rows have data ({non_nan_count/len(merged_df)*100:.1f}%)")
        else:
            print(f"\n⚠️ Warning: No columns found for {region_total}")
            print(f"  Looking for: {columns}")
    
    # Create a grand total column for all regions
    total_columns = [col for col in merged_df.columns if col.endswith('_TOTAL_BCF')]
    if total_columns:
        merged_df['MIDWEST_GRAND_TOTAL_BCF'] = merged_df[total_columns].sum(axis=1, skipna=True)
        
        # Replace 0 with NaN where all component columns were NaN
        all_nan_mask = merged_df[total_columns].isna().all(axis=1)
        merged_df.loc[all_nan_mask, 'MIDWEST_GRAND_TOTAL_BCF'] = pd.NA
        
        print(f"\n✓ Created MIDWEST_GRAND_TOTAL_BCF")
        print(f"  Summed {len(total_columns)} regional totals")
        non_nan_count = merged_df['MIDWEST_GRAND_TOTAL_BCF'].notna().sum()
        print(f"  Coverage: {non_nan_count}/{len(merged_df)} rows have data ({non_nan_count/len(merged_df)*100:.1f}%)")
    
    # =====================================================
    # DROP INDIVIDUAL COMPONENT COLUMNS AFTER SUMMATION
    # =====================================================
    print("\n" + "="*60)
    print("DROPPING INDIVIDUAL COMPONENT COLUMNS")
    print("="*60)
    
    # Collect all individual columns that were used in summations
    columns_to_drop_after_sum = []
    for region_total, columns in regional_columns.items():
        for col in columns:
            if col in merged_df.columns:
                columns_to_drop_after_sum.append(col)
    
    # Drop the individual columns
    if columns_to_drop_after_sum:
        print(f"\nDropping {len(columns_to_drop_after_sum)} individual component columns...")
        merged_df = merged_df.drop(columns=columns_to_drop_after_sum)
        print(f"✓ Dropped individual columns, keeping only regional totals")
        print(f"  New shape: {merged_df.shape[0]} rows × {merged_df.shape[1]} columns")
    
    # Drop the synmaxproductio_DATA_SOURCE column if it exists
    if 'synmaxproductio_DATA_SOURCE' in merged_df.columns:
        print(f"\n✓ Dropping column: synmaxproductio_DATA_SOURCE")
        merged_df = merged_df.drop(columns=['synmaxproductio_DATA_SOURCE'])
    
    print("\n" + "="*60)
    
    # Save the merged file
    output_filename = 'MIDWEST_merged_all_outer_with_totals.csv'
    output_path = os.path.join(output_dir, output_filename)
    
    try:
        merged_df.to_csv(output_path, index=False)
        file_size = os.path.getsize(output_path)
        
        if file_size < 1024 * 1024:
            size_str = f"{file_size/1024:.1f} KB"
        else:
            size_str = f"{file_size/(1024*1024):.1f} MB"
            
        print(f"\n✓ Merged file saved as: {output_filename}")
        print(f"  Path: {output_path}")
        print(f"  Size: {size_str}")
        
    except Exception as e:
        print(f"\n✗ Error saving merged file: {str(e)}")
    
    # Display sample of merged data with new columns
    print("\nFirst 5 rows of merged data (showing regional totals):")
    print("-" * 40)
    # Show just date and the regional total columns
    display_cols = ['date'] + [col for col in merged_df.columns if '_TOTAL_BCF' in col or col == 'MIDWEST_GRAND_TOTAL_BCF']
    if display_cols:
        print(merged_df[display_cols].head())
    
    # Show data coverage analysis
    print("\n" + "="*60)
    print("DATA COVERAGE ANALYSIS")
    print("="*60)
    
    for col in merged_df.columns:
        if '_TOTAL_BCF' in col or col == 'MIDWEST_GRAND_TOTAL_BCF':
            non_nan = merged_df[col].notna().sum()
            pct = non_nan / len(merged_df) * 100
            print(f"  {col}: {non_nan:,}/{len(merged_df):,} rows ({pct:.1f}%)")
    
    print("\nAll column names in merged file:")
    print("-" * 40)
    for i, col in enumerate(merged_df.columns, 1):
        if '_TOTAL_BCF' in col or col == 'MIDWEST_GRAND_TOTAL_BCF':
            print(f"  {i:3}. {col} *** SUMMATION COLUMN ***")
        else:
            print(f"  {i:3}. {col}")
        if i >= 30 and len(merged_df.columns) > 30:
            print(f"  ... and {len(merged_df.columns) - 30} more columns")
            break
            
elif merged_df is not None:
    print("\n⚠️ Warning: Merged dataframe is empty!")
    print("  This shouldn't happen with outer join. Check your input files.")
else:
    print("\n✗ No successful merges performed")

if date_column_issues:
    print(f"\n⚠️ Files without date-related columns: {len(date_column_issues)}")
    for file, cols in date_column_issues:
        print(f"  • {file}")
        print(f"    Columns: {cols[:3]}...")

if failed_files:
    print(f"\n✗ Failed to process: {len(failed_files)} files")
    for file, error in failed_files:
        print(f"  • {file}: {error}")

print("\n" + "="*60)
print("Process completed with OUTER JOIN!")
print("="*60)