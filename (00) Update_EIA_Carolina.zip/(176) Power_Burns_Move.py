import os
import shutil
from datetime import datetime
import glob
from collections import defaultdict

# Define paths
eia_stack_dir = r'D:\EIA_STACK'
pricing_rl_dir = r'D:\EIA_STACK\Pricing_RL'

print("="*60)
print("COPYING POWER BURN PREDICTION FILES TO REGIONAL FOLDERS")
print("="*60)
print("Note: TEXAS power burn files will be copied to both SOUTHCENTRAL and SOUTHCENTRAL_SALTS")
print("="*60)

# Define the mapping between source regions and target Pricing_RL regions
# Modified to support multiple destinations for Texas
region_mappings = {
    'california': ['PACIFIC'],
    'carolina': ['EAST'],
    'central': ['MIDWEST'],
    'florida': ['EAST'],
    'midatlantic': ['EAST'],
    'midwest': ['MIDWEST'],
    'newengland': ['EAST'],
    'newyork': ['EAST'],
    'northwest': ['PACIFIC'],
    'southeast': ['EAST'],
    'southwest': ['MOUNTAIN'],
    'tennessee': ['EAST'],
    'texas': ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS']  # Will copy to both folders
}

# Track statistics
successful_copies = []
failed_copies = []
not_found = []
files_found = []
regions_processed = set()

# Process each region
for source_region, target_regions in region_mappings.items():
    # Add all target regions to processed set
    for target in target_regions:
        regions_processed.add(target)
    
    # Display appropriate header based on number of targets
    if len(target_regions) > 1:
        print(f"\n{'='*50}")
        print(f"Processing {source_region.upper()}")
        print(f"  → Copying to: {', '.join(target_regions)}")
        print(f"{'='*50}")
    else:
        print(f"\n{'='*50}")
        print(f"Processing {source_region.upper()} → {target_regions[0]}")
        print(f"{'='*50}")
    
    # Source folder path
    source_folder = os.path.join(eia_stack_dir, source_region, 'Predictions')
    
    # Check if source folder exists
    if not os.path.exists(source_folder):
        print(f"  ⚠️ Source folder not found: {source_folder}")
        not_found.append((source_region, "Folder not found"))
        continue
    
    # Look for power burn files with the messy naming pattern
    # Pattern: predicted_power_burn_DAILY_{REGION}_Power_Burn_*.csv
    pattern1 = f"predicted_power_burn_DAILY_{source_region.upper()}_Power_Burn_*.csv"
    pattern2 = f"predicted_power_burn_DAILY_{source_region}_Power_Burn_*.csv"  # lowercase version
    pattern3 = f"predicted_power_burn_*.csv"  # Generic pattern as fallback
    
    power_burn_files = []
    
    # Try different patterns
    for pattern in [pattern1, pattern2, pattern3]:
        search_path = os.path.join(source_folder, pattern)
        found_files = glob.glob(search_path)
        if found_files:
            power_burn_files.extend(found_files)
            print(f"  Found {len(found_files)} file(s) matching pattern: {pattern}")
    
    # Remove duplicates if any
    power_burn_files = list(set(power_burn_files))
    
    if not power_burn_files:
        print(f"  ✗ No power burn prediction files found in {source_folder}")
        not_found.append((source_region, "No power burn files found"))
        
        # List what files are actually in the folder for debugging
        all_files = [f for f in os.listdir(source_folder) if f.endswith('.csv')]
        if all_files:
            print(f"  CSV files found in folder:")
            for f in all_files[:5]:  # Show first 5 files
                print(f"    - {f}")
            if len(all_files) > 5:
                print(f"    ... and {len(all_files) - 5} more files")
        continue
    
    # Process each target folder
    for target_region in target_regions:
        # Destination folder
        dest_folder = os.path.join(pricing_rl_dir, target_region)
        
        # Create destination folder if it doesn't exist
        if not os.path.exists(dest_folder):
            os.makedirs(dest_folder)
            print(f"  Created destination folder: {dest_folder}")
        
        # If multiple targets, add a sub-header
        if len(target_regions) > 1:
            print(f"\n  Copying to {target_region}:")
        
        # Copy each power burn file found
        for source_path in power_burn_files:
            filename = os.path.basename(source_path)
            
            # Create a cleaner filename for the destination
            # Keep the original but also create a simplified version
            if 'Power_Burn' in filename:
                # Create a simplified name like: {region}_power_burn_prediction.csv
                simplified_name = f"{source_region}_power_burn_prediction.csv"
            else:
                simplified_name = filename
            
            dest_path = os.path.join(dest_folder, simplified_name)
            
            try:
                # Copy the file with the simplified name
                shutil.copy2(source_path, dest_path)
                
                # Verify the copy
                source_size = os.path.getsize(source_path)
                dest_size = os.path.getsize(dest_path)
                
                if source_size == dest_size:
                    indent = "    " if len(target_regions) > 1 else "  "
                    print(f"{indent}✓ Copied: {filename}")
                    print(f"{indent}  Saved as: {simplified_name} ({source_size:,} bytes)")
                    successful_copies.append((source_region, target_region, filename, simplified_name))
                    
                    # Only add to files_found once (not for each target)
                    if target_region == target_regions[0]:
                        files_found.append((source_region, filename))
                else:
                    indent = "    " if len(target_regions) > 1 else "  "
                    print(f"{indent}⚠️ Warning: File sizes don't match for {filename}")
                    failed_copies.append((source_region, target_region, filename, "Size mismatch"))
                    
            except Exception as e:
                indent = "    " if len(target_regions) > 1 else "  "
                print(f"{indent}✗ Error copying {filename}: {str(e)}")
                failed_copies.append((source_region, target_region, filename, str(e)))

# Final summary
print("\n" + "="*60)
print("FINAL SUMMARY")
print("="*60)

# Group successful copies by target region
copies_by_target = defaultdict(list)
for source, target, original_name, simplified_name in successful_copies:
    copies_by_target[target].append((source, simplified_name))

if successful_copies:
    print(f"\n✓ Successfully copied: {len(successful_copies)} files")
    print("\nBy destination region:")
    for target in sorted(copies_by_target.keys()):
        print(f"\n  {target}:")
        # Group by source for cleaner display
        sources_in_target = defaultdict(list)
        for source, filename in copies_by_target[target]:
            sources_in_target[source].append(filename)
        
        for source in sorted(sources_in_target.keys()):
            if source == 'texas' and target in ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS']:
                print(f"    From {source} (shared with both SOUTHCENTRAL regions):")
            else:
                print(f"    From {source}:")
            for filename in sorted(sources_in_target[source]):
                print(f"      • {filename}")

if not_found:
    print(f"\n⚠️ Regions with issues: {len(not_found)}")
    # Remove duplicates for cleaner display
    unique_not_found = list(set(not_found))
    for source, issue in unique_not_found:
        print(f"  • {source}: {issue}")

if failed_copies:
    print(f"\n✗ Failed to copy: {len(failed_copies)} files")
    for source, target, filename, error in failed_copies:
        print(f"  • {source} → {target}: {filename} - Error: {error}")

# Show original filenames that were found
if files_found:
    print("\n" + "="*60)
    print("ORIGINAL FILENAMES PROCESSED")
    print("="*60)
    for source, original in files_found:
        print(f"  {source}: {original}")

# Show final structure for each target region
print("\n" + "="*60)
print("POWER BURN FILES IN EACH REGION")
print("="*60)

for region in sorted(regions_processed):
    region_path = os.path.join(pricing_rl_dir, region)
    if os.path.exists(region_path):
        # Look for power burn files
        power_files = [f for f in os.listdir(region_path) if 'power_burn' in f.lower() and f.endswith('.csv')]
        
        if power_files:
            print(f"\n{region}:")
            for f in sorted(power_files):
                file_size = os.path.getsize(os.path.join(region_path, f))
                print(f"  • {f} ({file_size:,} bytes)")
        else:
            print(f"\n{region}: No power burn files")

# Special note for TEXAS files
print("\n" + "="*60)
print("SPECIAL NOTE")
print("="*60)
print("✓ TEXAS power burn files have been copied to both:")
print("  • SOUTHCENTRAL/texas_power_burn_prediction.csv")
print("  • SOUTHCENTRAL_SALTS/texas_power_burn_prediction.csv")
print("This ensures both regional models have access to Texas power burn data.")

print("\n" + "="*60)
print("Process completed!")
print("="*60)