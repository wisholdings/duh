"""
Script to combine Pacific storage historical data with forecast data
Combines pacific.csv and pacific_long_term_seasonal_forecast.csv
Outputs combined file to D:\EIA_STACK\Pricing_RL\PACIFIC\HTML\
"""

import pandas as pd
import os
from datetime import datetime

# Define file paths
INPUT_DIR = r"D:\EIA_STACK\granular_storage"
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\PACIFIC\HTML"

# Input files
HISTORICAL_FILE = os.path.join(INPUT_DIR, "pacific.csv")
FORECAST_FILE = os.path.join(INPUT_DIR, "pacific_long_term_seasonal_forecast.csv")

# Output file
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "pacific_combined_storage.csv")

def main():
    """Main function to combine Pacific storage data"""
    
    print("="*60)
    print("PACIFIC STORAGE DATA COMBINER")
    print("="*60)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output directory: {OUTPUT_DIR}")
    
    try:
        # 1. Load historical data
        print("\n1. Loading historical Pacific data...")
        df_historical = pd.read_csv(HISTORICAL_FILE)
        print(f"   Loaded {len(df_historical)} rows of historical data")
        
        # Convert datetime to proper datetime format
        df_historical['datetime'] = pd.to_datetime(df_historical['datetime'])
        
        # 2. Load forecast data
        print("\n2. Loading forecast data...")
        df_forecast = pd.read_csv(FORECAST_FILE)
        print(f"   Loaded {len(df_forecast)} rows of forecast data")
        
        # Convert Forecast_Date to datetime
        df_forecast['Forecast_Date'] = pd.to_datetime(df_forecast['Forecast_Date'])
        
        # 3. Get the last historical date
        last_historical_date = df_historical['datetime'].max()
        print(f"\n3. Last historical date: {last_historical_date}")
        
        # 4. Prepare data for combination
        print("\n4. Preparing data for combination...")
        
        # Rename columns to match
        df_historical = df_historical.rename(columns={
            'Pacific': 'Storage_Level',
            'Delta_Change': 'Weekly_Change'
        })
        
        df_forecast = df_forecast.rename(columns={
            'Forecast_Date': 'datetime',
            'Projected_Storage_Level': 'Storage_Level',
            'Predicted_Delta': 'Weekly_Change'
        })
        
        # Keep only the columns we need
        df_historical = df_historical[['datetime', 'Storage_Level', 'Weekly_Change']]
        df_forecast = df_forecast[['datetime', 'Storage_Level', 'Weekly_Change']]
        
        # 5. Filter forecast to only future dates
        df_forecast_future = df_forecast[df_forecast['datetime'] > last_historical_date].copy()
        print(f"   Forecast rows after {last_historical_date.date()}: {len(df_forecast_future)}")
        
        # 6. Combine the dataframes
        print("\n5. Combining historical and forecast data...")
        df_combined = pd.concat([df_historical, df_forecast_future], ignore_index=True)
        
        # Sort by datetime
        df_combined = df_combined.sort_values('datetime').reset_index(drop=True)
        
        # 7. Add year-over-year columns
        print("\n6. Adding year-over-year analysis...")
        df_combined['YoY_Storage_Level'] = df_combined['Storage_Level'].shift(52)
        df_combined['YoY_Change'] = df_combined['Storage_Level'] - df_combined['YoY_Storage_Level']
        
        # 8. Save the combined file
        print(f"\n7. Saving combined file to: {OUTPUT_FILE}")
        df_combined.to_csv(OUTPUT_FILE, index=False, float_format='%.2f')
        print(f"   Successfully saved {len(df_combined)} rows")
        
        # 9. Print summary statistics
        print("\n" + "="*60)
        print("SUMMARY STATISTICS")
        print("="*60)
        
        print(f"\nHistorical Data:")
        print(f"  Date range: {df_historical['datetime'].min().date()} to {df_historical['datetime'].max().date()}")
        print(f"  Storage range: {df_historical['Storage_Level'].min():.1f} to {df_historical['Storage_Level'].max():.1f}")
        print(f"  Records: {len(df_historical)}")
        
        if len(df_forecast_future) > 0:
            print(f"\nForecast Data:")
            print(f"  Date range: {df_forecast_future['datetime'].min().date()} to {df_forecast_future['datetime'].max().date()}")
            print(f"  Storage range: {df_forecast_future['Storage_Level'].min():.1f} to {df_forecast_future['Storage_Level'].max():.1f}")
            print(f"  Records: {len(df_forecast_future)}")
        
        print(f"\nCombined Data:")
        print(f"  Total records: {len(df_combined)}")
        print(f"  Date range: {df_combined['datetime'].min().date()} to {df_combined['datetime'].max().date()}")
        print(f"  Columns: {', '.join(df_combined.columns)}")
        
        print("\n" + "="*60)
        print("✅ COMBINATION COMPLETE!")
        print("="*60)
        
        return df_combined
        
    except FileNotFoundError as e:
        print(f"\n❌ ERROR: File not found - {e}")
        return None
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    # Run the combination
    combined_data = main()
    
    if combined_data is not None:
        print(f"\n✅ Output saved to: {OUTPUT_FILE}")
    else:
        print("\n❌ Script failed. Check error messages above.")