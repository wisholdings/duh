import pandas as pd
import os

# Set the directories
input_dir = r'D:\EIA_STACK\granular_storage'  # Where source files are located
output_dir = r'D:\EIA_STACK\Pricing_RL\AGGREGATE'  # Where combined files will be saved

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# Define the regions and their file mappings
regions = {
    'east': {
        'actual_file': 'east.csv',
        'forecast_file': 'east_long_term_seasonal_forecast.csv',
        'column_name': 'East',
        'output_file': 'east_combined.csv'
    },
    'midwest': {
        'actual_file': 'midwest.csv',
        'forecast_file': 'midwest_long_term_seasonal_forecast.csv',
        'column_name': 'Midwest',
        'output_file': 'midwest_combined.csv'
    },
    'mountain': {
        'actual_file': 'mountain.csv',
        'forecast_file': 'mountain_long_term_seasonal_forecast.csv',
        'column_name': 'Mountain',
        'output_file': 'mountain_combined.csv'
    },
    'pacific': {
        'actual_file': 'pacific.csv',
        'forecast_file': 'pacific_long_term_seasonal_forecast.csv',
        'column_name': 'Pacific',
        'output_file': 'pacific_combined.csv'
    },
    'south_central_nonsalt': {
        'actual_file': 'south_central_nonsalt_region.csv',
        'forecast_file': 'southcentral_nonsalt_long_term_seasonal_forecast.csv',
        'column_name': 'South Central Nonsalt',
        'output_file': 'south_central_nonsalt_combined.csv'
    },
    'south_central_salt': {
        'actual_file': 'south_central_salt_region.csv',
        'forecast_file': 'southcentral_salt_long_term_seasonal_forecast.csv',
        'column_name': 'South Central Salt',
        'output_file': 'south_central_salt_combined.csv'
    }
}

print(f"{'='*60}")
print("COMBINING REGIONAL DATA WITH FORECASTS")
print(f"{'='*60}")
print(f"Reading from: {input_dir}")
print(f"Saving to:    {output_dir}")
print(f"{'='*60}")

# Process each region
for region_name, region_config in regions.items():
    print(f"\n{'='*60}")
    print(f"Processing {region_name.upper()}")
    print('='*60)
    
    try:
        # Build full file paths - input from input_dir
        actual_file_path = os.path.join(input_dir, region_config['actual_file'])
        forecast_file_path = os.path.join(input_dir, region_config['forecast_file'])
        
        # Read the actual data file
        actual_data = pd.read_csv(actual_file_path)
        print(f"Loaded {region_config['actual_file']}: {actual_data.shape[0]} rows")
        
        # Read the forecast file
        forecast_data = pd.read_csv(forecast_file_path)
        print(f"Loaded {region_config['forecast_file']}: {forecast_data.shape[0]} rows")
        
        # Convert date columns to datetime
        actual_data['datetime'] = pd.to_datetime(actual_data['datetime'])
        forecast_data['Forecast_Date'] = pd.to_datetime(forecast_data['Forecast_Date'])
        
        # Get the last date from actual data
        last_actual_date = actual_data['datetime'].max()
        print(f"Last actual data date: {last_actual_date.date()}")
        
        # Prepare forecast data to match actual data format
        forecast_aligned = forecast_data.copy()
        
        # Rename columns to match the actual data structure
        # We need to dynamically handle the region column name
        forecast_aligned = forecast_aligned.rename(columns={
            'Forecast_Date': 'datetime',
            'Projected_Storage_Level': region_config['column_name'],
            'Predicted_Delta': 'Delta_Change'
        })
        
        # Keep only the columns that match actual data format
        forecast_aligned = forecast_aligned[['datetime', region_config['column_name'], 'Delta_Change']]
        
        # Filter to only include forecast dates after the last actual date
        forecast_aligned = forecast_aligned[forecast_aligned['datetime'] > last_actual_date]
        print(f"Forecast rows to append: {len(forecast_aligned)}")
        
        # Combine actual and forecast data
        combined = pd.concat([actual_data, forecast_aligned], ignore_index=True)
        
        # Sort by datetime
        combined = combined.sort_values('datetime')
        combined = combined.reset_index(drop=True)
        
        # Round numerical columns to integers
        combined[region_config['column_name']] = combined[region_config['column_name']].round().astype('Int64')
        combined['Delta_Change'] = combined['Delta_Change'].round().astype('Int64')
        
        # Save the combined file - output to output_dir
        output_path = os.path.join(output_dir, region_config['output_file'])
        combined.to_csv(output_path, index=False)
        
        print(f"✓ Saved {region_config['output_file']} to AGGREGATE folder")
        print(f"  Total rows: {len(combined)}")
        print(f"  Date range: {combined['datetime'].min().date()} to {combined['datetime'].max().date()}")
        
        # Verify weekly continuity
        date_diffs = combined['datetime'].diff().dropna()
        if len(date_diffs) > 0:
            most_common_diff = date_diffs.mode()[0]
            print(f"  Interval: {most_common_diff.days} days (weekly)")
        
    except FileNotFoundError as e:
        print(f"✗ Error: Could not find file for {region_name}")
        print(f"  Looking in: {input_dir}")
        print(f"  Missing file: {os.path.basename(e.filename)}")
        continue
    except Exception as e:
        print(f"✗ Error processing {region_name}: {str(e)}")
        continue

print(f"\n{'='*60}")
print("SUMMARY")
print('='*60)
print(f"Input directory:  {input_dir}")
print(f"Output directory: {output_dir}")
print("\nCreated files in AGGREGATE folder:")
successful = 0
failed = 0
for region_name, region_config in regions.items():
    output_file = region_config['output_file']
    output_path = os.path.join(output_dir, output_file)
    if os.path.exists(output_path):
        print(f"  ✓ {output_file}")
        successful += 1
    else:
        print(f"  ✗ {output_file} (not created)")
        failed += 1

print(f"\nTotal: {successful} successful, {failed} failed")