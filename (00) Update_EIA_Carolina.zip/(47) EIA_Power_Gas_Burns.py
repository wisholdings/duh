import os
import json
import sys
import pandas as pd
import traceback
import time
from datetime import datetime
import requests
import warnings

# --- Configuration Loading ---
try:
    # Assumes script is in a subdirectory (e.g., 'scripts') of the project root
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    from config.settings import BASE_OUTPUT_DIR
    print(f"Loaded BASE_OUTPUT_DIR from config: {BASE_OUTPUT_DIR}")
except (ImportError, NameError, FileNotFoundError) as e:
    print(f"Could not import BASE_OUTPUT_DIR from config.settings ({e}). Using default.")
    # --- !! SET YOUR DEFAULT BASE DIRECTORY HERE IF CONFIG FAILS !! ---
    BASE_OUTPUT_DIR = "D:\\EIA_STACK" # EXAMPLE: Change this path
    print(f"Using default BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")

# --- EIA API Configuration ---
# It's generally better practice to store API keys securely (environment variables, config file)
# but placing it here for simplicity based on the original script.
API_KEY = ""

# Disable InsecureRequestWarning if verify=False is necessary (often in corporate environments)
# Consider addressing the root cause (installing certificates) if possible instead.
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

def fetch_natural_gas_data(api_key, region_codes, region_name_log):
    """
    Fetches monthly 'Electric Power Consumption' data for given EIA region codes.

    Args:
        api_key (str): Your EIA API key.
        region_codes (list): A list of EIA state/area codes (e.g., ['SFL']).
        region_name_log (str): The name of the region for logging purposes.

    Returns:
        pandas.DataFrame: DataFrame with 'period', 'duoarea', 'process-name', 'value'
                          for the specified regions and process, or empty DataFrame on error.
    """
    api_url = "https://api.eia.gov/v2/natural-gas/cons/sum/data/"
    offset = 0
    limit = 5000 # Max records per request
    combined_df = pd.DataFrame()
    today_date_str = datetime.now().strftime("%Y-%m")
    print(f"  Fetching data for region codes: {region_codes}")

    while True:
        params = {
            "api_key": api_key,
            "frequency": "monthly",
            "data[0]": "value",
            "start": "2019-01", # Fetching data from 2015 onwards
            "end": today_date_str,
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "offset": offset,
            "length": limit
        }

        # Add the 'duoarea' facets dynamically based on the region codes provided
        for i, code in enumerate(region_codes):
            params[f"facets[duoarea][{i}]"] = code

        try:
            # Using verify=False is generally discouraged for security reasons.
            # Only use it if you understand the risks or are in a trusted network environment
            # where certificate validation might fail.
            response = requests.get(api_url, params=params, verify=False, timeout=60) # Added timeout

            if response.status_code == 200:
                data = response.json()
                if 'response' in data and 'data' in data['response']:
                    page_data = data['response']['data']
                    if not page_data: # No more data left to fetch
                        print("    No more data found from API.")
                        break

                    df = pd.DataFrame(page_data)
                    print(f"    Fetched {len(df)} records (offset {offset})...")

                    # Basic validation of expected columns before processing
                    expected_cols = ['period', 'duoarea', 'process-name', 'value']
                    if not all(col in df.columns for col in expected_cols):
                        print(f"    Warning: Missing expected columns in API response batch. Skipping batch.")
                        print(f"    Found columns: {df.columns.tolist()}")
                        offset += limit # Still increment offset to avoid infinite loop on bad data
                        continue # Skip this batch

                    # Keep only necessary columns upfront
                    df = df[expected_cols]

                    # Filter for required process type
                    df_filtered = df[df['process-name'] == 'Electric Power Consumption'].copy() # Use .copy()

                    if not df_filtered.empty:
                        # Convert types safely
                        df_filtered['period'] = pd.to_datetime(df_filtered['period'], errors='coerce')
                        df_filtered['duoarea'] = df_filtered['duoarea'].astype(str)
                        df_filtered['value'] = pd.to_numeric(df_filtered['value'], errors='coerce')
                        df_filtered.dropna(subset=['period', 'value'], inplace=True) # Drop rows where conversion failed

                        combined_df = pd.concat([combined_df, df_filtered], ignore_index=True)
                    else:
                         print("    No 'Electric Power Consumption' data in this batch.")

                    offset += limit  # Increment offset to fetch next batch

                else:
                    # Handle cases where response structure is unexpected but status code is 200
                    print(f"    API response format unexpected for {region_name_log}. Data: {data}")
                    break # Stop fetching for this region if format is wrong

            elif response.status_code == 404:
                 print(f"    Warning: Data not found (404) for codes {region_codes} at offset {offset}. May indicate no data for this period/filter.")
                 break # Stop if we get a 404
            else:
                print(f"    ERROR: Failed to fetch data for {region_name_log}. Status: {response.status_code}, Response: {response.text}")
                # Depending on the error, you might want to retry or break
                break # Stop fetching for this region on error
        except requests.exceptions.RequestException as e:
            print(f"    ERROR: Network or request error for {region_name_log}: {e}")
            break # Stop fetching for this region on network error
        except json.JSONDecodeError as e:
            print(f"    ERROR: Could not decode JSON response for {region_name_log}: {e}")
            print(f"    Response Text: {response.text[:500]}...") # Print beginning of text
            break # Stop fetching for this region if JSON is invalid
        except Exception as e:
             print(f"    ERROR: An unexpected error occurred during fetch for {region_name_log}: {e}")
             traceback.print_exc()
             break

    print(f"  Finished fetching for {region_name_log}. Total relevant rows fetched: {len(combined_df)}")
    return combined_df

# Define regional groups (same as before)
regions = {
    "texas": ["STX"],
    "florida": ["SFL"],
    "carolina": ["SNC", "SSC"],
    "california": ["SCA"],
    "newengland": ["SME", "SCT", "SMA", "SNH", "SRI", "SVT"],
    "newyork": ["SNY"],
    "midatlantic": ["SMD", "SDE", "SPA", "SVA", "SWV"],
    "midwest": ["SIL", "SIN", "SMO", "SMI", "SMN", "SWI", "SIA", "SOH", "SKS", "SKY"],
    "southeast": ["SAL", "SAR", "SGA", "SMS", "SLA"],
    "southwest": ["SAZ", "SNM", "SNV", "SUT", "SCO"],
    "northwest": ["SID", "SOR", "SWA", "SWY", "SMT"],
    "central": ["SNE", "SNJ", "SND", "SSD", "SOK"],
    "tennessee": ["STN"]
}


# --- Main Processing Loop ---
print("\n=====================================================")
print("=== Starting EIA Natural Gas Data Processing        ===")
print("=====================================================")
start_total_time = time.time()
successful_regions = []
failed_regions = []

# Process each region
for region_name, region_codes in regions.items():
    region_upper = region_name.upper()
    print(f"\n\n################ Processing Region: {region_upper} ################")
    start_region_time = time.time()
    region_success = False

    try:
        # --- Define Paths ---
        region_base_dir = os.path.join(BASE_OUTPUT_DIR, region_name)
        final_dir = os.path.join(region_base_dir, "final")
        # Make sure the 'final' directory exists for this region
        os.makedirs(final_dir, exist_ok=True)
        print(f"  Output directory: {final_dir}")

        # --- Fetch Data ---
        region_df_raw = fetch_natural_gas_data(API_KEY, region_codes, region_upper)

        if region_df_raw.empty:
            print(f"  No data fetched or processed for {region_upper}. Skipping.")
            failed_regions.append(f"{region_name} (No data fetched)")
            continue # Move to the next region

        # --- Calculate Monthly Sum ---
        print(f"  Calculating monthly sums for {region_upper}...")
        # Group by month using PeriodIndex and sum the values
        # Use errors='coerce' just in case period conversion fails for some reason
        monthly_sum = region_df_raw.groupby(pd.to_datetime(region_df_raw['period'], errors='coerce').dt.to_period('M'))['value'].sum()

        if monthly_sum.empty:
             print(f"  Monthly summation resulted in empty data for {region_upper}. Skipping save.")
             failed_regions.append(f"{region_name} (Empty after summation)")
             continue

        # --- Prepare DataFrame for Saving ---
        # Convert the Series index (PeriodIndex) to a timestamp column
        df_to_save = monthly_sum.reset_index()
        df_to_save['period'] = df_to_save['period'].dt.to_timestamp() # Convert Period to Timestamp

        # Rename columns for clarity in the final CSV
        output_col_name = f"{region_upper}_NG_Consumption_MMcf" # More descriptive name (MMcf = Million Cubic Feet)
        df_to_save.rename(columns={'period': 'datetime', 'value': output_col_name}, inplace=True)

        # --- Save Locally ---
        output_filename = f"natural_gas_consumption_{region_name}.csv"
        output_filepath = os.path.join(final_dir, output_filename)
        print(f"  Saving monthly summed data to: {output_filepath}")
        df_to_save.to_csv(output_filepath, index=False, float_format='%.3f') # Save with 3 decimal places for MMcf
        print(f"  Successfully saved data for {region_upper}.")
        region_success = True


    except Exception as e:
        print(f"  ERROR processing region {region_upper}: {e}")
        traceback.print_exc()
        failed_regions.append(f"{region_name} (Unexpected Error: {type(e).__name__})")

    finally:
        if region_success:
            successful_regions.append(region_name)
        end_region_time = time.time()
        print(f"  Region processing time: {end_region_time - start_region_time:.2f} seconds.")
        print(f"################ End Processing Region: {region_upper} ################")


# --- End of Processing Summary ---
end_total_time = time.time()
total_duration = end_total_time - start_total_time

print("\n\n=============================================")
print("========== Processing Summary ==========")
print(f"Total regions attempted: {len(regions.keys())}")
print(f"Successfully processed regions: {len(successful_regions)}")
print(f"Failed regions: {len(failed_regions)}")

if failed_regions:
    print("\n--- Failure Details (Regions) ---")
    for fr_info in failed_regions:
        print(f"  - {fr_info}")
    print("\nPlease review the detailed logs above for specific errors within each region.")
elif len(successful_regions) == len(regions.keys()):
     print("\nAll specified regions processed successfully.")
else:
     print("\nProcessing finished, but success/failure count mismatch. Check logs.")


print(f"\nTotal execution time: {total_duration:.2f} seconds.")
print("=============================================")

if failed_regions:
    sys.exit(1) # Exit with error code if any region failed
else:
    sys.exit(0) # Exit successfully