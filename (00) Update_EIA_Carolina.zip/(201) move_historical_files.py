#!/usr/bin/env python3
"""
EIA Stack File Copy Script
Copies specific CSV files and HTML report from Pricing_RL\AGGREGATE to Historical_Files\{Date}
"""

import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Tuple

def copy_eia_files():
    """Main function to copy EIA files to historical directory"""
    
    # Get today's date in YYYYMMDD format
    today_date = datetime.now().strftime("%Y%m%d")
    
    # Define paths
    source_path = Path(r"D:\EIA_STACK\Pricing_RL\AGGREGATE")
    destination_base = Path(r"D:\EIA_STACK\Historical_Files")
    destination_path = destination_base / today_date
    
    # List of static files to copy
    static_files = [
        "east_combined.csv",
        "midwest_combined.csv",
        "mountain_combined.csv",
        "lower_48_combined_pipe.csv",
        "pacific_combined.csv",
        "south_central_nonsalt_combined.csv",
        "south_central_salt_combined.csv",
        "natural_gas_forecast.html"
    ]
    
    # Dynamic file with today's date
    dynamic_file = f"L48_{today_date}.csv"
    
    # Combine all files
    all_files = static_files + [dynamic_file]
    
    # Create destination directory if it doesn't exist
    try:
        destination_path.mkdir(parents=True, exist_ok=True)
        print(f"✓ Destination directory ready: {destination_path}")
    except Exception as e:
        print(f"✗ Error creating directory: {e}")
        return
    
    # Print header
    print("\n" + "="*60)
    print("EIA STACK FILE COPY OPERATION")
    print("="*60)
    print(f"Source: {source_path}")
    print(f"Destination: {destination_path}")
    print(f"Date: {today_date}")
    print("="*60 + "\n")
    
    # Initialize counters
    success_count = 0
    fail_count = 0
    failed_files = []
    
    # Copy each file
    for file_name in all_files:
        source_file = source_path / file_name
        dest_file = destination_path / file_name
        
        try:
            if source_file.exists():
                shutil.copy2(source_file, dest_file)
                print(f"✓ SUCCESS: Copied {file_name}")
                success_count += 1
            else:
                print(f"⚠ WARNING: File not found - {file_name}")
                fail_count += 1
                failed_files.append(file_name)
        except PermissionError:
            print(f"✗ ERROR: Permission denied - {file_name}")
            fail_count += 1
            failed_files.append(file_name)
        except Exception as e:
            print(f"✗ ERROR: Failed to copy {file_name} - {str(e)}")
            fail_count += 1
            failed_files.append(file_name)
    
    # Print summary
    print("\n" + "="*60)
    print("COPY OPERATION COMPLETED")
    print("="*60)
    print(f"✓ Successfully copied: {success_count} files")
    print(f"✗ Failed/Not found: {fail_count} files")
    
    if failed_files:
        print("\nFailed files:")
        for failed_file in failed_files:
            print(f"  - {failed_file}")
    
    print(f"\nDestination folder: {destination_path}")
    print("="*60)
    
    # Optional: Open destination folder in Windows Explorer
    # Uncomment the line below if you want to automatically open the folder
    # os.startfile(destination_path)
    
    return success_count, fail_count

def verify_source_files():
    """Optional function to check which files exist before copying"""
    source_path = Path(r"D:\EIA_STACK\Pricing_RL\AGGREGATE")
    today_date = datetime.now().strftime("%Y%m%d")
    
    files_to_check = [
        "east_combined.csv",
        "midwest_combined.csv",
        "mountain_combined.csv",
        "pacific_combined.csv",
        "south_central_nonsalt_combined.csv",
        "south_central_salt_combined.csv",
        "natural_gas_forecast.html",
        f"L48_{today_date}.csv"
    ]
    
    print("\n" + "="*60)
    print("SOURCE FILE VERIFICATION")
    print("="*60)
    
    existing_files = []
    missing_files = []
    
    for file_name in files_to_check:
        file_path = source_path / file_name
        if file_path.exists():
            file_size = file_path.stat().st_size / 1024  # Size in KB
            print(f"✓ Found: {file_name} ({file_size:.1f} KB)")
            existing_files.append(file_name)
        else:
            print(f"✗ Missing: {file_name}")
            missing_files.append(file_name)
    
    print(f"\nTotal: {len(existing_files)} found, {len(missing_files)} missing")
    print("="*60)
    
    return existing_files, missing_files

if __name__ == "__main__":
    try:
        # Optional: Verify files first (uncomment if desired)
        # print("Checking source files...")
        # verify_source_files()
        # input("\nPress Enter to continue with copy operation...")
        
        # Run the copy operation
        success, failed = copy_eia_files()
        
        # Exit code based on results
        if failed == 0:
            print("\n✓ All files copied successfully!")
            exit(0)
        else:
            print(f"\n⚠ Completed with {failed} issues.")
            exit(1)
            
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user.")
        exit(1)
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        exit(1)