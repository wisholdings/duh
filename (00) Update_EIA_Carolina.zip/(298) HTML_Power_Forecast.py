import os
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
import traceback

# --- Main Configuration ---
DB_CONNECTION_STRING = (
)
BASE_OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"

# Define all the forecast types to process
TASKS = [
    {"name": "Natural Gas", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_NG"},
    {"name": "Coal", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_COL"},
    {"name": "Hydro", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_WAT"},
    {"name": "Nuclear", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_NUC"},
    {"name": "Other", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_OTH"},
    {"name": "Load", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_LOAD"},
    {"name": "Solar", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_SUN"},
    {"name": "Wind", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_WND"},
    {"name": "Interchange", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_INTERCHANGE"},
    {"name": "Battery", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_BAT"},
    {"name": "Pumped Storage", "table_name": "PRODUCTION_NHITS_TABLE_FORECAST_PS"}
]

REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "newyork", "northwest", "southwest", "southeast", "tennessee", "texas"
]

# --- Main Execution Logic ---

def download_and_aggregate_forecasts():
    """
    Downloads, aggregates, and saves the latest N-HiTS forecasts for all types and regions.
    """
    print("=" * 80)
    print(" N-HiTS Forecast Download and Aggregation Script")
    print("=" * 80)
    
    engine = None
    try:
        print(f"Connecting to database: gasstosbxarmservus2001...")
        engine = create_engine(DB_CONNECTION_STRING)
        print("✓ Connection successful.")

        # Loop through each forecast type (NG, Coal, etc.)
        for task in TASKS:
            table_name = task['table_name']
            task_name = task['name']
            print(f"\n{'='*60}\n--- Processing Task: {task_name} (Table: {table_name}) ---\n{'='*60}")

            # 1. Find the three most recent publication dates for the current task
            print("1. Finding the three latest forecast publication dates...")
            latest_dates_query = f"""
                SELECT DISTINCT TOP 3 date_published 
                FROM {table_name} 
                ORDER BY date_published DESC
            """
            latest_dates_df = pd.read_sql(latest_dates_query, engine)

            if latest_dates_df.empty:
                print(f"   ✗ No publication dates found for '{task_name}'. Skipping.")
                continue
            
            latest_dates_list = pd.to_datetime(latest_dates_df['date_published']).dt.strftime('%Y-%m-%d').tolist()
            print(f"   ✓ Found publication dates: {', '.join(latest_dates_list)}")

            # 2. Download all hourly data for those three dates
            print("2. Downloading all hourly forecast data for these dates...")
            dates_for_sql = "','".join(latest_dates_list)
            data_query = f"""
                SELECT datetime, region, date_published, forecast_mw 
                FROM {table_name} 
                WHERE date_published IN ('{dates_for_sql}')
            """
            df_hourly = pd.read_sql(data_query, engine, parse_dates=['datetime'])

            if df_hourly.empty:
                print(f"   ✗ No forecast data found for the latest dates. Skipping.")
                continue
            
            print(f"   ✓ Downloaded {len(df_hourly)} total hourly records.")

            # 3. Process and save data for each region
            print("3. Aggregating and saving data for each region...")
            for region_name in REGIONS:
                # Filter data for the current region
                df_region = df_hourly[df_hourly['region'].str.lower() == region_name.lower()].copy()

                if df_region.empty:
                    continue # Skip if no data for this region in the download

                print(f"   - Processing {region_name.capitalize()}...")
                output_folder = os.path.join(BASE_OUTPUT_DIR, region_name)
                os.makedirs(output_folder, exist_ok=True)

                # Convert MW to GWh for aggregation (sum of MW over time / 1000)
                df_region['forecast_mwh'] = df_region['forecast_mw'] / 1

                # --- Daily Aggregation ---
                df_region['date'] = df_region['datetime'].dt.date
                df_daily = df_region.groupby(['date', 'date_published']).agg(
                    total_gwh=('forecast_mwh', 'sum')
                ).reset_index()
                
                daily_output_path = os.path.join(output_folder, f"forecast_daily_{task_name.lower().replace(' ', '_')}.csv")
                df_daily.to_csv(daily_output_path, index=False)
                print(f"     ✓ Saved daily data to: {os.path.basename(daily_output_path)}")

                # --- Monthly Aggregation ---
                df_region['month'] = df_region['datetime'].dt.to_period('M')
                df_monthly = df_region.groupby(['month', 'date_published']).agg(
                    total_gwh=('forecast_mwh', 'sum')
                ).reset_index()
                df_monthly['month'] = df_monthly['month'].astype(str) # Convert period to string for CSV

                monthly_output_path = os.path.join(output_folder, f"forecast_monthly_{task_name.lower().replace(' ', '_')}.csv")
                df_monthly.to_csv(monthly_output_path, index=False)
                print(f"     ✓ Saved monthly data to: {os.path.basename(monthly_output_path)}")

    except SQLAlchemyError as e:
        print(f"\nFATAL ERROR: A database error occurred: {e}")
        traceback.print_exc()
    except Exception as e:
        print(f"\nFATAL ERROR: An unexpected error occurred: {e}")
        traceback.print_exc()
    finally:
        if engine:
            engine.dispose()
            print("\n✓ Database connection closed.")
        print("\nScript execution finished.")

if __name__ == "__main__":
    download_and_aggregate_forecasts()