import pandas as pd
import os
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define output directory on D drive
OUTPUT_DIR = r"D:\EIA_STACK\storage_consolidated"

def ensure_output_directory():
    """Create output directory if it doesn't exist"""
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        logging.info(f"Created output directory: {OUTPUT_DIR}")

def process_storage_files_to_consolidated(input_folder="east", output_filename=None):
    """
    Processes all CSV files in the input folder, aggregates scheduled_quantity_sign_adj 
    by eff_gas_day for each facility, and creates a consolidated file with all facilities 
    as columns and dates as rows.
    
    Args:
        input_folder (str): Folder containing the individual storage facility CSV files
        output_filename (str): Name of the consolidated output CSV file (if None, auto-generated)
    """
    
    # Ensure output directory exists
    ensure_output_directory()
    
    # Auto-generate output filename if not provided
    if output_filename is None:
        output_filename = f"{input_folder}_consolidated_storage.csv"
    
    # Full path for output file
    output_path = os.path.join(OUTPUT_DIR, output_filename)
    
    # Check if input folder exists
    if not os.path.exists(input_folder):
        logging.error(f"Input folder '{input_folder}' does not exist!")
        return
    
    # Get all CSV files in the folder
    csv_files = [f for f in os.listdir(input_folder) if f.endswith('.csv')]
    
    if not csv_files:
        logging.warning(f"No CSV files found in '{input_folder}' folder!")
        return
    
    logging.info(f"Found {len(csv_files)} CSV files to process")
    
    # Dictionary to store processed data for each facility
    facility_data = {}
    
    # Process each CSV file
    for csv_file in csv_files:
        file_path = os.path.join(input_folder, csv_file)
        facility_name = csv_file.replace('.csv', '').replace('_', ' ')  # Clean up facility name
        
        try:
            logging.info(f"Processing {csv_file}...")
            
            # Read the CSV file
            df = pd.read_csv(file_path)
            
            # Check if required columns exist
            if 'eff_gas_day' not in df.columns or 'scheduled_quantity_sign_adj' not in df.columns:
                logging.warning(f"Required columns missing in {csv_file}. Skipping...")
                continue
            
            # Convert eff_gas_day to datetime
            df['eff_gas_day'] = pd.to_datetime(df['eff_gas_day'])
            
            # Handle missing values in scheduled_quantity_sign_adj
            df['scheduled_quantity_sign_adj'] = pd.to_numeric(df['scheduled_quantity_sign_adj'], errors='coerce')
            
            # Group by eff_gas_day and sum scheduled_quantity_sign_adj
            aggregated = df.groupby('eff_gas_day')['scheduled_quantity_sign_adj'].sum().reset_index()
            
            # Store the aggregated data
            facility_data[facility_name] = aggregated.set_index('eff_gas_day')['scheduled_quantity_sign_adj']
            
            logging.info(f"Successfully processed {csv_file}: {len(aggregated)} unique dates")
            
        except Exception as e:
            logging.error(f"Error processing {csv_file}: {str(e)}")
            continue
    
    if not facility_data:
        logging.error("No data was successfully processed from any files!")
        return
    
    # Create consolidated DataFrame
    logging.info("Creating consolidated DataFrame...")
    
    # Combine all facility data into a single DataFrame
    consolidated_df = pd.DataFrame(facility_data)
    
    # Reset index to make eff_gas_day a column
    consolidated_df.reset_index(inplace=True)
    
    # Sort by date
    consolidated_df.sort_values('eff_gas_day', inplace=True)
    
    # Fill NaN values with 0 (for dates where a facility has no data)
    consolidated_df.fillna(0, inplace=True)
    
    # Save to CSV in D drive directory
    consolidated_df.to_csv(output_path, index=False)
    
    logging.info(f"Consolidated data saved to '{output_path}'")
    logging.info(f"Final dataset shape: {consolidated_df.shape}")
    logging.info(f"Date range: {consolidated_df['eff_gas_day'].min()} to {consolidated_df['eff_gas_day'].max()}")
    logging.info(f"Facilities included: {list(consolidated_df.columns[1:])}")  # Skip eff_gas_day column
    
    # Display summary statistics
    print("\n=== CONSOLIDATION SUMMARY ===")
    print(f"Total files processed: {len(facility_data)}")
    print(f"Total unique dates: {len(consolidated_df)}")
    print(f"Output directory: {OUTPUT_DIR}")
    print(f"Output CSV file: {output_path}")
    print(f"Facilities: {len(consolidated_df.columns)-1}")  # -1 for eff_gas_day column
    
    # Show a sample of the data
    print(f"\nSample of consolidated data (first 5 rows):")
    print(consolidated_df.head())
    
    return consolidated_df

def analyze_data_completeness(input_folder="east"):
    """
    Analyzes the completeness and overlap of data across all storage facilities.
    """
    
    if not os.path.exists(input_folder):
        print(f"Input folder '{input_folder}' does not exist!")
        return
        
    csv_files = [f for f in os.listdir(input_folder) if f.endswith('.csv')]
    
    print("\n=== DATA COMPLETENESS ANALYSIS ===")
    
    for csv_file in csv_files:
        file_path = os.path.join(input_folder, csv_file)
        facility_name = csv_file.replace('.csv', '')
        
        try:
            df = pd.read_csv(file_path)
            
            if 'eff_gas_day' not in df.columns or 'scheduled_quantity_sign_adj' not in df.columns:
                continue
                
            df['eff_gas_day'] = pd.to_datetime(df['eff_gas_day'])
            
            # Count duplicates per day
            daily_counts = df.groupby('eff_gas_day').size()
            duplicate_days = daily_counts[daily_counts > 1]
            
            print(f"\n{facility_name}:")
            print(f"  Total rows: {len(df)}")
            print(f"  Unique dates: {len(daily_counts)}")
            print(f"  Days with multiple entries: {len(duplicate_days)}")
            if len(duplicate_days) > 0:
                print(f"  Max entries per day: {duplicate_days.max()}")
                print(f"  Example duplicate days: {duplicate_days.head(3).index.strftime('%Y-%m-%d').tolist()}")
            
        except Exception as e:
            print(f"\nError analyzing {facility_name}: {str(e)}")

def process_all_regions():
    """
    Process all region folders if they exist
    """
    regions = ['east', 'midwest', 'mountain', 'pacific', 'southcentral']
    
    print("\n=== PROCESSING ALL REGIONS ===")
    ensure_output_directory()
    
    for region in regions:
        if os.path.exists(region):
            print(f"\n--- Processing {region.upper()} region ---")
            process_storage_files_to_consolidated(region)
        else:
            print(f"\nRegion folder '{region}' not found, skipping...")
    
    print(f"\n=== ALL REGIONS PROCESSED ===")
    print(f"All consolidated files saved to: {OUTPUT_DIR}")

if __name__ == "__main__":
    logging.info("=== Starting Storage Data Consolidation ===")
    
    # Process a single region (change as needed)
    region_to_process = "east"  # Change this to your desired region
    
    # First, analyze the data completeness
    analyze_data_completeness(region_to_process)
    
    # Then consolidate the data
    consolidated_data = process_storage_files_to_consolidated(region_to_process)
    
    # Uncomment the line below to process ALL regions at once
    # process_all_regions()
    
    if consolidated_data is not None:
        logging.info("=== Consolidation completed successfully ===")
        print(f"\nFiles saved to: {OUTPUT_DIR}")
    else:
        logging.error("=== Consolidation failed ===")