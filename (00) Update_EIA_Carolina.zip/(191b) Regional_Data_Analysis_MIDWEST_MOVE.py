"""
Script to rename columns in MIDWEST_filtered.csv to more sensible names
Loads from D:\EIA_STACK\Pricing_RL\MIDWEST\MIDWEST_filtered.csv
Outputs to D:\EIA_STACK\Pricing_RL\MIDWEST\HTML\
"""

import pandas as pd
import os
from datetime import datetime

# Define file paths
INPUT_FILE = r"D:\EIA_STACK\Pricing_RL\MIDWEST\MIDWEST_filtered.csv"
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\MIDWEST\HTML"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "midwest_features_renamed.csv")

# Column renaming dictionary
COLUMN_MAPPING = {
    'date': 'Date',
    'midwestconsolid_BCF_ANR Pipeline': 'Storage_ANR_Pipeline',
    'midwestconsolid_BCF_ANR Storage': 'Storage_ANR_Storage',
    'midwestconsolid_BCF_Atmos': 'Storage_Atmos',
    'midwestconsolid_BCF_Barnsley': 'Storage_Barnsley',
    'midwestconsolid_BCF_Bell River Mills': 'Storage_Bell_River_Mills',
    'midwestconsolid_BCF_Bluewater': 'Storage_Bluewater',
    'midwestconsolid_BCF_Blue Lake': 'Storage_Blue_Lake',
    'midwestconsolid_BCF_Eaton Rapids': 'Storage_Eaton_Rapids',
    'midwestconsolid_BCF_Kimball 27': 'Storage_Kimball_27',
    'midwestconsolid_BCF_Lee 8': 'Storage_Lee_8',
    'midwestconsolid_BCF_NGPL': 'Storage_NGPL',
    'midwestconsolid_BCF_Northern Natural Gas': 'Storage_Northern_Natural_Gas',
    'midwestconsolid_BCF_Ohio Valley Hub': 'Storage_Ohio_Valley_Hub',
    'midwestconsolid_BCF_SWGS East': 'Storage_SWGS_East',
    'midwestconsolid_BCF_Texas Gas': 'Storage_Texas_Gas',
    'midwestconsolid_BCF_Washington 10': 'Storage_Washington_10',
    'midwestconsolid_BCF_White River': 'Storage_White_River',
    'synmaxproductio_DRY_GAS_BCF_DAY': 'Production_Dry_Gas_BCF',
    'midwestresident_MIDWEST_Residential_hourly_MMcf_BCF': 'MW_Residential_BCF',
    'weatherMIDWEST_gas_hdd': 'Weather_HDD',
    'weatherMIDWEST_population_cdd': 'Weather_Pop_CDD',
    'CENTRAL_TOTAL_BCF': 'Demand_Central_BCF',
    'MIDWEST_TOTAL_BCF': 'Demand_Midwest_BCF',
    'MIDWEST_GRAND_TOTAL_BCF': 'Demand_Midwest_Grand_Total_BCF'
}

def main():
    """Main function to rename Midwest columns"""
    
    print("="*60)
    print("MIDWEST COLUMN RENAMER")
    print("="*60)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output directory: {OUTPUT_DIR}")
    
    try:
        # 1. Load the data
        print(f"\n1. Loading data from: {INPUT_FILE}")
        df = pd.read_csv(INPUT_FILE)
        print(f"   Loaded {len(df)} rows and {len(df.columns)} columns")
        
        # 2. Display original column names
        print("\n2. Original column names:")
        for i, col in enumerate(df.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 3. Rename columns
        print("\n3. Renaming columns...")
        df_renamed = df.rename(columns=COLUMN_MAPPING)
        
        # 4. Display new column names
        print("\n4. New column names:")
        for i, col in enumerate(df_renamed.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 5. Convert date column to datetime if it exists
        if 'Date' in df_renamed.columns:
            print("\n5. Converting Date column to datetime format...")
            df_renamed['Date'] = pd.to_datetime(df_renamed['Date'])
            print(f"   Date range: {df_renamed['Date'].min().date()} to {df_renamed['Date'].max().date()}")
        
        # 6. Save the renamed file
        print(f"\n6. Saving renamed file to: {OUTPUT_FILE}")
        df_renamed.to_csv(OUTPUT_FILE, index=False, float_format='%.4f')
        print(f"   Successfully saved {len(df_renamed)} rows")
        
        # 7. Print summary statistics
        print("\n" + "="*60)
        print("SUMMARY STATISTICS")
        print("="*60)
        
        # Storage facilities
        storage_cols = [col for col in df_renamed.columns if col.startswith('Storage_')]
        if storage_cols:
            print(f"\nStorage Facilities ({len(storage_cols)} total):")
            total_storage_avg = 0
            for col in storage_cols:
                mean_val = df_renamed[col].mean()
                total_storage_avg += mean_val
                print(f"  {col}: Avg = {mean_val:.2f}")
            print(f"\n  TOTAL STORAGE AVERAGE: {total_storage_avg:.2f} BCF")
        
        # Demand metrics
        demand_cols = [col for col in df_renamed.columns if col.startswith('Demand_')]
        if demand_cols:
            print(f"\nRegional Demand Metrics:")
            for col in demand_cols:
                mean_val = df_renamed[col].mean()
                min_val = df_renamed[col].min()
                max_val = df_renamed[col].max()
                print(f"  {col}:")
                print(f"    Average: {mean_val:.2f} BCF")
                print(f"    Range: {min_val:.2f} to {max_val:.2f} BCF")
        
        # Midwest Residential
        if 'MW_Residential_BCF' in df_renamed.columns:
            print(f"\nMidwest Residential Demand:")
            print(f"  Average: {df_renamed['MW_Residential_BCF'].mean():.2f} BCF")
            print(f"  Range: {df_renamed['MW_Residential_BCF'].min():.2f} to {df_renamed['MW_Residential_BCF'].max():.2f} BCF")
        
        # Production
        if 'Production_Dry_Gas_BCF' in df_renamed.columns:
            print(f"\nProduction:")
            print(f"  Dry Gas Average: {df_renamed['Production_Dry_Gas_BCF'].mean():.2f} BCF/day")
            print(f"  Dry Gas Range: {df_renamed['Production_Dry_Gas_BCF'].min():.2f} to {df_renamed['Production_Dry_Gas_BCF'].max():.2f} BCF/day")
        
        # Weather
        weather_cols = [col for col in df_renamed.columns if col.startswith('Weather_')]
        if weather_cols:
            print("\nWeather Metrics:")
            for col in weather_cols:
                mean_val = df_renamed[col].mean()
                print(f"  {col}: Avg = {mean_val:.2f}")
        
        print("\n" + "="*60)
        print("✅ COLUMN RENAMING COMPLETE!")
        print("="*60)
        
        # Create a mapping reference file
        mapping_file = os.path.join(OUTPUT_DIR, "midwest_column_mapping.txt")
        print(f"\n7. Creating column mapping reference: {mapping_file}")
        
        with open(mapping_file, 'w') as f:
            f.write("MIDWEST COLUMN MAPPING REFERENCE\n")
            f.write("=" * 60 + "\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("ORIGINAL COLUMN NAME --> NEW COLUMN NAME\n")
            f.write("-" * 60 + "\n")
            
            for old_name, new_name in COLUMN_MAPPING.items():
                f.write(f"{old_name}\n  --> {new_name}\n\n")
            
            f.write("-" * 60 + "\n")
            f.write(f"Total columns renamed: {len(COLUMN_MAPPING)}\n")
            f.write(f"Input file: {INPUT_FILE}\n")
            f.write(f"Output file: {OUTPUT_FILE}\n")
        
        print("   Column mapping reference saved")
        
        return df_renamed
        
    except FileNotFoundError as e:
        print(f"\n❌ ERROR: File not found - {e}")
        return None
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    # Run the renaming
    renamed_data = main()
    
    if renamed_data is not None:
        print(f"\n✅ Output saved to: {OUTPUT_FILE}")
    else:
        print("\n❌ Script failed. Check error messages above.")