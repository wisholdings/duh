# -*- coding: utf-8 -*-
import os
import pandas as pd
import sys
import json
import traceback

# --- Configuration Loading ---
try:
    # Try to get the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    from config.settings import BASE_OUTPUT_DIR
    print(f"Loaded BASE_OUTPUT_DIR from config: {BASE_OUTPUT_DIR}")
except (ImportError, NameError, FileNotFoundError) as e:
    print(f"Could not import BASE_OUTPUT_DIR from config.settings ({e}). Using default.")
    # Fallback if __file__ is not defined (e.g. in interactive env) or config is missing
    current_dir_for_default = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
    project_root_for_default = os.path.abspath(os.path.join(current_dir_for_default, '..'))
    BASE_OUTPUT_DIR = os.path.join(project_root_for_default, "EIA_STACK") # Try standard default name
    if not os.path.exists(BASE_OUTPUT_DIR): # If standard default does not exist, use a more generic one or a hardcoded fallback
         BASE_OUTPUT_DIR = os.path.join(project_root_for_default, "EIA_STACK_DEFAULT") # A more generic default name
    # Example of an absolute fallback if truly needed, but dynamic is better
    # if not os.path.exists(BASE_OUTPUT_DIR):
    #      BASE_OUTPUT_DIR = "D:\\EIA_STACK" 
    print(f"Using default/fallback BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")

# --- Load Regions Configuration ---
try:
    script_dir_for_regions = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
    project_root = os.path.abspath(os.path.join(script_dir_for_regions, '..'))
    paths_to_check = [
        os.path.join(project_root, 'config', 'regions.json'),
        os.path.join(script_dir_for_regions, 'config', 'regions.json'), # Sibling 'config' folder
        os.path.join('config', 'regions.json') # Relative to CWD
    ]
    regions_config_path = None
    for path in paths_to_check:
        if os.path.exists(path):
            regions_config_path = path
            print(f"Found regions config at: {regions_config_path}")
            break
    if regions_config_path:
        with open(regions_config_path, 'r') as f:
            regions_data = json.load(f) # regions_data is expected to be a dict or list of region names
        print("Successfully loaded regions config.")
    else:
        raise FileNotFoundError("Core regions config file 'config/regions.json' not found in standard locations.")
except FileNotFoundError as e:
    print(f"Error: {e}")
    print("Exiting due to missing critical regions configuration.")
    sys.exit(1)
except Exception as e:
    print(f"Error loading regions config: {e}")
    traceback.print_exc()
    sys.exit(1)

# --- Define Fuel Type Calculation Parameters ---
# Each dict defines the columns needed for a specific fuel type's MW calculation.
fuel_calculations_config = [
    {
        "fuel_name": "COAL",
        "ratio_suffix": "_COAL_RATIO",
        "capacity_suffix": "_Total_Capacity_Coal",
        "mw_suffix": "_COL_MW"
    },
    {
        "fuel_name": "NATURAL GAS",
        "ratio_suffix": "_NG_RATIO",
        "capacity_suffix": "_Total_Capacity_Naturalgas",
        "mw_suffix": "_NG_MW"
    },
    {
        "fuel_name": "NUCLEAR",
        "ratio_suffix": "_NUCLEAR_RATIO",
        "capacity_suffix": "_Total_Capacity_Nuclear",
        "mw_suffix": "_NUC_MW"
    },
    {
        "fuel_name": "OTHER",
        "ratio_suffix": "_OTH_RATIO",
        "capacity_suffix": "_Total_Capacity_Other",
        "mw_suffix": "_OTH_MW"
    },
    {
        "fuel_name": "SOLAR",
        "ratio_suffix": "_SOLAR_RATIO", # Or _SUN_RATIO, adjust if needed
        "capacity_suffix": "_Total_Capacity_Solar",
        "mw_suffix": "_SUN_MW"
    },
    {
        "fuel_name": "WIND",
        "ratio_suffix": "_WIND_RATIO",
        "capacity_suffix": "_Total_Capacity_Wind",
        "mw_suffix": "_WND_MW"
    },
    {
        "fuel_name": "HYDRO",
        "ratio_suffix": "_HYDRO_RATIO",
        "capacity_suffix": "_Total_Capacity_Hydroelectric",
        "mw_suffix": "_WAT_MW"
    },
    {
        "fuel_name": "PS",
        "ratio_suffix": "_PS_RATIO",
        "capacity_suffix": "_Total_Capacity_Pumped_Storage",
        "mw_suffix": "_PS_MW"
    },
    {
        "fuel_name": "Bat",
        "ratio_suffix": "_BATTERIES_RATIO",
        "capacity_suffix": "_Total_Capacity_Batteries",
        "mw_suffix": "_BAT_MW"
    }
]

# --- Import required libraries for unscaling ---
try:
    import numpy as np
    NUMPY_AVAILABLE = True
    print("NumPy available for interchange unscaling.")
except ImportError:
    NUMPY_AVAILABLE = False
    print("Warning: NumPy not available. INTERCHANGE_RATIO unscaling will be skipped.")

def unscale_interchange_predictions(df, region_name, base_output_dir):
    """
    Unscale INTERCHANGE_RATIO predictions knowing they were scaled to [-1, 1].
    Uses the original MW data to determine the scaling factor that was used.
    Saves the result as {REGION}_INTERCHANGE_MW.
    """
    if not NUMPY_AVAILABLE:
        print(f"    NumPy not available. Skipping INTERCHANGE_RATIO unscaling for {region_name}.")
        return df, False
    
    region_upper = region_name.upper()
    interchange_ratio_col = f"{region_upper}_INTERCHANGE_RATIO"
    interchange_mw_col = f"{region_upper}_INTERCHANGE_MW"
    
    # Check if INTERCHANGE_RATIO column exists
    if interchange_ratio_col not in df.columns:
        print(f"    No {interchange_ratio_col} column found. Skipping unscaling.")
        return df, False
    
    # Look for the original MW data to determine the scaling factor
    # Try to find the original complete file with unscaled MW data
    original_file_path = os.path.join(base_output_dir, region_name, "final", f"{region_name.title()}_complete_finished.parquet")
    
    if not os.path.exists(original_file_path):
        print(f"    Original file not found at {original_file_path}. Cannot determine scaling factor.")
        return df, False
    
    try:
        # Load the original file to get the MW data range
        print(f"    Loading original file to determine scaling factor: {os.path.basename(original_file_path)}")
        original_df = pd.read_parquet(original_file_path)
        
        if interchange_mw_col not in original_df.columns:
            print(f"    No {interchange_mw_col} column found in original file. Cannot determine scaling factor.")
            return df, False
        
        # Get the MW values and calculate the scaling factor that was used
        mw_values = pd.to_numeric(original_df[interchange_mw_col], errors='coerce').dropna()
        
        if mw_values.empty:
            print(f"    No valid MW values found in {interchange_mw_col}. Cannot determine scaling factor.")
            return df, False
        
        # Calculate the maximum absolute value (this was used for scaling to [-1, 1])
        max_abs_mw = max(abs(mw_values.min()), abs(mw_values.max()))
        
        print(f"    Original MW range: [{mw_values.min():.2f}, {mw_values.max():.2f}]")
        print(f"    Calculated scaling factor (max_abs): {max_abs_mw:.2f}")
        
        # Get non-null values to unscale
        non_null_mask = df[interchange_ratio_col].notna()
        if not non_null_mask.any():
            print(f"    No valid values found in {interchange_ratio_col}. Skipping unscaling.")
            return df, False
        
        # Apply inverse transformation: MW = ratio * max_abs
        scaled_values = df.loc[non_null_mask, interchange_ratio_col]
        unscaled_values = scaled_values * max_abs_mw
        
        # Update the dataframe - create new MW column and optionally remove ratio column
        df_updated = df.copy()
        df_updated[interchange_mw_col] = np.nan  # Initialize the MW column
        df_updated.loc[non_null_mask, interchange_mw_col] = unscaled_values
        
        # Report the transformation
        original_range = f"[{scaled_values.min():.4f}, {scaled_values.max():.4f}]"
        unscaled_range = f"[{unscaled_values.min():.2f}, {unscaled_values.max():.2f}]"
        valid_count = non_null_mask.sum()
        
        print(f"    ✅ Created {interchange_mw_col} with {valid_count} unscaled values")
        print(f"       Ratio range: {original_range} → MW range: {unscaled_range}")
        
        return df_updated, True
        
    except Exception as e:
        print(f"    Error unscaling {interchange_ratio_col}: {e}")
        traceback.print_exc()
        return df, False

print("\n--- Starting MW Calculations in predict_staging.csv ---")

# --- Process each region ---
# Assuming regions_data is a dictionary where keys are region names, or a list of region names.
region_keys = list(regions_data.keys()) if isinstance(regions_data, dict) else regions_data

for region_name in region_keys:
    try:
        print(f"\nProcessing region: {region_name.upper()}")
        region_upper = region_name.upper()  # For ratio and MW columns (TEXAS_COAL_RATIO)
        region_title = region_name.title()  # For capacity columns (Texas_Total_Capacity_Coal)

        # Construct the path to the predict_staging.csv file
        csv_path = os.path.join(BASE_OUTPUT_DIR, region_name, 'final', 'predict_staging.csv')
        
        if not os.path.exists(csv_path):
            print(f"  predict_staging.csv file not found for region {region_name} at {csv_path}. Skipping.")
            continue

        # Load the CSV file once per region
        print(f"  Loading predict_staging.csv file: {csv_path}")
        df = None # Initialize df
        try:
            df = pd.read_csv(csv_path)
            # Ensure 'date' is datetime if it exists
            if 'date' in df.columns and not pd.api.types.is_datetime64_any_dtype(df['date']):
                try:
                    df['date'] = pd.to_datetime(df['date'])
                    print(f"    Converted 'date' column to datetime for {csv_path}")
                except Exception as e_date_conv:
                    print(f"    Warning: Could not convert 'date' column in {csv_path} to datetime: {e_date_conv}. Proceeding with original type.")

        except Exception as e_read:
            print(f"    Error reading CSV file {csv_path}: {e_read}. Skipping region.")
            traceback.print_exc()
            continue
        
        if df is None or df.empty:
            print(f"    DataFrame for {region_name} is empty or failed to load. Skipping calculations.")
            continue

        # Log existing MW columns for debugging
        expected_mw_cols = [f"{region_upper}{calc['mw_suffix']}" for calc in fuel_calculations_config]
        existing_mw_cols = [col for col in df.columns if col in expected_mw_cols]
        if existing_mw_cols:
            print(f"    Existing MW columns found: {existing_mw_cols}")
        
        df_changed_in_region = False # Flag to track if any MW column was updated for this region

        # Iterate through each fuel type calculation defined
        for calc_config in fuel_calculations_config:
            fuel_name = calc_config["fuel_name"]
            ratio_col = f"{region_upper}{calc_config['ratio_suffix']}"
            capacity_col = f"{region_title}{calc_config['capacity_suffix']}"
            mw_col = f"{region_upper}{calc_config['mw_suffix']}"

            print(f"    Attempting calculation for {fuel_name} ({mw_col})...")

            # Check if required input columns exist for this fuel type
            required_input_cols = [ratio_col, capacity_col]
            missing_input_cols = [col for col in required_input_cols if col not in df.columns]

            if missing_input_cols:
                print(f"      Skipping {fuel_name} MW calculation: Missing input columns {missing_input_cols} in {csv_path}.")
                continue
            
            # Ensure columns are numeric before multiplication
            try:
                df[ratio_col] = pd.to_numeric(df[ratio_col], errors='coerce')
                df[capacity_col] = pd.to_numeric(df[capacity_col], errors='coerce')
                
                # Check for full NaN columns after coercion, which might indicate bad data
                if df[ratio_col].isnull().all():
                    print(f"      Warning: Column '{ratio_col}' became all NaNs after numeric conversion.")
                if df[capacity_col].isnull().all():
                    print(f"      Warning: Column '{capacity_col}' became all NaNs after numeric conversion.")

            except Exception as e_numeric:
                print(f"      Error converting columns to numeric for {fuel_name} ({ratio_col}, {capacity_col}): {e_numeric}. Skipping this calculation.")
                continue

            # Check if the multiplication would result in meaningful data
            # Skip if both columns are all NaN or if the result would be all NaN
            ratio_has_data = not df[ratio_col].isnull().all()
            capacity_has_data = not df[capacity_col].isnull().all()
            
            if not ratio_has_data or not capacity_has_data:
                print(f"      Skipping {fuel_name} MW calculation: One or both input columns contain no valid data.")
                continue
            
            # Perform a test multiplication to see if we get any non-NaN results
            test_result = df[ratio_col] * df[capacity_col]
            if test_result.isnull().all():
                print(f"      Skipping {fuel_name} MW calculation: Multiplication would result in all NaN values.")
                continue

            # Perform the multiplication
            print(f"      Calculating: {mw_col} = {ratio_col} * {capacity_col}")
            df[mw_col] = df[ratio_col] * df[capacity_col]
            df_changed_in_region = True
            
            # Report how many valid values were created
            valid_count = df[mw_col].notna().sum()
            total_count = len(df[mw_col])
            print(f"      Successfully calculated {mw_col}. {valid_count}/{total_count} rows have valid values.")

        # --- NEW: Unscale INTERCHANGE_RATIO predictions after MW calculations ---
        print(f"  🔄 Attempting to unscale INTERCHANGE_RATIO predictions...")
        if NUMPY_AVAILABLE:
            df, interchange_unscaled = unscale_interchange_predictions(df, region_name, BASE_OUTPUT_DIR)
            if interchange_unscaled:
                df_changed_in_region = True  # Mark that we made changes
                print(f"  ✅ INTERCHANGE_RATIO predictions unscaled successfully.")
            else:
                print(f"  ⚠️  INTERCHANGE_RATIO unscaling skipped (no original file found or no data).")
        else:
            interchange_unscaled = False
            print(f"  ⚠️  INTERCHANGE_RATIO unscaling skipped (NumPy not available).")

        # Save the updated DataFrame back to the CSV file if any changes were made
        if df_changed_in_region:
            print(f"  Saving updated data to {csv_path}")
            
            # Before saving, verify that we didn't accidentally create any empty MW columns
            # Get all MW columns that were supposed to be created
            expected_mw_cols = [f"{region_upper}{calc['mw_suffix']}" for calc in fuel_calculations_config]
            existing_mw_cols = [col for col in df.columns if col in expected_mw_cols]
            
            # Check for and remove any MW columns that are completely empty or all NaN
            cols_to_remove = []
            for mw_col in existing_mw_cols:
                if mw_col in df.columns:
                    if df[mw_col].isnull().all() or len(df[mw_col].dropna()) == 0:
                        cols_to_remove.append(mw_col)
                        print(f"    Warning: Removing empty MW column {mw_col} before saving.")
            
            if cols_to_remove:
                df = df.drop(columns=cols_to_remove)
                print(f"    Removed {len(cols_to_remove)} empty MW columns: {cols_to_remove}")
            
            try:
                df.to_csv(
                    csv_path,
                    index=False
                )
                print(f"  Successfully saved updated predict_staging.csv for {region_name}.")
                if interchange_unscaled:
                    print(f"  📊 File now contains {region_upper}_INTERCHANGE_MW alongside other MW calculations.")
            except Exception as e_save:
                print(f"    Error saving updated predict_staging.csv for {region_name}: {e_save}")
                traceback.print_exc()
        else:
            print(f"  No MW calculations performed or changed data for {region_name}. CSV file not re-saved.")

    except Exception as e:
        print(f"  Major error processing region {region_name}: {e}")
        print(traceback.format_exc())
        # Continue to the next region

print("\n--- All region processing complete. ---")