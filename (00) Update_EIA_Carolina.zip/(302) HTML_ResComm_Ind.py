import os
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import traceback

# --- Configuration ---
DB_CONNECTION_STRING = (
)
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"

# List of consumption types to process, derived from your script
CONSUMPTION_TYPES = ["residential", "commercial", "industrial"]

# --- Main Logic ---

def download_latest_forecasts():
    """
    Downloads forecast data from the last 3 publication dates for each 
    consumption type and saves it to a CSV file.
    """
    print("\n" + "="*80)
    print("   DOWNLOADING LATEST REGIONAL CONSUMPTION FORECASTS (LAST 3 RUNS)")
    print("="*80)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Database: gasstosbxarmservus2001")
    print(f"Output Directory: {os.path.abspath(OUTPUT_DIR)}")
    print("="*80)
    
    download_summary = []
    engine = None

    try:
        engine = create_engine(DB_CONNECTION_STRING)
        
        for consumption_type in CONSUMPTION_TYPES:
            consumption_cap = consumption_type.capitalize()
            table_name = f"FORECAST_{consumption_type.upper()}_BURNS_REGIONAL_HYBRID"
            
            print(f"\n{'='*40}")
            print(f"Processing: {consumption_cap} Sector")
            print(f"{'='*40}")
            print(f"🗃️  Source Table: {table_name}")

            try:
                # Step 1: Find the three most recent 'date_published' values
                latest_dates_query = f"""
                    SELECT DISTINCT TOP 3 date_published 
                    FROM {table_name} 
                    ORDER BY date_published DESC
                """
                latest_dates_df = pd.read_sql(latest_dates_query, engine)

                if latest_dates_df.empty:
                    print(f"    ✗ No data found in table '{table_name}'. Skipping.")
                    download_summary.append((consumption_cap, "SKIPPED", "No data in table"))
                    continue
                
                # Convert to datetime to prevent errors and format for query
                latest_dates_list = pd.to_datetime(latest_dates_df['date_published']).dt.strftime('%Y-%m-%d').tolist()
                print(f"    ✓ Found latest publish dates: {', '.join(latest_dates_list)}")

                # Step 2: Fetch all data for those three publication dates
                dates_for_sql = "','".join(latest_dates_list)
                data_query = f"""
                    SELECT * 
                    FROM {table_name} 
                    WHERE date_published IN ('{dates_for_sql}')
                    ORDER BY date_published, datetime
                """
                df = pd.read_sql(data_query, engine)

                if df.empty:
                    print(f"    ✗ No forecast data found for the latest dates. Skipping.")
                    download_summary.append((consumption_cap, "SKIPPED", "No data for latest dates"))
                    continue
                
                print(f"    ✓ Downloaded {len(df)} rows of forecast data.")

                # Step 3: Save the data to a CSV file
                output_filename = f"forecast_{consumption_type}_burns.csv"
                output_filepath = os.path.join(OUTPUT_DIR, output_filename)
                
                df.to_csv(output_filepath, index=False)
                print(f"    ✓ Successfully saved data to: {output_filepath}")
                download_summary.append((consumption_cap, "SUCCESS", f"{len(df)} rows saved"))

            except SQLAlchemyError as e:
                print(f"    ✗ SQL Error processing {consumption_cap}: {e}")
                download_summary.append((consumption_cap, "FAILED", "SQL Error"))
            except Exception as e:
                print(f"    ✗ An unexpected error occurred for {consumption_cap}: {e}")
                download_summary.append((consumption_cap, "FAILED", str(e)))

    except Exception as e:
        print(f"\nFATAL ERROR: Could not connect to the database.")
        print(f"  -> Reason: {e}")
        traceback.print_exc()
    finally:
        if engine:
            engine.dispose()
            print("\n    ✓ Database connection closed")

    # --- Final Summary ---
    print("\n" + "="*80)
    print("DOWNLOAD SUMMARY")
    print("="*80)
    
    for sector, status, details in download_summary:
        status_symbol = "✓" if status == "SUCCESS" else "✗"
        print(f"  {status_symbol} {sector:12s}: {status:8s} - {details}")
    
    print("\n" + "="*80)
    print("✅ Script completed!")
    print("="*80)

# --- Execute the Script ---
if __name__ == "__main__":
    download_latest_forecasts()