"""
Script to rename columns in EAST_filtered.csv to more sensible names
Loads from D:\EIA_STACK\Pricing_RL\EAST\EAST_filtered.csv
Outputs to D:\EIA_STACK\Pricing_RL\EAST\HTML\
"""

import pandas as pd
import os
from datetime import datetime

# Define file paths
INPUT_FILE = r"D:\EIA_STACK\Pricing_RL\EAST\EAST_filtered.csv"
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\EAST\HTML"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "east_features_renamed.csv")

# Column renaming dictionary
COLUMN_MAPPING = {
    'date': 'Date',
    'eastconsolidate_BCF_Accident': 'Storage_Accident',
    'eastconsolidate_BCF_Columbia Gas Storage': 'Storage_Columbia_Gas',
    'eastconsolidate_BCF_DTI Storage': 'Storage_DTI',
    'eastconsolidate_BCF_Early Grove': 'Storage_Early_Grove',
    'eastconsolidate_BCF_Ellisburg': 'Storage_Ellisburg',
    'eastconsolidate_BCF_Equitrans': 'Storage_Equitrans',
    'eastconsolidate_BCF_Hardy': 'Storage_Hardy',
    'eastconsolidate_BCF_Honeoye': 'Storage_Honeoye',
    'eastconsolidate_BCF_Leidy': 'Storage_Leidy',
    'eastconsolidate_BCF_Lost River': 'Storage_Lost_River',
    'eastconsolidate_BCF_NFGSC': 'Storage_NFGSC',
    'eastconsolidate_BCF_North Summit': 'Storage_North_Summit',
    'eastconsolidate_BCF_Oakford': 'Storage_Oakford',
    'eastconsolidate_BCF_Pine Needle': 'Storage_Pine_Needle',
    'eastconsolidate_BCF_Rager Mountain': 'Storage_Rager_Mountain',
    'eastconsolidate_BCF_Saltville': 'Storage_Saltville',
    'eastconsolidate_BCF_Seneca Lake Gas': 'Storage_Seneca_Lake',
    'eastconsolidate_BCF_Stagecoach': 'Storage_Stagecoach',
    'eastconsolidate_BCF_Steckman Ridge': 'Storage_Steckman_Ridge',
    'eastconsolidate_BCF_Steuben': 'Storage_Steuben',
    'eastconsolidate_BCF_Thomas Corners': 'Storage_Thomas_Corners',
    'eastconsolidate_BCF_UGI': 'Storage_UGI',
    'eastconsolidate_BCF_Unknown East Facility': 'Storage_Unknown_East',
    'eastconsolidate_BCF_Wyckoff': 'Storage_Wyckoff',
    'synmaxproductio_DRY_GAS_BCF_DAY': 'Production_Dry_Gas_BCF',
    'weatherEAST_gas_hdd': 'Weather_HDD',
    'weatherEAST_population_cdd': 'Weather_Pop_CDD',
    'CAROLINA_TOTAL_BCF': 'Demand_Carolina_BCF',
    'FLORIDA_TOTAL_BCF': 'Demand_Florida_BCF',
    'MIDATLANTIC_TOTAL_BCF': 'Demand_MidAtlantic_BCF',
    'NEWYORK_TOTAL_BCF': 'Demand_NewYork_BCF',
    'SOUTHEAST_TOTAL_BCF': 'Demand_Southeast_BCF',
    'NEWENGLAND_TOTAL_BCF': 'Demand_NewEngland_BCF',
    'TENNESSEE_TOTAL_BCF': 'Demand_Tennessee_BCF'
}

def main():
    """Main function to rename East columns"""
    
    print("="*60)
    print("EAST COLUMN RENAMER")
    print("="*60)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output directory: {OUTPUT_DIR}")
    
    try:
        # 1. Load the data
        print(f"\n1. Loading data from: {INPUT_FILE}")
        df = pd.read_csv(INPUT_FILE)
        print(f"   Loaded {len(df)} rows and {len(df.columns)} columns")
        
        # 2. Display original column names
        print("\n2. Original column names:")
        for i, col in enumerate(df.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 3. Rename columns
        print("\n3. Renaming columns...")
        df_renamed = df.rename(columns=COLUMN_MAPPING)
        
        # 4. Display new column names
        print("\n4. New column names:")
        for i, col in enumerate(df_renamed.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 5. Convert date column to datetime if it exists
        if 'Date' in df_renamed.columns:
            print("\n5. Converting Date column to datetime format...")
            df_renamed['Date'] = pd.to_datetime(df_renamed['Date'])
            print(f"   Date range: {df_renamed['Date'].min().date()} to {df_renamed['Date'].max().date()}")
        
        # 6. Save the renamed file
        print(f"\n6. Saving renamed file to: {OUTPUT_FILE}")
        df_renamed.to_csv(OUTPUT_FILE, index=False, float_format='%.4f')
        print(f"   Successfully saved {len(df_renamed)} rows")
        
        # 7. Print summary statistics
        print("\n" + "="*60)
        print("SUMMARY STATISTICS")
        print("="*60)
        
        # Storage facilities
        storage_cols = [col for col in df_renamed.columns if col.startswith('Storage_')]
        if storage_cols:
            print(f"\nStorage Facilities ({len(storage_cols)} total):")
            total_storage_avg = 0
            for col in storage_cols:
                mean_val = df_renamed[col].mean()
                total_storage_avg += mean_val
                print(f"  {col}: Avg = {mean_val:.2f}")
            print(f"\n  TOTAL STORAGE AVERAGE: {total_storage_avg:.2f} BCF")
        
        # Regional demand
        demand_cols = [col for col in df_renamed.columns if col.startswith('Demand_')]
        if demand_cols:
            print(f"\nRegional Demand ({len(demand_cols)} regions):")
            total_demand_avg = 0
            for col in demand_cols:
                mean_val = df_renamed[col].mean()
                min_val = df_renamed[col].min()
                max_val = df_renamed[col].max()
                total_demand_avg += mean_val
                print(f"  {col}:")
                print(f"    Average: {mean_val:.2f} BCF")
                print(f"    Range: {min_val:.2f} to {max_val:.2f} BCF")
            print(f"\n  TOTAL DEMAND AVERAGE: {total_demand_avg:.2f} BCF")
        
        # Production
        if 'Production_Dry_Gas_BCF' in df_renamed.columns:
            print(f"\nProduction:")
            print(f"  Dry Gas Average: {df_renamed['Production_Dry_Gas_BCF'].mean():.2f} BCF/day")
            print(f"  Dry Gas Range: {df_renamed['Production_Dry_Gas_BCF'].min():.2f} to {df_renamed['Production_Dry_Gas_BCF'].max():.2f} BCF/day")
        
        # Weather
        weather_cols = [col for col in df_renamed.columns if col.startswith('Weather_')]
        if weather_cols:
            print("\nWeather Metrics:")
            for col in weather_cols:
                mean_val = df_renamed[col].mean()
                print(f"  {col}: Avg = {mean_val:.2f}")
        
        print("\n" + "="*60)
        print("✅ COLUMN RENAMING COMPLETE!")
        print("="*60)
        
        # Create a mapping reference file
        mapping_file = os.path.join(OUTPUT_DIR, "east_column_mapping.txt")
        print(f"\n7. Creating column mapping reference: {mapping_file}")
        
        with open(mapping_file, 'w') as f:
            f.write("EAST COLUMN MAPPING REFERENCE\n")
            f.write("=" * 60 + "\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("ORIGINAL COLUMN NAME --> NEW COLUMN NAME\n")
            f.write("-" * 60 + "\n")
            
            for old_name, new_name in COLUMN_MAPPING.items():
                f.write(f"{old_name}\n  --> {new_name}\n\n")
            
            f.write("-" * 60 + "\n")
            f.write(f"Total columns renamed: {len(COLUMN_MAPPING)}\n")
            f.write(f"Input file: {INPUT_FILE}\n")
            f.write(f"Output file: {OUTPUT_FILE}\n")
        
        print("   Column mapping reference saved")
        
        return df_renamed
        
    except FileNotFoundError as e:
        print(f"\n❌ ERROR: File not found - {e}")
        return None
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    # Run the renaming
    renamed_data = main()
    
    if renamed_data is not None:
        print(f"\n✅ Output saved to: {OUTPUT_FILE}")
    else:
        print("\n❌ Script failed. Check error messages above.")