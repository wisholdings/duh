import pandas as pd
import glob
import os
import sys

# --- Configuration ---
# The base directory containing all region subdirectories.
BASE_PATH = r'D:\EIA_STACK'

# The patterns used to identify columns that should be copied.
PATTERNS_TO_COPY = ['MW', '_Total', 'is_analogous']

# The column used to link the main data with the weights data.
# This column will be included in the weights file.
LINKING_COLUMN = 'date'


def copy_columns_to_weights_files():
    """
    Finds all train.parquet and predict.parquet files, and for each,
    copies columns matching the specified patterns into new _weights.parquet files.
    The original files are NOT modified.
    """
    print("--- Starting Column Copy Process ---")
    print(f"Looking for columns with patterns: {PATTERNS_TO_COPY}")

    # Find all region directories within the base path
    region_dirs = [d for d in glob.glob(os.path.join(BASE_PATH, '')) if os.path.isdir(d)]

    if not region_dirs:
        print(f"Error: No region directories found in {BASE_PATH}. Exiting.", file=sys.stderr)
        return

    # Iterate over each region's directory
    for region_dir in region_dirs:
        region_name = os.path.basename(region_dir)
        print(f"\nProcessing region: {region_name}")
        final_dir = os.path.join(region_dir, 'final')

        # Process both 'train' and 'predict' file types
        for file_type in ['train', 'predict']:
            source_file = os.path.join(final_dir, f'{file_type}.parquet')
            dest_weights_file = os.path.join(final_dir, f'{file_type}_weights.parquet')

            # --- Step 1: Check if the source file exists ---
            if not os.path.exists(source_file):
                print(f"  - {os.path.basename(source_file)}: NOT FOUND")
                continue

            print(f"  - Analyzing {os.path.basename(source_file)}...")
            
            # --- Step 2: Read the source data ---
            try:
                df = pd.read_parquet(source_file)
            except Exception as e:
                print(f"    - ⚠️ Error reading file: {e}", file=sys.stderr)
                continue

            # Ensure the linking column exists
            if LINKING_COLUMN not in df.columns:
                print(f"    - ⚠️ Skipping: Linking column '{LINKING_COLUMN}' not found in the source file.")
                continue

            # --- Step 3: Identify columns to copy based on patterns ---
            columns_to_copy = [
                col for col in df.columns 
                if any(pattern in col for pattern in PATTERNS_TO_COPY)
            ]

            if not columns_to_copy:
                print(f"    - No columns with specified patterns found. Nothing to copy.")
                continue

            # --- Step 4: Create the new DataFrame for the weights file ---
            # It will contain the linking column + all matched columns
            final_weights_columns = [LINKING_COLUMN] + columns_to_copy
            
            # Create the new dataframe by selecting only the desired columns
            weights_df = df[final_weights_columns].copy()

            # --- Step 5: Save the new weights file ---
            try:
                weights_df.to_parquet(dest_weights_file, index=False)
                print(f"    - ✅ Successfully created {os.path.basename(dest_weights_file)} with {len(columns_to_copy)} columns.")
            except Exception as e:
                print(f"    - ⚠️ Error writing weights file: {e}", file=sys.stderr)


if __name__ == "__main__":
    copy_columns_to_weights_files()
    print("\nProcessing complete!")