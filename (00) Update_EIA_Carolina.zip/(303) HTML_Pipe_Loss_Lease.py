import os
import shutil
import traceback

# --- Configuration ---
SOURCE_DIR = r"D:\EIA_STACK\us_total\final"
DESTINATION_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"

def copy_us_total_files():
    """
    Copies all files from the 'us_total\final' directory to the 'Update' folder.
    """
    print("\n" + "="*80)
    print("   COPYING US TOTAL FINAL FILES")
    print("="*80)
    print(f"Source:      {SOURCE_DIR}")
    print(f"Destination: {DESTINATION_DIR}")
    print("="*80)

    # --- Validate Source and Destination ---
    if not os.path.isdir(SOURCE_DIR):
        print(f"\n✗ ERROR: Source directory not found: {SOURCE_DIR}")
        print("Script terminated.")
        return

    try:
        os.makedirs(DESTINATION_DIR, exist_ok=True)
        print(f"\n✓ Destination directory is ready.")
    except Exception as e:
        print(f"\n✗ ERROR: Could not create destination directory: {e}")
        traceback.print_exc()
        return

    # --- Copy Files ---
    copied_count = 0
    skipped_count = 0
    error_count = 0

    try:
        files_to_copy = [f for f in os.listdir(SOURCE_DIR) if os.path.isfile(os.path.join(SOURCE_DIR, f))]
        
        if not files_to_copy:
            print("\n- No files found in the source directory to copy.")
        else:
            print(f"\nFound {len(files_to_copy)} files to copy...")

        for filename in files_to_copy:
            source_path = os.path.join(SOURCE_DIR, filename)
            destination_path = os.path.join(DESTINATION_DIR, filename)
            
            try:
                print(f"  - Copying '{filename}'...", end='')
                shutil.copy2(source_path, destination_path)
                print(" Done.")
                copied_count += 1
            except Exception as e:
                print(f" FAILED. Error: {e}")
                error_count += 1

    except Exception as e:
        print(f"\n✗ FATAL ERROR during file processing: {e}")
        traceback.print_exc()

    # --- Final Summary ---
    print("\n" + "="*80)
    print("COPY SUMMARY")
    print("="*80)
    print(f"  ✓ Files Copied:   {copied_count}")
    print(f"  - Files Skipped:  {skipped_count}")
    print(f"  ✗ Errors:         {error_count}")
    print("\n✅ Script completed!")
    print("="*80)


if __name__ == "__main__":
    copy_us_total_files()