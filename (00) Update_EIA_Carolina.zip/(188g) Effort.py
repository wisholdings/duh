# =============================================================================
# STORAGE DELTA CALCULATION SCRIPT
# =============================================================================
import pandas as pd
import os
from datetime import datetime
import glob

# --- CONFIGURATION ---
AGGREGATE_PATH = r"D:\EIA_STACK\Pricing_RL\AGGREGATE"

# Columns to sum for storage_delta
COLUMNS_TO_SUM = [
    'LNG_IMPORTS_BCF',
    'LNG_EXPORTS_BCF',
    'CAD_NET_FLOW_BCF',
    'MEX_EXPORTS_BCF',
    'commercial_bcf',
    'industrial_bcf',
    'residential_bcf',
    'L48_Power_Burns',  # This is the renamed L48_Power_Burns
    'pipe_loss_bcf',
    'lease_plant_loss_bcf',
    'production_bcf'
]

# =============================================================================
# MAIN FUNCTION
# =============================================================================
def calculate_storage_delta():
    """Find today's L48 file and calculate storage_delta"""
    
    print("\n" + "=" * 80)
    print("STORAGE DELTA CALCULATION")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    print(f"Working directory: {AGGREGATE_PATH}")
    
    # Find the most recent L48 file
    print("\n" + "=" * 60)
    print("STEP 1: FINDING L48 FILE")
    print("=" * 60)
    
    # Look for L48_*.csv files
    pattern = os.path.join(AGGREGATE_PATH, "L48_*.csv")
    l48_files = glob.glob(pattern)
    
    if not l48_files:
        print(f"  ✗ No L48 files found in {AGGREGATE_PATH}")
        return False
    
    # Get the most recent file (by filename, since it includes date)
    l48_files.sort()
    latest_file = l48_files[-1]
    filename = os.path.basename(latest_file)
    
    print(f"  ✓ Found file: {filename}")
    
    # Load the file
    print("\n" + "=" * 60)
    print("STEP 2: LOADING AND PROCESSING DATA")
    print("=" * 60)
    
    try:
        print(f"  Loading {filename}...")
        df = pd.read_csv(latest_file)
        print(f"  ✓ Loaded {len(df):,} records")
        
        # Check for Date column
        if 'Date' not in df.columns:
            print(f"  ✗ No 'Date' column found")
            return False
        
        df['Date'] = pd.to_datetime(df['Date'])
        print(f"  Date range: {df['Date'].min().date()} to {df['Date'].max().date()}")
        
        # Check which columns exist
        print(f"\n  Checking for required columns...")
        missing_columns = []
        found_columns = []
        
        for col in COLUMNS_TO_SUM:
            if col in df.columns:
                found_columns.append(col)
                non_null = df[col].notna().sum()
                print(f"    ✓ {col}: {non_null:,} non-null values")
            else:
                missing_columns.append(col)
                print(f"    ✗ {col}: NOT FOUND")
        
        if not found_columns:
            print(f"\n  ✗ None of the required columns found!")
            return False
        
        if missing_columns:
            print(f"\n  ⚠ Warning: {len(missing_columns)} columns not found")
            print(f"    Proceeding with {len(found_columns)} available columns")
        
        # Calculate storage_delta
        print("\n" + "=" * 60)
        print("STEP 3: CALCULATING STORAGE DELTA")
        print("=" * 60)
        
        print(f"  Summing {len(found_columns)} columns...")
        
        # Initialize storage_delta with zeros
        df['storage_delta'] = 0.0
        
        # Sum the columns
        for col in found_columns:
            df['storage_delta'] = df['storage_delta'] + df[col].fillna(0)
        
        # Show statistics
        print(f"  ✓ Storage delta calculated")
        print(f"\n  Storage Delta Statistics:")
        print(f"    Mean:   {df['storage_delta'].mean():.2f} BCF/day")
        print(f"    Median: {df['storage_delta'].median():.2f} BCF/day")
        print(f"    Min:    {df['storage_delta'].min():.2f} BCF/day")
        print(f"    Max:    {df['storage_delta'].max():.2f} BCF/day")
        print(f"    Std:    {df['storage_delta'].std():.2f} BCF/day")
        
        # Count non-zero values
        non_zero = (df['storage_delta'] != 0).sum()
        print(f"    Non-zero days: {non_zero:,} / {len(df):,}")
        
        # Show sample of calculations
        print(f"\n  Sample calculations (first 5 non-zero):")
        sample_df = df[df['storage_delta'] != 0].head()
        
        for idx, row in sample_df.iterrows():
            print(f"\n    Date: {row['Date'].date()}")
            total = 0
            for col in found_columns:
                val = row[col] if pd.notna(row[col]) else 0
                if val != 0:
                    print(f"      {col}: {val:.2f}")
                    total += val
            print(f"      → storage_delta: {row['storage_delta']:.2f}")
        
        # Save the updated file
        print("\n" + "=" * 60)
        print("STEP 4: SAVING UPDATED FILE")
        print("=" * 60)
        
        # Overwrite the original file
        df.to_csv(latest_file, index=False)
        
        file_size = os.path.getsize(latest_file) / (1024 * 1024)  # MB
        print(f"  ✓ File saved: {filename}")
        print(f"    Size: {file_size:.2f} MB")
        print(f"    Total columns: {len(df.columns)}")
        
        # Show all columns in the file
        print(f"\n  All columns in file:")
        for i, col in enumerate(df.columns, 1):
            print(f"    {i:3}. {col}")
        
        # Verify storage_delta is in the file
        if 'storage_delta' in df.columns:
            print(f"\n  ✓ 'storage_delta' column successfully added")
        else:
            print(f"\n  ✗ Error: 'storage_delta' column not found after save")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error processing file: {e}")
        import traceback
        traceback.print_exc()
        return False

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the storage delta calculation"""
    
    success = calculate_storage_delta()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ STORAGE DELTA CALCULATION COMPLETE!")
    else:
        print("✗ STORAGE DELTA CALCULATION FAILED!")
    print("=" * 80)
    
    if success:
        print("\nSummary:")
        print(f"  The 'storage_delta' column has been added to the L48 file")
        print(f"  It represents the daily sum of all supply and demand components")
        print(f"  Positive values = net addition to storage")
        print(f"  Negative values = net withdrawal from storage")
    
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()