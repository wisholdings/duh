"""
Script to rename columns in PACIFIC_filtered.csv to more sensible names
Loads from D:\EIA_STACK\Pricing_RL\PACIFIC\PACIFIC_filtered.csv
Outputs to D:\EIA_STACK\Pricing_RL\PACIFIC\HTML\
"""

import pandas as pd
import os
from datetime import datetime

# Define file paths
INPUT_FILE = r"D:\EIA_STACK\Pricing_RL\PACIFIC\PACIFIC_filtered.csv"
OUTPUT_DIR = r"D:\EIA_STACK\Pricing_RL\PACIFIC\HTML"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "pacific_features_renamed.csv")

# Column renaming dictionary
COLUMN_MAPPING = {
    'date': 'Date',
    'northwestcommer_NORTHWEST_Commercial_hourly_MMcf_BCF': 'NW_Commercial_BCF',
    'northwestindust_NORTHWEST_Industrial_hourly_MMcf_BCF': 'NW_Industrial_BCF',
    'northwestpowerb_NORTHWEST_Power_Burn_BCF': 'NW_Power_Burn_BCF',
    'northwestreside_NORTHWEST_Residential_hourly_MMcf_BCF': 'NW_Residential_BCF',
    'pacificconsolid_Central Valley': 'Storage_Central_Valley',
    'pacificconsolid_Gill Ranch': 'Storage_Gill_Ranch',
    'pacificconsolid_Jackson Prairie': 'Storage_Jackson_Prairie',
    'pacificconsolid_Lodi': 'Storage_Lodi',
    'pacificconsolid_PGE': 'Storage_PGE',
    'pacificconsolid_Socal': 'Storage_Socal',
    'pacificconsolid_Wild Goose': 'Storage_Wild_Goose',
    'californiacomme_CALIFORNIA_Commercial_hourly_MMcf_BCF': 'CA_Commercial_BCF',
    'californiaindus_CALIFORNIA_Industrial_hourly_MMcf_BCF': 'CA_Industrial_BCF',
    'californiapower_CALIFORNIA_Power_Burn_BCF': 'CA_Power_Burn_BCF',
    'californiaresid_CALIFORNIA_Residential_hourly_MMcf_BCF': 'CA_Residential_BCF',
    'synmaxproductio_DRY_GAS_BCF_DAY': 'Production_Dry_Gas_BCF',
    'weatherPACIFIC_gas_hdd': 'Weather_HDD',
    'weatherPACIFIC_population_cdd': 'Weather_Pop_CDD'
}

def main():
    """Main function to rename Pacific columns"""
    
    print("="*60)
    print("PACIFIC COLUMN RENAMER")
    print("="*60)
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Output directory: {OUTPUT_DIR}")
    
    try:
        # 1. Load the data
        print(f"\n1. Loading data from: {INPUT_FILE}")
        df = pd.read_csv(INPUT_FILE)
        print(f"   Loaded {len(df)} rows and {len(df.columns)} columns")
        
        # 2. Display original column names
        print("\n2. Original column names:")
        for i, col in enumerate(df.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 3. Rename columns
        print("\n3. Renaming columns...")
        df_renamed = df.rename(columns=COLUMN_MAPPING)
        
        # 4. Display new column names
        print("\n4. New column names:")
        for i, col in enumerate(df_renamed.columns, 1):
            print(f"   {i:2}. {col}")
        
        # 5. Convert date column to datetime if it exists
        if 'Date' in df_renamed.columns:
            print("\n5. Converting Date column to datetime format...")
            df_renamed['Date'] = pd.to_datetime(df_renamed['Date'])
            print(f"   Date range: {df_renamed['Date'].min().date()} to {df_renamed['Date'].max().date()}")
        
        # 6. Save the renamed file
        print(f"\n6. Saving renamed file to: {OUTPUT_FILE}")
        df_renamed.to_csv(OUTPUT_FILE, index=False, float_format='%.4f')
        print(f"   Successfully saved {len(df_renamed)} rows")
        
        # 7. Print summary statistics
        print("\n" + "="*60)
        print("SUMMARY STATISTICS")
        print("="*60)
        
        # Northwest totals
        nw_cols = [col for col in df_renamed.columns if col.startswith('NW_')]
        if nw_cols:
            print("\nNorthwest Region:")
            for col in nw_cols:
                mean_val = df_renamed[col].mean()
                print(f"  {col}: Avg = {mean_val:.2f} BCF")
        
        # California totals
        ca_cols = [col for col in df_renamed.columns if col.startswith('CA_')]
        if ca_cols:
            print("\nCalifornia Region:")
            for col in ca_cols:
                mean_val = df_renamed[col].mean()
                print(f"  {col}: Avg = {mean_val:.2f} BCF")
        
        # Storage facilities
        storage_cols = [col for col in df_renamed.columns if col.startswith('Storage_')]
        if storage_cols:
            print("\nStorage Facilities:")
            for col in storage_cols:
                mean_val = df_renamed[col].mean()
                print(f"  {col}: Avg = {mean_val:.2f}")
        
        # Production
        if 'Production_Dry_Gas_BCF' in df_renamed.columns:
            print(f"\nProduction:")
            print(f"  Dry Gas: Avg = {df_renamed['Production_Dry_Gas_BCF'].mean():.2f} BCF/day")
        
        # Weather
        weather_cols = [col for col in df_renamed.columns if col.startswith('Weather_')]
        if weather_cols:
            print("\nWeather Metrics:")
            for col in weather_cols:
                mean_val = df_renamed[col].mean()
                print(f"  {col}: Avg = {mean_val:.2f}")
        
        print("\n" + "="*60)
        print("✅ COLUMN RENAMING COMPLETE!")
        print("="*60)
        
        # Create a mapping reference file
        mapping_file = os.path.join(OUTPUT_DIR, "pacific_column_mapping.txt")
        print(f"\n7. Creating column mapping reference: {mapping_file}")
        
        with open(mapping_file, 'w') as f:
            f.write("PACIFIC COLUMN MAPPING REFERENCE\n")
            f.write("=" * 60 + "\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("ORIGINAL COLUMN NAME --> NEW COLUMN NAME\n")
            f.write("-" * 60 + "\n")
            
            for old_name, new_name in COLUMN_MAPPING.items():
                f.write(f"{old_name}\n  --> {new_name}\n\n")
            
            f.write("-" * 60 + "\n")
            f.write(f"Total columns renamed: {len(COLUMN_MAPPING)}\n")
            f.write(f"Input file: {INPUT_FILE}\n")
            f.write(f"Output file: {OUTPUT_FILE}\n")
        
        print("   Column mapping reference saved")
        
        return df_renamed
        
    except FileNotFoundError as e:
        print(f"\n❌ ERROR: File not found - {e}")
        return None
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    # Run the renaming
    renamed_data = main()
    
    if renamed_data is not None:
        print(f"\n✅ Output saved to: {OUTPUT_FILE}")
    else:
        print("\n❌ Script failed. Check error messages above.")