import os
import sys
import pandas as pd
import traceback
import time
from datetime import datetime
import requests
import warnings
from sqlalchemy import create_engine, MetaData, Table, Column, DateTime, String, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.dialects.mssql import REAL

# --- Configuration ---

# 1. DATABASE CONNECTION: Update with your database connection string
DB_CONNECTION_STRING = (
)

# 2. DATABASE TABLE NAME: The name of the new WIDE format table.
TABLE_NAME = "EIA_STORAGE_WIDE"

# 3. EIA API KEY
API_KEY = "" # Your EIA API Key

# Suppress insecure request warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')


def fetch_storage_data(api_key):
    """
    Fetches the weekly natural gas storage data from the EIA API.
    """
    api_url = "https://api.eia.gov/v2/natural-gas/stor/wkly/data/"
    offset = 0
    limit = 5000
    combined_df = pd.DataFrame()
    print("Fetching weekly storage data from EIA...")

    while True:
        params = {
            "api_key": api_key,
            "frequency": "weekly",
            "data[0]": "value",
            "start": "2019-01-01",
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "offset": offset,
            "length": limit
        }
        try:
            response = requests.get(api_url, params=params, verify=False, timeout=90)
            if response.status_code == 200:
                data = response.json()
                page_data = data.get('response', {}).get('data', [])
                if not page_data:
                    print("  -> No more data found from API.")
                    break
                df = pd.DataFrame(page_data)
                print(f"  -> Fetched {len(df)} records (offset {offset})...")
                combined_df = pd.concat([combined_df, df], ignore_index=True)
                offset += limit
            else:
                print(f"  -> ERROR: Failed to fetch data. Status: {response.status_code}, Response: {response.text}")
                break
        except Exception as e:
             print(f"  -> ERROR: An unexpected error occurred during fetch: {e}")
             traceback.print_exc()
             break

    print(f"Finished fetching. Total rows fetched: {len(combined_df)}")
    return combined_df


def create_wide_sql_table(engine, table_name, df_columns):
    """
    Dynamically creates the SQL Server table with a column for each storage type.
    It drops the existing table to ensure the schema is always up-to-date.
    """
    metadata = MetaData()
    sql_columns = [Column('date', DateTime, primary_key=True)]
    
    for col_name in df_columns:
        if col_name.lower() != 'date':
            sql_columns.append(Column(col_name, REAL, nullable=True))

    table = Table(table_name, metadata, *sql_columns, extend_existing=True)
    
    try:
        print(f"Dropping table '{table_name}' if it exists to recreate schema...")
        with engine.begin() as conn:
            conn.execute(text(f"DROP TABLE IF EXISTS {table_name}"))
        print(f"  -> Table '{table_name}' dropped.")
        
        metadata.create_all(engine, tables=[table])
        print(f"Table '{table_name}' created successfully with {len(sql_columns)} columns.")
    except SQLAlchemyError as e:
        print(f"ERROR: Could not create table '{table_name}': {e}")
        raise


def upload_data(engine, table_name, df):
    """
    Bulk-inserts the new data into the freshly created table.
    """
    if df.empty:
        print("Dataframe is empty. No data to upload.")
        return 0

    with engine.begin() as connection:
        try:
            print(f"Bulk inserting {len(df)} rows into '{table_name}'...")
            df.to_sql(name=table_name, con=connection, if_exists='append', index=True)
            print("  -> Bulk insert complete.")
        except SQLAlchemyError as e:
            print(f"ERROR: An error occurred during the database operation: {e}")
            raise
    return len(df)


# --- Main Execution ---
def main():
    print("\n==========================================================")
    print("=== EIA Storage - Pivot to Wide Format & Upload Script ===")
    print("==========================================================")
    start_time = time.time()

    try:
        # --- 1. Fetch Data ---
        raw_df = fetch_storage_data(API_KEY)
        if raw_df.empty:
            print("\nNo data was fetched. Exiting.")
            sys.exit(1)

        # --- 2. Process and Pivot Data to WIDE Format ---
        print("\nProcessing and pivoting data into wide format...")
        
        # --- THIS IS THE FIX ---
        # Convert the 'value' column to a numeric type before pivoting.
        # errors='coerce' will turn any non-numeric values into 'NaN' (Not a Number)
        raw_df['value'] = pd.to_numeric(raw_df['value'], errors='coerce')
        # --- END FIX ---

        region_map = {
            'R31': 'EAST', 'R32': 'MIDWEST', 'R34': 'MOUNTAIN', 'R35': 'PACIFIC',
            'R33': 'SOUTH_CENTRAL',
            'R48': 'LOWER_48'
        }
        process_map = {
            'SWO': '',
            'SSO': '_SALT',
            'SNO': '_NONSALT'
        }
        
        raw_df['region_name'] = raw_df['duoarea'].map(region_map)
        raw_df['process_suffix'] = raw_df['process'].map(process_map)
        raw_df['column_label'] = raw_df['region_name'].fillna('') + raw_df['process_suffix'].fillna('')
        raw_df['column_label'] = raw_df['column_label'].str.strip('_')
        
        df_to_pivot = raw_df.dropna(subset=['column_label', 'value'])
        
        df_wide = df_to_pivot.pivot_table(
            index='period',
            columns='column_label',
            values='value'
        )
        
        df_wide.index = pd.to_datetime(df_wide.index)
        df_wide.index.name = 'date'
        
        print(f"  -> Data successfully pivoted. Shape: {df_wide.shape}")
        print(f"  -> Columns created: {df_wide.columns.tolist()}")

        # --- 3. Connect to Database and Upload ---
        print("\nConnecting to database...")
        engine = create_engine(DB_CONNECTION_STRING)
        
        create_wide_sql_table(engine, TABLE_NAME, df_wide.columns)
        
        rows_uploaded = upload_data(engine, TABLE_NAME, df_wide)

        # --- 4. Print Summary ---
        print("\n" + "=" * 20 + " UPLOAD SUMMARY " + "=" * 20)
        print(f"  Records (dates) uploaded: {rows_uploaded}")
        print(f"  Target table: {TABLE_NAME}")
        if not df_wide.empty:
            print(f"  Date range: {df_wide.index.min().date()} to {df_wide.index.max().date()}")
        print("  Upload completed successfully!")
        print("=" * 60)

    except Exception as e:
        print(f"\nFATAL ERROR: {e}")
        traceback.print_exc()
        sys.exit(1)
    
    finally:
        if 'engine' in locals() and engine:
            engine.dispose()
        end_time = time.time()
        print(f"\nTotal execution time: {end_time - start_time:.2f} seconds.")
        print("Script execution finished.")

if __name__ == "__main__":
    main()