# =============================================================================
# Daily Storage & Supply/Demand Balance Dashboard - Improved Version
# =============================================================================
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from datetime import datetime, timedelta
import os
import glob

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="Natural Gas Storage & Balance Dashboard",
    page_icon="⛽",
    layout="wide"
)

# --- DATA LOADING ---
@st.cache_data(ttl=3600)
def load_daily_data():
    """Load the most recent daily flat file from Pricing_RL folder"""
    try:
        # Define the path to look for files
        data_path = r'D:\EIA_STACK\Pricing_RL'
        
        # Look for the most recent gas_burns_daily_flat_file_*.csv
        pattern = os.path.join(data_path, 'gas_burns_daily_flat_file_*.csv')
        csv_files = glob.glob(pattern)
        
        if not csv_files:
            # If not in Pricing_RL, check current directory as fallback
            csv_files = glob.glob('gas_burns_daily_flat_file_*.csv')
            if not csv_files:
                st.error("No daily flat file found. Please run the pipeline script first.")
                return None
        
        # Get the most recent file
        latest_file = max(csv_files, key=os.path.getctime)
        
        # Load the CSV
        df = pd.read_csv(latest_file)
        df['Date'] = pd.to_datetime(df['Date'])
        
        # Display file info
        file_size = os.path.getsize(latest_file) / (1024 * 1024)  # MB
        st.sidebar.success(f"📁 Loaded: {os.path.basename(latest_file)}")
        st.sidebar.info(f"📊 Size: {file_size:.2f} MB | Rows: {len(df):,}")
        
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

def calculate_consumption_by_sector(df):
    """Calculate consumption totals by sector for EIA regions"""
    sectors = ['residential', 'commercial', 'industrial', 'power']
    
    for sector in sectors:
        # Look for EIA aggregated columns
        eia_cols = [col for col in df.columns if 
                   col.startswith(f'{sector}_') and 
                   col.endswith('_eia_bcf')]
        
        if eia_cols:
            # Sum all EIA regions for this sector (values are negative)
            df[f'total_{sector}_bcf'] = df[eia_cols].sum(axis=1)
        else:
            # Fallback to granular columns if EIA columns don't exist
            sector_cols = [col for col in df.columns if 
                          col.startswith(f'{sector}_') and 
                          col.endswith('_bcf')]
            if sector_cols:
                df[f'total_{sector}_bcf'] = df[sector_cols].sum(axis=1)
            else:
                df[f'total_{sector}_bcf'] = 0
    
    # Calculate total consumption (convert from negative to positive)
    consumption_cols = [f'total_{s}_bcf' for s in sectors]
    df['total_consumption_bcf'] = -df[consumption_cols].sum(axis=1)
    
    return df

def calculate_supply_demand_balance(df):
    """Calculate comprehensive supply/demand balance"""
    
    # Supply components (positive values)
    df['supply_production'] = df['production_bcf'].fillna(0)
    df['supply_lng_imports'] = df['lng_imports_bcf'].fillna(0)
    df['supply_can_imports'] = df['can_net_flow_bcf'].clip(lower=0).fillna(0)
    
    df['total_supply'] = (df['supply_production'] + 
                          df['supply_lng_imports'] + 
                          df['supply_can_imports'])
    
    # Demand components (convert negatives to positive)
    df['demand_consumption'] = df['total_consumption_bcf'].fillna(0)
    df['demand_lng_exports'] = -df['lng_exports_bcf'].fillna(0)
    df['demand_mex_exports'] = -df['mex_exports_bcf'].fillna(0)
    df['demand_can_exports'] = -df['can_net_flow_bcf'].clip(upper=0).fillna(0)
    df['demand_losses'] = -(df['pipe_loss_bcf'].fillna(0) + 
                            df['lease_plant_loss_bcf'].fillna(0))
    
    df['total_demand'] = (df['demand_consumption'] + 
                          df['demand_lng_exports'] + 
                          df['demand_mex_exports'] + 
                          df['demand_can_exports'] + 
                          df['demand_losses'])
    
    # Net balance
    df['net_balance'] = df['total_supply'] - df['total_demand']
    
    return df

# --- MAIN APP ---
st.title("⛽ Natural Gas Storage & Supply/Demand Balance")
st.markdown("*Real-time analysis with EIA storage regions and 8-week bias adjustment*")

# Load data
with st.spinner("Loading daily data..."):
    df = load_daily_data()

if df is None:
    st.stop()

# Process data
df = calculate_consumption_by_sector(df)
df = calculate_supply_demand_balance(df)

# Identify today and forecast periods
today = datetime.now().date()
df['is_forecast'] = df['Date'].dt.date > today

# --- SIDEBAR CONTROLS ---
st.sidebar.title("⚙️ Dashboard Controls")

# Date range selection
st.sidebar.markdown("### 📅 Date Range")
min_date = df['Date'].min().date()
max_date = df['Date'].max().date()

# Preset options
preset = st.sidebar.radio(
    "Quick selection:",
    ["Last Year", "Last 6 Months", "Last 3 Months", "Forecast Only", "Custom"]
)

if preset == "Last Year":
    start_date = max_date - timedelta(days=365)
    end_date = max_date
elif preset == "Last 6 Months":
    start_date = max_date - timedelta(days=180)
    end_date = max_date
elif preset == "Last 3 Months":
    start_date = max_date - timedelta(days=90)
    end_date = max_date
elif preset == "Forecast Only":
    start_date = today
    end_date = max_date
else:
    col1, col2 = st.sidebar.columns(2)
    with col1:
        start_date = st.date_input("Start", value=max_date - timedelta(days=365))
    with col2:
        end_date = st.date_input("End", value=max_date)

# Filter data
mask = (df['Date'].dt.date >= start_date) & (df['Date'].dt.date <= end_date)
filtered_df = df[mask].copy()

# Display options
st.sidebar.markdown("### 📊 Display Options")
show_components = st.sidebar.checkbox("Show detailed components", value=True)
show_regional = st.sidebar.checkbox("Show EIA regional breakdown", value=False)
smoothing = st.sidebar.slider("Smoothing (days)", 1, 30, 7)

# --- KEY METRICS ---
st.markdown("## 📈 Current Status")

# Calculate key metrics
latest_data = df[df['Date'].dt.date <= today].iloc[-1] if not df[df['Date'].dt.date <= today].empty else df.iloc[-1]
forecast_end = df.iloc[-1]

col1, col2, col3, col4, col5, col6 = st.columns(6)

with col1:
    current_storage = latest_data['storage_lower_48_bcf'] if pd.notna(latest_data['storage_lower_48_bcf']) else 0
    st.metric("Current Storage", f"{current_storage:,.0f} BCF")

with col2:
    current_prod = latest_data['production_bcf']
    st.metric("Production", f"{current_prod:.1f} BCF/d")

with col3:
    current_cons = latest_data['total_consumption_bcf']
    st.metric("Consumption", f"{current_cons:.1f} BCF/d")

with col4:
    current_balance = latest_data['net_balance']
    st.metric("Net Balance", f"{current_balance:+.1f} BCF/d",
              delta_color="normal" if current_balance > 0 else "inverse")

with col5:
    if 'storage_adjusted_forecast_bcf' in df.columns:
        forecast_storage = forecast_end['storage_adjusted_forecast_bcf']
        change = forecast_storage - current_storage if current_storage else 0
        st.metric("Adjusted Forecast", f"{forecast_storage:,.0f} BCF",
                  f"{change:+,.0f} BCF")
    else:
        forecast_storage = forecast_end['storage_forecast_lower_48_bcf'] if 'storage_forecast_lower_48_bcf' in df.columns else 0
        change = forecast_storage - current_storage if current_storage else 0
        st.metric("Forecast Storage", f"{forecast_storage:,.0f} BCF",
                  f"{change:+,.0f} BCF")

with col6:
    if 'bias_adjustment_8week' in df.columns:
        latest_bias = df[df['bias_adjustment_8week'].notna()]['bias_adjustment_8week'].iloc[-1] if not df[df['bias_adjustment_8week'].notna()].empty else 0
        st.metric("8-Week Bias Adj", f"{latest_bias:+.1f} BCF",
                  help="Cumulative bias adjustment based on 8-week average error")

st.markdown("---")

# --- STORAGE PROJECTION CHART ---
st.markdown("## 📊 Storage Analysis")

tab1, tab2, tab3 = st.tabs(["Storage Projections", "Supply/Demand Balance", "Component Analysis"])

with tab1:
    fig_storage = go.Figure()
    
    # Apply smoothing if requested
    if smoothing > 1:
        plot_df = filtered_df.copy()
        plot_df['storage_lower_48_bcf'] = plot_df['storage_lower_48_bcf'].rolling(window=smoothing, center=True).mean()
        if 'storage_forecast_lower_48_bcf' in plot_df.columns:
            plot_df['storage_forecast_lower_48_bcf'] = plot_df['storage_forecast_lower_48_bcf'].rolling(window=smoothing, center=True).mean()
        if 'storage_adjusted_forecast_bcf' in plot_df.columns:
            plot_df['storage_adjusted_forecast_bcf'] = plot_df['storage_adjusted_forecast_bcf'].rolling(window=smoothing, center=True).mean()
    else:
        plot_df = filtered_df
    
    # EIA Actual Storage
    actual_data = plot_df[plot_df['Date'].dt.date <= today]
    if not actual_data.empty and 'storage_lower_48_bcf' in actual_data.columns:
        fig_storage.add_trace(go.Scatter(
            x=actual_data['Date'],
            y=actual_data['storage_lower_48_bcf'],
            mode='lines',
            name='EIA Actual',
            line=dict(color='#1f77b4', width=3),
            hovertemplate='%{x|%b %d, %Y}<br>Actual: %{y:,.0f} BCF<extra></extra>'
        ))
    
    # Original Forecast
    if 'storage_forecast_lower_48_bcf' in plot_df.columns:
        forecast_data = plot_df[plot_df['storage_forecast_lower_48_bcf'].notna()]
        if not forecast_data.empty:
            fig_storage.add_trace(go.Scatter(
                x=forecast_data['Date'],
                y=forecast_data['storage_forecast_lower_48_bcf'],
                mode='lines',
                name='Base Forecast',
                line=dict(color='orange', width=2, dash='dot'),
                hovertemplate='%{x|%b %d, %Y}<br>Base: %{y:,.0f} BCF<extra></extra>'
            ))
    
    # Adjusted Forecast
    if 'storage_adjusted_forecast_bcf' in plot_df.columns:
        adjusted_data = plot_df[plot_df['storage_adjusted_forecast_bcf'].notna()]
        if not adjusted_data.empty:
            fig_storage.add_trace(go.Scatter(
                x=adjusted_data['Date'],
                y=adjusted_data['storage_adjusted_forecast_bcf'],
                mode='lines',
                name='8-Week Adjusted',
                line=dict(color='red', width=2.5),
                hovertemplate='%{x|%b %d, %Y}<br>Adjusted: %{y:,.0f} BCF<extra></extra>'
            ))
    
    # Add reference lines - use shapes instead of vline to avoid conversion issues
    fig_storage.add_shape(
        type="line",
        x0=today, x1=today,
        y0=0, y1=1,
        yref="paper",
        line=dict(color="gray", width=2, dash="dash")
    )
    fig_storage.add_annotation(
        x=today, y=0.98, yref="paper",
        text="Today", showarrow=False,
        font=dict(size=12, color="gray"),
        bgcolor="white"
    )
    
    # Add 5-year range if available
    if 'storage_lower_48_bcf' in df.columns:
        storage_values = df['storage_lower_48_bcf'].dropna()
        if len(storage_values) > 0:
            avg_storage = storage_values.mean()
            fig_storage.add_hline(y=avg_storage, line_width=1, line_dash="dot",
                                 line_color="green", annotation_text=f"Avg: {avg_storage:,.0f}")
    
    fig_storage.update_layout(
        title="Lower 48 Storage: Actual vs Forecasts with 8-Week Bias Adjustment",
        xaxis_title="Date",
        yaxis_title="Storage (BCF)",
        hovermode='x unified',
        height=500,
        template='plotly_white',
        legend=dict(yanchor="top", y=0.99, xanchor="left", x=0.01)
    )
    
    st.plotly_chart(fig_storage, use_container_width=True)
    
    # Show error metrics if available
    if 'storage_error' in df.columns:
        recent_errors = df[df['storage_error'].notna()].tail(10)
        if not recent_errors.empty:
            col1, col2, col3 = st.columns(3)
            with col1:
                mae = recent_errors['storage_error'].abs().mean()
                st.metric("Mean Absolute Error (10d)", f"{mae:.1f} BCF")
            with col2:
                rmse = np.sqrt((recent_errors['storage_error'] ** 2).mean())
                st.metric("RMSE (10d)", f"{rmse:.1f} BCF")
            with col3:
                if 'bias_adjustment_8week' in df.columns:
                    avg_bias = df[df['bias_adjustment_8week'].notna()]['bias_adjustment_8week'].mean()
                    st.metric("Avg Bias Adjustment", f"{avg_bias:.2f} BCF")

with tab2:
    # Create supply/demand balance chart
    fig_balance = make_subplots(
        rows=2, cols=1,
        subplot_titles=("Daily Supply & Demand", "Net Balance"),
        row_heights=[0.6, 0.4],
        vertical_spacing=0.12,
        shared_xaxes=True
    )
    
    # Apply smoothing
    if smoothing > 1:
        balance_df = filtered_df.copy()
        balance_df['total_supply'] = balance_df['total_supply'].rolling(window=smoothing, center=True).mean()
        balance_df['total_demand'] = balance_df['total_demand'].rolling(window=smoothing, center=True).mean()
        balance_df['net_balance'] = balance_df['net_balance'].rolling(window=smoothing, center=True).mean()
    else:
        balance_df = filtered_df
    
    # Supply and Demand lines
    fig_balance.add_trace(
        go.Scatter(
            x=balance_df['Date'],
            y=balance_df['total_supply'],
            name='Total Supply',
            line=dict(color='green', width=2.5),
            hovertemplate='Supply: %{y:.1f} BCF/d<extra></extra>'
        ),
        row=1, col=1
    )
    
    fig_balance.add_trace(
        go.Scatter(
            x=balance_df['Date'],
            y=balance_df['total_demand'],
            name='Total Demand',
            line=dict(color='red', width=2.5),
            hovertemplate='Demand: %{y:.1f} BCF/d<extra></extra>'
        ),
        row=1, col=1
    )
    
    # Net Balance bars
    colors = ['green' if x > 0 else 'red' for x in balance_df['net_balance']]
    fig_balance.add_trace(
        go.Bar(
            x=balance_df['Date'],
            y=balance_df['net_balance'],
            name='Net Balance',
            marker_color=colors,
            hovertemplate='Net: %{y:.1f} BCF/d<extra></extra>'
        ),
        row=2, col=1
    )
    
    # Add reference lines - horizontal line at zero for net balance
    fig_balance.add_hline(y=0, line_width=1, line_dash="dash", line_color="gray", row=2, col=1)
    
    # Add today line to each subplot separately to avoid issues
    for row in [1, 2]:
        fig_balance.add_shape(
            type="line",
            x0=today, x1=today,
            y0=0, y1=1,
            yref="y" if row == 1 else "y2",
            line=dict(color="gray", width=1, dash="dash"),
            row=row, col=1
        )
    
    fig_balance.update_xaxes(title_text="Date", row=2, col=1)
    fig_balance.update_yaxes(title_text="BCF/d", row=1, col=1)
    fig_balance.update_yaxes(title_text="BCF/d", row=2, col=1)
    
    fig_balance.update_layout(
        height=600,
        template='plotly_white',
        hovermode='x unified',
        showlegend=True,
        legend=dict(yanchor="top", y=0.99, xanchor="left", x=0.01)
    )
    
    st.plotly_chart(fig_balance, use_container_width=True)

with tab3:
    if show_components:
        col1, col2 = st.columns(2)
        
        with col1:
            # Supply components
            fig_supply = go.Figure()
            
            fig_supply.add_trace(go.Scatter(
                x=filtered_df['Date'],
                y=filtered_df['supply_production'],
                name='Production',
                stackgroup='one',
                line=dict(color='darkgreen', width=0),
                fillcolor='darkgreen'
            ))
            
            fig_supply.add_trace(go.Scatter(
                x=filtered_df['Date'],
                y=filtered_df['supply_lng_imports'],
                name='LNG Imports',
                stackgroup='one',
                line=dict(color='lightgreen', width=0),
                fillcolor='lightgreen'
            ))
            
            fig_supply.add_trace(go.Scatter(
                x=filtered_df['Date'],
                y=filtered_df['supply_can_imports'],
                name='Canada Imports',
                stackgroup='one',
                line=dict(color='lime', width=0),
                fillcolor='lime'
            ))
            
            fig_supply.update_layout(
                title="Supply Components (Stacked)",
                xaxis_title="Date",
                yaxis_title="BCF/d",
                height=400,
                template='plotly_white',
                hovermode='x unified'
            )
            st.plotly_chart(fig_supply, use_container_width=True)
        
        with col2:
            # Demand components
            fig_demand = go.Figure()
            
            # Add consumption by sector
            for sector, color in zip(['residential', 'commercial', 'industrial', 'power'],
                                    ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']):
                if f'total_{sector}_bcf' in filtered_df.columns:
                    fig_demand.add_trace(go.Scatter(
                        x=filtered_df['Date'],
                        y=-filtered_df[f'total_{sector}_bcf'],  # Convert to positive
                        name=sector.title(),
                        stackgroup='one',
                        line=dict(color=color, width=0),
                        fillcolor=color
                    ))
            
            # Add exports
            fig_demand.add_trace(go.Scatter(
                x=filtered_df['Date'],
                y=filtered_df['demand_lng_exports'],
                name='LNG Exports',
                stackgroup='one',
                line=dict(color='orange', width=0),
                fillcolor='orange'
            ))
            
            fig_demand.add_trace(go.Scatter(
                x=filtered_df['Date'],
                y=filtered_df['demand_mex_exports'],
                name='Mexico Exports',
                stackgroup='one',
                line=dict(color='red', width=0),
                fillcolor='red'
            ))
            
            fig_demand.update_layout(
                title="Demand Components (Stacked)",
                xaxis_title="Date",
                yaxis_title="BCF/d",
                height=400,
                template='plotly_white',
                hovermode='x unified'
            )
            st.plotly_chart(fig_demand, use_container_width=True)

# --- REGIONAL BREAKDOWN ---
if show_regional:
    st.markdown("---")
    st.markdown("## 🗺️ EIA Regional Analysis")
    
    regions = ['pacific', 'mountain', 'midwest', 'east', 'south_central']
    region_colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
    
    fig_regional = go.Figure()
    
    for region, color in zip(regions, region_colors):
        # Look for total consumption by region
        col_name = f'total_consumption_{region}_eia_bcf'
        if col_name in filtered_df.columns:
            fig_regional.add_trace(go.Scatter(
                x=filtered_df['Date'],
                y=-filtered_df[col_name],  # Convert to positive
                name=region.replace('_', ' ').title(),
                line=dict(color=color, width=2),
                hovertemplate='%{y:.1f} BCF/d<extra></extra>'
            ))
    
    fig_regional.update_layout(
        title="Daily Consumption by EIA Storage Region",
        xaxis_title="Date",
        yaxis_title="Consumption (BCF/d)",
        height=400,
        template='plotly_white',
        hovermode='x unified'
    )
    
    st.plotly_chart(fig_regional, use_container_width=True)

# --- DATA TABLE ---
with st.expander("📋 View Data Table"):
    # Select key columns
    display_cols = ['Date', 'is_forecast', 'production_bcf', 'total_consumption_bcf',
                   'lng_exports_bcf', 'storage_lower_48_bcf', 'storage_adjusted_forecast_bcf',
                   'net_balance', 'bias_adjustment_8week']
    
    available_cols = [col for col in display_cols if col in filtered_df.columns]
    display_df = filtered_df[available_cols].copy()
    display_df = display_df.round(2)
    
    # Format the dataframe for display
    st.dataframe(
        display_df.style.format({
            col: '{:.2f}' for col in display_df.select_dtypes(include=[np.number]).columns
        }),
        use_container_width=True,
        height=400
    )
    
    # Download button
    csv = display_df.to_csv(index=False)
    st.download_button(
        label="📥 Download Filtered Data",
        data=csv,
        file_name=f"storage_balance_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        mime="text/csv"
    )

# --- FOOTER ---
st.markdown("---")
col1, col2, col3 = st.columns(3)
with col1:
    st.caption(f"**Data Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}")
with col2:
    st.caption(f"**Date Range:** {filtered_df['Date'].min().strftime('%Y-%m-%d')} to {filtered_df['Date'].max().strftime('%Y-%m-%d')}")
with col3:
    if 'bias_adjustment_8week' in df.columns:
        st.caption("**Features:** 8-week bias adjustment enabled")
    else:
        st.caption("**Features:** Standard forecast")