# -*- coding: utf-8 -*-
import os
import pandas as pd
import sys
import json
import traceback

# Reuse the BASE_OUTPUT_DIR loading logic
try:
    # Attempt to get the directory of the current script
    script_dir = os.path.dirname(__file__) if '__file__' in globals() else os.getcwd()
    parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    from config.settings import BASE_OUTPUT_DIR
    print(f"Loaded BASE_OUTPUT_DIR from config: {BASE_OUTPUT_DIR}")
except ImportError:
    print("Could not import BASE_OUTPUT_DIR from config.settings. Using default.")
    # Fallback if __file__ is not defined or structure is different
    script_dir_fallback = os.getcwd()
    BASE_OUTPUT_DIR = os.path.abspath(os.path.join(script_dir_fallback, '..', 'EIA_STACK'))
    print(f"Using default BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")
except NameError: # This can happen if __file__ is not defined (e.g. in some interactive environments)
    print("Could not determine script directory using __file__. Using current working directory for default BASE_OUTPUT_DIR.")
    BASE_OUTPUT_DIR = os.path.abspath(os.path.join(os.getcwd(), '..', 'EIA_STACK')) # Fallback to CWD based path
    print(f"Using default BASE_OUTPUT_DIR: {BASE_OUTPUT_DIR}")


# Load regions from config file
try:
    script_dir = os.path.dirname(__file__) if '__file__' in globals() else os.getcwd()
    project_root_guess1 = os.path.abspath(os.path.join(script_dir, '..'))
    regions_config_path = os.path.join(project_root_guess1, 'config', 'regions.json')

    if not os.path.exists(regions_config_path):
        # Fallback for cases where script might be in a sub-sub-directory or structure is different
        project_root_guess2 = os.path.abspath(os.path.join(script_dir, '..', '..'))
        regions_config_path = os.path.join(project_root_guess2, 'config', 'regions.json')
    
    if not os.path.exists(regions_config_path):
        # Final fallback to current working directory structure (if script is run from project root)
        regions_config_path = os.path.join('config', 'regions.json')

    if not os.path.exists(regions_config_path):
        print(f"Error: Core regions config file 'config/regions.json' not found at expected paths. Exiting.")
        sys.exit(1)

    with open(regions_config_path, 'r') as f:
        regions = json.load(f)
    print(f"Loaded regions from {regions_config_path}")
except FileNotFoundError:
    print(f"Error: Core regions config file 'config/regions.json' not found. Exiting.")
    sys.exit(1)
except Exception as e:
    print(f"Error loading regions config: {e}. Exiting.")
    sys.exit(1)

print(f"\n--- Starting CSV Staging File Combination Process ---")
print(f"Combining train_staging.csv + predict_staging.csv → combined.csv")

# Process each region
for region_key in regions: # Iterate through keys if regions is a dict, or items if it's a list of strings
    region_name = region_key # Assuming region_key is the string name like "PJM", "MISO" etc.
    print(f"\n--- Processing region: {region_name.upper()} ---")
    try:
        # Define paths for train_staging, predict_staging, and combined CSV files
        train_staging_path = os.path.join(BASE_OUTPUT_DIR, region_name, 'final', 'train_staging.csv')
        predict_staging_path = os.path.join(BASE_OUTPUT_DIR, region_name, 'final', 'predict_staging.csv')
        combined_csv_path = os.path.join(BASE_OUTPUT_DIR, region_name, 'final', 'combined.csv')

        # Check if both input files exist
        if not os.path.exists(train_staging_path):
            print(f"  ❌ train_staging.csv not found for region {region_name} at {train_staging_path}. Skipping.")
            continue
        if not os.path.exists(predict_staging_path):
            print(f"  ❌ predict_staging.csv not found for region {region_name} at {predict_staging_path}. Skipping.")
            continue

        # Load the CSV files
        print(f"  📁 Loading train_staging.csv and predict_staging.csv for {region_name}...")
        
        try:
            train_df = pd.read_csv(train_staging_path)
            predict_df = pd.read_csv(predict_staging_path)
        except Exception as e:
            print(f"  ❌ Error loading CSV files for {region_name}: {e}")
            continue
        
        print(f"    Train staging data shape: {train_df.shape}")
        print(f"    Predict staging data shape: {predict_df.shape}")

        # Convert date columns to datetime if they exist
        for df, df_name in [(train_df, 'train_staging'), (predict_df, 'predict_staging')]:
            if 'date' in df.columns:
                try:
                    df['date'] = pd.to_datetime(df['date'])
                    print(f"    ✅ Converted 'date' column to datetime in {df_name}")
                except Exception as e:
                    print(f"    ⚠️  Warning: Could not convert 'date' column in {df_name}: {e}")

        # Check for column alignment
        train_cols = set(train_df.columns)
        predict_cols = set(predict_df.columns)
        
        if train_cols != predict_cols:
            missing_in_predict = train_cols - predict_cols
            missing_in_train = predict_cols - train_cols
            
            if missing_in_predict:
                print(f"    ⚠️  Columns in train but not predict: {missing_in_predict}")
            if missing_in_train:
                print(f"    ⚠️  Columns in predict but not train: {missing_in_train}")
                
            # Get common columns for safe concatenation
            common_cols = list(train_cols & predict_cols)
            print(f"    🔧 Using {len(common_cols)} common columns for combination")
            train_df = train_df[common_cols]
            predict_df = predict_df[common_cols]
        else:
            print(f"    ✅ Column structure matches between files ({len(train_cols)} columns)")

        # Combine the DataFrames
        print(f"  🔄 Combining DataFrames...")
        combined_df = pd.concat([train_df, predict_df], ignore_index=True)
        print(f"    Combined shape before processing: {combined_df.shape}")

        # Sort by date if date column exists
        if 'date' in combined_df.columns:
            print(f"  📅 Sorting by date column...")
            combined_df = combined_df.sort_values('date').reset_index(drop=True)
            
            # Show date range
            date_range = f"{combined_df['date'].min()} to {combined_df['date'].max()}"
            print(f"    Date range: {date_range}")

        # Check for NaNs before filling
        nan_counts_before = combined_df.isnull().sum()
        nan_columns_before = nan_counts_before[nan_counts_before > 0]
        total_nans_before = nan_counts_before.sum()
        
        if total_nans_before > 0:
            print(f"  🔍 Found {total_nans_before} NaN values across {len(nan_columns_before)} columns")
            if len(nan_columns_before) <= 10:  # Show details if not too many columns
                print(f"    NaN counts: {dict(nan_columns_before)}")
            else:
                print(f"    Top 5 columns with NaNs: {dict(nan_columns_before.head())}")
        else:
            print(f"  ✅ No NaN values found in combined data")

        # Forward fill NaNs, then backward fill remaining NaNs
        if total_nans_before > 0:
            print(f"  🔧 Applying forward fill (ffill) and backward fill (bfill) to handle NaNs...")
            combined_df.ffill(inplace=True)
            combined_df.bfill(inplace=True)
            
            # Check for NaNs after filling
            nan_counts_after = combined_df.isnull().sum().sum()
            if nan_counts_after > 0:
                remaining_nan_cols = combined_df.isnull().sum()[combined_df.isnull().sum() > 0]
                print(f"    ⚠️  Warning: {nan_counts_after} NaNs still present after filling!")
                print(f"    Remaining NaN columns: {dict(remaining_nan_cols)}")
            else:
                print(f"    ✅ Successfully filled all NaN values")

        # Save the combined DataFrame to CSV
        print(f"  💾 Saving combined data to {os.path.basename(combined_csv_path)}...")
        try:
            combined_df.to_csv(combined_csv_path, index=False)
            file_size_mb = os.path.getsize(combined_csv_path) / (1024 * 1024)
            print(f"  ✅ Successfully saved combined.csv for {region_name}")
            print(f"    Final dataset: {len(combined_df)} rows, {len(combined_df.columns)} columns")
            print(f"    File size: {file_size_mb:.2f} MB")
            print(f"    Breakdown: train({len(train_df)} rows) + predict({len(predict_df)} rows) = {len(combined_df)} total")
        except Exception as e:
            print(f"  ❌ Error saving combined.csv for {region_name}: {e}")
            continue

    except Exception as e:
        print(f"  ❌ Error processing region {region_name}: {e}")
        print(f"  {traceback.format_exc()}")
        continue

print(f"\n✅ CSV staging file combination process complete for all regions!")
print(f"📁 Output files: {BASE_OUTPUT_DIR}/{{region}}/final/combined.csv")