import pandas as pd
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import numpy as np
import warnings
import os

# Suppress common pandas warnings
warnings.filterwarnings('ignore', category=FutureWarning)

# --- 1. Load and Prepare Data ---
print("Step 1: Loading and preparing data...")
features_path = r'D:\EIA_STACK\Pricing_RL\MOUNTAIN\MOUNTAIN_filtered.csv' 
# UPDATED: Path to your new target file
target_path = r'D:\EIA_STACK\granular_storage\mountain.csv'
future_covariates_path = r'D:\EIA_STACK\Pricing_RL\MOUNTAIN\future_covariates.csv'

try:
    df_features_daily = pd.read_csv(features_path)
    df_target_weekly = pd.read_csv(target_path)
except FileNotFoundError as e:
    print(f"Error: Could not find a historical data file.\nDetails: {e}")
    exit()

df_features_daily['date'] = pd.to_datetime(df_features_daily['date'])
df_target_weekly['datetime'] = pd.to_datetime(df_target_weekly['datetime'])
df_features_daily.set_index('date', inplace=True)
df_target_weekly.set_index('datetime', inplace=True)

# --- 2. Advanced Feature Engineering (Daily) ---
print("\nStep 2: Engineering rolling features on historical daily data...")
# This line requires 'TEXAS_TOTAL_BCF' to exist in your filtered file.

# --- 3. Aggregate Daily Data to Weekly ---
print("\nStep 3: Aggregating historical daily data to a weekly cadence...")
aggregation_rules = {col: 'last' if '_BCF' in col or '_avg' in col or 'NONSALT' in col else 'sum' for col in df_features_daily.columns}
df_features_weekly = df_features_daily.resample('W-FRI').agg(aggregation_rules)

# --- 4. Merge Data and Engineer Weekly Features ---
print("\nStep 4: Merging data and engineering weekly/seasonal features...")
df_merged = pd.merge(df_features_weekly, df_target_weekly, left_index=True, right_index=True, how='inner')

# UPDATED: All references changed to the new target column name.
# !! IMPORTANT: Manually verify that 'south_central_nonsalt_region' is the exact column name in your CSV file !!
TARGET_COLUMN = 'Mountain' 

df_merged[f'{TARGET_COLUMN}_Lag_1_Week'] = df_merged[TARGET_COLUMN].shift(1)
df_merged[f'{TARGET_COLUMN}_Lag_2_Week'] = df_merged[TARGET_COLUMN].shift(2)
df_merged[f'{TARGET_COLUMN}_Lag_52_Week'] = df_merged[TARGET_COLUMN].shift(52)
df_merged['Week_of_Year'] = df_merged.index.isocalendar().week.astype(int)
df_merged['Month'] = df_merged.index.month
df_merged.dropna(inplace=True)


# --- 5. Define Final Features (X) and Target (y) ---
y = df_merged['Delta_Change']
# UPDATED: Dropping the new target column
X = df_merged.drop(columns=[TARGET_COLUMN, 'Delta_Change'])

# --- 6 & 7. Backtesting (Included for completeness) ---
print("\nStep 6 & 7: Running Walk-Forward Validation (Backtesting)...")
start_date_test = '2024-01-01'
test_indices = X[X.index >= start_date_test].index
backtest_results = []
for current_date in test_indices:
    X_train = X[X.index < current_date]; y_train = y[y.index < current_date]
    X_test_current = X.loc[[current_date]]; actual_delta = y.loc[current_date]
    # UPDATED: Using new target column for actual level and lag
    actual_level = df_merged.loc[current_date, TARGET_COLUMN]; last_week_level = df_merged.loc[current_date, f'{TARGET_COLUMN}_Lag_1_Week']
    lgbm = lgb.LGBMRegressor(random_state=42, n_estimators=250, learning_rate=0.05, num_leaves=31, verbose=-1)
    lgbm.fit(X_train, y_train)
    predicted_delta = lgbm.predict(X_test_current)[0]
    predicted_level = last_week_level + predicted_delta
    backtest_results.append({'Date': current_date.date(), 'Actual_Level': actual_level, 'Predicted_Level': predicted_level, 'Error': actual_level - predicted_level, 'Actual_Delta': actual_delta, 'Predicted_Delta': predicted_delta})
results_df = pd.DataFrame(backtest_results).set_index('Date')
final_mae = results_df['Error'].abs().mean()
print(f"\n--- Backtest MAE on Storage Level: {final_mae:.2f} BCF ---")


# --- 8. Train Final Model on All Data ---
print("\nStep 8: Training final model on all available data...")
lgbm_final = lgb.LGBMRegressor(random_state=42, n_estimators=250, learning_rate=0.05, num_leaves=31, verbose=-1)
lgbm_final.fit(X, y)

# --- 9. Generate Short-Term Forecast ---
print("\nStep 9: Generating short-term (next week) forecast...")
last_known_features = X.iloc[[-1]]
# UPDATED: Getting last actual level from the new target column
last_actual_level = df_merged[TARGET_COLUMN].iloc[-1]
next_delta_prediction = lgbm_final.predict(last_known_features)[0]
next_level_prediction = last_actual_level + next_delta_prediction
print("\n----------------------[ Short-Term Forecast ]-----------------------")
print(f"Predicted EIA South Central Nonsalt storage for next week: {next_level_prediction:.2f} BCF")
print("--------------------------------------------------------------------")


# --- 10. Generate LONG-TERM Forecast with optional Future Covariates ---
print("\nStep 10: Generating long-term seasonal forecast profile...")
avg_weekly_features = X.groupby('Week_of_Year').mean()
future_covariates_weekly = None

if os.path.exists(future_covariates_path):
    print(f"Found future covariates file: {future_covariates_path}")
    df_future_daily = pd.read_csv(future_covariates_path)
    df_future_daily['date'] = pd.to_datetime(df_future_daily['date'])
    df_future_daily.set_index('date', inplace=True)
    future_covariates_weekly = df_future_daily.resample('W-FRI').agg(aggregation_rules)
    print("Successfully processed future covariates.")
else:
    print("No future covariates file found.")

last_date = X.index.max()
forecast_dates = pd.date_range(start=last_date, periods=53, freq='W-FRI')[1:]
# UPDATED: Initial lags are from the new target column
lag1 = df_merged.loc[last_date, TARGET_COLUMN]
lag2 = df_merged.loc[last_date, f'{TARGET_COLUMN}_Lag_1_Week']
long_term_forecasts = []

for date in forecast_dates:
    week_num = date.isocalendar().week
    month_num = date.month

    if future_covariates_weekly is not None and date in future_covariates_weekly.index:
        features_for_week = future_covariates_weekly.loc[date].copy()
        features_for_week = features_for_week.combine_first(avg_weekly_features.loc[week_num])
    else:
        features_for_week = avg_weekly_features.loc[week_num].copy()

    # UPDATED: Overwriting with iterative lag features for new target
    features_for_week[f'{TARGET_COLUMN}_Lag_1_Week'] = lag1
    features_for_week[f'{TARGET_COLUMN}_Lag_2_Week'] = lag2
    historical_date_lookup = date - pd.DateOffset(weeks=52)
    closest_date_iloc = np.abs(df_merged.index - historical_date_lookup).argmin()
    features_for_week[f'{TARGET_COLUMN}_Lag_52_Week'] = df_merged.iloc[closest_date_iloc][TARGET_COLUMN]
    features_for_week['Week_of_Year'] = week_num
    features_for_week['Month'] = month_num

    features_df = pd.DataFrame([features_for_week], columns=X.columns)
    predicted_delta = lgbm_final.predict(features_df)[0]
    new_storage_level = lag1 + predicted_delta
    long_term_forecasts.append({'Forecast_Date': date.date(), 'Week_Number': week_num, 'Predicted_Delta': predicted_delta, 'Projected_Storage_Level': new_storage_level})

    lag2 = lag1
    lag1 = new_storage_level

forecast_df = pd.DataFrame(long_term_forecasts).set_index('Forecast_Date')
# UPDATED: Output path for south central nonsalt
output_path = r'D:\EIA_STACK\granular_storage\mountain_long_term_seasonal_forecast.csv'
forecast_df.to_csv(output_path)

print(f"\n--- Long-Term Seasonal Profile (Next 52 Weeks) ---")
print(f"Saved results to: {output_path}")
print(forecast_df.round(2))

forecast_df['Projected_Storage_Level'].plot(figsize=(15, 7), marker='.', linestyle='--')
plt.title('Projected 52-Week Storage Forecast (South Central Nonsalt Region)')
plt.xlabel('Date')
plt.ylabel('Projected Storage (BCF)')
plt.grid(True)
#plt.show()