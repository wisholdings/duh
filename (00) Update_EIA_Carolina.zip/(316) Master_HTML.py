import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX
import plotly.graph_objects as go
from datetime import timedelta, datetime
import warnings
import json
import os
import numpy as np
import traceback

# --- Suppress Warnings ---
warnings.filterwarnings("ignore")

# --- Main Configuration ---
AGGREGATE_BASE_DIR = r'D:\EIA_STACK\Pricing_RL\AGGREGATE'
CONFIG_DIR = r'c:\EIA\config'
WEATHER_UPDATE_DIR = os.path.join(AGGREGATE_BASE_DIR, "Update")
TODAY = datetime.now()
OUTPUT_FILENAME = os.path.join(AGGREGATE_BASE_DIR, "Comprehensive_Market_Report.html")

# =================================================================================
# SECTION 1: NATURAL GAS FORECAST DATA & HTML GENERATION
# =================================================================================

def get_gas_report_components():
    """
    Generates the HTML and JavaScript components for the Natural Gas Market Update tab.
    Returns a dictionary of components to be injected into the main template.
    """
    print("\n" + "="*80)
    print("   STARTING: Natural Gas Market Update Component Generation")
    print("="*80)
    
    try:
        # --- DYNAMICALLY SETTING PATHS AND DATES ---
        current_date = TODAY.strftime('%Y-%m-%d')
        file_name = f'L48_{TODAY.strftime("%Y%m%d")}.csv'
        file_path = os.path.join(AGGREGATE_BASE_DIR, file_name)
        print(f"Attempting to load data from: {file_path}")

        # --- Load Data ---
        df_full = pd.read_csv(file_path)
        df_full['Date'] = pd.to_datetime(df_full['Date'])
        df_full.set_index('Date', inplace=True)
        df_full.sort_index(inplace=True)
        
        try:
            pipe_file_path = os.path.join(AGGREGATE_BASE_DIR, 'lower_48_combined_pipe.csv')
            df_pipe = pd.read_csv(pipe_file_path)
            df_pipe['datetime'] = pd.to_datetime(df_pipe['datetime'])
            df_pipe.set_index('datetime', inplace=True)
            df_pipe.sort_index(inplace=True)
            pipe_data_loaded = True
        except FileNotFoundError:
            pipe_data_loaded = False
            df_pipe = None

        # --- Rename and Prepare Data ---
        df_full.rename(columns={'gas_hdd': 'HDD', 'population_cdd': 'CDD', 'L48_Power_Burns': 'Power Burns (Bcf/d)', 'Storage_Corrected': 'Storage Level (Bcf)', 'storage_delta': 'Storage Injection/Withdrawal (Bcf/d)'}, inplace=True)
        df_model = df_full.loc[:current_date].copy()
        df_model.drop(columns=['Implied_Storage', 'storage_lower_48_bcf'], inplace=True, errors='ignore')
        df_model.ffill(inplace=True)
        df_model.bfill(inplace=True)

        consumption_cols = ['commercial_bcf', 'industrial_bcf', 'residential_bcf', 'Power Burns (Bcf/d)', 'LNG_EXPORTS_BCF', 'MEX_EXPORTS_BCF']
        df_model['Total Consumption'] = df_model[consumption_cols].sum(axis=1).abs()
        df_model['Total Supply'] = df_model['production_bcf'] + df_model['LNG_IMPORTS_BCF'] + df_model['CAD_NET_FLOW_BCF']

        # --- Generate Forecasts ---
        metrics_to_forecast_short = ['Total Consumption', 'Total Supply', 'CDD', 'HDD', 'Power Burns (Bcf/d)', 'Storage Level (Bcf)']
        forecast_horizon_short = 14
        last_date = df_model.index[-1]
        forecast_dates_short = pd.date_range(start=last_date + timedelta(days=1), periods=forecast_horizon_short)
        forecast_df_short = pd.DataFrame(index=forecast_dates_short)

        for metric in metrics_to_forecast_short:
            series_to_forecast = df_model[metric].abs() if metric in ['Power Burns (Bcf/d)'] else df_model[metric]
            model = SARIMAX(series_to_forecast, order=(1, 1, 1), seasonal_order=(1, 1, 1, 7), enforce_stationarity=False, enforce_invertibility=False)
            try:
                results = model.fit(disp=False)
                forecast_df_short[metric] = results.get_forecast(steps=forecast_horizon_short).predicted_mean
            except Exception:
                forecast_df_short[metric] = [series_to_forecast.iloc[-1]] * forecast_horizon_short
        
        last_known_storage = df_model['Storage Level (Bcf)'].dropna().iloc[-1]
        full_storage_path = pd.concat([pd.Series([last_known_storage], index=[last_date]), forecast_df_short['Storage Level (Bcf)']])
        forecast_df_short['Storage Injection/Withdrawal (Bcf/d)'] = full_storage_path.diff().dropna().values

        # --- Process Regional Data ---
        regional_files = {'East': {'file': 'east_combined.csv', 'column': 'East', 'stats': 'east_historical_weekly_avg.csv'}, 'Midwest': {'file': 'midwest_combined.csv', 'column': 'Midwest', 'stats': 'midwest_historical_weekly_avg.csv'}, 'Mountain': {'file': 'mountain_combined.csv', 'column': 'Mountain', 'stats': 'mountain_historical_weekly_avg.csv'}, 'Pacific': {'file': 'pacific_combined.csv', 'column': 'Pacific', 'stats': 'pacific_historical_weekly_avg.csv'}, 'South Central Salt': {'file': 'south_central_salt_combined.csv', 'column': 'South Central Salt', 'stats': 'south_central_salt_historical_weekly_avg.csv'}, 'South Central Nonsalt': {'file': 'south_central_nonsalt_combined.csv', 'column': 'South Central Nonsalt', 'stats': 'south_central_nonsalt_historical_weekly_avg.csv'}}
        regional_chart_data, regional_stats_data = {}, {}
        one_year_back, one_year_forward = pd.Timestamp(current_date) - pd.DateOffset(years=1), pd.Timestamp(current_date) + pd.DateOffset(years=1)
        
        for region, file_info in regional_files.items():
            try:
                df_region = pd.read_csv(os.path.join(AGGREGATE_BASE_DIR, file_info['file']))
                df_region['datetime'] = pd.to_datetime(df_region['datetime'])
                df_region.set_index('datetime', inplace=True)
                storage_column_name = file_info['column']
                if storage_column_name not in df_region.columns or 'Delta_Change' not in df_region.columns: continue
                df_window = df_region.loc[(df_region.index >= one_year_back) & (df_region.index <= one_year_forward)]
                historical_data = df_window[df_window.index <= pd.Timestamp(current_date)][storage_column_name].dropna()
                forecast_data = df_window[df_window.index > pd.Timestamp(current_date)][storage_column_name].dropna()
                delta_data = df_window['Delta_Change'].dropna()
                all_dates, hist_values, fore_values, delta_values = [], [], [], []
                for date, value in historical_data.items(): all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(float(value)); fore_values.append(None)
                if not historical_data.empty and hist_values: fore_values[-1] = hist_values[-1]
                for date, value in forecast_data.items(): all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(None); fore_values.append(float(value))
                for date_str in all_dates: delta_values.append(float(delta_data[pd.Timestamp(date_str)]) if pd.Timestamp(date_str) in delta_data.index else None)
                regional_chart_data[region] = {'labels': json.dumps(all_dates), 'historical': json.dumps(hist_values), 'forecast': json.dumps(fore_values), 'delta': json.dumps(delta_values)}
            except Exception: pass
            try:
                df_stats = pd.read_csv(os.path.join(AGGREGATE_BASE_DIR, file_info['stats']))
                if not all(col in df_stats.columns for col in ['Week', 'Delta_Avg', 'Delta_Min', 'Delta_Max']): continue
                regional_stats_data[region] = {'labels': json.dumps(df_stats['Week'].tolist()), 'avg': json.dumps(df_stats['Delta_Avg'].tolist()), 'min': json.dumps(df_stats['Delta_Min'].tolist()), 'max': json.dumps(df_stats['Delta_Max'].tolist())}
            except Exception: pass

        # --- Prepare Summary Tables ---
        def get_pipe_week_data(end_date, df_pipe):
            try:
                row = df_pipe.loc[df_pipe.index <= end_date].iloc[-1]
                return f"{row['Lower_48_Total']:.2f} (End of Week)", f"{row['Delta_Change']/7:.2f} (Avg)", f"{row['Delta_Change']:.2f} (Sum)"
            except (IndexError, KeyError): return "N/A", "N/A", "N/A"

        pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current = get_pipe_week_data(last_date, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
        pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1 = get_pipe_week_data(last_date + timedelta(days=7), df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
        pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2 = get_pipe_week_data(last_date + timedelta(days=14), df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
        
        summary_df = pd.DataFrame({
            'Metric': ['Total Consumption', 'Total Supply', 'CDD', 'HDD', 'Power Burns (Bcf/d)', 'Storage Level (Bcf)', 'Storage Injection/Withdrawal (Bcf/d)', 'Pipe Model Delta (Bcf)'],
            'Current Week': [f"{df_model['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{df_model['Total Supply'].tail(7).mean():.2f} (Avg)", f"{df_model['CDD'].tail(7).sum():.2f} (Sum)", f"{df_model['HDD'].tail(7).sum():.2f} (Sum)", f"{df_model['Power Burns (Bcf/d)'].abs().tail(7).mean():.2f} (Avg)", pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current],
            'Week 1 Forecast': [f"{forecast_df_short['Total Consumption'].head(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].head(7).mean():.2f} (Avg)", f"{forecast_df_short['CDD'].head(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].head(7).sum():.2f} (Sum)", f"{forecast_df_short['Power Burns (Bcf/d)'].head(7).mean():.2f} (Avg)", pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1],
            'Week 2 Forecast': [f"{forecast_df_short['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].tail(7).mean():.2f} (Avg)", f"{forecast_df_short['CDD'].tail(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].tail(7).sum():.2f} (Sum)", f"{forecast_df_short['Power Burns (Bcf/d)'].tail(7).mean():.2f} (Avg)", pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2]
        })
        forecast_display_df = forecast_df_short.round(2); forecast_display_df.index = forecast_display_df.index.strftime('%Y-%m-%d')
        
        # --- Prepare Chart Data ---
        start_plot_date, end_plot_date = datetime.strptime('2024-04-01', '%Y-%m-%d'), datetime.strptime('2026-11-01', '%Y-%m-%d')
        df_plot = df_full.loc[start_plot_date:end_plot_date].copy()
        storage_plot_series = df_plot['Storage Level (Bcf)']
        chart_labels = storage_plot_series.index.strftime('%Y-%m-%d').tolist()
        chart_data = json.dumps([val if pd.notna(val) else None for val in storage_plot_series.round(2)])
        pipe_chart_data, pipe_delta_chart_data = "[]", "[]"
        if pipe_data_loaded:
            pipe_plot_series = df_pipe['Lower_48_Total'].loc[start_plot_date:end_plot_date]
            pipe_chart_data = json.dumps([val if pd.notna(val) else None for val in pipe_plot_series.reindex(storage_plot_series.index, method='ffill').round(2)])
            pipe_delta_series = df_pipe['Delta_Change']
            pipe_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in pipe_delta_series.reindex(storage_plot_series.index, method='ffill').round(2)])
        main_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in df_full['Storage Level (Bcf)'].dropna().resample('W-FRI').last().diff().reindex(storage_plot_series.index, method='ffill').round(2)])
        df_plot['Total Consumption'] = df_plot[consumption_cols].sum(axis=1).abs()
        df_plot['Total Supply'] = df_plot['production_bcf'] + df_plot['LNG_IMPORTS_BCF'] + df_plot['CAD_NET_FLOW_BCF']
        df_plot['Surplus/Deficit'] = df_plot['Total Supply'] - df_plot['Total Consumption']
        surplus_chart_data = json.dumps([val if pd.notna(val) else None for val in df_plot['Surplus/Deficit'].round(2)])
        
        # --- Build HTML and JS for Gas Report ---
        regional_charts_html, regional_scripts = "", ""
        for idx, region in enumerate(regional_files.keys()):
            regional_charts_html += f"<h3>{region} Analysis</h3>"
            if region in regional_chart_data: regional_charts_html += f'<h4>Storage Level & Weekly Change (Forecast)</h4><div class="chart-container"><canvas id="regionalChart{idx}"></canvas></div>'
            if region in regional_stats_data: regional_charts_html += f'<h4>Historical Weekly Change Distribution (5-Year)</h4><div class="chart-container"><canvas id="regionalStatsChart{idx}"></canvas></div>'
            if region in regional_chart_data:
                data = regional_chart_data[region]
                regional_scripts += f"""new Chart(document.getElementById('regionalChart{idx}'), {{ data: {{ labels: {data['labels']}, datasets: [ {{ type: 'line', label: 'Historical Storage (Bcf)', data: {data['historical']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'line', label: 'Forecast Storage (Bcf)', data: {data['forecast']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, borderDash: [6, 6], pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'bar', label: 'Weekly Delta (Bcf)', data: {data['delta']}, backgroundColor: {data['delta']}.map(v => v === null ? 'rgba(0,0,0,0)' : v >= 0 ? 'rgba(46, 204, 113, 0.7)' : 'rgba(231, 76, 60, 0.7)'), yAxisID: 'y1', barThickness: 8 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Storage Level and Weekly Change' }} }}, scales: {{ x: {{ ticks: {{ maxRotation: 45, minRotation: 45, maxTicksLimit: 12 }} }}, y: {{ type: 'linear', display: true, position: 'left', title: {{ display: true, text: 'Storage Level (Bcf)' }} }}, y1: {{ type: 'linear', display: true, position: 'right', title: {{ display: true, text: 'Weekly Change (Bcf)' }}, grid: {{ drawOnChartArea: false }} }} }} }} }});"""
            if region in regional_stats_data:
                stats = regional_stats_data[region]
                regional_scripts += f"""new Chart(document.getElementById('regionalStatsChart{idx}'), {{ type: 'line', data: {{ labels: {stats['labels']}, datasets: [ {{ label: 'Max Change', data: {stats['max']}, borderColor: 'rgba(189, 195, 199, 0.5)', pointRadius: 0, borderWidth: 1, fill: false }}, {{ label: 'Min/Max Range', data: {stats['min']}, borderColor: 'rgba(189, 195, 199, 0.5)', backgroundColor: 'rgba(189, 195, 199, 0.2)', pointRadius: 0, borderWidth: 1, fill: '-1' }}, {{ label: 'Avg Change', data: {stats['avg']}, borderColor: 'rgb(44, 62, 80)', borderWidth: 2.5, pointRadius: 0, fill: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Historical Range of Weekly Changes (Bcf)' }}, legend: {{ labels: {{ filter: function(item, chart) {{ return !item.text.includes('Max Change'); }} }} }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Week of Year' }} }}, y: {{ title: {{ display: true, text: 'Weekly Change (Bcf)' }} }} }} }} }});"""

        gas_html_content = f"""
            <div class="header"><h1>Natural Gas Market Update</h1><h2>A Two-Week Forward Look with Regional Analysis</h2></div>
            <p><b>Report Generated For Date:</b> {pd.to_datetime(current_date).strftime('%Y-%m-%d')}</p>
            <p>This report provides a two-week forecast for key U.S. natural gas fundamentals, starting from {last_date.strftime('%Y-%m-%d')}.</p>
            <h2>Key Projections Summary</h2>{summary_df.to_html(index=False, justify='left', classes='styled-table')}
            <h2>Detailed Daily Forecast (14 Days)</h2>{forecast_display_df.to_html(justify='left', classes='styled-table')}
            <h2>U.S. Lower 48 Analysis</h2>
            <h4>Storage Trajectory</h4><div class="chart-container"><canvas id="storageChart"></canvas></div>
            <h4>Weekly Storage Change</h4><div class="chart-container"><canvas id="storageDeltaChart"></canvas></div>
            <h4>Supply/Demand Balance (Surplus/Deficit)</h4><div class="chart-container"><canvas id="surplusChart"></canvas></div>
            <div class="regional-section"><h2>Regional Storage Analysis</h2>{regional_charts_html}</div>
        """
        
        gas_js_script = f"""
            const chartLabels = {json.dumps(chart_labels)};
            new Chart(document.getElementById('storageChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [ {{ label: 'Storage Level (Bcf)', data: {chart_data}, borderColor: 'rgb(52, 152, 219)', backgroundColor: 'rgba(52, 152, 219, 0.1)', borderWidth: 2.5, pointRadius: 1.5, spanGaps: false }}, {{ label: 'Storage_Modelling', data: {pipe_chart_data}, borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'U.S. Natural Gas Storage Levels (Bcf)' }} }} }} }});
            new Chart(document.getElementById('storageDeltaChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [ {{ label: 'Storage Level Change (Bcf)', data: {main_delta_chart_data}, borderColor: 'rgb(52, 152, 219)', tension: 0.1 }}, {{ label: 'Storage_Modelling Change (Bcf)', data: {pipe_delta_chart_data}, borderColor: 'rgb(231, 76, 60)', tension: 0.1 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Weekly Storage Change (Bcf)' }} }} }} }});
            new Chart(document.getElementById('surplusChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [{{ label: 'Daily Surplus/Deficit (Bcf/d)', data: {surplus_chart_data}, borderColor: 'rgb(46, 204, 113)', backgroundColor: 'rgba(46, 204, 113, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }}] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Daily Market Balance (Supply - Consumption)' }} }} }} }});
            {regional_scripts}
        """
        
        print("✓ Gas report components generated successfully.")
        return {'html': gas_html_content, 'js': gas_js_script}

    except Exception as e:
        print(f"✗ An error occurred in Natural Gas Report Generation: {e}")
        traceback.print_exc()
        return {'html': '<h2>Error Generating Natural Gas Report</h2><p>Could not generate the report. Please check the console for details.</p>', 'js': ''}

# =================================================================================
# SECTION 2: REGIONAL WEATHER DATA & HTML GENERATION
# =================================================================================

def get_weather_report_components():
    """
    Generates the HTML components for the Regional Weather Report tab.
    Returns a dictionary of components to be injected into the main template.
    """
    print("\n" + "="*80)
    print("   STARTING: Regional Weather Report Component Generation")
    print("="*80)
    
    REGIONS_TO_PROCESS = ["CONUS", "EAST", "SOUTHCENTRAL", "MOUNTAIN", "PACIFIC", "midwest"]
    all_region_html = {}

    for region in REGIONS_TO_PROCESS:
        try:
            # Load Data
            region_path = os.path.join(WEATHER_UPDATE_DIR, region)
            df_hist = pd.read_csv(os.path.join(region_path, "weather_historical.csv"), parse_dates=['DATE'])
            df_fore = pd.read_csv(os.path.join(region_path, "weather_forecast.csv"), parse_dates=['DATE', 'DATE_PUBLISHED'])
            df_hist['DATE'], df_fore['DATE'], df_fore['DATE_PUBLISHED'] = df_hist['DATE'].dt.date, df_fore['DATE'].dt.date, df_fore['DATE_PUBLISHED'].dt.date

            # Create Evolution Plots
            latest_pub_dates = sorted(df_fore['DATE_PUBLISHED'].unique(), reverse=True)[:3]
            fig_hdd, fig_cdd = go.Figure(), go.Figure()
            forecast_summary_data = []
            if latest_pub_dates:
                forecast_end_date = latest_pub_dates[0] + timedelta(days=14)
                colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
                for i, pub_date in enumerate(latest_pub_dates):
                    df_subset = df_fore[(df_fore['DATE_PUBLISHED'] == pub_date) & (df_fore['DATE'] >= pub_date) & (df_fore['DATE'] <= forecast_end_date)].sort_values('DATE')
                    if not df_subset.empty:
                        fig_hdd.add_trace(go.Scatter(x=df_subset['DATE'].tolist(), y=df_subset['GW_HDD'].tolist(), mode='lines+markers', name=f'HDD ({pub_date.strftime("%Y-%m-%d")})', line=dict(color=colors[i], dash=('solid' if i == 0 else 'dash'))))
                        fig_cdd.add_trace(go.Scatter(x=df_subset['DATE'].tolist(), y=df_subset['PW_CDD'].tolist(), mode='lines+markers', name=f'CDD ({pub_date.strftime("%Y-%m-%d")})', line=dict(color=colors[i], dash=('solid'if i == 0 else 'dash'))))
                        forecast_summary_data.append({
                            'Forecast Date': pub_date.strftime("%Y-%m-%d"),
                            'Total GW-HDD': df_subset['GW_HDD'].sum(),
                            'Total PW-CDD': df_subset['PW_CDD'].sum()
                        })

            fig_hdd.update_layout(height=450, title=f'{region}: GW-HDD Forecast Evolution', template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
            fig_cdd.update_layout(height=450, title=f'{region}: PW-CDD Forecast Evolution', template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))

            # Create Forecast Run Summary Table
            forecast_summary_table_html = ""
            if forecast_summary_data:
                df_summary = pd.DataFrame(forecast_summary_data)
                forecast_summary_table_html = df_summary.to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

            # Create Comparison Tables
            latest_pub_date = df_fore['DATE_PUBLISHED'].max()
            df_current_forecast = df_fore[df_fore['DATE_PUBLISHED'] == latest_pub_date]
            forecast_start_date = df_current_forecast['DATE'].min()
            df_forecast_window = df_current_forecast[(df_current_forecast['DATE'] >= forecast_start_date) & (df_current_forecast['DATE'] <= forecast_start_date + timedelta(days=13))]
            
            hdd_table_html, cdd_table_html = "", ""
            if len(df_forecast_window) >= 14:
                forecast_total_hdd, forecast_total_cdd = df_forecast_window['GW_HDD'].sum(), df_forecast_window['PW_CDD'].sum()
                ly_total_hdd, ly_total_cdd = 0, 0
                avg_5y_hdd_list, avg_5y_cdd_list = [], []
                df_hist['DATE'] = pd.to_datetime(df_hist['DATE'])
                for year in range(TODAY.year - 5, TODAY.year):
                    period_start = (forecast_start_date.replace(year=year, day=28) if forecast_start_date.month == 2 and forecast_start_date.day == 29 else forecast_start_date.replace(year=year))
                    period_end = period_start + timedelta(days=13)
                    df_hist_period = df_hist[(df_hist['DATE'] >= pd.to_datetime(period_start)) & (df_hist['DATE'] <= pd.to_datetime(period_end))]
                    if not df_hist_period.empty:
                        year_total_hdd, year_total_cdd = df_hist_period['GW_HDD'].sum(), df_hist_period['PW_CDD'].sum()
                        avg_5y_hdd_list.append(year_total_hdd); avg_5y_cdd_list.append(year_total_cdd)
                        if year == TODAY.year - 1: ly_total_hdd, ly_total_cdd = year_total_hdd, year_total_cdd
                avg_5y_hdd = sum(avg_5y_hdd_list) / len(avg_5y_hdd_list) if avg_5y_hdd_list else 0
                avg_5y_cdd = sum(avg_5y_cdd_list) / len(avg_5y_cdd_list) if avg_5y_cdd_list else 0
                hdd_table_html = pd.DataFrame({'Period': ['14-Day Forecast', 'Last Year', '5-Year Average'], 'Total GW-HDD': [forecast_total_hdd, ly_total_hdd, avg_5y_hdd]}).to_html(index=False, float_format='%.1f', classes='styled-table', border=0)
                cdd_table_html = pd.DataFrame({'Period': ['14-Day Forecast', 'Last Year', '5-Year Average'], 'Total PW-CDD': [forecast_total_cdd, ly_total_cdd, avg_5y_cdd]}).to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

            # Assemble Region Content
            region_content = f'''
                <div class="table-container">
                    <div class="table-wrapper"><h3>{region}: 14-Day GW-HDD Comparison</h3>{hdd_table_html}</div>
                    <div class="table-wrapper"><h3>{region}: 14-Day PW-CDD Comparison</h3>{cdd_table_html}</div>
                </div>
                <div class="table-container">
                    <div class="table-wrapper"><h3>{region}: Forecast Run Summary (15-Day Total)</h3>{forecast_summary_table_html}</div>
                </div>
            '''
            region_content += fig_hdd.to_html(full_html=False, include_plotlyjs=False)
            region_content += fig_cdd.to_html(full_html=False, include_plotlyjs=False)
            all_region_html[region] = region_content
            print(f"✓ Weather components for {region} generated.")

        except Exception as e:
            print(f"✗ Could not process weather for region {region}: {e}")
            all_region_html[region] = f"<h3>Error generating weather report for {region}.</h3>"

    # Build final HTML for the weather tab
    weather_tab_buttons = "".join([f'<button class="weather-tablinks" onclick="openWeatherRegion(event, \'{r}\')">{r}</button>' for r in all_region_html.keys()])
    weather_tab_contents = "".join([f'<div id="weather-{r}" class="weather-tabcontent" style="display:none;">{content}</div>' for r, content in all_region_html.items()])
    
    weather_html_content = f"""
        <div class="header"><h1>Regional Weather Outlook</h1></div>
        <div class="sub-tabs-container">
            <div class="sub-tab-bar">{weather_tab_buttons}</div>
            <div class="sub-tab-content-area">{weather_tab_contents}</div>
        </div>
    """
    print("✓ Weather report components generated successfully.")
    return {'html': weather_html_content}

# =================================================================================
# SECTION 3: MODELLING DETAILS & HTML GENERATION
# =================================================================================

def get_modelling_details_components():
    """
    Generates the HTML components for the Modelling Details tab.
    Returns a dictionary of components to be injected into the main template.
    """
    print("\n" + "="*80)
    print("   STARTING: Modelling Details Component Generation")
    print("="*80)
    
    try:
        # --- Define file paths ---
        mapping_file = os.path.join(CONFIG_DIR, 'month_mapping.json')
        weather_file = os.path.join(WEATHER_UPDATE_DIR, 'CONUS', 'weather_historical.csv')

        # --- Load data ---
        with open(mapping_file, 'r') as f:
            month_mapping = json.load(f)
        
        df_weather = pd.read_csv(weather_file, parse_dates=['DATE'])
        
        # --- Process data ---
        table_data = []
        for forecast_month, analog_month in month_mapping.items():
            try:
                analog_year, analog_month_num = map(int, analog_month.split('-'))
                
                # Filter weather data for the specific analog month
                df_month = df_weather[
                    (df_weather['DATE'].dt.year == analog_year) & 
                    (df_weather['DATE'].dt.month == analog_month_num)
                ]
                
                # Sum HDD and CDD for that month
                hdd_sum = df_month['GW_HDD'].sum()
                cdd_sum = df_month['PW_CDD'].sum()
                
                table_data.append({
                    'Forecast Month': forecast_month,
                    'Analog Month': analog_month,
                    'Analog Total GW-HDD': hdd_sum,
                    'Analog Total PW-CDD': cdd_sum
                })
            except Exception:
                # Append with N/A if any error occurs for a specific month
                table_data.append({
                    'Forecast Month': forecast_month,
                    'Analog Month': analog_month,
                    'Analog Total GW-HDD': 'N/A',
                    'Analog Total PW-CDD': 'N/A'
                })

        # --- Create HTML table ---
        df_details = pd.DataFrame(table_data)
        details_table_html = df_details.to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

        html_content = f"""
            <div class="header">
                <h1>Modelling Details</h1>
                <h2>Analog Month Mapping and Weather Data</h2>
            </div>
            <p>This table shows the historical analog months used for generating long-term forecasts and their corresponding total degree days.</p>
            {details_table_html}
        """
        print("✓ Modelling details components generated successfully.")
        return {'html': html_content}

    except Exception as e:
        print(f"✗ An error occurred in Modelling Details Generation: {e}")
        traceback.print_exc()
        return {'html': '<h2>Error Generating Modelling Details</h2><p>Could not generate the report. Please check the console for details.</p>'}


# =================================================================================
# SECTION 4: MAIN HTML ASSEMBLY
# =================================================================================

def generate_combined_report():
    """
    Orchestrates the generation of all components and assembles the final
    combined HTML report with a main tabbed interface.
    """
    gas_components = get_gas_report_components()
    weather_components = get_weather_report_components()
    modelling_components = get_modelling_details_components()

    # --- Master HTML Template ---
    final_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Comprehensive Market Report</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 0; background-color: #f0f2f5; color: #333; }}
            /* --- Main Tab Navigation --- */
            .main-tab-bar {{ overflow: hidden; border-bottom: 1px solid #ccc; background-color: #2c3e50; }}
            .main-tab-bar button {{ background-color: inherit; float: left; border: none; outline: none; cursor: pointer; padding: 14px 20px; transition: 0.3s; font-size: 18px; color: white; }}
            .main-tab-bar button:hover {{ background-color: #34495e; }}
            .main-tab-bar button.active {{ background-color: #3498db; }}
            .main-tab-content {{ display: none; padding: 20px; animation: fadeEffect 0.5s; }}
            @keyframes fadeEffect {{ from {{opacity: 0;}} to {{opacity: 1;}} }}

            /* --- General Content Styling --- */
            .header {{ text-align: center; margin-bottom: 20px; }}
            h1, h2, h3, h4 {{ color: #2c3e50; }}
            h1 {{ border-bottom: 3px solid #3498db; padding-bottom: 10px; }}
            .styled-table {{ border-collapse: collapse; width: 100%; max-width: 800px; margin: 20px auto; box-shadow: 0 2px 3px rgba(0,0,0,0.1); font-size: 0.9em; }}
            .styled-table th, .styled-table td {{ border: 1px solid #ddd; text-align: left; padding: 12px; }}
            .styled-table th {{ background-color: #3498db; color: white; }}
            .styled-table tbody tr:nth-child(even) {{ background-color: #f2f2f2; }}
            .chart-container {{ position: relative; height:50vh; width:100%; margin-top: 15px; margin-bottom: 40px; }}
            .regional-section, .table-container {{ margin-top: 30px; padding-top: 20px; border-top: 2px solid #bdc3c7; }}
            
            /* --- Weather Sub-Tabs --- */
            .sub-tabs-container {{ display: flex; height: calc(100vh - 100px); }}
            .sub-tab-bar {{ overflow: auto; border-right: 1px solid #ccc; background-color: #f1f1f1; width: 15%; min-width: 150px; }}
            .sub-tab-bar button {{ display: block; width: 100%; border: none; outline: none; text-align: left; padding: 18px 16px; transition: 0.3s; font-size: 16px; cursor: pointer; background-color: inherit; }}
            .sub-tab-bar button:hover {{ background-color: #ddd; }}
            .sub-tab-bar button.active {{ background-color: #ccc; }}
            .sub-tab-content-area {{ flex-grow: 1; padding: 0 20px; overflow-y: auto; }}
            .weather-tabcontent {{ display: none; }}
            .table-container {{ display: flex; justify-content: center; gap: 40px; flex-wrap: wrap; }}
            .table-wrapper {{ text-align: center; }}
        </style>
    </head>
    <body>
        <div class="main-tab-bar">
            <button class="main-tablinks" onclick="openMainTab(event, 'GasReport')" id="defaultOpen">Natural Gas Forecast</button>
            <button class="main-tablinks" onclick="openMainTab(event, 'WeatherReport')">Regional Weather</button>
            <button class="main-tablinks" onclick="openMainTab(event, 'ModellingDetails')">Modelling Details</button>
        </div>

        <div id="GasReport" class="main-tab-content">
            {gas_components['html']}
        </div>

        <div id="WeatherReport" class="main-tab-content">
            {weather_components['html']}
        </div>

        <div id="ModellingDetails" class="main-tab-content">
            {modelling_components['html']}
        </div>

        <script>
            // --- Main Tab Logic ---
            function openMainTab(evt, tabName) {{
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("main-tab-content");
                for (i = 0; i < tabcontent.length; i++) {{ tabcontent[i].style.display = "none"; }}
                tablinks = document.getElementsByClassName("main-tablinks");
                for (i = 0; i < tablinks.length; i++) {{ tablinks[i].className = tablinks[i].className.replace(" active", ""); }}
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
                
                // Trigger resize for any Plotly charts in the newly opened tab
                if (tabName === 'WeatherReport') {{
                    var plotlyGraphs = document.getElementById(tabName).getElementsByClassName('plotly-graph-div');
                    for (i = 0; i < plotlyGraphs.length; i++) {{ Plotly.Plots.resize(plotlyGraphs[i]); }}
                }}
            }}
            document.getElementById("defaultOpen").click();

            // --- Weather Sub-Tab Logic ---
            function openWeatherRegion(evt, regionName) {{
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("weather-tabcontent");
                for (i = 0; i < tabcontent.length; i++) {{ tabcontent[i].style.display = "none"; }}
                tablinks = document.getElementsByClassName("weather-tablinks");
                for (i = 0; i < tablinks.length; i++) {{ tablinks[i].className = tablinks[i].className.replace(" active", ""); }}
                var activeTab = document.getElementById("weather-" + regionName);
                activeTab.style.display = "block";
                evt.currentTarget.className += " active";
                // Resize Plotly graphs within the active sub-tab
                var plotlyGraphs = activeTab.getElementsByClassName('plotly-graph-div');
                for (i = 0; i < plotlyGraphs.length; i++) {{ Plotly.Plots.resize(plotlyGraphs[i]); }}
            }}
            // Auto-click the first weather region tab if it exists
            if (document.getElementsByClassName("weather-tablinks").length > 0) {{
                document.getElementsByClassName("weather-tablinks")[0].click();
            }}

            // --- Gas Report Chart.js Initialization ---
            {gas_components['js']}
        </script>
    </body>
    </html>
    """

    # --- Write to File ---
    try:
        with open(OUTPUT_FILENAME, "w", encoding='utf-8') as f:
            f.write(final_html)
        print("\n" + "="*80)
        print(f"✓✓✓ Comprehensive report successfully saved to: {OUTPUT_FILENAME}")
        print("="*80)
    except Exception as e:
        print(f"\n✗✗✗ Failed to write final HTML file: {e}")

# =================================================================================
# MAIN EXECUTION BLOCK
# =================================================================================

if __name__ == "__main__":
    generate_combined_report()
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX
import plotly.graph_objects as go
from datetime import timedelta, datetime
import warnings
import json
import os
import numpy as np
import traceback

# --- Suppress Warnings ---
warnings.filterwarnings("ignore")

# --- Main Configuration ---
AGGREGATE_BASE_DIR = r'D:\EIA_STACK\Pricing_RL\AGGREGATE'
CONFIG_DIR = r'c:\EIA\config'
WEATHER_UPDATE_DIR = os.path.join(AGGREGATE_BASE_DIR, "Update")
TODAY = datetime.now()
OUTPUT_FILENAME = os.path.join(AGGREGATE_BASE_DIR, "Comprehensive_Market_Report.html")

# =================================================================================
# SECTION 1: NATURAL GAS FORECAST DATA & HTML GENERATION
# =================================================================================

def get_gas_report_components():
    """
    Generates the HTML and JavaScript components for the Natural Gas Market Update tab.
    Returns a dictionary of components to be injected into the main template.
    """
    print("\n" + "="*80)
    print("   STARTING: Natural Gas Market Update Component Generation")
    print("="*80)
    
    try:
        # --- DYNAMICALLY SETTING PATHS AND DATES ---
        current_date = TODAY.strftime('%Y-%m-%d')
        file_name = f'L48_{TODAY.strftime("%Y%m%d")}.csv'
        file_path = os.path.join(AGGREGATE_BASE_DIR, file_name)
        print(f"Attempting to load data from: {file_path}")

        # --- Load Data ---
        df_full = pd.read_csv(file_path)
        df_full['Date'] = pd.to_datetime(df_full['Date'])
        df_full.set_index('Date', inplace=True)
        df_full.sort_index(inplace=True)
        
        try:
            pipe_file_path = os.path.join(AGGREGATE_BASE_DIR, 'lower_48_combined_pipe.csv')
            df_pipe = pd.read_csv(pipe_file_path)
            df_pipe['datetime'] = pd.to_datetime(df_pipe['datetime'])
            df_pipe.set_index('datetime', inplace=True)
            df_pipe.sort_index(inplace=True)
            pipe_data_loaded = True
        except FileNotFoundError:
            pipe_data_loaded = False
            df_pipe = None

        # --- Rename and Prepare Data ---
        df_full.rename(columns={'gas_hdd': 'HDD', 'population_cdd': 'CDD', 'L48_Power_Burns': 'Power Burns (Bcf/d)', 'Storage_Corrected': 'Storage Level (Bcf)', 'storage_delta': 'Storage Injection/Withdrawal (Bcf/d)'}, inplace=True)
        df_model = df_full.loc[:current_date].copy()
        df_model.drop(columns=['Implied_Storage', 'storage_lower_48_bcf'], inplace=True, errors='ignore')
        df_model.ffill(inplace=True)
        df_model.bfill(inplace=True)

        consumption_cols = ['commercial_bcf', 'industrial_bcf', 'residential_bcf', 'Power Burns (Bcf/d)', 'LNG_EXPORTS_BCF', 'MEX_EXPORTS_BCF']
        df_model['Total Consumption'] = df_model[consumption_cols].sum(axis=1).abs()
        df_model['Total Supply'] = df_model['production_bcf'] + df_model['LNG_IMPORTS_BCF'] + df_model['CAD_NET_FLOW_BCF']

        # --- Generate Forecasts ---
        metrics_to_forecast_short = ['Total Consumption', 'Total Supply', 'CDD', 'HDD', 'Power Burns (Bcf/d)', 'Storage Level (Bcf)']
        forecast_horizon_short = 14
        last_date = df_model.index[-1]
        forecast_dates_short = pd.date_range(start=last_date + timedelta(days=1), periods=forecast_horizon_short)
        forecast_df_short = pd.DataFrame(index=forecast_dates_short)

        for metric in metrics_to_forecast_short:
            series_to_forecast = df_model[metric].abs() if metric in ['Power Burns (Bcf/d)'] else df_model[metric]
            model = SARIMAX(series_to_forecast, order=(1, 1, 1), seasonal_order=(1, 1, 1, 7), enforce_stationarity=False, enforce_invertibility=False)
            try:
                results = model.fit(disp=False)
                forecast_df_short[metric] = results.get_forecast(steps=forecast_horizon_short).predicted_mean
            except Exception:
                forecast_df_short[metric] = [series_to_forecast.iloc[-1]] * forecast_horizon_short
        
        last_known_storage = df_model['Storage Level (Bcf)'].dropna().iloc[-1]
        full_storage_path = pd.concat([pd.Series([last_known_storage], index=[last_date]), forecast_df_short['Storage Level (Bcf)']])
        forecast_df_short['Storage Injection/Withdrawal (Bcf/d)'] = full_storage_path.diff().dropna().values

        # --- Process Regional Data ---
        regional_files = {'East': {'file': 'east_combined.csv', 'column': 'East', 'stats': 'east_historical_weekly_avg.csv'}, 'Midwest': {'file': 'midwest_combined.csv', 'column': 'Midwest', 'stats': 'midwest_historical_weekly_avg.csv'}, 'Mountain': {'file': 'mountain_combined.csv', 'column': 'Mountain', 'stats': 'mountain_historical_weekly_avg.csv'}, 'Pacific': {'file': 'pacific_combined.csv', 'column': 'Pacific', 'stats': 'pacific_historical_weekly_avg.csv'}, 'South Central Salt': {'file': 'south_central_salt_combined.csv', 'column': 'South Central Salt', 'stats': 'south_central_salt_historical_weekly_avg.csv'}, 'South Central Nonsalt': {'file': 'south_central_nonsalt_combined.csv', 'column': 'South Central Nonsalt', 'stats': 'south_central_nonsalt_historical_weekly_avg.csv'}}
        regional_chart_data, regional_stats_data = {}, {}
        one_year_back, one_year_forward = pd.Timestamp(current_date) - pd.DateOffset(years=1), pd.Timestamp(current_date) + pd.DateOffset(years=1)
        
        for region, file_info in regional_files.items():
            try:
                df_region = pd.read_csv(os.path.join(AGGREGATE_BASE_DIR, file_info['file']))
                df_region['datetime'] = pd.to_datetime(df_region['datetime'])
                df_region.set_index('datetime', inplace=True)
                storage_column_name = file_info['column']
                if storage_column_name not in df_region.columns or 'Delta_Change' not in df_region.columns: continue
                df_window = df_region.loc[(df_region.index >= one_year_back) & (df_region.index <= one_year_forward)]
                historical_data = df_window[df_window.index <= pd.Timestamp(current_date)][storage_column_name].dropna()
                forecast_data = df_window[df_window.index > pd.Timestamp(current_date)][storage_column_name].dropna()
                delta_data = df_window['Delta_Change'].dropna()
                all_dates, hist_values, fore_values, delta_values = [], [], [], []
                for date, value in historical_data.items(): all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(float(value)); fore_values.append(None)
                if not historical_data.empty and hist_values: fore_values[-1] = hist_values[-1]
                for date, value in forecast_data.items(): all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(None); fore_values.append(float(value))
                for date_str in all_dates: delta_values.append(float(delta_data[pd.Timestamp(date_str)]) if pd.Timestamp(date_str) in delta_data.index else None)
                regional_chart_data[region] = {'labels': json.dumps(all_dates), 'historical': json.dumps(hist_values), 'forecast': json.dumps(fore_values), 'delta': json.dumps(delta_values)}
            except Exception: pass
            try:
                df_stats = pd.read_csv(os.path.join(AGGREGATE_BASE_DIR, file_info['stats']))
                if not all(col in df_stats.columns for col in ['Week', 'Delta_Avg', 'Delta_Min', 'Delta_Max']): continue
                regional_stats_data[region] = {'labels': json.dumps(df_stats['Week'].tolist()), 'avg': json.dumps(df_stats['Delta_Avg'].tolist()), 'min': json.dumps(df_stats['Delta_Min'].tolist()), 'max': json.dumps(df_stats['Delta_Max'].tolist())}
            except Exception: pass

        # --- Prepare Summary Tables ---
        def get_pipe_week_data(end_date, df_pipe):
            try:
                row = df_pipe.loc[df_pipe.index <= end_date].iloc[-1]
                return f"{row['Lower_48_Total']:.2f} (End of Week)", f"{row['Delta_Change']/7:.2f} (Avg)", f"{row['Delta_Change']:.2f} (Sum)"
            except (IndexError, KeyError): return "N/A", "N/A", "N/A"

        pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current = get_pipe_week_data(last_date, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
        pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1 = get_pipe_week_data(last_date + timedelta(days=7), df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
        pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2 = get_pipe_week_data(last_date + timedelta(days=14), df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
        
        summary_df = pd.DataFrame({
            'Metric': ['Total Consumption', 'Total Supply', 'CDD', 'HDD', 'Power Burns (Bcf/d)', 'Storage Level (Bcf)', 'Storage Injection/Withdrawal (Bcf/d)', 'Pipe Model Delta (Bcf)'],
            'Current Week': [f"{df_model['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{df_model['Total Supply'].tail(7).mean():.2f} (Avg)", f"{df_model['CDD'].tail(7).sum():.2f} (Sum)", f"{df_model['HDD'].tail(7).sum():.2f} (Sum)", f"{df_model['Power Burns (Bcf/d)'].abs().tail(7).mean():.2f} (Avg)", pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current],
            'Week 1 Forecast': [f"{forecast_df_short['Total Consumption'].head(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].head(7).mean():.2f} (Avg)", f"{forecast_df_short['CDD'].head(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].head(7).sum():.2f} (Sum)", f"{forecast_df_short['Power Burns (Bcf/d)'].head(7).mean():.2f} (Avg)", pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1],
            'Week 2 Forecast': [f"{forecast_df_short['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].tail(7).mean():.2f} (Avg)", f"{forecast_df_short['CDD'].tail(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].tail(7).sum():.2f} (Sum)", f"{forecast_df_short['Power Burns (Bcf/d)'].tail(7).mean():.2f} (Avg)", pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2]
        })
        forecast_display_df = forecast_df_short.round(2); forecast_display_df.index = forecast_display_df.index.strftime('%Y-%m-%d')
        
        # --- Prepare Chart Data ---
        start_plot_date, end_plot_date = datetime.strptime('2024-04-01', '%Y-%m-%d'), datetime.strptime('2026-11-01', '%Y-%m-%d')
        df_plot = df_full.loc[start_plot_date:end_plot_date].copy()
        storage_plot_series = df_plot['Storage Level (Bcf)']
        chart_labels = storage_plot_series.index.strftime('%Y-%m-%d').tolist()
        chart_data = json.dumps([val if pd.notna(val) else None for val in storage_plot_series.round(2)])
        pipe_chart_data, pipe_delta_chart_data = "[]", "[]"
        if pipe_data_loaded:
            pipe_plot_series = df_pipe['Lower_48_Total'].loc[start_plot_date:end_plot_date]
            pipe_chart_data = json.dumps([val if pd.notna(val) else None for val in pipe_plot_series.reindex(storage_plot_series.index, method='ffill').round(2)])
            pipe_delta_series = df_pipe['Delta_Change']
            pipe_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in pipe_delta_series.reindex(storage_plot_series.index, method='ffill').round(2)])
        main_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in df_full['Storage Level (Bcf)'].dropna().resample('W-FRI').last().diff().reindex(storage_plot_series.index, method='ffill').round(2)])
        df_plot['Total Consumption'] = df_plot[consumption_cols].sum(axis=1).abs()
        df_plot['Total Supply'] = df_plot['production_bcf'] + df_plot['LNG_IMPORTS_BCF'] + df_plot['CAD_NET_FLOW_BCF']
        df_plot['Surplus/Deficit'] = df_plot['Total Supply'] - df_plot['Total Consumption']
        surplus_chart_data = json.dumps([val if pd.notna(val) else None for val in df_plot['Surplus/Deficit'].round(2)])
        
        # --- Build HTML and JS for Gas Report ---
        regional_charts_html, regional_scripts = "", ""
        for idx, region in enumerate(regional_files.keys()):
            regional_charts_html += f"<h3>{region} Analysis</h3>"
            if region in regional_chart_data: regional_charts_html += f'<h4>Storage Level & Weekly Change (Forecast)</h4><div class="chart-container"><canvas id="regionalChart{idx}"></canvas></div>'
            if region in regional_stats_data: regional_charts_html += f'<h4>Historical Weekly Change Distribution (5-Year)</h4><div class="chart-container"><canvas id="regionalStatsChart{idx}"></canvas></div>'
            if region in regional_chart_data:
                data = regional_chart_data[region]
                regional_scripts += f"""new Chart(document.getElementById('regionalChart{idx}'), {{ data: {{ labels: {data['labels']}, datasets: [ {{ type: 'line', label: 'Historical Storage (Bcf)', data: {data['historical']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'line', label: 'Forecast Storage (Bcf)', data: {data['forecast']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, borderDash: [6, 6], pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'bar', label: 'Weekly Delta (Bcf)', data: {data['delta']}, backgroundColor: {data['delta']}.map(v => v === null ? 'rgba(0,0,0,0)' : v >= 0 ? 'rgba(46, 204, 113, 0.7)' : 'rgba(231, 76, 60, 0.7)'), yAxisID: 'y1', barThickness: 8 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Storage Level and Weekly Change' }} }}, scales: {{ x: {{ ticks: {{ maxRotation: 45, minRotation: 45, maxTicksLimit: 12 }} }}, y: {{ type: 'linear', display: true, position: 'left', title: {{ display: true, text: 'Storage Level (Bcf)' }} }}, y1: {{ type: 'linear', display: true, position: 'right', title: {{ display: true, text: 'Weekly Change (Bcf)' }}, grid: {{ drawOnChartArea: false }} }} }} }} }});"""
            if region in regional_stats_data:
                stats = regional_stats_data[region]
                regional_scripts += f"""new Chart(document.getElementById('regionalStatsChart{idx}'), {{ type: 'line', data: {{ labels: {stats['labels']}, datasets: [ {{ label: 'Max Change', data: {stats['max']}, borderColor: 'rgba(189, 195, 199, 0.5)', pointRadius: 0, borderWidth: 1, fill: false }}, {{ label: 'Min/Max Range', data: {stats['min']}, borderColor: 'rgba(189, 195, 199, 0.5)', backgroundColor: 'rgba(189, 195, 199, 0.2)', pointRadius: 0, borderWidth: 1, fill: '-1' }}, {{ label: 'Avg Change', data: {stats['avg']}, borderColor: 'rgb(44, 62, 80)', borderWidth: 2.5, pointRadius: 0, fill: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Historical Range of Weekly Changes (Bcf)' }}, legend: {{ labels: {{ filter: function(item, chart) {{ return !item.text.includes('Max Change'); }} }} }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Week of Year' }} }}, y: {{ title: {{ display: true, text: 'Weekly Change (Bcf)' }} }} }} }} }});"""

        gas_html_content = f"""
            <div class="header"><h1>Natural Gas Market Update</h1><h2>A Two-Week Forward Look with Regional Analysis</h2></div>
            <p><b>Report Generated For Date:</b> {pd.to_datetime(current_date).strftime('%Y-%m-%d')}</p>
            <p>This report provides a two-week forecast for key U.S. natural gas fundamentals, starting from {last_date.strftime('%Y-%m-%d')}.</p>
            <h2>Key Projections Summary</h2>{summary_df.to_html(index=False, justify='left', classes='styled-table')}
            <h2>Detailed Daily Forecast (14 Days)</h2>{forecast_display_df.to_html(justify='left', classes='styled-table')}
            <h2>U.S. Lower 48 Analysis</h2>
            <h4>Storage Trajectory</h4><div class="chart-container"><canvas id="storageChart"></canvas></div>
            <h4>Weekly Storage Change</h4><div class="chart-container"><canvas id="storageDeltaChart"></canvas></div>
            <h4>Supply/Demand Balance (Surplus/Deficit)</h4><div class="chart-container"><canvas id="surplusChart"></canvas></div>
            <div class="regional-section"><h2>Regional Storage Analysis</h2>{regional_charts_html}</div>
        """
        
        gas_js_script = f"""
            const chartLabels = {json.dumps(chart_labels)};
            new Chart(document.getElementById('storageChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [ {{ label: 'Storage Level (Bcf)', data: {chart_data}, borderColor: 'rgb(52, 152, 219)', backgroundColor: 'rgba(52, 152, 219, 0.1)', borderWidth: 2.5, pointRadius: 1.5, spanGaps: false }}, {{ label: 'Storage_Modelling', data: {pipe_chart_data}, borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'U.S. Natural Gas Storage Levels (Bcf)' }} }} }} }});
            new Chart(document.getElementById('storageDeltaChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [ {{ label: 'Storage Level Change (Bcf)', data: {main_delta_chart_data}, borderColor: 'rgb(52, 152, 219)', tension: 0.1 }}, {{ label: 'Storage_Modelling Change (Bcf)', data: {pipe_delta_chart_data}, borderColor: 'rgb(231, 76, 60)', tension: 0.1 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Weekly Storage Change (Bcf)' }} }} }} }});
            new Chart(document.getElementById('surplusChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [{{ label: 'Daily Surplus/Deficit (Bcf/d)', data: {surplus_chart_data}, borderColor: 'rgb(46, 204, 113)', backgroundColor: 'rgba(46, 204, 113, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }}] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Daily Market Balance (Supply - Consumption)' }} }} }} }});
            {regional_scripts}
        """
        
        print("✓ Gas report components generated successfully.")
        return {'html': gas_html_content, 'js': gas_js_script}

    except Exception as e:
        print(f"✗ An error occurred in Natural Gas Report Generation: {e}")
        traceback.print_exc()
        return {'html': '<h2>Error Generating Natural Gas Report</h2><p>Could not generate the report. Please check the console for details.</p>', 'js': ''}

# =================================================================================
# SECTION 2: REGIONAL WEATHER DATA & HTML GENERATION
# =================================================================================

def get_weather_report_components():
    """
    Generates the HTML components for the Regional Weather Report tab.
    Returns a dictionary of components to be injected into the main template.
    """
    print("\n" + "="*80)
    print("   STARTING: Regional Weather Report Component Generation")
    print("="*80)
    
    REGIONS_TO_PROCESS = ["CONUS", "EAST", "SOUTHCENTRAL", "MOUNTAIN", "PACIFIC", "midwest"]
    all_region_html = {}

    for region in REGIONS_TO_PROCESS:
        try:
            # Load Data
            region_path = os.path.join(WEATHER_UPDATE_DIR, region)
            df_hist = pd.read_csv(os.path.join(region_path, "weather_historical.csv"), parse_dates=['DATE'])
            df_fore = pd.read_csv(os.path.join(region_path, "weather_forecast.csv"), parse_dates=['DATE', 'DATE_PUBLISHED'])
            df_hist['DATE'], df_fore['DATE'], df_fore['DATE_PUBLISHED'] = df_hist['DATE'].dt.date, df_fore['DATE'].dt.date, df_fore['DATE_PUBLISHED'].dt.date

            # Create Evolution Plots
            latest_pub_dates = sorted(df_fore['DATE_PUBLISHED'].unique(), reverse=True)[:3]
            fig_hdd, fig_cdd = go.Figure(), go.Figure()
            forecast_summary_data = []
            if latest_pub_dates:
                forecast_end_date = latest_pub_dates[0] + timedelta(days=14)
                colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
                for i, pub_date in enumerate(latest_pub_dates):
                    df_subset = df_fore[(df_fore['DATE_PUBLISHED'] == pub_date) & (df_fore['DATE'] >= pub_date) & (df_fore['DATE'] <= forecast_end_date)].sort_values('DATE')
                    if not df_subset.empty:
                        fig_hdd.add_trace(go.Scatter(x=df_subset['DATE'].tolist(), y=df_subset['GW_HDD'].tolist(), mode='lines+markers', name=f'HDD ({pub_date.strftime("%Y-%m-%d")})', line=dict(color=colors[i], dash=('solid' if i == 0 else 'dash'))))
                        fig_cdd.add_trace(go.Scatter(x=df_subset['DATE'].tolist(), y=df_subset['PW_CDD'].tolist(), mode='lines+markers', name=f'CDD ({pub_date.strftime("%Y-%m-%d")})', line=dict(color=colors[i], dash=('solid'if i == 0 else 'dash'))))
                        forecast_summary_data.append({
                            'Forecast Date': pub_date.strftime("%Y-%m-%d"),
                            'Total GW-HDD': df_subset['GW_HDD'].sum(),
                            'Total PW-CDD': df_subset['PW_CDD'].sum()
                        })

            fig_hdd.update_layout(height=450, title=f'{region}: GW-HDD Forecast Evolution', template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
            fig_cdd.update_layout(height=450, title=f'{region}: PW-CDD Forecast Evolution', template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))

            # Create Forecast Run Summary Table
            forecast_summary_table_html = ""
            if forecast_summary_data:
                df_summary = pd.DataFrame(forecast_summary_data)
                forecast_summary_table_html = df_summary.to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

            # Create Comparison Tables
            latest_pub_date = df_fore['DATE_PUBLISHED'].max()
            df_current_forecast = df_fore[df_fore['DATE_PUBLISHED'] == latest_pub_date]
            forecast_start_date = df_current_forecast['DATE'].min()
            df_forecast_window = df_current_forecast[(df_current_forecast['DATE'] >= forecast_start_date) & (df_current_forecast['DATE'] <= forecast_start_date + timedelta(days=13))]
            
            hdd_table_html, cdd_table_html = "", ""
            if len(df_forecast_window) >= 14:
                forecast_total_hdd, forecast_total_cdd = df_forecast_window['GW_HDD'].sum(), df_forecast_window['PW_CDD'].sum()
                ly_total_hdd, ly_total_cdd = 0, 0
                avg_5y_hdd_list, avg_5y_cdd_list = [], []
                df_hist['DATE'] = pd.to_datetime(df_hist['DATE'])
                for year in range(TODAY.year - 5, TODAY.year):
                    period_start = (forecast_start_date.replace(year=year, day=28) if forecast_start_date.month == 2 and forecast_start_date.day == 29 else forecast_start_date.replace(year=year))
                    period_end = period_start + timedelta(days=13)
                    df_hist_period = df_hist[(df_hist['DATE'] >= pd.to_datetime(period_start)) & (df_hist['DATE'] <= pd.to_datetime(period_end))]
                    if not df_hist_period.empty:
                        year_total_hdd, year_total_cdd = df_hist_period['GW_HDD'].sum(), df_hist_period['PW_CDD'].sum()
                        avg_5y_hdd_list.append(year_total_hdd); avg_5y_cdd_list.append(year_total_cdd)
                        if year == TODAY.year - 1: ly_total_hdd, ly_total_cdd = year_total_hdd, year_total_cdd
                avg_5y_hdd = sum(avg_5y_hdd_list) / len(avg_5y_hdd_list) if avg_5y_hdd_list else 0
                avg_5y_cdd = sum(avg_5y_cdd_list) / len(avg_5y_cdd_list) if avg_5y_cdd_list else 0
                hdd_table_html = pd.DataFrame({'Period': ['14-Day Forecast', 'Last Year', '5-Year Average'], 'Total GW-HDD': [forecast_total_hdd, ly_total_hdd, avg_5y_hdd]}).to_html(index=False, float_format='%.1f', classes='styled-table', border=0)
                cdd_table_html = pd.DataFrame({'Period': ['14-Day Forecast', 'Last Year', '5-Year Average'], 'Total PW-CDD': [forecast_total_cdd, ly_total_cdd, avg_5y_cdd]}).to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

            # Assemble Region Content
            region_content = f'''
                <div class="table-container">
                    <div class="table-wrapper"><h3>{region}: 14-Day GW-HDD Comparison</h3>{hdd_table_html}</div>
                    <div class="table-wrapper"><h3>{region}: 14-Day PW-CDD Comparison</h3>{cdd_table_html}</div>
                </div>
                <div class="table-container">
                    <div class="table-wrapper"><h3>{region}: Forecast Run Summary (15-Day Total)</h3>{forecast_summary_table_html}</div>
                </div>
            '''
            region_content += fig_hdd.to_html(full_html=False, include_plotlyjs=False)
            region_content += fig_cdd.to_html(full_html=False, include_plotlyjs=False)
            all_region_html[region] = region_content
            print(f"✓ Weather components for {region} generated.")

        except Exception as e:
            print(f"✗ Could not process weather for region {region}: {e}")
            all_region_html[region] = f"<h3>Error generating weather report for {region}.</h3>"

    # Build final HTML for the weather tab
    weather_tab_buttons = "".join([f'<button class="weather-tablinks" onclick="openWeatherRegion(event, \'{r}\')">{r}</button>' for r in all_region_html.keys()])
    weather_tab_contents = "".join([f'<div id="weather-{r}" class="weather-tabcontent" style="display:none;">{content}</div>' for r, content in all_region_html.items()])
    
    weather_html_content = f"""
        <div class="header"><h1>Regional Weather Outlook</h1></div>
        <div class="sub-tabs-container">
            <div class="sub-tab-bar">{weather_tab_buttons}</div>
            <div class="sub-tab-content-area">{weather_tab_contents}</div>
        </div>
    """
    print("✓ Weather report components generated successfully.")
    return {'html': weather_html_content}

# =================================================================================
# SECTION 3: MODELLING DETAILS & HTML GENERATION
# =================================================================================

def get_modelling_details_components():
    """
    Generates the HTML components for the Modelling Details tab.
    Returns a dictionary of components to be injected into the main template.
    """
    print("\n" + "="*80)
    print("   STARTING: Modelling Details Component Generation")
    print("="*80)
    
    try:
        # --- Define file paths ---
        mapping_file = os.path.join(CONFIG_DIR, 'month_mapping.json')
        weather_file = os.path.join(WEATHER_UPDATE_DIR, 'CONUS', 'weather_historical.csv')

        # --- Load data ---
        with open(mapping_file, 'r') as f:
            month_mapping = json.load(f)
        
        df_weather = pd.read_csv(weather_file, parse_dates=['DATE'])
        
        # --- Process data ---
        table_data = []
        for forecast_month, analog_month in month_mapping.items():
            try:
                analog_year, analog_month_num = map(int, analog_month.split('-'))
                
                # Filter weather data for the specific analog month
                df_month = df_weather[
                    (df_weather['DATE'].dt.year == analog_year) & 
                    (df_weather['DATE'].dt.month == analog_month_num)
                ]
                
                # Sum HDD and CDD for that month
                hdd_sum = df_month['GW_HDD'].sum()
                cdd_sum = df_month['PW_CDD'].sum()
                
                table_data.append({
                    'Forecast Month': forecast_month,
                    'Analog Month': analog_month,
                    'Analog Total GW-HDD': hdd_sum,
                    'Analog Total PW-CDD': cdd_sum
                })
            except Exception:
                # Append with N/A if any error occurs for a specific month
                table_data.append({
                    'Forecast Month': forecast_month,
                    'Analog Month': analog_month,
                    'Analog Total GW-HDD': 'N/A',
                    'Analog Total PW-CDD': 'N/A'
                })

        # --- Create HTML table ---
        df_details = pd.DataFrame(table_data)
        details_table_html = df_details.to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

        html_content = f"""
            <div class="header">
                <h1>Modelling Details</h1>
                <h2>Analog Month Mapping and Weather Data</h2>
            </div>
            <p>This table shows the historical analog months used for generating long-term forecasts and their corresponding total degree days.</p>
            {details_table_html}
        """
        print("✓ Modelling details components generated successfully.")
        return {'html': html_content}

    except Exception as e:
        print(f"✗ An error occurred in Modelling Details Generation: {e}")
        traceback.print_exc()
        return {'html': '<h2>Error Generating Modelling Details</h2><p>Could not generate the report. Please check the console for details.</p>'}


# =================================================================================
# SECTION 4: MAIN HTML ASSEMBLY
# =================================================================================

def generate_combined_report():
    """
    Orchestrates the generation of all components and assembles the final
    combined HTML report with a main tabbed interface.
    """
    gas_components = get_gas_report_components()
    weather_components = get_weather_report_components()
    modelling_components = get_modelling_details_components()

    # --- Master HTML Template ---
    final_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Comprehensive Market Report</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 0; background-color: #f0f2f5; color: #333; }}
            /* --- Main Tab Navigation --- */
            .main-tab-bar {{ overflow: hidden; border-bottom: 1px solid #ccc; background-color: #2c3e50; }}
            .main-tab-bar button {{ background-color: inherit; float: left; border: none; outline: none; cursor: pointer; padding: 14px 20px; transition: 0.3s; font-size: 18px; color: white; }}
            .main-tab-bar button:hover {{ background-color: #34495e; }}
            .main-tab-bar button.active {{ background-color: #3498db; }}
            .main-tab-content {{ display: none; padding: 20px; animation: fadeEffect 0.5s; }}
            @keyframes fadeEffect {{ from {{opacity: 0;}} to {{opacity: 1;}} }}

            /* --- General Content Styling --- */
            .header {{ text-align: center; margin-bottom: 20px; }}
            h1, h2, h3, h4 {{ color: #2c3e50; }}
            h1 {{ border-bottom: 3px solid #3498db; padding-bottom: 10px; }}
            .styled-table {{ border-collapse: collapse; width: 100%; max-width: 800px; margin: 20px auto; box-shadow: 0 2px 3px rgba(0,0,0,0.1); font-size: 0.9em; }}
            .styled-table th, .styled-table td {{ border: 1px solid #ddd; text-align: left; padding: 12px; }}
            .styled-table th {{ background-color: #3498db; color: white; }}
            .styled-table tbody tr:nth-child(even) {{ background-color: #f2f2f2; }}
            .chart-container {{ position: relative; height:50vh; width:100%; margin-top: 15px; margin-bottom: 40px; }}
            .regional-section, .table-container {{ margin-top: 30px; padding-top: 20px; border-top: 2px solid #bdc3c7; }}
            
            /* --- Weather Sub-Tabs --- */
            .sub-tabs-container {{ display: flex; height: calc(100vh - 100px); }}
            .sub-tab-bar {{ overflow: auto; border-right: 1px solid #ccc; background-color: #f1f1f1; width: 15%; min-width: 150px; }}
            .sub-tab-bar button {{ display: block; width: 100%; border: none; outline: none; text-align: left; padding: 18px 16px; transition: 0.3s; font-size: 16px; cursor: pointer; background-color: inherit; }}
            .sub-tab-bar button:hover {{ background-color: #ddd; }}
            .sub-tab-bar button.active {{ background-color: #ccc; }}
            .sub-tab-content-area {{ flex-grow: 1; padding: 0 20px; overflow-y: auto; }}
            .weather-tabcontent {{ display: none; }}
            .table-container {{ display: flex; justify-content: center; gap: 40px; flex-wrap: wrap; }}
            .table-wrapper {{ text-align: center; }}
        </style>
    </head>
    <body>
        <div class="main-tab-bar">
            <button class="main-tablinks" onclick="openMainTab(event, 'GasReport')" id="defaultOpen">Natural Gas Forecast</button>
            <button class="main-tablinks" onclick="openMainTab(event, 'WeatherReport')">Regional Weather</button>
            <button class="main-tablinks" onclick="openMainTab(event, 'ModellingDetails')">Modelling Details</button>
        </div>

        <div id="GasReport" class="main-tab-content">
            {gas_components['html']}
        </div>

        <div id="WeatherReport" class="main-tab-content">
            {weather_components['html']}
        </div>

        <div id="ModellingDetails" class="main-tab-content">
            {modelling_components['html']}
        </div>

        <script>
            // --- Main Tab Logic ---
            function openMainTab(evt, tabName) {{
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("main-tab-content");
                for (i = 0; i < tabcontent.length; i++) {{ tabcontent[i].style.display = "none"; }}
                tablinks = document.getElementsByClassName("main-tablinks");
                for (i = 0; i < tablinks.length; i++) {{ tablinks[i].className = tablinks[i].className.replace(" active", ""); }}
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
                
                // Trigger resize for any Plotly charts in the newly opened tab
                if (tabName === 'WeatherReport') {{
                    var plotlyGraphs = document.getElementById(tabName).getElementsByClassName('plotly-graph-div');
                    for (i = 0; i < plotlyGraphs.length; i++) {{ Plotly.Plots.resize(plotlyGraphs[i]); }}
                }}
            }}
            document.getElementById("defaultOpen").click();

            // --- Weather Sub-Tab Logic ---
            function openWeatherRegion(evt, regionName) {{
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("weather-tabcontent");
                for (i = 0; i < tabcontent.length; i++) {{ tabcontent[i].style.display = "none"; }}
                tablinks = document.getElementsByClassName("weather-tablinks");
                for (i = 0; i < tablinks.length; i++) {{ tablinks[i].className = tablinks[i].className.replace(" active", ""); }}
                var activeTab = document.getElementById("weather-" + regionName);
                activeTab.style.display = "block";
                evt.currentTarget.className += " active";
                // Resize Plotly graphs within the active sub-tab
                var plotlyGraphs = activeTab.getElementsByClassName('plotly-graph-div');
                for (i = 0; i < plotlyGraphs.length; i++) {{ Plotly.Plots.resize(plotlyGraphs[i]); }}
            }}
            // Auto-click the first weather region tab if it exists
            if (document.getElementsByClassName("weather-tablinks").length > 0) {{
                document.getElementsByClassName("weather-tablinks")[0].click();
            }}

            // --- Gas Report Chart.js Initialization ---
            {gas_components['js']}
        </script>
    </body>
    </html>
    """

    # --- Write to File ---
    try:
        with open(OUTPUT_FILENAME, "w", encoding='utf-8') as f:
            f.write(final_html)
        print("\n" + "="*80)
        print(f"✓✓✓ Comprehensive report successfully saved to: {OUTPUT_FILENAME}")
        print("="*80)
    except Exception as e:
        print(f"\n✗✗✗ Failed to write final HTML file: {e}")

# =================================================================================
# MAIN EXECUTION BLOCK
# =================================================================================

if __name__ == "__main__":
    generate_combined_report()