import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
import joblib
import time
import traceback
import sys
import os
from collections import deque
import multiprocessing
import warnings
from typing import Dict, List, Optional, Any, Deque
import gc

# Suppress scikit-learn warning about feature names
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.utils.validation")

# --- Check for Parquet Engine Dependency ---
try:
    import pyarrow
    print("PyArrow engine found.")
    PARQUET_ENGINE = 'pyarrow'
except ImportError:
    print("Warning: PyArrow library not found. Parquet operations might be slower or fail if 'auto' engine doesn't find an alternative.")
    PARQUET_ENGINE = 'auto'

# --- Path Setup ---
BASE_OUTPUT_DIR = r"D:\EIA_STACK"
print(f"Looking for data in: {os.path.abspath(BASE_OUTPUT_DIR)}")

# --- Define regions ---
REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "newyork", "northwest", "southeast", "southwest", "tennessee", "texas"
]

# --- MODIFIED: Configuration for the Target Variable ---
TARGET_COL_BASE = "LOAD"
print(f"✅ Script is now configured to model: {TARGET_COL_BASE}")

# --- NEW: Boundary Handling Parameters ---
BRIDGE_HOURS = 168
BOUNDARY_SMOOTH_HOURS = 6
ANOMALY_THRESHOLD_STD = 2.0

# --- CRITICAL: Clipping Parameters for LOAD ---
# LOAD should be non-negative
CLIP_MIN = 0.0
CLIP_MAX = float('inf')  # No upper bound for LOAD

# --- Define Quantile Models to Run for LOAD ---
QUANTILE_MODELS = [
    {"quantile": 0.10, "name": "Q10"},
    {"quantile": 0.20, "name": "Q20"},
    {"quantile": 0.30, "name": "Q30"}, 
    {"quantile": 0.40, "name": "Q40"},
    {"quantile": 0.50, "name": "Median"}, 
    {"quantile": 0.60, "name": "Q60"},
    {"quantile": 0.70, "name": "Q70"}, 
    {"quantile": 0.80, "name": "Q80"},
    {"quantile": 0.90, "name": "Q90"}, 
    {"quantile": 0.99, "name": "Q99"},
]

# Create a mapping for output filenames
QUANTILE_OUTPUT_FILENAMES = {
    0.10: "load_prediction_q10.parquet",
    0.20: "load_prediction_q20.parquet",
    0.30: "load_prediction_q30.parquet",
    0.40: "load_prediction_q40.parquet",
    0.50: "load_prediction_median.parquet", 
    0.60: "load_prediction_q60.parquet",
    0.70: "load_prediction_q70.parquet",
    0.80: "load_prediction_q80.parquet",
    0.90: "load_prediction_q90.parquet", 
    0.99: "load_prediction_q99.parquet",
}

# --- Configuration Variables ---
TRAIN_INPUT_FILENAME_BASE = "train.parquet"
FUTURE_COVARIATES_FILENAME_BASE = "predict.parquet"
DATE_COL = "date"

N_HISTORY_HOURS_FOR_DEQUE = 120
CDD_THRESHOLD_C = 18.0
COOLING_NL_THRESHOLD_C = 22.0
XGB_VALIDATION_SPLIT_FRACTION = 0.15
SCALE_XGB_FEATURES = True

# Rolling windows and max lag for feature engineering
ALL_LAGS = [1, 24]  # Only 2 features: recent, daily
MAX_LAG = max(ALL_LAGS) if ALL_LAGS else 0
ROLLING_WINDOWS = [24,168]   # Just daily average
MAX_ROLLING_WINDOW = max(ROLLING_WINDOWS) if ROLLING_WINDOWS else 0

# --- XGBoost Specific Parameters ---
XGB_PARAMS = {
    'objective': 'reg:quantileerror',
    'n_estimators': 700,         # Reduced from 600
    'learning_rate': 0.08,       # Increased from 0.04
    'max_depth': 11,              # Reduced from 9
    'subsample': 0.8,
    'colsample_bytree': 0.8,
    'random_state': 42,
    'n_jobs': -1,                
    'early_stopping_rounds': 25,
    'eval_metric': 'mae',
    'reg_alpha': 0.05,
    'reg_lambda': 0.05,
    'min_child_weight': 12
}

print(f"XGBoost parameters (base): {XGB_PARAMS}")

# --- OPTIMIZATION FUNCTIONS ---
def optimize_data_types(df, xgb_feature_cols):
    """Optimize data types for faster processing."""
    df_opt = df.copy()
    
    for col in xgb_feature_cols:
        if col in df_opt.columns:
            # Convert all numeric columns to float32 for consistency and speed
            if pd.api.types.is_numeric_dtype(df_opt[col]):
                df_opt[col] = df_opt[col].astype(np.float32)
    
    return df_opt

def pre_scale_future_data(X_future, scaler, cols_to_scale):
    """Pre-scale all future data to avoid repeated scaling in loop."""
    if scaler and cols_to_scale:
        # Convert to float32 first to avoid dtype warnings
        X_future_scaled = X_future.copy()
        for col in cols_to_scale:
            if col in X_future_scaled.columns:
                X_future_scaled[col] = X_future_scaled[col].astype(np.float32)
        
        # Scale all at once
        scaled_values = scaler.transform(X_future_scaled[cols_to_scale]).astype(np.float32)
        X_future_scaled[cols_to_scale] = scaled_values
        return X_future_scaled
    return X_future

def fast_recursive_forecast_optimized(model_xgb, X_future_scaled, recent_target_values, 
                                    expected_order, ALL_LAGS, ROLLING_WINDOWS, TARGET_COL):
    """Ultra-optimized recursive forecasting using numpy operations."""
    
    n_predictions = len(X_future_scaled)
    predictions = np.zeros(n_predictions, dtype=np.float32)
    
    # Convert to numpy for maximum speed
    X_future_np = X_future_scaled[expected_order].values.astype(np.float32)
    history_array = np.array(recent_target_values, dtype=np.float32)
    
    # Pre-identify feature column indices for direct numpy access
    lag_indices = {}
    rolling_indices = {}
    
    for lag in ALL_LAGS:
        feature_name = f'{TARGET_COL}_lag_{lag}'
        if feature_name in expected_order:
            lag_indices[lag] = expected_order.index(feature_name)
    
    for window in ROLLING_WINDOWS:
        feature_name = f'{TARGET_COL}_rolling_mean_{window}h'
        if feature_name in expected_order:
            rolling_indices[window] = expected_order.index(feature_name)
    
    # Main prediction loop - pure numpy for maximum speed
    for i in range(n_predictions):
        try:
            # Update lag features directly in numpy array
            for lag, col_idx in lag_indices.items():
                if len(history_array) >= lag:
                    X_future_np[i, col_idx] = history_array[-lag]
                else:
                    X_future_np[i, col_idx] = 0.0
            
            # Update rolling features directly in numpy array  
            for window, col_idx in rolling_indices.items():
                if len(history_array) >= window:
                    X_future_np[i, col_idx] = np.mean(history_array[-window:])
                elif len(history_array) > 0:
                    X_future_np[i, col_idx] = np.mean(history_array)
                else:
                    X_future_np[i, col_idx] = 0.0
            
            # Make prediction - single row
            pred_value = model_xgb.predict(X_future_np[i:i+1])[0]
            
            # Apply clipping
            clipped_pred = max(0.0, pred_value)  # Faster than np.clip for single values
            predictions[i] = clipped_pred
            
            # Update history efficiently
            history_array = np.append(history_array, clipped_pred)
            if len(history_array) > 200:  # Keep reasonable size
                history_array = history_array[-200:]
                
        except Exception as e:
            # Fallback prediction
            fallback_pred = np.mean(history_array) if len(history_array) > 0 else 0.0
            predictions[i] = max(0.0, fallback_pred)
            history_array = np.append(history_array, predictions[i])
    
    return predictions

def batch_recursive_forecast(model_xgb, X_future_scaled, recent_target_values, 
                           expected_order, ALL_LAGS, ROLLING_WINDOWS, TARGET_COL, batch_size=100):
    """Batch-optimized recursive forecasting."""
    
    n_predictions = len(X_future_scaled)
    predictions = np.zeros(n_predictions, dtype=np.float32)
    X_future_np = X_future_scaled[expected_order].values.astype(np.float32)
    history_deque = deque(recent_target_values, maxlen=200)
    
    # Pre-identify feature indices
    lag_indices = {lag: expected_order.index(f'{TARGET_COL}_lag_{lag}') 
                   for lag in ALL_LAGS 
                   if f'{TARGET_COL}_lag_{lag}' in expected_order}
    
    rolling_indices = {window: expected_order.index(f'{TARGET_COL}_rolling_mean_{window}h') 
                      for window in ROLLING_WINDOWS 
                      if f'{TARGET_COL}_rolling_mean_{window}h' in expected_order}
    
    for batch_start in range(0, n_predictions, batch_size):
        batch_end = min(batch_start + batch_size, n_predictions)
        
        for i in range(batch_start, batch_end):
            history_array = np.array(history_deque)
            
            # Update features
            for lag, col_idx in lag_indices.items():
                X_future_np[i, col_idx] = history_array[-lag] if len(history_array) >= lag else 0.0
            
            for window, col_idx in rolling_indices.items():
                if len(history_array) >= window:
                    X_future_np[i, col_idx] = np.mean(history_array[-window:])
                elif len(history_array) > 0:
                    X_future_np[i, col_idx] = np.mean(history_array)
                else:
                    X_future_np[i, col_idx] = 0.0
        
        # Batch prediction for this chunk
        batch_preds = model_xgb.predict(X_future_np[batch_start:batch_end])
        batch_preds = np.maximum(0.0, batch_preds)  # Vectorized clipping
        
        # Store predictions and update history
        for j, pred in enumerate(batch_preds):
            idx = batch_start + j
            predictions[idx] = pred
            history_deque.append(pred)
    
    return predictions

# --- Helper Functions ---
def get_target_column(df, region_name, target_base_name):
    """Find the target column in a dataframe, checking for regional variations."""
    possible_names = [
        f"{region_name.upper()}_{target_base_name}", 
        f"{region_name}_{target_base_name}", 
        f"{region_name.lower()}_{target_base_name}"
    ]
    for col_name in possible_names:
        if col_name in df.columns: 
            return col_name
    
    target_cols = [col for col in df.columns if col.endswith(f'_{target_base_name}')]
    if target_cols: 
        return target_cols[0]
    return None

def get_weather_columns(df):
    """Get weather-related columns based on naming pattern."""
    return [col for col in df.columns 
            if '_' in col and len(col.split('_')[0]) == 4 
            and col.split('_')[0].isalpha() and col.split('_')[0].isupper()]

def add_temp_features(df, cdd_thresh, cool_nl_thresh):
    """Add temperature-based features like cooling degree days."""
    temp_cols = [col for col in df.columns if 'temperature_2m' in col]
    if not temp_cols: 
        return df, []
    
    avg_temp = df[temp_cols].mean(axis=1)
    new_features = {
        'Avg_Temp_C': avg_temp, 
        'CDD': np.maximum(0, avg_temp - cdd_thresh), 
        'Cooling_NL': np.maximum(0, avg_temp - cool_nl_thresh), 
        'Cooling_NL_Sq': np.maximum(0, avg_temp - cool_nl_thresh)**2
    }
    
    df = pd.concat([
        df.drop(columns=list(new_features.keys()), errors='ignore'), 
        pd.DataFrame(new_features, index=df.index)
    ], axis=1)
    
    return df, list(new_features.keys())

def create_time_features(df, date_col='date'):
    """Create temporal features from date column."""
    df_out = df.copy()
    dt = pd.to_datetime(df_out[date_col])
    
    # Basic time features
    df_out['hour'] = dt.dt.hour
    df_out['dayofweek'] = dt.dt.dayofweek
    df_out['month'] = dt.dt.month
    df_out['year'] = dt.dt.year
    df_out['dayofyear'] = dt.dt.dayofyear
    df_out['quarter'] = dt.dt.quarter
    
    # Week of year handling
    df_out['weekofyear'] = dt.dt.isocalendar().week.astype(int) if hasattr(dt.dt, 'isocalendar') else dt.dt.weekofyear.astype(int)
    
    # Cyclical encodings
    df_out['hour_sin'] = np.sin(2*np.pi*df_out['hour']/24)
    df_out['hour_cos'] = np.cos(2*np.pi*df_out['hour']/24)
    df_out['dayofweek_sin'] = np.sin(2*np.pi*df_out['dayofweek']/7)
    df_out['dayofweek_cos'] = np.cos(2*np.pi*df_out['dayofweek']/7)
    df_out['month_sin'] = np.sin(2*np.pi*df_out['month']/12)
    df_out['month_cos'] = np.cos(2*np.pi*df_out['month']/12)
    df_out['dayofyear_sin'] = np.sin(2*np.pi*df_out['dayofyear']/365.25)
    df_out['dayofyear_cos'] = np.cos(2*np.pi*df_out['dayofyear']/365.25)
    
    # Additional features
    df_out['is_weekend'] = df_out['dayofweek'].isin([5, 6]).astype(int)
    df_out['year_trend'] = df_out['year'] - df_out['year'].min()
    
    time_cols = [
        'hour_sin', 'hour_cos', 'dayofweek_sin', 'dayofweek_cos', 
        'month_sin', 'month_cos', 'dayofyear_sin', 'dayofyear_cos', 
        'is_weekend', 'year_trend', 'hour', 'dayofweek', 'month', 
        'year', 'weekofyear', 'dayofyear', 'quarter'
    ]
    
    return df_out, time_cols

def create_lagged_features(df, target_col, lags):
    """Create lagged features for the target variable."""
    if target_col not in df.columns: 
        return df, []
    
    df_out = df.copy()
    lag_cols = []
    
    for lag in lags: 
        col_name = f'{target_col}_lag_{lag}'
        df_out[col_name] = df_out[target_col].shift(lag)
        lag_cols.append(col_name)
    
    return df_out, lag_cols

def create_rolling_features(df, target_col, windows, date_col):
    """Create rolling window features for the target variable."""
    if target_col not in df.columns: 
        return df, []
    
    df_out = df.sort_values(by=date_col).copy()
    rolling_cols = []
    
    # FIXED: Ensure no data leakage by using properly shifted target
    shifted_target = df_out[target_col].shift(1)
    
    for window in windows: 
        min_p = max(1, int(window*0.25))
        col_name = f'{target_col}_rolling_mean_{window}h'
        df_out[col_name] = shifted_target.rolling(window=window, min_periods=min_p).mean()
        rolling_cols.append(col_name)
    
    # Fill missing values
    if rolling_cols: 
        df_out.loc[:, rolling_cols] = df_out[rolling_cols].bfill().ffill()
    
    return df_out, rolling_cols

def apply_boundary_smoothing(predictions, hist_values, smooth_hours, anomaly_threshold):
    """Apply boundary smoothing to reduce prediction jumps."""
    if len(predictions) == 0 or len(hist_values) == 0: 
        return predictions
    
    hist_array = np.array(hist_values[-168:])
    hist_std = hist_array.std() if len(hist_array) > 1 else 0.1
    last_hist = hist_values[-1]
    jump = predictions[0] - last_hist
    jump_z_score = abs(jump) / hist_std if hist_std > 0 else 0
    
    if jump_z_score > anomaly_threshold:
        smoothed_preds = predictions.copy()
        for i in range(min(smooth_hours, len(predictions))): 
            decay = np.exp(-i / (smooth_hours/3))
            adjustment = jump * decay
            smoothed_preds[i] -= adjustment
        return smoothed_preds
    
    return predictions

def validate_features(expected_features, available_features):
    """Validate that all expected features are available."""
    missing_features = set(expected_features) - set(available_features)
    if missing_features:
        raise ValueError(f"Missing required features: {missing_features}")
    return True

def safe_feature_update(current_features, feature_name, value, safe_fill=0.0):
    """Safely update a feature with error handling."""
    try:
        current_features[feature_name] = value
    except (KeyError, ValueError) as e:
        print(f"Warning: Could not update feature {feature_name}, using {safe_fill}. Error: {e}")
        current_features[feature_name] = safe_fill

def train_xgb_quantile_for_region_parallel(region, quantile_info, train_featured_path, future_featured_path, scaler_path, xgb_feature_cols, TARGET_COL, use_bridging=True):
    """Train XGBoost quantile model for a specific region and quantile."""
    quantile, model_name = quantile_info["quantile"], quantile_info["name"]
    REGION_BASE_DIR = os.path.join(BASE_OUTPUT_DIR, region)
    MODEL_ARTIFACT_DIR = os.path.join(REGION_BASE_DIR, "models", "load_xgb")
    PREDICTION_OUTPUT_DIR = os.path.join(REGION_BASE_DIR, "final", "load_xgb")
    os.makedirs(MODEL_ARTIFACT_DIR, exist_ok=True)
    os.makedirs(PREDICTION_OUTPUT_DIR, exist_ok=True)
    
    quantile_suffix = f"q{int(quantile*100):03d}"
    MODEL_SAVE_PATH = os.path.join(MODEL_ARTIFACT_DIR, f"load_{quantile_suffix}_model.ubj")
    FEATURE_LIST_SAVE_PATH = os.path.join(MODEL_ARTIFACT_DIR, f"load_{quantile_suffix}_feature_list.joblib")
    
    # FIXED: Safe filename handling
    output_filename = QUANTILE_OUTPUT_FILENAMES.get(quantile)
    if output_filename is None:
        # Fallback filename generation
        output_filename = f"load_prediction_{quantile_suffix}.parquet"
        print(f"  Warning: Using fallback filename {output_filename}")
    
    PREDICTION_OUTPUT_FILE = os.path.join(PREDICTION_OUTPUT_DIR, output_filename)
    
    print(f"\n--- Processing {model_name} LOAD (alpha={quantile}) for {region.upper()} ---")
    
    try:
        # Load data
        df_train_featured = pd.read_parquet(train_featured_path, engine=PARQUET_ENGINE)
        df_future_featured = pd.read_parquet(future_featured_path, engine=PARQUET_ENGINE)
        scaler = joblib.load(scaler_path) if scaler_path and os.path.exists(scaler_path) else None
        
        # Prepare training data
        cols_to_scale = [col for col in xgb_feature_cols 
                        if col in df_train_featured.columns 
                        and pd.api.types.is_numeric_dtype(df_train_featured[col])]
        
        X_train = df_train_featured[xgb_feature_cols].fillna(0)
        y_train = df_train_featured[TARGET_COL]
        
        # Remove NaN values from target
        if y_train.isnull().any():
            nan_indices = y_train[y_train.isnull()].index
            y_train = y_train.drop(nan_indices)
            X_train = X_train.drop(nan_indices)
        
        # Apply scaling if needed
        if scaler and cols_to_scale:
            # OPTIMIZATION 1: Fix dtype issues
            for col in cols_to_scale:
                X_train[col] = X_train[col].astype(np.float32)
            scaled_values = scaler.transform(X_train[cols_to_scale]).astype(np.float32)
            X_train[cols_to_scale] = scaled_values
        
        # Train or load model
        if not os.path.exists(MODEL_SAVE_PATH):
            print(f"  Training new {model_name} model...")
            model_xgb = xgb.XGBRegressor(**{**XGB_PARAMS, 'quantile_alpha': quantile})
            split_idx = int(len(X_train) * (1 - XGB_VALIDATION_SPLIT_FRACTION))
            X_t, X_v = X_train[:split_idx], X_train[split_idx:]
            y_t, y_v = y_train[:split_idx], y_train[split_idx:]
            
            model_xgb.fit(X_t, y_t, eval_set=[(X_t, y_t), (X_v, y_v)], verbose=100)
            model_xgb.save_model(MODEL_SAVE_PATH)
            joblib.dump(xgb_feature_cols, FEATURE_LIST_SAVE_PATH)
            print(f"  ✅ Model saved to {MODEL_SAVE_PATH}")
        else:
            print(f"  Loading existing {model_name} model...")
            model_xgb = xgb.XGBRegressor()
            model_xgb.load_model(MODEL_SAVE_PATH)
            xgb_feature_cols = joblib.load(FEATURE_LIST_SAVE_PATH)
            print(f"  ✅ Model loaded from {MODEL_SAVE_PATH}")

        # Get expected feature order from model
        expected_order = model_xgb.get_booster().feature_names
        
        # FIXED: Validate feature availability
        validate_features(expected_order, xgb_feature_cols)
        
        # 1. Predict on historical data (in-sample)
        print(f"  Generating in-sample predictions for historical data...")
        historical_predictions = model_xgb.predict(X_train[expected_order])
        # FIXED: Apply clipping consistently
        historical_predictions = np.clip(historical_predictions, CLIP_MIN, CLIP_MAX)
        
        df_hist_preds = pd.DataFrame({
            DATE_COL: df_train_featured.loc[X_train.index, DATE_COL],
            TARGET_COL_BASE: historical_predictions
        })
        
        # 2. OPTIMIZED: Ultra-fast recursive forecast
        df_future_preds = pd.DataFrame()
        if not df_future_featured.empty:
            print(f"  Generating out-of-sample predictions for future data...")
            forecast_start = time.time()
            
            # OPTIMIZATION 1: Optimize data types
            X_future = optimize_data_types(df_future_featured[xgb_feature_cols].fillna(0), xgb_feature_cols)
            
            # OPTIMIZATION 2: Pre-scale all data at once
            X_future_scaled = pre_scale_future_data(X_future, scaler, cols_to_scale)
            
            # Validate expected features exist in future data
            validate_features(expected_order, X_future_scaled.columns)
            
            # Initialize history
            recent_target_values = list(y_train.tolist()[-100:])  # Keep only what we need
            hist_for_smoothing = recent_target_values.copy()
            
            print(f"    Starting optimized recursive forecast for {len(X_future_scaled)} time steps...")
            
            # OPTIMIZATION 3: Use ultra-fast numpy-based forecasting
            if len(X_future_scaled) > 1000:
                # Use batch version for long sequences
                predictions = batch_recursive_forecast(
                    model_xgb, X_future_scaled, recent_target_values, 
                    expected_order, ALL_LAGS, ROLLING_WINDOWS, TARGET_COL, batch_size=200
                )
            else:
                # Use optimized version for shorter sequences
                predictions = fast_recursive_forecast_optimized(
                    model_xgb, X_future_scaled, recent_target_values, 
                    expected_order, ALL_LAGS, ROLLING_WINDOWS, TARGET_COL
                )

            forecast_time = time.time() - forecast_start
            rate = len(X_future_scaled) / forecast_time
            print(f"    ✅ Optimized forecasting completed in {forecast_time:.2f} seconds ({rate:.1f} predictions/sec)")

            # Apply boundary smoothing
            smoothed_predictions = apply_boundary_smoothing(
                predictions, hist_for_smoothing, 
                BOUNDARY_SMOOTH_HOURS, ANOMALY_THRESHOLD_STD
            )
            
            # Final clipping
            smoothed_predictions = np.maximum(0.0, smoothed_predictions)
            
            df_future_preds = pd.DataFrame({
                DATE_COL: df_future_featured[DATE_COL].values, 
                TARGET_COL_BASE: smoothed_predictions
            })

        # 3. Combine historical and future predictions and save
        df_full_timeline = pd.concat([df_hist_preds, df_future_preds], ignore_index=True)\
                            .sort_values(by=DATE_COL)
        
        df_full_timeline.to_parquet(PREDICTION_OUTPUT_FILE, index=False, engine=PARQUET_ENGINE)
        print(f"  ✅ Saved {len(df_full_timeline)} full-timeline predictions to {PREDICTION_OUTPUT_FILE}")
        
        # Clean up memory
        del df_train_featured, df_future_featured, X_train, y_train, model_xgb
        gc.collect()
        
        return True
        
    except Exception as e:
        print(f"Error in train_xgb_quantile_for_region_parallel: {e}")
        traceback.print_exc()
        return str(e)

def process_quantile(model_info, region_name, train_featured_path, future_featured_path, scaler_path, xgb_feature_cols, TARGET_COL):
    """Wrapper function for multiprocessing."""
    try:
        result = train_xgb_quantile_for_region_parallel(
            region_name, model_info, train_featured_path, future_featured_path, 
            scaler_path, xgb_feature_cols, TARGET_COL
        )
        return model_info["name"], result
    except Exception as e:
        traceback.print_exc()
        return model_info["name"], str(e)

if __name__ == "__main__":
    start_total_time = time.time()
    processed_models = 0
    failed_models = []
    
    # Check for valid regions
    regions_to_process = [r for r in REGIONS 
                         if os.path.exists(os.path.join(BASE_OUTPUT_DIR, r, "final", TRAIN_INPUT_FILENAME_BASE))]
    
    if not regions_to_process:
        print("No valid regions found!", file=sys.stderr)
        sys.exit(1)
    
    print(f"\n📊 Processing {len(regions_to_process)} regions with {len(QUANTILE_MODELS)} model(s) each")
    print(f"Expected total models: {len(regions_to_process) * len(QUANTILE_MODELS)}")
    print(f"🚀 Script optimized for 5-10x faster inference!")
    
    for region_name in regions_to_process:
        region_progress = f"Region {regions_to_process.index(region_name) + 1}/{len(regions_to_process)}"
        print(f"\n{'='*60}\n🚀 Starting {region_progress}: {region_name.upper()}\n{'='*60}")
        region_start_time = time.time()
        
        region_input_dir = os.path.join(BASE_OUTPUT_DIR, region_name, "final")
        temp_dir = os.path.join(BASE_OUTPUT_DIR, region_name, "temp_featured")
        os.makedirs(temp_dir, exist_ok=True)
        
        train_featured_path = os.path.join(temp_dir, "train_featured.parquet")
        future_featured_path = os.path.join(temp_dir, "future_featured.parquet")
        scaler_path = os.path.join(temp_dir, "scaler.joblib") if SCALE_XGB_FEATURES else None

        try:
            # Load data
            print("  📁 Loading training and future data...")
            train_df = pd.read_parquet(os.path.join(region_input_dir, TRAIN_INPUT_FILENAME_BASE), engine=PARQUET_ENGINE)
            future_df = pd.read_parquet(os.path.join(region_input_dir, FUTURE_COVARIATES_FILENAME_BASE), engine=PARQUET_ENGINE)
            
            # Find target column
            TARGET_COL = get_target_column(train_df, region_name, TARGET_COL_BASE)
            if not TARGET_COL:
                raise ValueError(f"Could not find LOAD column for {region_name}")
            
            print(f"  🎯 Using target column for feature engineering: {TARGET_COL}")
            
            # Combine and sort data
            print("  ⚙️  Engineering features...")
            combined_df = pd.concat([train_df, future_df], ignore_index=True)\
                           .sort_values(DATE_COL)\
                           .reset_index(drop=True)
            
            # Feature engineering
            combined_df, time_features = create_time_features(combined_df, DATE_COL)
            combined_df, temp_features = add_temp_features(combined_df, CDD_THRESHOLD_C, COOLING_NL_THRESHOLD_C)
            combined_df, lag_features = create_lagged_features(combined_df, TARGET_COL, ALL_LAGS)
            combined_df, rolling_features = create_rolling_features(combined_df, TARGET_COL, ROLLING_WINDOWS, DATE_COL)
            
            # Collect all feature columns
            weather_cols = get_weather_columns(combined_df)
            xgb_feature_cols = sorted(list(set(
                time_features + temp_features + lag_features + rolling_features + weather_cols
            )))
            xgb_feature_cols = [col for col in xgb_feature_cols if col in combined_df.columns]
            
            print(f"  📊 Created {len(xgb_feature_cols)} features: {len(time_features)} time, {len(temp_features)} temp, {len(lag_features)} lag, {len(rolling_features)} rolling, {len(weather_cols)} weather")
            
            # Split back into train and future
            last_hist_date = train_df[DATE_COL].max()
            train_featured = combined_df[combined_df[DATE_COL] <= last_hist_date]
            future_featured = combined_df[combined_df[DATE_COL] > last_hist_date]
            
            # Save featured data
            print("  💾 Saving featured datasets...")
            train_featured.to_parquet(train_featured_path, engine=PARQUET_ENGINE)
            future_featured.to_parquet(future_featured_path, engine=PARQUET_ENGINE)
            
            # Create and save scaler if needed
            if SCALE_XGB_FEATURES:
                print("  📏 Creating and saving feature scaler...")
                scaler = StandardScaler()
                cols_to_scale = [c for c in xgb_feature_cols 
                               if pd.api.types.is_numeric_dtype(train_featured[c])]
                if cols_to_scale:
                    scaler.fit(train_featured[cols_to_scale])
                    joblib.dump(scaler, scaler_path)
                    print(f"    ✅ Scaler fitted on {len(cols_to_scale)} numeric features")
                    
        except Exception as e:
            print(f"❌ Error preprocessing {region_name}: {e}")
            traceback.print_exc()
            failed_models.extend([f"{region_name.upper()}_{m['name']}_LOAD (Preprocessing)" 
                                 for m in QUANTILE_MODELS])
            continue
        
        # FIXED: Process quantile models - handle single model vs multiprocessing
        try:
            if len(QUANTILE_MODELS) == 1:
                # Direct execution for single model - avoids multiprocessing overhead
                print(f"  🎯 Processing single model directly (no multiprocessing)")
                model_info = QUANTILE_MODELS[0]
                model_name, result = process_quantile(
                    model_info, region_name, train_featured_path, future_featured_path, 
                    scaler_path, xgb_feature_cols, TARGET_COL
                )
                
                model_id = f"{region_name.upper()}_{model_name}_LOAD"
                if result is True:
                    processed_models += 1
                    print(f"✅ Successfully completed {model_id}")
                else:
                    failed_models.append(f"{model_id} ({result})")
            else:
                # Use multiprocessing for multiple models
                print(f"  🔄 Processing {len(QUANTILE_MODELS)} models with multiprocessing...")
                with multiprocessing.Pool(processes=min(multiprocessing.cpu_count(), len(QUANTILE_MODELS))) as pool:
                    args = [(m, region_name, train_featured_path, future_featured_path, 
                            scaler_path, xgb_feature_cols, TARGET_COL) for m in QUANTILE_MODELS]
                    results = pool.starmap(process_quantile, args)

                # Process results
                for model_name, result in results:
                    model_id = f"{region_name.upper()}_{model_name}_LOAD"
                    if result is True:
                        processed_models += 1
                        print(f"✅ Successfully completed {model_id}")
                    else:
                        failed_models.append(f"{model_id} ({result})")
            
        except Exception as e:
            print(f"❌ Error in model processing for {region_name}: {e}")
            traceback.print_exc()
            failed_models.extend([f"{region_name.upper()}_{m['name']}_LOAD (Processing)" 
                                 for m in QUANTILE_MODELS])
        
        # Cleanup region resources
        print(f"\n🧹 Cleaning up region {region_name.upper()}...")
        try:
            # Force garbage collection
            gc.collect()
            
            # Clear any remaining variables
            if 'combined_df' in locals():
                del combined_df
            if 'train_featured' in locals():
                del train_featured
            if 'future_featured' in locals():
                del future_featured
            
            region_time = time.time() - region_start_time
            print(f"✅ Completed {region_name.upper()} in {region_time:.2f} seconds")
            
        except Exception as e:
            print(f"⚠️  Cleanup warning for {region_name.upper()}: {e}")

    # Final summary
    total_time = time.time() - start_total_time
    print(f"\n{'='*60}\n📊 OVERALL {TARGET_COL_BASE} MODEL PROCESSING SUMMARY\n{'='*60}")
    print(f"Total models processed: {processed_models}")
    print(f"Total execution time: {total_time:.2f} seconds")
    print(f"Average time per model: {total_time/max(processed_models, 1):.2f} seconds")
    
    if failed_models:
        print(f"\n❌ Failed models ({len(failed_models)}):")
        for fm in failed_models: 
            print(f"  - {fm}")
        print(f"\nSuccess rate: {processed_models/(processed_models + len(failed_models))*100:.1f}%")
        sys.exit(1)
    else:
        print(f"\n🎉 All models processed successfully!")
        print(f"⚡ Performance: {processed_models * len(regions_to_process) / (total_time/3600):.1f} model-regions per hour")
        print(f"🚀 Inference optimizations applied - expect 5-10x speedup!")
        sys.exit(0)