import os
import shutil
from datetime import datetime
import glob
from collections import defaultdict

# Define paths
hybrid_results_dir = r'D:\EIA_STACK\HYBRID_RESULTS'
pricing_rl_dir = r'D:\EIA_STACK\Pricing_RL'

print("="*60)
print("COPYING HYBRID PREDICTION FILES TO REGIONAL FOLDERS")
print("="*60)
print("Note: TEXAS files will be copied to both SOUTHCENTRAL and SOUTHCENTRAL_SALTS")
print("="*60)

# Define the mapping between HYBRID_RESULTS regions and Pricing_RL regions
# Modified to handle multiple target folders for a single source
region_mappings = {
    'CALIFORNIA': {
        'target_folders': ['PACIFIC'],
        'files': ['california_commercial.csv', 'california_industrial.csv', 'california_residential_final_hybrid_forecast.csv']
    },
    'TEXAS': {
        'target_folders': ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS'],  # Will copy to both folders
        'files': ['texas_commercial.csv', 'texas_industrial.csv', 'texas_residential_final_hybrid_forecast.csv']
    },
    'FLORIDA': {
        'target_folders': ['EAST'],
        'files': ['florida_commercial.csv', 'florida_industrial.csv', 'florida_residential_final_hybrid_forecast.csv']
    },
    'NEWYORK': {
        'target_folders': ['EAST'],
        'files': ['newyork_commercial.csv', 'newyork_industrial.csv', 'newyork_residential_final_hybrid_forecast.csv']
    },
    'MIDWEST': {
        'target_folders': ['MIDWEST'],
        'files': ['midwest_commercial.csv', 'midwest_industrial.csv', 'midwest_residential_final_hybrid_forecast.csv']
    },
    'NEWENGLAND': {
        'target_folders': ['EAST'],
        'files': ['newengland_commercial.csv', 'newengland_industrial.csv', 'newengland_residential_final_hybrid_forecast.csv']
    },
    'CAROLINA': {
        'target_folders': ['EAST'],
        'files': ['carolina_commercial.csv', 'carolina_industrial.csv', 'carolina_residential_final_hybrid_forecast.csv']
    },
    'MIDATLANTIC': {
        'target_folders': ['EAST'],
        'files': ['midatlantic_commercial.csv', 'midatlantic_industrial.csv', 'midatlantic_residential_final_hybrid_forecast.csv']
    },
    'CENTRAL': {
        'target_folders': ['MIDWEST'],
        'files': ['central_commercial.csv', 'central_industrial.csv', 'central_residential_final_hybrid_forecast.csv']
    },
    'TENNESSEE': {
        'target_folders': ['EAST'],
        'files': ['tennessee_commercial.csv', 'tennessee_industrial.csv', 'tennessee_residential_final_hybrid_forecast.csv']
    },
    'SOUTHEAST': {
        'target_folders': ['EAST'],
        'files': ['southeast_commercial.csv', 'southeast_industrial.csv', 'southeast_residential_final_hybrid_forecast.csv']
    },
    'NORTHWEST': {
        'target_folders': ['PACIFIC'],
        'files': ['northwest_commercial.csv', 'northwest_industrial.csv', 'northwest_residential_final_hybrid_forecast.csv']
    },
    'SOUTHWEST': {
        'target_folders': ['MOUNTAIN'],
        'files': ['southwest_commercial.csv', 'southwest_industrial.csv', 'southwest_residential_final_hybrid_forecast.csv']
    }
}

# Track statistics
successful_copies = []
failed_copies = []
not_found = []
regions_processed = set()

# Process each region
for source_region, config in region_mappings.items():
    target_regions = config['target_folders']
    
    # Add all target regions to the processed set
    for target in target_regions:
        regions_processed.add(target)
    
    # Display appropriate header based on number of targets
    if len(target_regions) > 1:
        print(f"\n{'='*50}")
        print(f"Processing {source_region}")
        print(f"  → Copying to: {', '.join(target_regions)}")
        print(f"{'='*50}")
    else:
        print(f"\n{'='*50}")
        print(f"Processing {source_region} → {target_regions[0]}")
        print(f"{'='*50}")
    
    # Source folder path
    source_folder = os.path.join(hybrid_results_dir, source_region, 'Predictions')
    
    # Check if source folder exists
    if not os.path.exists(source_folder):
        print(f"  ⚠️ Source folder not found: {source_folder}")
        not_found.append((source_region, "Folder not found"))
        continue
    
    # Process each target folder
    for target_region in target_regions:
        # Destination folder
        dest_folder = os.path.join(pricing_rl_dir, target_region)
        
        # Create destination folder if it doesn't exist
        if not os.path.exists(dest_folder):
            os.makedirs(dest_folder)
            print(f"  Created destination folder: {dest_folder}")
        
        # If multiple targets, add a sub-header
        if len(target_regions) > 1:
            print(f"\n  Copying to {target_region}:")
        
        # Copy each file
        for filename in config['files']:
            source_path = os.path.join(source_folder, filename)
            dest_path = os.path.join(dest_folder, filename)
            
            if not os.path.exists(source_path):
                if len(target_regions) == 1 or target_region == target_regions[0]:  # Only report once for multi-target
                    print(f"  ✗ File not found: {filename}")
                    not_found.append((source_region, filename))
                continue
            
            try:
                # Copy the file
                shutil.copy2(source_path, dest_path)
                
                # Verify the copy
                source_size = os.path.getsize(source_path)
                dest_size = os.path.getsize(dest_path)
                
                if source_size == dest_size:
                    indent = "    " if len(target_regions) > 1 else "  "
                    print(f"{indent}✓ Copied: {filename} ({source_size:,} bytes)")
                    successful_copies.append((source_region, target_region, filename))
                else:
                    indent = "    " if len(target_regions) > 1 else "  "
                    print(f"{indent}⚠️ Warning: File sizes don't match for {filename}")
                    failed_copies.append((source_region, target_region, filename, "Size mismatch"))
                    
            except Exception as e:
                indent = "    " if len(target_regions) > 1 else "  "
                print(f"{indent}✗ Error copying {filename}: {str(e)}")
                failed_copies.append((source_region, target_region, filename, str(e)))

# Final summary
print("\n" + "="*60)
print("FINAL SUMMARY")
print("="*60)

# Group successful copies by target region
copies_by_target = defaultdict(list)
for source, target, filename in successful_copies:
    copies_by_target[target].append((source, filename))

if successful_copies:
    print(f"\n✓ Successfully copied: {len(successful_copies)} files")
    print("\nBy destination region:")
    for target in sorted(copies_by_target.keys()):
        print(f"\n  {target}:")
        # Group by source region for cleaner display
        sources_in_target = defaultdict(list)
        for source, filename in copies_by_target[target]:
            sources_in_target[source].append(filename)
        
        for source in sorted(sources_in_target.keys()):
            if source == 'TEXAS' and target in ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS']:
                print(f"    From {source} (shared with both SOUTHCENTRAL regions):")
            else:
                print(f"    From {source}:")
            for filename in sorted(sources_in_target[source]):
                print(f"      • {filename}")

if not_found:
    print(f"\n⚠️ Files/Folders not found: {len(not_found)}")
    # Remove duplicates for cleaner display
    unique_not_found = list(set(not_found))
    for source, item in unique_not_found:
        print(f"  • {source}: {item}")

if failed_copies:
    print(f"\n✗ Failed to copy: {len(failed_copies)} files")
    for source, target, filename, error in failed_copies:
        print(f"  • {source} → {target}: {filename} - Error: {error}")

# Show final structure for processed regions
print("\n" + "="*60)
print("FINAL STRUCTURE IN PRICING_RL")
print("="*60)

for region in sorted(regions_processed):
    region_path = os.path.join(pricing_rl_dir, region)
    if os.path.exists(region_path):
        print(f"\n{region}/")
        files = sorted([f for f in os.listdir(region_path) if f.endswith('.csv')])
        
        # Group files by type
        weather_files = [f for f in files if f.startswith('weather_')]
        storage_files = [f for f in files if 'storage' in f.lower() or 'filtered' in f.lower()]
        commercial_files = [f for f in files if 'commercial' in f.lower()]
        industrial_files = [f for f in files if 'industrial' in f.lower()]
        residential_files = [f for f in files if 'residential' in f.lower()]
        power_files = [f for f in files if 'power' in f.lower()]
        other_files = [f for f in files if f not in weather_files + storage_files + commercial_files + industrial_files + residential_files + power_files]
        
        if weather_files:
            print("  Weather files:")
            for f in weather_files:
                print(f"    • {f}")
        
        if storage_files:
            print("  Storage files:")
            for f in storage_files:
                print(f"    • {f}")
        
        if commercial_files:
            print("  Commercial files:")
            for f in commercial_files:
                print(f"    • {f}")
        
        if industrial_files:
            print("  Industrial files:")
            for f in industrial_files:
                print(f"    • {f}")
        
        if residential_files:
            print("  Residential files:")
            for f in residential_files:
                print(f"    • {f}")
        
        if power_files:
            print("  Power files:")
            for f in power_files:
                print(f"    • {f}")
        
        if other_files:
            print("  Other files:")
            for f in other_files:
                print(f"    • {f}")
        
        print(f"  Total files: {len(files)}")

# Special note for TEXAS files
print("\n" + "="*60)
print("SPECIAL NOTE")
print("="*60)
print("✓ TEXAS files have been copied to both:")
print("  • SOUTHCENTRAL/")
print("  • SOUTHCENTRAL_SALTS/")
print("This ensures both regional models have access to Texas demand data.")

print("\n" + "="*60)
print("Process completed!")
print("="*60)