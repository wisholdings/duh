import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
import joblib
import time
import traceback
import sys
import os
from collections import deque
import multiprocessing
import warnings
from typing import Dict, List, Optional, Any, Deque
import gc

# Suppress scikit-learn warning about feature names
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.utils.validation")

# --- Check for Parquet Engine Dependency ---
try:
    import pyarrow
    print("PyArrow engine found.")
    PARQUET_ENGINE = 'pyarrow'
except ImportError:
    print("Warning: PyArrow library not found. Parquet operations might be slower or fail if 'auto' engine doesn't find an alternative.")
    PARQUET_ENGINE = 'auto'

# --- Path Setup ---
BASE_OUTPUT_DIR = r"D:\EIA_STACK"
print(f"Looking for data in: {os.path.abspath(BASE_OUTPUT_DIR)}")

# --- Define regions ---
REGIONS = [
    "california", "carolina", "central", "florida", "midatlantic", "midwest",
    "newengland", "northwest", "southeast", "southwest", "tennessee", "texas"
]

# --- MODIFIED: Configuration for the Target Variable ---
TARGET_COL_BASE = "SOLAR_RATIO"
print(f"✅ Script is now configured to model: {TARGET_COL_BASE}")

# ### NEW: Hurdle Model Configuration for Solar ###
USE_HURDLE_MODEL = TARGET_COL_BASE == "SOLAR_RATIO"
DAYLIGHT_START_HOUR = 6  # 6 AM
DAYLIGHT_END_HOUR = 19 # 7 PM (inclusive)

if USE_HURDLE_MODEL:
    print(f"☀️ Hurdle model enabled for SOLAR_RATIO. Training on hours {DAYLIGHT_START_HOUR}-{DAYLIGHT_END_HOUR} only.")

# --- CORRECTED: Ratio Scaling Configuration ---
RATIO_SCALE = 1000
USE_RATIO_SCALING = TARGET_COL_BASE.endswith('_RATIO')

# --- NEW: Boundary Handling Parameters ---
BRIDGE_HOURS = 168
BOUNDARY_SMOOTH_HOURS = 6
ANOMALY_THRESHOLD_STD = 2.0

# --- CORRECTED: Clipping Parameters for SOLAR_RATIO ---
if USE_RATIO_SCALING:
    CLIP_MIN = 0.0
    CLIP_MAX = RATIO_SCALE
    FINAL_MIN = 0.0
    FINAL_MAX = 1.0
else:
    CLIP_MIN = 0.0
    CLIP_MAX = 1.0
    FINAL_MIN = 0.0
    FINAL_MAX = 1.0
print(f"Scaling: Input [0,1] → Training [0,{RATIO_SCALE}] → Output [0,1]")

# --- Define Quantile Models to Run ---
QUANTILE_MODELS = [
    {"quantile": 0.10, "name": "Q10"}, {"quantile": 0.20, "name": "Q20"},
    {"quantile": 0.30, "name": "Q30"}, {"quantile": 0.40, "name": "Q40"},
    {"quantile": 0.50, "name": "Median"}, {"quantile": 0.60, "name": "Q60"},
    {"quantile": 0.70, "name": "Q70"}, {"quantile": 0.80, "name": "Q80"},
    {"quantile": 0.90, "name": "Q90"}, {"quantile": 0.99, "name": "Q99"},
]

# --- DYNAMIC: Create a mapping for output filenames based on the target ---
QUANTILE_OUTPUT_FILENAMES = {
    q_info["quantile"]: f"{TARGET_COL_BASE.lower()}_prediction_{q_info['name'].lower()}.parquet" for q_info in QUANTILE_MODELS
}

# --- Configuration Variables ---
TRAIN_INPUT_FILENAME_BASE = "train.parquet"
FUTURE_COVARIATES_FILENAME_BASE = "predict.parquet"
DATE_COL = "date"
XGB_VALIDATION_SPLIT_FRACTION = 0.15

# --- Feature Engineering Config ---
ALL_LAGS = [1, 24]
MAX_LAG = max(ALL_LAGS) if ALL_LAGS else 0
ROLLING_WINDOWS = [24,168]
MAX_ROLLING_WINDOW = max(ROLLING_WINDOWS) if ROLLING_WINDOWS else 0

# --- XGBoost Specific Parameters ---
if USE_RATIO_SCALING:
    XGB_PARAMS = {
        'objective': 'reg:quantileerror', 'n_estimators': 700, 'learning_rate': 0.08, 'max_depth': 11,
        'subsample': 0.8, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 1,
        'early_stopping_rounds': 30, 'eval_metric': 'mae', 'reg_alpha': 0.1, 'reg_lambda': 0.1, 'min_child_weight': 8
    }
else:
    XGB_PARAMS = {
        'objective': 'reg:quantileerror', 'n_estimators': 600, 'learning_rate': 0.08, 'max_depth': 11,
        'subsample': 0.8, 'colsample_bytree': 0.8, 'random_state': 42, 'n_jobs': 1,
        'early_stopping_rounds': 25, 'eval_metric': 'mae', 'reg_alpha': 0.05, 'reg_lambda': 0.05, 'min_child_weight': 12
    }

print(f"Creating {len(ALL_LAGS)} lag features from lags: {ALL_LAGS}")
if USE_RATIO_SCALING:
    print(f"Ratio scaling enabled: values will be multiplied by {RATIO_SCALE}")

# --- OPTIMIZATION & HELPER FUNCTIONS ---
def optimize_data_types(df, xgb_feature_cols):
    df_opt = df.copy()
    for col in xgb_feature_cols:
        if col in df_opt.columns and pd.api.types.is_numeric_dtype(df_opt[col]):
            df_opt[col] = df_opt[col].astype(np.float32)
    return df_opt

def fast_recursive_forecast_optimized(model_xgb, X_future_scaled, recent_target_values,
                                    expected_order, ALL_LAGS, ROLLING_WINDOWS, TARGET_COL,
                                    CLIP_MIN, CLIP_MAX):
    n_predictions = len(X_future_scaled)
    predictions = np.zeros(n_predictions, dtype=np.float32)
    X_future_np = X_future_scaled[expected_order].values.astype(np.float32)
    history_array = np.array(recent_target_values, dtype=np.float32)
    lag_indices = {lag: expected_order.index(f'{TARGET_COL}_lag_{lag}') for lag in ALL_LAGS if f'{TARGET_COL}_lag_{lag}' in expected_order}
    rolling_indices = {window: expected_order.index(f'{TARGET_COL}_rolling_mean_{window}h') for window in ROLLING_WINDOWS if f'{TARGET_COL}_rolling_mean_{window}h' in expected_order}

    for i in range(n_predictions):
        try:
            for lag, col_idx in lag_indices.items():
                X_future_np[i, col_idx] = history_array[-lag] if len(history_array) >= lag else 0.0
            for window, col_idx in rolling_indices.items():
                if len(history_array) >= window:
                    X_future_np[i, col_idx] = np.mean(history_array[-window:])
                else:
                    X_future_np[i, col_idx] = np.mean(history_array) if len(history_array) > 0 else 0.0
            pred_value = model_xgb.predict(X_future_np[i:i+1])[0]
            clipped_pred = np.clip(pred_value, CLIP_MIN, CLIP_MAX)
            predictions[i] = clipped_pred
            history_array = np.append(history_array, clipped_pred)[-200:]
        except Exception:
            fallback_pred = np.mean(history_array) if len(history_array) > 0 else 0.0
            predictions[i] = np.clip(fallback_pred, CLIP_MIN, CLIP_MAX)
            history_array = np.append(history_array, predictions[i])[-200:]
    return predictions

def batch_recursive_forecast(model_xgb, X_future_scaled, recent_target_values,
                           expected_order, ALL_LAGS, ROLLING_WINDOWS, TARGET_COL,
                           CLIP_MIN, CLIP_MAX, batch_size=100):
    n_predictions = len(X_future_scaled)
    predictions = np.zeros(n_predictions, dtype=np.float32)
    X_future_np = X_future_scaled[expected_order].values.astype(np.float32)
    history_deque = deque(recent_target_values, maxlen=200)
    lag_indices = {lag: expected_order.index(f'{TARGET_COL}_lag_{lag}') for lag in ALL_LAGS if f'{TARGET_COL}_lag_{lag}' in expected_order}
    rolling_indices = {window: expected_order.index(f'{TARGET_COL}_rolling_mean_{window}h') for window in ROLLING_WINDOWS if f'{TARGET_COL}_rolling_mean_{window}h' in expected_order}
    for batch_start in range(0, n_predictions, batch_size):
        batch_end = min(batch_start + batch_size, n_predictions)
        for i in range(batch_start, batch_end):
            history_array = np.array(history_deque)
            for lag, col_idx in lag_indices.items():
                X_future_np[i, col_idx] = history_array[-lag] if len(history_array) >= lag else 0.0
            for window, col_idx in rolling_indices.items():
                if len(history_array) >= window:
                    X_future_np[i, col_idx] = np.mean(history_array[-window:])
                else:
                    X_future_np[i, col_idx] = np.mean(history_array) if len(history_array) > 0 else 0.0
        batch_preds = model_xgb.predict(X_future_np[batch_start:batch_end])
        batch_preds = np.clip(batch_preds, CLIP_MIN, CLIP_MAX)
        for j, pred in enumerate(batch_preds):
            idx = batch_start + j
            predictions[idx] = pred
            history_deque.append(pred)
    return predictions

def get_target_column(df, region_name, target_base_name):
    possible_names = [f"{region_name.upper()}_{target_base_name}", f"{region_name}_{target_base_name}", f"{region_name.lower()}_{target_base_name}", target_base_name]
    for col_name in possible_names:
        if col_name in df.columns: return col_name
    target_cols = [col for col in df.columns if col.endswith(f'_{target_base_name}')]
    if target_cols: return target_cols[0]
    return None

def get_weather_columns(df):
    return [col for col in df.columns if '_' in col and len(col.split('_')[0]) == 4 and col.split('_')[0].isalpha() and col.split('_')[0].isupper()]

def create_time_features(df, date_col='date'):
    df_out = df.copy()
    dt = pd.to_datetime(df_out[date_col])
    df_out['hour'] = dt.dt.hour; df_out['dayofweek'] = dt.dt.dayofweek; df_out['month'] = dt.dt.month; df_out['year'] = dt.dt.year; df_out['dayofyear'] = dt.dt.dayofyear; df_out['quarter'] = dt.dt.quarter
    df_out['weekofyear'] = dt.dt.isocalendar().week.astype(int) if hasattr(dt.dt, 'isocalendar') else dt.dt.weekofyear.astype(int)
    df_out['hour_sin'] = np.sin(2*np.pi*df_out['hour']/24); df_out['hour_cos'] = np.cos(2*np.pi*df_out['hour']/24)
    df_out['dayofweek_sin'] = np.sin(2*np.pi*df_out['dayofweek']/7); df_out['dayofweek_cos'] = np.cos(2*np.pi*df_out['dayofweek']/7)
    df_out['month_sin'] = np.sin(2*np.pi*df_out['month']/12); df_out['month_cos'] = np.cos(2*np.pi*df_out['month']/12)
    df_out['dayofyear_sin'] = np.sin(2*np.pi*df_out['dayofyear']/365.25); df_out['dayofyear_cos'] = np.cos(2*np.pi*df_out['dayofyear']/365.25)
    df_out['is_weekend'] = df_out['dayofweek'].isin([5, 6]).astype(int); df_out['year_trend'] = df_out['year'] - df_out['year'].min()
    time_cols = ['hour_sin', 'hour_cos', 'dayofweek_sin', 'dayofweek_cos', 'month_sin', 'month_cos', 'dayofyear_sin', 'dayofyear_cos', 'is_weekend', 'year_trend', 'hour', 'dayofweek', 'month', 'year', 'weekofyear', 'dayofyear', 'quarter']
    return df_out, time_cols

def create_lagged_features(df, target_col, lags):
    if target_col not in df.columns: return df, []
    df_out = df.copy(); lag_cols = []
    for lag in lags: col_name = f'{target_col}_lag_{lag}'; df_out[col_name] = df_out[target_col].shift(lag); lag_cols.append(col_name)
    return df_out, lag_cols

def create_rolling_features(df, target_col, windows, date_col):
    if target_col not in df.columns: return df, []
    df_out = df.sort_values(by=date_col).copy(); rolling_cols = []
    shifted_target = df_out[target_col].shift(1)
    for window in windows:
        min_p = max(1, int(window * 0.25)); col_name = f'{target_col}_rolling_mean_{window}h'
        df_out[col_name] = shifted_target.rolling(window=window, min_periods=min_p).mean(); rolling_cols.append(col_name)
    if rolling_cols: df_out.loc[:, rolling_cols] = df_out[rolling_cols].bfill().ffill()
    return df_out, rolling_cols

def validate_features(expected_features, available_features):
    missing_features = set(expected_features) - set(available_features)
    if missing_features:
        raise ValueError(f"Missing required features: {missing_features}")
    return True

def convert_to_final_scale(scaled_predictions, use_scaling, ratio_scale, final_min, final_max):
    if use_scaling:
        final_predictions = scaled_predictions / ratio_scale
        final_predictions = np.clip(final_predictions, final_min, final_max)
    else:
        final_predictions = np.clip(scaled_predictions, final_min, final_max)
    return final_predictions

def add_daylight_feature(df, start_hour, end_hour):
    """Creates a binary feature indicating if the hour is within the daylight range."""
    if 'hour' not in df.columns:
        df['hour'] = pd.to_datetime(df[DATE_COL]).dt.hour
    df['is_daylight'] = df['hour'].between(start_hour, end_hour).astype(int)
    return df, ['is_daylight']

# --- Main Modeling Function ---
def train_xgb_quantile_for_region_parallel(region, quantile_info, train_featured_path, future_featured_path,
                                         train_split_featured_path, validation_split_featured_path,
                                         xgb_feature_cols, TARGET_COL):
    quantile, model_name = quantile_info["quantile"], quantile_info["name"]
    target_lower = TARGET_COL_BASE.lower()
    REGION_BASE_DIR = os.path.join(BASE_OUTPUT_DIR, region)
    MODEL_ARTIFACT_DIR = os.path.join(REGION_BASE_DIR, "models", f"{target_lower}_xgb")
    PREDICTION_OUTPUT_DIR = os.path.join(REGION_BASE_DIR, "final", f"{target_lower}_xgb")
    os.makedirs(MODEL_ARTIFACT_DIR, exist_ok=True); os.makedirs(PREDICTION_OUTPUT_DIR, exist_ok=True)
    
    quantile_suffix = f"q{int(quantile*100):03d}"
    MODEL_SAVE_PATH = os.path.join(MODEL_ARTIFACT_DIR, f"{target_lower}_{quantile_suffix}_model.ubj")
    FEATURE_LIST_SAVE_PATH = os.path.join(MODEL_ARTIFACT_DIR, f"{target_lower}_{quantile_suffix}_feature_list.joblib")
    
    output_filename = QUANTILE_OUTPUT_FILENAMES.get(quantile, f"{target_lower}_prediction_{quantile_suffix}.parquet")
    PREDICTION_OUTPUT_FILE = os.path.join(PREDICTION_OUTPUT_DIR, output_filename)
    
    print(f"\n--- Processing {model_name} {TARGET_COL_BASE} (alpha={quantile}) for {region.upper()} ---")
    
    try:
        df_train_featured = pd.read_parquet(train_featured_path, engine=PARQUET_ENGINE)
        df_future_featured = pd.read_parquet(future_featured_path, engine=PARQUET_ENGINE)
        
        # --- HURDLE MODEL: STEP 1 - Filter training data to daylight hours only ---
        if USE_HURDLE_MODEL:
            print("  ☀️ Applying hurdle model: Filtering training data to daylight hours.")
            df_train_daylight = df_train_featured[df_train_featured['is_daylight'] == 1].copy()
            X_train = df_train_daylight[xgb_feature_cols].fillna(0)
            y_train = df_train_daylight[TARGET_COL].dropna()
            X_train = X_train.loc[y_train.index]
        else:
            X_train = df_train_featured[xgb_feature_cols].fillna(0)
            y_train = df_train_featured[TARGET_COL].dropna()
            X_train = X_train.loc[y_train.index]
        
        if not os.path.exists(MODEL_SAVE_PATH):
            print("  Stage 1: Finding optimal n_estimators...")
            model_finder = xgb.XGBRegressor(**{**XGB_PARAMS, 'quantile_alpha': quantile})
            train_split_featured = pd.read_parquet(train_split_featured_path, engine=PARQUET_ENGINE)
            validation_split_featured = pd.read_parquet(validation_split_featured_path, engine=PARQUET_ENGINE)
            
            if USE_HURDLE_MODEL:
                train_split_featured = train_split_featured[train_split_featured['is_daylight'] == 1]
                validation_split_featured = validation_split_featured[validation_split_featured['is_daylight'] == 1]

            X_t = train_split_featured[xgb_feature_cols].fillna(0)
            y_t = train_split_featured[TARGET_COL].dropna()
            X_t = X_t.loc[y_t.index]
            X_v = validation_split_featured[xgb_feature_cols].fillna(0)
            y_v = validation_split_featured[TARGET_COL].dropna()
            X_v = X_v.loc[y_v.index]
            
            model_finder.fit(X_t, y_t, eval_set=[(X_v, y_v)], verbose=False)
            best_rounds = model_finder.best_iteration
            print(f"  Optimal rounds found: {best_rounds}")
            
            print("  Stage 2: Training final model on (daylight-only) dataset...")
            final_params = {**XGB_PARAMS, 'quantile_alpha': quantile, 'n_estimators': best_rounds}
            del final_params['early_stopping_rounds']
            model_xgb = xgb.XGBRegressor(**final_params)
            model_xgb.fit(X_train, y_train, verbose=False) # X_train is already filtered if needed
            
            model_xgb.save_model(MODEL_SAVE_PATH)
            joblib.dump(xgb_feature_cols, FEATURE_LIST_SAVE_PATH)
            print(f"  ✅ Model saved to {MODEL_SAVE_PATH}")
        else:
            print(f"  Loading existing model for {region.upper()}...")
            model_xgb = xgb.XGBRegressor(); model_xgb.load_model(MODEL_SAVE_PATH)
            xgb_feature_cols = joblib.load(FEATURE_LIST_SAVE_PATH)

        expected_order = model_xgb.get_booster().feature_names
        validate_features(expected_order, xgb_feature_cols)
        
        print(f"  Generating full-timeline predictions...")
        
        # Predict on historical data (all hours)
        full_X_train = df_train_featured[expected_order].fillna(0)
        historical_predictions = model_xgb.predict(full_X_train)
        if USE_HURDLE_MODEL:
            print("    ☀️ Forcing nighttime historical predictions to zero.")
            night_mask_hist = df_train_featured['is_daylight'] == 0
            historical_predictions[night_mask_hist] = 0.0

        # Predict on future data (recursively, then adjust)
        df_future_preds = pd.DataFrame()
        if not df_future_featured.empty:
            print(f"    Generating out-of-sample predictions recursively...")
            X_future = optimize_data_types(df_future_featured[expected_order].fillna(0), xgb_feature_cols)
            recent_target_values = list(y_train.tolist()[-200:])
            
            if len(X_future) > 1000:
                future_predictions = batch_recursive_forecast(
                    model_xgb, X_future, recent_target_values, expected_order, ALL_LAGS,
                    ROLLING_WINDOWS, TARGET_COL, CLIP_MIN, CLIP_MAX, batch_size=200
                )
            else:
                future_predictions = fast_recursive_forecast_optimized(
                    model_xgb, X_future, recent_target_values, expected_order, ALL_LAGS,
                    ROLLING_WINDOWS, TARGET_COL, CLIP_MIN, CLIP_MAX
                )

            if USE_HURDLE_MODEL:
                print("    ☀️ Forcing nighttime future predictions to zero.")
                night_mask_future = df_future_featured['is_daylight'] == 0
                future_predictions[night_mask_future] = 0.0
        
        # Post-processing and dataframe creation
        final_historical_preds = convert_to_final_scale(historical_predictions, USE_RATIO_SCALING, RATIO_SCALE, FINAL_MIN, FINAL_MAX)
        df_hist_preds = pd.DataFrame({DATE_COL: df_train_featured[DATE_COL], TARGET_COL_BASE: final_historical_preds})

        if not df_future_featured.empty:
            final_future_preds = convert_to_final_scale(future_predictions, USE_RATIO_SCALING, RATIO_SCALE, FINAL_MIN, FINAL_MAX)
            df_future_preds = pd.DataFrame({DATE_COL: df_future_featured[DATE_COL], TARGET_COL_BASE: final_future_preds})

        # Combine and save
        df_full_timeline = pd.concat([df_hist_preds, df_future_preds], ignore_index=True).sort_values(by=DATE_COL)
        df_full_timeline.to_parquet(PREDICTION_OUTPUT_FILE, index=False, engine=PARQUET_ENGINE)
        print(f"  ✅ Saved {len(df_full_timeline)} predictions to {PREDICTION_OUTPUT_FILE}")
        
        del df_train_featured, df_future_featured, X_train, y_train, model_xgb; gc.collect()
        return True
    except Exception as e:
        print(f"Error in train_xgb_quantile_for_region_parallel: {e}"); traceback.print_exc()
        return str(e)

def process_quantile(model_info, region_name, paths, xgb_feature_cols, TARGET_COL):
    """Wrapper function for multiprocessing."""
    try:
        result = train_xgb_quantile_for_region_parallel(region_name, model_info, **paths, xgb_feature_cols=xgb_feature_cols, TARGET_COL=TARGET_COL)
        return model_info["name"], result
    except Exception as e:
        traceback.print_exc(); return model_info["name"], str(e)

# --- Main Execution Block ---
if __name__ == "__main__":
    start_total_time = time.time(); processed_models = 0; failed_models = []
    regions_to_process = [r for r in REGIONS if os.path.exists(os.path.join(BASE_OUTPUT_DIR, r, "final", TRAIN_INPUT_FILENAME_BASE))]
    if not regions_to_process: print("No valid regions found!", file=sys.stderr); sys.exit(1)
    
    print(f"\n📊 Processing {len(regions_to_process)} regions with {len(QUANTILE_MODELS)} model(s) each")
    
    for region_name in regions_to_process:
        print(f"\n{'='*60}\n🚀 Starting Region {regions_to_process.index(region_name) + 1}/{len(regions_to_process)}: {region_name.upper()}\n{'='*60}")
        region_start_time = time.time()
        
        temp_dir = os.path.join(BASE_OUTPUT_DIR, region_name, "temp_featured")
        os.makedirs(temp_dir, exist_ok=True)
        
        paths = {
            "train_featured_path": os.path.join(temp_dir, "train_featured.parquet"),
            "future_featured_path": os.path.join(temp_dir, "future_featured.parquet"),
            "train_split_featured_path": os.path.join(temp_dir, "train_split_featured.parquet"),
            "validation_split_featured_path": os.path.join(temp_dir, "validation_split_featured.parquet")
        }

        try:
            print("  📁 Loading data...")
            train_df = pd.read_parquet(os.path.join(BASE_OUTPUT_DIR, region_name, "final", TRAIN_INPUT_FILENAME_BASE), engine=PARQUET_ENGINE)
            future_df = pd.read_parquet(os.path.join(BASE_OUTPUT_DIR, region_name, "final", FUTURE_COVARIATES_FILENAME_BASE), engine=PARQUET_ENGINE)
            
            TARGET_COL = get_target_column(train_df, region_name, TARGET_COL_BASE)
            if not TARGET_COL: print(f"Info: Target '{TARGET_COL_BASE}' not found for {region_name}. Skipping."); continue
            print(f"  🎯 Using target column: {TARGET_COL}")
            
            if USE_RATIO_SCALING:
                train_df.loc[:, TARGET_COL] *= RATIO_SCALE
                print(f"  📏 Applied ratio scaling (×{RATIO_SCALE})")

            print("  ⚙️  Creating train/validation split...")
            val_size = int(len(train_df) * XGB_VALIDATION_SPLIT_FRACTION)
            
            print("  ⚙️  Engineering features for full dataset...")
            combined_full_df = pd.concat([train_df, future_df], ignore_index=True).sort_values(DATE_COL).reset_index(drop=True)
            
            combined_full_df, time_features = create_time_features(combined_full_df, DATE_COL)
            solar_features = []
            if USE_HURDLE_MODEL:
                combined_full_df, solar_features = add_daylight_feature(combined_full_df, DAYLIGHT_START_HOUR, DAYLIGHT_END_HOUR)
            
            # ### MODIFIED: No longer creating temp features ###
            lag_features = create_lagged_features(combined_full_df, TARGET_COL, ALL_LAGS)[1]
            rolling_features = create_rolling_features(combined_full_df, TARGET_COL, ROLLING_WINDOWS, DATE_COL)[1]
            
            weather_cols = get_weather_columns(combined_full_df)
            xgb_feature_cols = sorted(list(set(time_features + lag_features + rolling_features + weather_cols + solar_features)))
            xgb_feature_cols = [col for col in xgb_feature_cols if col in combined_full_df.columns and col != TARGET_COL]
            print(f"  📊 Created {len(xgb_feature_cols)} features (Note: Temperature features removed for Solar model).")
            
            last_hist_date = train_df[DATE_COL].max()
            train_featured = combined_full_df[combined_full_df[DATE_COL] <= last_hist_date].copy()
            future_featured = combined_full_df[combined_full_df[DATE_COL] > last_hist_date].copy()
            
            print("  ⚙️  Engineering features for validation split (no leakage)...")
            train_split_featured = train_featured.iloc[:-val_size].copy()
            history_needed = max(MAX_LAG, MAX_ROLLING_WINDOW, 1)
            history_for_validation = train_df.iloc[-(val_size + history_needed):-val_size]
            combined_for_val = pd.concat([history_for_validation, train_df.iloc[-val_size:]], ignore_index=True).sort_values(DATE_COL).reset_index(drop=True)
            
            combined_for_val, _ = create_time_features(combined_for_val, DATE_COL)
            if USE_HURDLE_MODEL:
                combined_for_val, _ = add_daylight_feature(combined_for_val, DAYLIGHT_START_HOUR, DAYLIGHT_END_HOUR)
            combined_for_val, _ = create_lagged_features(combined_for_val, TARGET_COL, ALL_LAGS)
            combined_for_val, _ = create_rolling_features(combined_for_val, TARGET_COL, ROLLING_WINDOWS, DATE_COL)
            validation_split_featured = combined_for_val.iloc[-val_size:].copy()
            
            print("  💾 Saving featured datasets...")
            train_featured.to_parquet(paths["train_featured_path"], engine=PARQUET_ENGINE)
            future_featured.to_parquet(paths["future_featured_path"], engine=PARQUET_ENGINE)
            train_split_featured.to_parquet(paths["train_split_featured_path"], engine=PARQUET_ENGINE)
            validation_split_featured.to_parquet(paths["validation_split_featured_path"], engine=PARQUET_ENGINE)

        except Exception as e:
            print(f"❌ Error preprocessing {region_name}: {e}"); traceback.print_exc()
            failed_models.extend([f"{region_name.upper()}_{m['name']}_{TARGET_COL_BASE}" for m in QUANTILE_MODELS]); continue
        
        try:
            print(f"  🔄 Processing {len(QUANTILE_MODELS)} models with multiprocessing...")
            with multiprocessing.Pool(processes=min(multiprocessing.cpu_count(), len(QUANTILE_MODELS))) as pool:
                args = [(m, region_name, paths, xgb_feature_cols, TARGET_COL) for m in QUANTILE_MODELS]
                results = pool.starmap(process_quantile, args)

            for model_name, result in results:
                model_id = f"{region_name.upper()}_{model_name}_{TARGET_COL_BASE}"
                if result is True: processed_models += 1; print(f"✅ Completed {model_id}")
                else: failed_models.append(f"{model_id} ({result})")
                    
        except Exception as e:
            print(f"❌ Error in multiprocessing for {region_name}: {e}"); traceback.print_exc()
            failed_models.extend([f"{region_name.upper()}_{m['name']}_{TARGET_COL_BASE}" for m in QUANTILE_MODELS])
        
        print(f"\n🧹 Cleaning up region {region_name.upper()}...")
        try:
            gc.collect()
            region_time = time.time() - region_start_time
            print(f"✅ Completed {region_name.upper()} in {region_time:.2f} seconds")
        except Exception as e:
            print(f"⚠️  Cleanup warning for {region_name.upper()}: {e}")

    total_time = time.time() - start_total_time
    print(f"\n{'='*60}\n📊 OVERALL {TARGET_COL_BASE} MODEL PROCESSING SUMMARY\n{'='*60}")
    print(f"Total models processed: {processed_models}")
    print(f"Total execution time: {total_time:.2f} seconds")
    
    if failed_models:
        print(f"\n❌ Failed models ({len(failed_models)}):"); [print(f"  - {fm}") for fm in failed_models]
        print(f"\nSuccess rate: {processed_models/(processed_models + len(failed_models))*100:.1f}%"); sys.exit(1)
    else:
        print(f"\n🎉 All models processed successfully!"); sys.exit(0)