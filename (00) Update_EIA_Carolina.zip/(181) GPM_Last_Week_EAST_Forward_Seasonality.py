import pandas as pd
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import numpy as np
import warnings
import os

# Suppress common pandas warnings
warnings.filterwarnings('ignore', category=FutureWarning)

# --- 1. Load and Prepare Data ---
print("Step 1: Loading and preparing data...")
features_path = r'D:\EIA_STACK\Pricing_RL\PACIFIC\PACIFIC_filtered.csv'
target_path = r'D:\EIA_STACK\granular_storage\pacific.csv'
future_covariates_path = r'D:\EIA_STACK\Pricing_RL\PACIFIC\future_covariates.csv'

try:
    df_features_daily = pd.read_csv(features_path)
    df_target_weekly = pd.read_csv(target_path)
except FileNotFoundError as e:
    print(f"Error: Could not find a historical data file.\nDetails: {e}")
    exit()

df_features_daily['date'] = pd.to_datetime(df_features_daily['date'])
df_target_weekly['datetime'] = pd.to_datetime(df_target_weekly['datetime'])
df_features_daily.set_index('date', inplace=True)
df_target_weekly.set_index('datetime', inplace=True)

# --- 2. Advanced Feature Engineering (Daily) ---
print("\nStep 2: Engineering rolling features on historical daily data...")
# CORRECTED COLUMN NAME HERE
df_features_daily['synmax_7day_avg'] = df_features_daily['synmaxproductio_DRY_GAS_BCF_DAY'].rolling(window=7).mean()

# --- 3. Aggregate Daily Data to Weekly ---
print("\nStep 3: Aggregating historical daily data to a weekly cadence...")
aggregation_rules = {col: 'last' if 'eastconsolidate_BCF' in col or '_avg' in col else 'sum' for col in df_features_daily.columns}
df_features_weekly = df_features_daily.resample('W-FRI').agg(aggregation_rules)

# --- 4. Merge Data and Engineer Weekly Features ---
print("\nStep 4: Merging data and engineering weekly/seasonal features...")
df_merged = pd.merge(df_features_weekly, df_target_weekly, left_index=True, right_index=True, how='inner')
df_merged['East_Lag_1_Week'] = df_merged['Pacific'].shift(1)
df_merged['East_Lag_2_Week'] = df_merged['Pacific'].shift(2)
df_merged['East_Lag_52_Week'] = df_merged['Pacific'].shift(52)
df_merged['Week_of_Year'] = df_merged.index.isocalendar().week.astype(int)
df_merged['Month'] = df_merged.index.month
df_merged.dropna(inplace=True)

# --- 5. Define Final Features (X) and Target (y) ---
# --- 5. Define Final Features (X) and Target (y) ---
y = df_merged['Delta_Change']
# Drop the target variables AND the non-numeric 'DATA_SOURCE' column
X = df_merged.drop(columns=['Pacific', 'Delta_Change'])

# --- 6 & 7. Backtesting (Included for completeness) ---
print("\nStep 6 & 7: Running Walk-Forward Validation (Backtesting)...")
start_date_test = '2024-01-01'
test_indices = X[X.index >= start_date_test].index
backtest_results = []
for current_date in test_indices:
    X_train = X[X.index < current_date]; y_train = y[y.index < current_date]
    X_test_current = X.loc[[current_date]]; actual_delta = y.loc[current_date]
    actual_level = df_merged.loc[current_date, 'Pacific']; last_week_level = df_merged.loc[current_date, 'East_Lag_1_Week']
    lgbm = lgb.LGBMRegressor(random_state=42, n_estimators=250, learning_rate=0.05, num_leaves=31, verbose=-1)
    lgbm.fit(X_train, y_train)
    predicted_delta = lgbm.predict(X_test_current)[0]
    predicted_level = last_week_level + predicted_delta
    backtest_results.append({'Date': current_date.date(), 'Actual_Level': actual_level, 'Predicted_Level': predicted_level, 'Error': actual_level - predicted_level, 'Actual_Delta': actual_delta, 'Predicted_Delta': predicted_delta})
results_df = pd.DataFrame(backtest_results).set_index('Date')
final_mae = results_df['Error'].abs().mean()
print(f"\n--- Backtest MAE on Storage Level: {final_mae:.2f} BCF ---")


# --- 8. Train Final Model on All Data ---
print("\nStep 8: Training final model on all available data...")
lgbm_final = lgb.LGBMRegressor(random_state=42, n_estimators=250, learning_rate=0.05, num_leaves=31, verbose=-1)
lgbm_final.fit(X, y)

# --- 9. Generate Short-Term Forecast ---
print("\nStep 9: Generating short-term (next week) forecast...")
last_known_features = X.iloc[[-1]]
last_actual_level = df_merged['Pacific'].iloc[-1]
next_delta_prediction = lgbm_final.predict(last_known_features)[0]
next_level_prediction = last_actual_level + next_delta_prediction
print("\n----------------------[ Short-Term Forecast ]-----------------------")
print(f"Predicted EIA East storage for next week: {next_level_prediction:.2f} BCF")
print("--------------------------------------------------------------------")


# --- 10. Generate LONG-TERM Forecast with optional Future Covariates ---
print("\nStep 10: Generating long-term seasonal forecast profile...")

# a. Calculate historical averages to use as a fallback for any missing data
avg_weekly_features = X.groupby('Week_of_Year').mean()
future_covariates_weekly = None

# b. Load and process the future covariates file if it exists
if os.path.exists(future_covariates_path):
    print(f"Found future covariates file: {future_covariates_path}")
    df_future_daily = pd.read_csv(future_covariates_path)
    df_future_daily['date'] = pd.to_datetime(df_future_daily['date'])
    df_future_daily.set_index('date', inplace=True)
    future_covariates_weekly = df_future_daily.resample('W-FRI').agg(aggregation_rules)
    print("Successfully processed future covariates.")
else:
    print("No future covariates file found. Using historical averages for long-term forecast.")

# c. Set up forecast period
last_date = X.index.max()
forecast_dates = pd.date_range(start=last_date, periods=53, freq='W-FRI')[1:]
lag1 = df_merged.loc[last_date, 'Pacific']
lag2 = df_merged.loc[last_date, 'East_Lag_1_Week']
long_term_forecasts = []

# d. Loop and predict for the next 52 weeks
for date in forecast_dates:
    week_num = date.isocalendar().week
    month_num = date.month
    
    # --- HYBRID FEATURE LOGIC ---
    if future_covariates_weekly is not None and date in future_covariates_weekly.index:
        # 1. Start with your specific forecast for this week.
        # It will have NaNs for the columns you didn't provide (e.g., eastconsolidate...).
        features_for_week = future_covariates_weekly.loc[date].copy()
        
        # 2. Use combine_first to intelligently fill the NaNs with historical averages.
        features_for_week = features_for_week.combine_first(avg_weekly_features.loc[week_num])
    else:
        # Fallback: If no future file or date is missing, use historical averages for everything.
        features_for_week = avg_weekly_features.loc[week_num].copy()
    
    # Overwrite lags and date features with iteratively calculated values
    features_for_week['East_Lag_1_Week'] = lag1
    features_for_week['East_Lag_2_Week'] = lag2
    historical_date_lookup = date - pd.DateOffset(weeks=52)
    closest_date_iloc = np.abs(df_merged.index - historical_date_lookup).argmin()
    features_for_week['East_Lag_52_Week'] = df_merged.iloc[closest_date_iloc]['Pacific']
    features_for_week['Week_of_Year'] = week_num
    features_for_week['Month'] = month_num
    
    features_df = pd.DataFrame([features_for_week], columns=X.columns)
    
    # Predict and store
    predicted_delta = lgbm_final.predict(features_df)[0]
    new_storage_level = lag1 + predicted_delta
    long_term_forecasts.append({'Forecast_Date': date.date(), 'Week_Number': week_num, 'Predicted_Delta': predicted_delta, 'Projected_Storage_Level': new_storage_level})
    
    # Update lags for the next iteration
    lag2 = lag1
    lag1 = new_storage_level

# e. Present results
forecast_df = pd.DataFrame(long_term_forecasts).set_index('Forecast_Date')
output_path = r'D:\EIA_STACK\granular_storage\pacific_long_term_seasonal_forecast.csv'
forecast_df.to_csv(output_path)

print(f"\n--- Long-Term Seasonal Profile (Next 52 Weeks) ---")
print(f"Saved results to: {output_path}")
print(forecast_df.round(2))

forecast_df['Projected_Storage_Level'].plot(figsize=(15, 7), marker='.', linestyle='--')
plt.title('Projected 52-Week Storage Forecast (East Region)')
plt.xlabel('Date')
plt.ylabel('Projected Storage (BCF)')
plt.grid(True)
# plt.show()