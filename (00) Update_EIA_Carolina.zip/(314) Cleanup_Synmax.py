import pandas as pd
import os
import traceback

def process_regional_production():
    """
    Processes regional Synmax production files, re-maps them to new
    regional folders, combines Gulf and Southeast into SouthCentral,
    and cleans up the original files.
    """
    # --- Configuration ---
    source_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    
    # Mapping: source_filename_prefix -> destination_folder
    # 'SouthCentral' is a special case handled separately.
    simple_mapping = {
        'synmax_production_northeast': 'EAST',
        'synmax_production_midwest': 'MIDWEST',
        'synmax_production_west': 'MOUNTAIN'
    }
    
    print("--- Starting Regional Production Processing ---")
    print(f"Source folder: '{os.path.abspath(source_folder)}'")

    # --- 1. Process simple one-to-one file moves ---
    for prefix, dest_folder in simple_mapping.items():
        input_filename = f"{prefix}.csv"
        file_path = os.path.join(source_folder, input_filename)
        output_folder = os.path.join(source_folder, dest_folder)
        output_path = os.path.join(output_folder, 'production.csv')
        
        print(f"\nProcessing '{input_filename}' -> '{dest_folder}' region...")

        if not os.path.exists(file_path):
            print(f"  [Info] File not found, skipping: {input_filename}")
            continue
            
        try:
            df = pd.read_csv(file_path)
            
            # Standardize column names
            df.rename(columns={'DATE': 'datetime', 'DRY_GAS_BCF_DAY': 'production_BCF'}, inplace=True)
            
            # Keep only the relevant columns
            output_df = df[['datetime', 'production_BCF']]
            
            # Create destination folder and save
            os.makedirs(output_folder, exist_ok=True)
            output_df.to_csv(output_path, index=False)
            print(f"  - Saved standardized data to: {output_path}")
            
            # Delete original file
            os.remove(file_path)
            print(f"  ✓ Successfully processed and deleted original file.")

        except Exception as e:
            print(f"  [ERROR] Failed to process {input_filename}. Reason: {e}")
            traceback.print_exc()

    # --- 2. Process and combine for SouthCentral ---
    print("\nProcessing 'gulf' + 'southeast' -> 'SOUTHCENTRAL' region...")
    try:
        gulf_file = os.path.join(source_folder, 'synmax_production_gulf.csv')
        se_file = os.path.join(source_folder, 'synmax_production_southeast.csv')
        
        if not os.path.exists(gulf_file) or not os.path.exists(se_file):
            print("  [Info] One or both source files (gulf, southeast) not found. Skipping SouthCentral.")
        else:
            # Read both files
            df_gulf = pd.read_csv(gulf_file)
            df_se = pd.read_csv(se_file)
            
            # Merge dataframes on DATE. Use an outer merge to keep all dates from both files.
            # Fill missing values with 0 so addition works correctly.
            merged_df = pd.merge(df_gulf, df_se, on='DATE', how='outer', suffixes=('_gulf', '_se')).fillna(0)
            
            # Sum the production columns
            merged_df['production_BCF'] = merged_df['DRY_GAS_BCF_DAY_gulf'] + merged_df['DRY_GAS_BCF_DAY_se']
            
            # Standardize final dataframe
            merged_df.rename(columns={'DATE': 'datetime'}, inplace=True)
            output_df = merged_df[['datetime', 'production_BCF']]
            
            # Define output path and save
            output_folder = os.path.join(source_folder, 'SOUTHCENTRAL')
            output_path = os.path.join(output_folder, 'production.csv')
            os.makedirs(output_folder, exist_ok=True)
            output_df.to_csv(output_path, index=False)
            print(f"  - Combined data saved to: {output_path}")
            
            # Delete original files
            os.remove(gulf_file)
            os.remove(se_file)
            print("  ✓ Successfully processed and deleted original gulf and southeast files.")

    except Exception as e:
        print(f"  [ERROR] Failed to process SouthCentral combination. Reason: {e}")
        traceback.print_exc()

    print("\n--- Regional Production Processing Complete! ---")

# --- Run the script ---
if __name__ == "__main__":
    process_regional_production()