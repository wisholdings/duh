#!/usr/bin/env python3
"""
Combine Regional Storage Data Script
Sums storage values from all regional CSV files to create Lower 48 combined file
"""

import pandas as pd
from pathlib import Path
import sys

def combine_regional_storage():
    """Combine all regional storage CSV files into Lower 48 total"""
    
    # Define directory path
    data_dir = Path(r"D:\EIA_STACK\Pricing_RL\AGGREGATE")
    
    # Define regional files and their corresponding column names
    regional_files = {
        "east_combined.csv": "East",
        "midwest_combined.csv": "Midwest", 
        "mountain_combined.csv": "Mountain",
        "pacific_combined.csv": "Pacific",
        "south_central_nonsalt_combined.csv": "South Central Nonsalt",
        "south_central_salt_combined.csv": "South Central Salt"
    }
    
    print("="*60)
    print("COMBINING REGIONAL STORAGE DATA TO LOWER 48")
    print("="*60)
    print(f"Directory: {data_dir}\n")
    
    # Initialize combined dataframe with None
    combined_df = None
    missing_files = []
    processed_files = []
    
    # Read and combine each regional file
    for file_name, region_column in regional_files.items():
        file_path = data_dir / file_name
        
        try:
            if not file_path.exists():
                print(f"⚠ WARNING: File not found - {file_name}")
                missing_files.append(file_name)
                continue
            
            # Read the CSV file
            df = pd.read_csv(file_path)
            print(f"✓ Read {file_name}: {len(df)} rows")
            
            # Get the storage column (second column) and rename it for clarity
            # The column names are the region names (East, Midwest, etc.)
            storage_col_name = region_column
            
            if combined_df is None:
                # Initialize with datetime and first region's data
                combined_df = pd.DataFrame()
                combined_df['datetime'] = df['datetime']
                combined_df[region_column] = df[storage_col_name]
            else:
                # Add this region's storage data
                combined_df[region_column] = df[storage_col_name]
            
            processed_files.append(file_name)
            
        except Exception as e:
            print(f"✗ ERROR: Failed to process {file_name} - {str(e)}")
            missing_files.append(file_name)
    
    # Check if we have data to combine
    if combined_df is None or len(processed_files) == 0:
        print("\n✗ ERROR: No files could be processed. Exiting.")
        return False
    
    print(f"\n{len(processed_files)} files processed successfully")
    
    # Calculate Lower 48 total (sum of all regions)
    regional_columns = [col for col in combined_df.columns if col != 'datetime']
    combined_df['Lower_48_Total'] = combined_df[regional_columns].sum(axis=1)
    
    # Create output dataframe with just datetime and Lower 48 total
    output_df = pd.DataFrame()
    output_df['datetime'] = combined_df['datetime']
    output_df['Lower_48_Total'] = combined_df['Lower_48_Total']
    
    # Calculate Delta_Change (difference from previous row)
    output_df['Delta_Change'] = output_df['Lower_48_Total'].diff()
    
    # Output file path
    output_file = data_dir / "lower_48_combined_pipe.csv"
    
    try:
        # Save to CSV
        output_df.to_csv(output_file, index=False)
        print(f"\n✓ SUCCESS: Created {output_file.name}")
        print(f"  - Rows: {len(output_df)}")
        print(f"  - Columns: {', '.join(output_df.columns)}")
        
        # Display summary statistics
        print("\nSummary Statistics:")
        print(f"  - Total Lower 48 Storage (latest): {output_df['Lower_48_Total'].iloc[-1]:,}")
        print(f"  - Average Storage: {output_df['Lower_48_Total'].mean():,.1f}")
        print(f"  - Min Storage: {output_df['Lower_48_Total'].min():,}")
        print(f"  - Max Storage: {output_df['Lower_48_Total'].max():,}")
        
        # Show breakdown of latest values by region
        if len(processed_files) == len(regional_files):
            print("\nLatest Regional Breakdown:")
            latest_row = combined_df.iloc[-1]
            for region in regional_columns:
                value = latest_row[region]
                pct = (value / latest_row['Lower_48_Total']) * 100
                print(f"  - {region}: {value:,} ({pct:.1f}%)")
        
        return True
        
    except Exception as e:
        print(f"\n✗ ERROR: Failed to save output file - {str(e)}")
        return False

def verify_output():
    """Verify the output file was created correctly"""
    output_path = Path(r"D:\EIA_STACK\Pricing_RL\AGGREGATE\lower_48_combined_pipe.csv")
    
    if output_path.exists():
        df = pd.read_csv(output_path)
        print("\n" + "="*60)
        print("OUTPUT FILE VERIFICATION")
        print("="*60)
        print(f"File: {output_path.name}")
        print(f"Rows: {len(df)}")
        print(f"Columns: {list(df.columns)}")
        print("\nFirst 5 rows:")
        print(df.head())
        print("\nLast 5 rows:")
        print(df.tail())
        return True
    else:
        print(f"\n✗ Output file not found: {output_path}")
        return False

if __name__ == "__main__":
    try:
        # Run the combination process
        success = combine_regional_storage()
        
        if success:
            # Optionally verify the output
            print("\n" + "="*60)
            verify_output()
            print("\n✓ Process completed successfully!")
            sys.exit(0)
        else:
            print("\n✗ Process failed.")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        sys.exit(1)