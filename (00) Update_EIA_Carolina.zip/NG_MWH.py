import streamlit as st
import pandas as pd
from datetime import datetime, timedelta, date
from sqlalchemy import create_engine, text
import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="NG Power Forecast by EIA Regions", 
    page_icon="🔥",
    layout="wide"
)

# --- ESTABLISH THE TRUE CURRENT DATE ---
TODAY = date.today()

# --- AZURE SQL DATABASE CONFIGURATION ---
AZURE_DB_CONNECTION_STRING = (
)

# --- EIA REGION MAPPING ---
EIA_REGION_MAPPING = {
    'pacific': ['california', 'northwest'],
    'mountain': ['southwest'],
    'midwest': ['midwest', 'central'],
    'east': ['newengland', 'newyork', 'midatlantic', 'carolina'],
    'south_central': ['texas', 'tennessee', 'southeast', 'florida']
}

# --- Database Connection ---
def get_db_engine():
    """Create database engine for Azure SQL connection with proper error handling."""
    try:
        engine = create_engine(
            AZURE_DB_CONNECTION_STRING, 
            echo=False, 
            pool_recycle=1800,
            pool_pre_ping=True,
            pool_size=5,
            max_overflow=10,
            connect_args={
                'timeout': 30,
                'login_timeout': 30,
                'appname': 'NG_Power_EIA_Dashboard'
            }
        )
        with engine.connect() as connection:
            connection.execute(text("SELECT 1")).scalar()
        return engine
    except Exception as e:
        st.error(f"Database Connection Error: {e}")
        return None

@st.cache_data(ttl=1800)
def load_ng_power_data():
    """Load NG power forecast data and aggregate to EIA regions with retry logic."""
    max_retries = 3
    retry_delay = 2
    
    for attempt in range(max_retries):
        try:
            engine = get_db_engine()
            if not engine:
                if attempt < max_retries - 1:
                    st.warning(f"Connection attempt {attempt + 1} failed. Retrying...")
                    import time
                    time.sleep(retry_delay)
                    continue
                else:
                    return None
            
            query = text("""
            SELECT 
                [datetime],
                [region],
                [date_published],
                [forecast_mw]
            FROM [dbo].[PRODUCTION_NHITS_TABLE_FORECAST_NG]
            WHERE [forecast_mw] IS NOT NULL
            ORDER BY [datetime] ASC, [region] ASC
            """)
            
            with engine.connect() as connection:
                df = pd.read_sql_query(query, connection)
            
            if not df.empty:
                df['datetime'] = pd.to_datetime(df['datetime'])
                df['date_published'] = pd.to_datetime(df['date_published']).dt.date
                
                # Aggregate hourly to daily
                df['date'] = df['datetime'].dt.date
                daily_df = df.groupby(['date', 'region', 'date_published'], as_index=False).agg({
                    'forecast_mw': 'mean'
                }).round(0)
                
                daily_df = daily_df.rename(columns={'date': 'datetime'})
                daily_df['datetime'] = pd.to_datetime(daily_df['datetime'])
                
                # Map regions to EIA storage regions
                eia_aggregated = []
                for eia_region, sub_regions in EIA_REGION_MAPPING.items():
                    for dt in daily_df['datetime'].unique():
                        for pub_date in daily_df['date_published'].unique():
                            date_data = daily_df[
                                (daily_df['datetime'] == dt) & 
                                (daily_df['date_published'] == pub_date)
                            ]
                            
                            eia_sum = date_data[date_data['region'].isin(sub_regions)]['forecast_mw'].sum()
                            
                            if eia_sum > 0:
                                eia_aggregated.append({
                                    'datetime': dt,
                                    'eia_region': eia_region.upper(),
                                    'date_published': pub_date,
                                    'forecast_mw': eia_sum
                                })
                
                eia_df = pd.DataFrame(eia_aggregated)
                return eia_df
            return None
            
        except Exception as e:
            if attempt < max_retries - 1:
                st.warning(f"Attempt {attempt + 1} failed: {str(e)[:100]}... Retrying...")
                import time
                time.sleep(retry_delay)
            else:
                st.error(f"Failed to load data after {max_retries} attempts: {str(e)}")
                return None
    
    return None

def calculate_eia_stats(df, eia_region):
    """Calculate statistics for EIA region including day-over-day changes."""
    region_data = df[df['eia_region'] == eia_region].copy().sort_values(['datetime', 'date_published'])
    
    if region_data.empty:
        return None
    
    publication_dates = sorted(region_data['date_published'].unique(), reverse=True)
    today_pub = publication_dates[0] if len(publication_dates) > 0 else None
    yesterday_pub = publication_dates[1] if len(publication_dates) > 1 else None
    
    historical = region_data[region_data['datetime'].dt.date <= TODAY]
    forecast = region_data[region_data['datetime'].dt.date > TODAY]
    
    next_30_dates = pd.date_range(start=TODAY + timedelta(days=1), periods=30, freq='D')
    
    today_forecasts = region_data[
        (region_data['date_published'] == today_pub) &
        (region_data['datetime'].dt.date.isin(next_30_dates.date)) 
    ] if today_pub else pd.DataFrame()
    
    yesterday_forecasts = region_data[
        (region_data['date_published'] == yesterday_pub) &
        (region_data['datetime'].dt.date.isin(next_30_dates.date))
    ] if yesterday_pub else pd.DataFrame()
    
    # Calculate day-over-day changes
    dod_change = None
    dod_pct_change = None
    
    if not today_forecasts.empty and not yesterday_forecasts.empty:
        merged = pd.merge(
            today_forecasts[['datetime', 'forecast_mw']], 
            yesterday_forecasts[['datetime', 'forecast_mw']], 
            on='datetime', 
            suffixes=('_today', '_yesterday')
        )
        if not merged.empty:
            merged['change'] = merged['forecast_mw_today'] - merged['forecast_mw_yesterday']
            merged['pct_change'] = (merged['change'] / merged['forecast_mw_yesterday']) * 100
            dod_change = merged['change'].mean()
            dod_pct_change = merged['pct_change'].mean()
    
    latest_historical = historical['forecast_mw'].iloc[-1] if not historical.empty else None
    
    latest_pub_forecast = forecast[forecast['date_published'] == today_pub] if today_pub else forecast
    
    next_7_days = latest_pub_forecast[
        latest_pub_forecast['datetime'].dt.date.between(
            TODAY + timedelta(days=1), 
            TODAY + timedelta(days=7)
        )
    ]['forecast_mw'].mean()
    
    next_30_days = latest_pub_forecast[
        latest_pub_forecast['datetime'].dt.date.between(
            TODAY + timedelta(days=1), 
            TODAY + timedelta(days=30)
        )
    ]['forecast_mw'].mean()
    
    next_30_data = latest_pub_forecast[
        latest_pub_forecast['datetime'].dt.date.between(
            TODAY + timedelta(days=1), 
            TODAY + timedelta(days=30)
        )
    ]
    
    peak_30 = next_30_data['forecast_mw'].max() if not next_30_data.empty else None
    min_30 = next_30_data['forecast_mw'].min() if not next_30_data.empty else None
    
    return {
        'latest_historical': latest_historical,
        'next_7_avg': next_7_days,
        'next_30_avg': next_30_days,
        'peak_30': peak_30,
        'min_30': min_30,
        'dod_change': dod_change,
        'dod_pct_change': dod_pct_change,
        'publication_dates': publication_dates[:3],
        'data_count': len(region_data),
        'region_data': region_data
    }

# --- PAGE TITLE ---
st.title("🔥 Natural Gas Power Generation by EIA Storage Regions")
st.markdown("*Aggregated MW Generation Forecasts with Day-over-Day Changes*")

# --- Load and Process Data ---
with st.spinner("Loading and aggregating NG power forecast data..."):
    eia_data = load_ng_power_data()

if eia_data is None or eia_data.empty:
    st.error("No natural gas power forecast data could be loaded from the database.")
    st.stop()

# Data summary
latest_published = eia_data['date_published'].max()
total_records = len(eia_data)
date_range = f"{eia_data['datetime'].min().strftime('%Y-%m-%d')} to {eia_data['datetime'].max().strftime('%Y-%m-%d')}"

st.info(f"📊 **Data Summary:** {total_records:,} aggregated records | **Date Range:** {date_range} | **Latest Published:** {latest_published}")

# --- EIA REGION OVERVIEW ---
st.subheader("📊 EIA Storage Regions Overview - NG Power Generation")

overview_data = []
for eia_region in ['PACIFIC', 'MOUNTAIN', 'MIDWEST', 'EAST', 'SOUTH_CENTRAL']:
    stats = calculate_eia_stats(eia_data, eia_region)
    if stats:
        overview_data.append({
            'Region': eia_region,
            'Latest MW': stats['latest_historical'],
            '7-Day Avg': stats['next_7_avg'],
            '30-Day Avg': stats['next_30_avg'],
            'DoD Change': stats['dod_change'],
            'DoD %': stats['dod_pct_change']
        })

if overview_data:
    overview_df = pd.DataFrame(overview_data)
    
    cols = st.columns(5)
    for i, row in overview_df.iterrows():
        with cols[i]:
            st.metric(
                row['Region'],
                f"{row['Latest MW']:,.0f} MW" if pd.notna(row['Latest MW']) else "N/A",
                f"{row['DoD Change']:+,.0f} MW ({row['DoD %']:+.1f}%)" if pd.notna(row['DoD Change']) else None,
                help=f"7-Day Avg: {row['7-Day Avg']:,.0f} MW | 30-Day Avg: {row['30-Day Avg']:,.0f} MW" if pd.notna(row['7-Day Avg']) else "No forecast data"
            )

st.markdown("---")

# --- DETAILED REGION ANALYSIS ---
st.subheader("🔍 Detailed Regional Analysis")

col1, col2 = st.columns([2, 1])

with col1:
    selected_eia_region = st.selectbox(
        "Select EIA Storage Region for Detailed View:",
        ['PACIFIC', 'MOUNTAIN', 'MIDWEST', 'EAST', 'SOUTH_CENTRAL'],
        index=0
    )
    
    sub_regions = EIA_REGION_MAPPING[selected_eia_region.lower()]
    st.caption(f"**Includes:** {', '.join([r.title() for r in sub_regions])}")

with col2:
    region_stats = calculate_eia_stats(eia_data, selected_eia_region)
    if region_stats:
        st.metric(
            "Total Data Points", 
            f"{region_stats['data_count']:,}",
            help=f"Aggregated forecast points for {selected_eia_region}"
        )

# --- FORECAST CHART ---
st.subheader(f"📈 NG Power Forecast Timeline - {selected_eia_region}")

region_df = eia_data[eia_data['eia_region'] == selected_eia_region].copy()

if not region_df.empty:
    chart_start_date = TODAY - timedelta(days=14)
    chart_end_date = TODAY + timedelta(days=30)
    
    plot_df = region_df[
        (region_df['datetime'].dt.date >= chart_start_date) & 
        (region_df['datetime'].dt.date <= chart_end_date)
    ].copy().sort_values(['datetime', 'date_published'])
    
    if not plot_df.empty:
        pub_dates = sorted(plot_df['date_published'].unique(), reverse=True)
        
        fig = go.Figure()
        
        colors = ['steelblue', 'orange', 'green', 'purple']
        line_styles = ['solid', 'dash', 'dot', 'dashdot']
        
        for i, pub_date in enumerate(pub_dates[:4]):
            pub_data = plot_df[plot_df['date_published'] == pub_date]
            
            historical_data = pub_data[pub_data['datetime'].dt.date <= TODAY]
            future_data = pub_data[pub_data['datetime'].dt.date > TODAY]
            
            if not historical_data.empty:
                fig.add_trace(go.Scatter(
                    x=historical_data['datetime'],
                    y=historical_data['forecast_mw'],
                    mode='lines+markers',
                    name=f'Historical ({pub_date.strftime("%m/%d")})',
                    line=dict(color=colors[i % len(colors)], width=2),
                    marker=dict(size=4),
                    showlegend=(i == 0)
                ))
            
            if not future_data.empty:
                fig.add_trace(go.Scatter(
                    x=future_data['datetime'],
                    y=future_data['forecast_mw'],
                    mode='lines+markers',
                    name=f'Forecast {pub_date.strftime("%m/%d")}',
                    line=dict(
                        color=colors[i % len(colors)], 
                        width=4 if i == 0 else 2,
                        dash=line_styles[i % len(line_styles)]
                    ),
                    marker=dict(size=5 if i == 0 else 4),
                    opacity=1.0 if i == 0 else 0.7
                ))
        
        today_datetime = pd.Timestamp(TODAY)
        fig.add_shape(
            type="line",
            x0=today_datetime,
            x1=today_datetime,
            y0=0,
            y1=1,
            yref="paper",
            line=dict(color="red", width=2, dash="dash")
        )
        
        fig.add_annotation(
            x=today_datetime,
            y=0.95,
            yref="paper",
            text="Today",
            showarrow=False,
            font=dict(color="red", size=12),
            bgcolor="white",
            bordercolor="red",
            borderwidth=1
        )
        
        fig.update_layout(
            title=f"Natural Gas Power Generation Forecast: {selected_eia_region}",
            xaxis_title="Date",
            yaxis_title="Daily Average Megawatts (MW)",
            template='plotly_white',
            hovermode='closest',
            height=500,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)

st.markdown("---")

# --- DAY-OVER-DAY CHANGES TABLE ---
st.subheader("📊 Day-over-Day Forecast Changes by Region")

dod_table_data = []
for eia_region in ['PACIFIC', 'MOUNTAIN', 'MIDWEST', 'EAST', 'SOUTH_CENTRAL']:
    stats = calculate_eia_stats(eia_data, eia_region)
    if stats and stats['dod_change'] is not None:
        dod_table_data.append({
            "EIA Region": eia_region,
            "Latest Forecast (MW)": f"{stats['latest_historical']:,.0f}" if stats['latest_historical'] else "N/A",
            "Absolute Change (MW)": f"{stats['dod_change']:+,.0f}",
            "Percent Change": f"{stats['dod_pct_change']:+.2f}%",
            "7-Day Outlook (MW)": f"{stats['next_7_avg']:,.0f}" if pd.notna(stats['next_7_avg']) else "N/A",
            "30-Day Outlook (MW)": f"{stats['next_30_avg']:,.0f}" if pd.notna(stats['next_30_avg']) else "N/A"
        })

if dod_table_data:
    dod_df = pd.DataFrame(dod_table_data)
    st.dataframe(
        dod_df,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Absolute Change (MW)": st.column_config.TextColumn(
                "DoD Change (MW)",
                help="Average day-over-day change in MW"
            ),
            "Percent Change": st.column_config.TextColumn(
                "DoD Change (%)",
                help="Average day-over-day percentage change"
            )
        }
    )

# --- COMPARISON CHART ---
st.subheader("🔥 All EIA Regions Comparison (Next 30 Days)")

comparison_start = TODAY + timedelta(days=1)
comparison_end = TODAY + timedelta(days=30)

fig_multi = go.Figure()

colors = ['steelblue', 'forestgreen', 'darkorange', 'purple', 'crimson']

for i, eia_region in enumerate(['PACIFIC', 'MOUNTAIN', 'MIDWEST', 'EAST', 'SOUTH_CENTRAL']):
    region_data = eia_data[
        (eia_data['eia_region'] == eia_region) &
        (eia_data['datetime'].dt.date >= comparison_start) &
        (eia_data['datetime'].dt.date <= comparison_end)
    ]
    
    if not region_data.empty:
        latest_pub = region_data['date_published'].max()
        latest_data = region_data[region_data['date_published'] == latest_pub]
        
        fig_multi.add_trace(go.Scatter(
            x=latest_data['datetime'],
            y=latest_data['forecast_mw'],
            mode='lines+markers',
            name=eia_region,
            line=dict(color=colors[i], width=3),
            marker=dict(size=5)
        ))

fig_multi.update_layout(
    title="30-Day NG Power Forecast - All EIA Storage Regions",
    xaxis_title="Date",
    yaxis_title="Daily Average Megawatts (MW)",
    template='plotly_white',
    hovermode='closest',
    height=600,
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=-0.15,
        xanchor="center",
        x=0.5
    )
)

st.plotly_chart(fig_multi, use_container_width=True)

# --- POWER GENERATION MIX ---
st.subheader("⚡ Natural Gas in the Power Mix")
st.info("Natural gas power generation provides critical grid reliability, ramping quickly to meet demand changes and complement renewable generation variability.")

# --- EXPORT OPTIONS ---
with st.expander("📥 Export Data"):
    if st.button("Export EIA Regional NG Power Summary"):
        if dod_table_data:
            csv = pd.DataFrame(dod_table_data).to_csv(index=False)
            st.download_button(
                "Download NG Power EIA Regional Summary (CSV)",
                csv,
                f"ng_power_eia_summary_{TODAY.strftime('%Y%m%d')}.csv",
                "text/csv"
            )

# --- FOOTER ---
st.markdown("---")
st.caption(f"**Last Data Published:** {latest_published} | **Dashboard Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}")
st.caption("**Note:** Data aggregated from granular regions to EIA storage regions for alignment with gas storage analysis.")