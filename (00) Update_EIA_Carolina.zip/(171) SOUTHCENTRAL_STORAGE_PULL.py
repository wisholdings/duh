import pandas as pd
import psycopg2
import logging
import sys
import os
import re

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# PostgreSQL Database Connection Details
DB_CONFIG = {
    "host": "",
    "database": "",
    "user": "",
    "password": "",
    "port": 443
}

def clean_folder_name(name):
    """Cleans up a string to be used as a folder name."""
    if not isinstance(name, str):
        name = str(name)
    
    # Replace spaces with underscores
    name = name.replace(' ', '_')
    # Remove any characters that are not alphanumeric, underscores, or hyphens
    name = re.sub(r'[^\w-]+', '', name)
    return name

def fetch_and_save_pipeline_data_to_csv(tickers_to_fetch: list, output_csv_name: str, facility_name: str):
    """
    Connects to the PostgreSQL database, fetches pipeline nomination data for
    specified tickers (NO STATE FILTERING), and saves it to a CSV file.

    Args:
        tickers_to_fetch (list): A list of ticker strings.
        output_csv_name (str): The name of the CSV file to save the data to.
        facility_name (str): The name of the storage facility for logging purposes.
    """
    if not tickers_to_fetch:
        logging.warning(f"No tickers provided for '{facility_name}'. Skipping data fetch.")
        return

    # Format the Python list of tickers for the SQL 'IN' clause
    formatted_tickers = ",".join(f"'{ticker}'" for ticker in tickers_to_fetch)

    # Construct the SQL query with NO STATE FILTERING
    SQL_QUERY = f"""
    select
        meta.pipeline_name, meta.tsp, meta.tsp_short, meta.ticker, meta.loc_name, meta.loc, meta.loc_qti_id
        , meta.loc_qti_short, meta.loc_purp_desc, meta.rec_del_sign, meta.loc_zone, meta.category_short, meta.sub_category_desc
        , meta.sub_category_2_desc, meta.country_name, meta.state_name, meta.state_abb, meta.province_name, meta.offshore_block_name
        , meta.county_name, meta.latitude, meta.longitude, meta.connecting_pipeline, meta.connecting_entity, meta.storage_name, meta.storage_calc_flag
        , meta.units, noms.cycle_id, noms.cycle_desc, noms.hourly_cycle_id, noms.eff_gas_day, noms.end_eff_gas_day, noms.design_capacity
        , noms.operating_capacity, noms.scheduled_quantity, noms.scheduled_quantity * meta.rec_del_sign as scheduled_quantity_sign_adj
        , noms.operationally_available, reg.region_name as regions_criterion, reg.eia_ng_regions
    from pipelines.nomination_points noms
    inner join pipelines.metadata meta on meta.metadata_id = noms.metadata_id
    left join pipelines.regions reg on reg.state_name = meta.state_name
    where  (noms.eff_gas_day <= current_date and noms.eff_gas_day >= '1/1/2019')
    and meta.ticker in ({formatted_tickers})
    order by meta.tsp_short, noms.eff_gas_day, meta.ticker;
    """

    cnxn = None
    try:
        logging.info(f"Attempting to connect to the database for '{facility_name}', file: {output_csv_name}...")
        logging.info(f"Fetching ALL pipeline data for tickers (no state filtering)")

        cnxn = psycopg2.connect(**DB_CONFIG)
        logging.info("Database connection successful.")

        logging.info(f"Executing SQL query for {facility_name} with tickers: {tickers_to_fetch}...")

        df = pd.read_sql(SQL_QUERY, cnxn)
        logging.info(f"Successfully loaded {len(df)} rows for {facility_name}.")

        if len(df) == 0:
            logging.warning(f"No data fetched for '{facility_name}'. Skipping CSV creation.")
            return

        # Create the pipeline data directory
        folder_name = "southcentral"
        os.makedirs(folder_name, exist_ok=True)
        logging.info(f"Ensured directory '{folder_name}' exists.")

        # Construct the full output path
        full_output_path = os.path.join(folder_name, output_csv_name)

        df.to_csv(full_output_path, index=False)
        logging.info(f"Data successfully saved to {full_output_path}")

    except psycopg2.Error as e:
        logging.error(f"Database error while processing {facility_name}: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred while processing {facility_name}: {e}")
    finally:
        if cnxn:
            cnxn.close()
            logging.info(f"Database connection closed for {facility_name}.")

if __name__ == "__main__":
    # Storage Facilities Configuration (NO STATE RESTRICTIONS)
    storage_configs = [
        {
            "facility_name": "Arcadia",
            "tickers": [
                "PLNM.002.1176773.7", "PLNM.002.1176773.8", "PLNM.002.1302114.7", "PLNM.002.1302114.8",
                "PLNM.002.13323.7", "PLNM.002.13323.8", "PLNM.002.14701.7", "PLNM.002.221970.7",
                "PLNM.002.221970.8", "PLNM.002.4403044.8", "PLNM.002.45876.8", "PLNM.002.4649567.8",
                "PLNM.002.7444812.7", "PLNM.002.7444812.8", "PLNM.002.822090.7", "PLNM.002.822090.8",
                "PLNM.002.85943.7", "PLNM.002.85943.8", "PLNM.002.910011.7", "PLNM.002.AGS2.7", "PLNM.002.PELICO.7"
            ],
            "output_filename": "Arcadia.csv"
        },
        {
            "facility_name": "Bay Gas",
            "tickers": [
                "PLNM.005.BG1002.7", "PLNM.005.BG1002.8", "PLNM.005.BG1003.7", "PLNM.005.BG1003.8",
                "PLNM.005.BG1008.7", "PLNM.005.BG1008.8", "PLNM.005.BG1013.7"
            ],
            "output_filename": "Bay_Gas.csv"
        },
        {
            "facility_name": "Bistineau",
            "tickers": [
                "PLNM.112.10401.7", "PLNM.112.10402.8", "PLNM.112.22806.7", "PLNM.112.22807.8",
                "PLNM.112.23377.7", "PLNM.112.23377.8", "PLNM.112.3597.7"
            ],
            "output_filename": "Bistineau.csv"
        },
        {
            "facility_name": "Boardwalk",
            "tickers": [
                "PLNM.110.23141.8", "PLNM.110.23142.7", "PLNM.110.23382.7", "PLNM.110.23382.8",
                "PLNM.110.23383.7", "PLNM.110.23383.8", "PLNM.110.23384.7", "PLNM.110.23384.8",
                "PLNM.110.23385.7", "PLNM.110.23385.8", "PLNM.110.23386.7", "PLNM.110.23386.8",
                "PLNM.110.23387.7", "PLNM.110.23387.8"
            ],
            "output_filename": "Boardwalk.csv"
        },
        {
            "facility_name": "Bobcat",
            "tickers": [
                "PLNM.063.45401.7", "PLNM.063.45401.8", "PLNM.063.45403.7", "PLNM.063.45403.8",
                "PLNM.063.45405.7", "PLNM.063.45405.8", "PLNM.063.45407.7", "PLNM.063.45407.8",
                "PLNM.063.45409.7", "PLNM.063.45409.8"
            ],
            "output_filename": "Bobcat.csv"
        },
        {
            "facility_name": "Cadeville Gas Storage",
            "tickers": [
                "PLNM.334.1302113.7", "PLNM.334.1302113.8", "PLNM.334.1378985.7", "PLNM.334.1378985.8",
                "PLNM.334.79039.7", "PLNM.334.79039.8", "PLNM.334.810066.7", "PLNM.334.810066.8",
                "PLNM.334.AGS1.7", "PLNM.334.AGS1.8", "PLNM.334.AGS2.7", "PLNM.334.AGS2.8",
                "PLNM.334.AGS3.7", "PLNM.334.AGS3.8", "PLNM.334.AGS4.7", "PLNM.334.AGS5.7",
                "PLNM.334.AGS5.8", "PLNM.334.AGSEGTL.7", "PLNM.334.AGSEGTL.8", "PLNM.334.PGS1.7"
            ],
            "output_filename": "Cadeville_Gas_Storage.csv"
        },
        {
            "facility_name": "Caledonia",
            "tickers": [
                "PLNM.008.542519.7", "PLNM.008.542519.8", "PLNM.008.542524.7", "PLNM.008.542524.8"
            ],
            "output_filename": "Caledonia.csv"
        },
        {
            "facility_name": "Clear Lake",
            "tickers": ["PLNM.073.75300.1", "PLNM.073.75300.2"],
            "output_filename": "Clear_Lake.csv"
        },
        {
            "facility_name": "Egan",
            "tickers": [
                "PLNM.066.40111.8", "PLNM.066.45101.7", "PLNM.066.45101.8", "PLNM.066.45103.7",
                "PLNM.066.45103.8", "PLNM.066.45105.7", "PLNM.066.45105.8", "PLNM.066.45107.7",
                "PLNM.066.45107.8", "PLNM.066.45109.7", "PLNM.066.45109.8", "PLNM.066.45113.7",
                "PLNM.066.45113.8", "PLNM.066.45115.7", "PLNM.066.45115.8", "PLNM.066.45117.8",
                "PLNM.066.45122.7", "PLNM.066.45122.8"
            ],
            "output_filename": "Egan.csv"
        },
        {
            "facility_name": "Eminence",
            "tickers": ["PLNM.109.1002689.7", "PLNM.109.1002689.8"],
            "output_filename": "Eminence.csv"
        },
        {
            "facility_name": "Freebird",
            "tickers": ["PLNM.146.12709.8", "PLNM.146.21039.7"],
            "output_filename": "Freebird.csv"
        },
        {
            "facility_name": "Golden Triangle",
            "tickers": [
                "PLNM.013.1091389.7", "PLNM.013.1091389.8", "PLNM.013.1091391.7", "PLNM.013.1091391.8",
                "PLNM.013.1091395.7", "PLNM.013.1091395.8", "PLNM.013.1091397.7", "PLNM.013.1091424.7",
                "PLNM.013.1091424.8", "PLNM.013.1091446.7", "PLNM.013.6000.7", "PLNM.013.6000.8",
                "PLNM.013.6002.7", "PLNM.013.6002.8", "PLNM.013.6006.7", "PLNM.013.6006.8",
                "PLNM.013.6010.7", "PLNM.013.6010.8", "PLNM.013.6012.7", "PLNM.013.6012.8",
                "PLNM.013.6014.7", "PLNM.013.6014.8", "PLNM.013.6017.7", "PLNM.013.6017.8"
            ],
            "output_filename": "Golden_Triangle.csv"
        },
        {
            "facility_name": "Jefferson Island",
            "tickers": [
                "PLNM.100.4119.7", "PLNM.100.4119.8", "PLNM.112.23356.7", "PLNM.112.23356.8",
                "PLNM.049.25731.7", "PLNM.049.25731.8", "PLNM.031.287799.7", "PLNM.031.287799.8",
                "PLNM.094.94035.7", "PLNM.054.412398.7", "PLNM.054.412398.8", "PLNM.114.9412.7",
                "PLNM.114.9412.8", "PLNM.097.80717.7", "PLNM.097.80717.8"
            ],
            "output_filename": "Jefferson_Island.csv"
        },
        {
            "facility_name": "Katy",
            "tickers": [
                "PLNM.112.23358.7", "PLNM.112.23358.8", "PLNM.049.908197.7", "PLNM.049.908197.8",
                "PLNM.054.412271.7", "PLNM.054.412271.8", "PLNM.109.1004190.7", "PLNM.109.1004190.8",
                "PLNM.097.82815.8", "PLNM.097.82816.7"
            ],
            "output_filename": "Katy.csv"
        },
        {
            "facility_name": "Keystone",
            "tickers": [
                "PLNM.042.301595.7", "PLNM.042.301595.8", "PLNM.134.78353.7", "PLNM.134.78353.8",
                "PLNM.096.78386.7", "PLNM.096.78386.8"
            ],
            "output_filename": "Keystone.csv"
        },
        {
            "facility_name": "LA Storage",
            "tickers": [
                "PLNM.019.624000.7", "PLNM.019.624000.8", "PLNM.019.624716.7", "PLNM.019.624716.8",
                "PLNM.019.624719.7", "PLNM.019.624719.8", "PLNM.019.624723.7", "PLNM.019.624723.8",
                "PLNM.019.624724.7", "PLNM.019.624724.8", "PLNM.019.624727.7", "PLNM.019.624727.8",
                "PLNM.019.624800.8", "PLNM.019.624801.7", "PLNM.019.CAMERON.7", "PLNM.019.CAMERON.8"
            ],
            "output_filename": "LA_Storage.csv"
        },
        {
            "facility_name": "Leaf River",
            "tickers": [
                "PLNM.018.1939164.7", "PLNM.018.1939164.8", "PLNM.018.6900518.7", "PLNM.018.6900518.8",
                "PLNM.018.7844424.7", "PLNM.018.7844424.8", "PLNM.018.7933021.7", "PLNM.018.7933021.8",
                "PLNM.018.8081508.7", "PLNM.018.8081508.8", "PLNM.018.8094236.7", "PLNM.018.8094236.8",
                "PLNM.018.VENTURE.7"
            ],
            "output_filename": "Leaf_River.csv"
        },
        {
            "facility_name": "Mississippi Hub",
            "tickers": [
                "PLNM.021.1112164.7", "PLNM.021.1112164.8", "PLNM.021.1112165.7", "PLNM.021.1112165.8",
                "PLNM.021.1113564.7", "PLNM.021.1113564.8"
            ],
            "output_filename": "Mississippi_Hub.csv"
        },
        {
            "facility_name": "Monroe",
            "tickers": [
                "PLNM.023.421061.7", "PLNM.023.421061.8", "PLNM.023.75578.7", "PLNM.023.75578.8",
                "PLNM.023.MGSATMO.8"
            ],
            "output_filename": "Monroe.csv"
        },
        {
            "facility_name": "Moss Bluff",
            "tickers": [
                "PLNM.049.3817.7", "PLNM.049.3817.8", "PLNM.073.75773.7", "PLNM.073.75773.8"
            ],
            "output_filename": "Moss_Bluff.csv"
        },
        {
            "facility_name": "Napoleonville",
            "tickers": ["PLNM.112.23357.7", "PLNM.112.23357.8"],
            "output_filename": "Napoleonville.csv"
        },
        {
            "facility_name": "Perryville",
            "tickers": [
                "PLNM.331.1250929.8", "PLNM.331.4235.7", "PLNM.331.4235.8", "PLNM.331.8100676.7",
                "PLNM.331.8100676.8", "PLNM.331.822033.7", "PLNM.331.822033.8", "PLNM.331.8220333.7",
                "PLNM.331.8220333.8"
            ],
            "output_filename": "Perryville.csv"
        },
        {
            "facility_name": "Petal",
            "tickers": ["PLNM.112.50202.7", "PLNM.112.50202.8"],
            "output_filename": "Petal.csv"
        },
        {
            "facility_name": "Pine Prairie",
            "tickers": [
                "PLNM.026.33333.7", "PLNM.026.33333.8", "PLNM.026.4205.7", "PLNM.026.4205.8",
                "PLNM.026.421043.7", "PLNM.026.421043.8", "PLNM.026.44404.7", "PLNM.026.44404.8",
                "PLNM.026.4545454.7", "PLNM.026.4545454.8", "PLNM.026.4909414.7", "PLNM.026.4909414.8",
                "PLNM.026.55555.7", "PLNM.026.55555.8", "PLNM.026.6565656.7", "PLNM.026.6565656.8",
                "PLNM.026.75524.7", "PLNM.026.75524.8", "PLNM.026.7661851.7", "PLNM.026.7661851.8",
                "PLNM.026.7661857.8", "PLNM.026.7845778.7", "PLNM.026.7845778.8", "PLNM.026.9003442.7",
                "PLNM.026.9003442.8", "PLNM.026.9115.7", "PLNM.026.9115.8"
            ],
            "output_filename": "Pine_Prairie.csv"
        },
        {
            "facility_name": "Salt Plains",
            "tickers": [
                "PLNM.154.139.7", "PLNM.154.16376.8", "PLNM.154.443155.8", "PLNM.154.443156.7"
            ],
            "output_filename": "Salt_Plains.csv"
        },
        {
            "facility_name": "Southern Natural Gas",
            "tickers": ["PLNM.053.677777.7", "PLNM.053.677777.8"],
            "output_filename": "Southern_Natural_Gas.csv"
        },
        {
            "facility_name": "Southern Pines",
            "tickers": [
                "PLNM.033.1005320.7", "PLNM.033.1005320.8", "PLNM.033.202910.7", "PLNM.033.202910.8",
                "PLNM.033.3000141.7", "PLNM.033.6246161.7", "PLNM.033.6246161.8", "PLNM.033.7409406.7",
                "PLNM.033.7846178.7", "PLNM.033.7846178.8", "PLNM.033.8300910.7", "PLNM.033.8310983.7",
                "PLNM.033.8310983.8", "PLNM.033.9003942.7", "PLNM.033.9003942.8", "PLNM.033.SOUTHPI.7",
                "PLNM.033.SOUTHPI.8"
            ],
            "output_filename": "Southern_Pines.csv"
        },
        {
            "facility_name": "SSC",
            "tickers": [
                "PLNM.154.15405.8", "PLNM.154.81.7", "PLNM.154.999020.7", "PLNM.154.999020.8",
                "PLNM.154.999021.7", "PLNM.154.999021.8", "PLNM.154.999022.7", "PLNM.154.999022.8",
                "PLNM.154.999023.7", "PLNM.154.999023.8"
            ],
            "output_filename": "SSC.csv"
        },
        {
            "facility_name": "SWGS West",
            "tickers": ["PLNM.095.SWGSW.7", "PLNM.095.SWGSW.8"],
            "output_filename": "SWGS_West.csv"
        },
        {
            "facility_name": "Tennessee",
            "tickers": ["PLNM.054.47148.7", "PLNM.054.47148.8"],
            "output_filename": "Tennessee.csv"
        },
        {
            "facility_name": "Tres Palacios",
            "tickers": [
                "PLNM.036.40331.8", "PLNM.036.40332.7", "PLNM.036.40333.7", "PLNM.036.45301.7",
                "PLNM.036.45301.8", "PLNM.036.45303.7", "PLNM.036.45303.8", "PLNM.036.45307.7",
                "PLNM.036.45307.8", "PLNM.036.45309.7", "PLNM.036.45309.8", "PLNM.036.45311.7",
                "PLNM.036.45311.8", "PLNM.036.45313.7", "PLNM.036.45313.8", "PLNM.036.45315.7",
                "PLNM.036.45315.8", "PLNM.036.45317.7", "PLNM.036.45317.8", "PLNM.036.45319.7",
                "PLNM.036.45319.8", "PLNM.036.45321.7", "PLNM.036.45321.8"
            ],
            "output_filename": "Tres_Palacios.csv"
        },
        {
            "facility_name": "Washington",
            "tickers": ["PLNM.109.1002687.7", "PLNM.109.1002687.8"],
            "output_filename": "Washington.csv"
        },
        {
            "facility_name": "Mississippi River Trans",
            "tickers": ["PLNM.138.808579.7", "PLNM.138.808580.8"],
            "output_filename": "Mississippi_River_Trans.csv"
        },
        {
            "facility_name": "Enable",
            "tickers": ["PLNM.137.808581.8", "PLNM.137.808582.7"],
            "output_filename": "Enable.csv"
        },
        {
            "facility_name": "Northern Natural Gas",
            "tickers": [
                "PLNM.134.466.7", "PLNM.134.466.8", "PLNM.134.594.7", "PLNM.134.594.8"
            ],
            "output_filename": "Northern_Natural_Gas.csv"
        }
    ]

    logging.info("--- Starting Pipeline Data Processing (No State Filtering) ---")
    
    for config in storage_configs:
        facility_name = config.get('facility_name', 'Unknown')
        output_name = config.get('output_filename', 'default.csv')
        tickers = config.get('tickers', [])

        logging.info(f"\nProcessing {facility_name}...")
        logging.info(f"Tickers: {len(tickers)} tickers")
        logging.info(f"Output file: {output_name}")
        
        fetch_and_save_pipeline_data_to_csv(
            tickers,
            output_name,
            facility_name
        )
        
        logging.info(f"Finished processing {facility_name}.\n")

    logging.info("--- Pipeline Data Processing Completed ---")