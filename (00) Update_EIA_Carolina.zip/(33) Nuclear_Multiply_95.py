# -*- coding: utf-8 -*-
import pandas as pd
import os
import glob
import traceback
import numpy as np
import sys

# Check for Parquet engine dependency
try:
    import pyarrow
    print("PyArrow engine found.")
except ImportError:
    print("Warning: PyArrow not found. Parquet operations might be slower or fail.")

# --- Configuration ---

# Base directory where regional folders are located
base_stack_directory = r'D:\EIA_STACK'

# Subdirectory structure within each region to find the target predict.parquet
target_subdirectory = 'final'
target_filename = 'predict.parquet'

# --- Column Name Configuration ---

# Name of the date/time column in the TARGET (predict.parquet) files
target_date_col_parquet = 'date'  # Date column name used in predict.parquet

# Pattern for the nuclear ratio column to adjust
nuclear_ratio_column_pattern = "{REGION_UPPER}_NUCLEAR_RATIO"

# Adjustment factor for the nuclear ratio
adjustment_factor = 1.0

# --- Script Logic ---
print("--- Starting Nuclear Ratio Adjustment Script ---")
print(f"Target Predict Parquet Location: {base_stack_directory}\\[region]\\{target_subdirectory}\\{target_filename}")
print(f"Target Parquet Date Column: '{target_date_col_parquet}'")
print(f"Column to Adjust (Pattern): '{nuclear_ratio_column_pattern}'")
print(f"Adjustment Factor: {adjustment_factor}")

# Find all regions by scanning for predict.parquet files in the directory structure
target_files_pattern = os.path.join(base_stack_directory, '', target_subdirectory, target_filename)
target_files = glob.glob(target_files_pattern)

if not target_files:
    print(f"No '{target_filename}' files found in '{base_stack_directory}\\*\\{target_subdirectory}'. Nothing to process.")
    exit()

print(f"\nFound {len(target_files)} target predict.parquet files to process.")
process_success_count = 0
process_skip_count = 0
process_error_count = 0

# --- Process each target file ---
for target_file_path in target_files:
    try:
        # Extract region name from the directory structure
        # Path format: D:\EIA_STACK\[region]\final\predict.parquet
        region_base_name_lower = os.path.basename(os.path.dirname(os.path.dirname(target_file_path)))
        region_base_name_upper = region_base_name_lower.upper()

        print(f"\n--- Processing Region: {region_base_name_lower} ---")
        print(f"  Target Parquet: {target_file_path}")

        # Define the specific nuclear ratio column for this region
        nuclear_ratio_col = nuclear_ratio_column_pattern.format(REGION_UPPER=region_base_name_upper)
        print(f"  Column to adjust: {nuclear_ratio_col}")

        # 1. Read Target Predict Parquet
        print(f"  Reading target predict.parquet: {target_file_path}")
        try:
            engine_to_use = 'pyarrow' if 'pyarrow' in sys.modules else 'auto'
            df_target = pd.read_parquet(target_file_path, engine=engine_to_use)

            # Ensure the date column is datetime
            if target_date_col_parquet not in df_target.columns:
                print(f"  Error: Target parquet '{target_file_path}' does not contain the expected date column '{target_date_col_parquet}'. Skipping.")
                process_error_count += 1
                continue
            df_target[target_date_col_parquet] = pd.to_datetime(df_target[target_date_col_parquet])

            # Remove timezone if present
            if df_target[target_date_col_parquet].dt.tz is not None:
                df_target[target_date_col_parquet] = df_target[target_date_col_parquet].dt.tz_localize(None)
                print(f"  Removed timezone from target Parquet '{target_date_col_parquet}'.")

            if df_target.empty:
                print(f"  Warning: Target parquet {target_file_path} is empty. Skipping.")
                process_skip_count += 1
                continue

            print(f"  Read {len(df_target)} rows from target Parquet.")
            print(f"  Target Parquet Date Range: {df_target[target_date_col_parquet].min()} to {df_target[target_date_col_parquet].max()}")

        except Exception as e:
            print(f"  Error reading target parquet {target_file_path}: {e}")
            traceback.print_exc()
            process_error_count += 1
            continue

        # 2. Check for Nuclear Ratio Column
        if nuclear_ratio_col not in df_target.columns:
            print(f"  Warning: Nuclear ratio column '{nuclear_ratio_col}' not found in {target_file_path}. Skipping adjustment.")
            process_skip_count += 1
            continue

        # 3. Apply Adjustment to Nuclear Ratio Column
        print(f"  Adjusting '{nuclear_ratio_col}' by multiplying by {adjustment_factor}")
        try:
            df_target[nuclear_ratio_col] = df_target[nuclear_ratio_col] * adjustment_factor
            print(f"  Successfully adjusted '{nuclear_ratio_col}'.")
        except Exception as e:
            print(f"  Error adjusting column '{nuclear_ratio_col}' in {target_file_path}: {e}")
            traceback.print_exc()
            process_error_count += 1
            continue

        # 4. Save Updated Parquet
        print(f"  Saving updated target parquet: {target_file_path}")
        try:
            engine_to_use = 'pyarrow' if 'pyarrow' in sys.modules else 'auto'
            df_target.to_parquet(target_file_path, index=False, engine=engine_to_use)
            print(f"  Successfully updated/saved '{target_filename}' for region '{region_base_name_lower}'.")
            process_success_count += 1
        except Exception as e:
            print(f"  Error writing target parquet '{target_file_path}': {e}")
            traceback.print_exc()
            process_error_count += 1

    except Exception as outer_e:
        print(f"\nError processing file {target_file_path}: {outer_e}")
        traceback.print_exc()
        process_error_count += 1

# --- Final Summary ---
print("\n--- Nuclear Ratio Adjustment Summary ---")
print(f"Successfully processed regions: {process_success_count}")
print(f"Skipped regions (missing column, empty file): {process_skip_count}")
print(f"Regions with errors: {process_error_count}")

print("\nScript finished.")