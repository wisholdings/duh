import pandas as pd
import os
import glob
import re

def simplify_column_name(column_name):
    """
    Simplifies a complex EIA column name to its state code.
    Example: 'GEN.NRC_NUKE.ByState.FC@CT~MW_Offline' -> 'CT'
    """
    if column_name.lower() == 'date':
        return 'date'
    
    # Use regex to find the state code after '@'
    match = re.search(r'@([A-Z]{2})~', column_name)
    if match:
        return match.group(1)
    
    # Handle the 'ALL' case specifically
    if '@ALL~' in column_name:
        return 'ALL'
        
    # Return the original name if no pattern is matched, with a warning
    print(f"Warning: Could not simplify column name: {column_name}")
    return column_name

def merge_and_clean_data_queries(base_dir):
    """
    Finds, merges, and cleans DataQuery CSV files in a given directory.
    """
    print(f"--- Starting Data Merge and Clean-up ---")
    print(f"Searching for DataQuery*.csv files in: {base_dir}")

    # 1. Find all the DataQuery CSV files
    # Using a pattern that matches "DataQuery.csv", "DataQuery (1).csv", etc.
    # IMPORTANT: Exclude the script's own output file to prevent recursive reading.
    file_pattern = os.path.join(base_dir, 'DataQuery*.csv') 
    files_to_merge = glob.glob(file_pattern)
    output_file_to_exclude = os.path.join(base_dir, 'DataQuery_Merged.csv')
    files_to_merge = [f for f in files_to_merge if os.path.normpath(f) != os.path.normpath(output_file_to_exclude)]

    if not files_to_merge:
        print("Error: No 'DataQuery*.csv' files found. Please check the directory.")
        return

    print(f"Found {len(files_to_merge)} files to merge:")
    for f in files_to_merge:
        print(f"  - {os.path.basename(f)}")

    # 2. Read all files into a list of DataFrames
    df_list = []
    for file_path in files_to_merge:
        # Specify a common date format to avoid UserWarning and improve parsing speed.
        # This format handles dates like '9/7/2025 12:00:00 AM'
        try:
            df = pd.read_csv(file_path, parse_dates=['date'], date_format='%m/%d/%Y %I:%M:%S %p')
            df_list.append(df)
        except Exception as e:
            print(f"Error reading {file_path}: {e}")

    if not df_list:
        print("Error: No data could be read from the files. Exiting.")
        return

    # 3. Merge all DataFrames on the 'date' column
    print("\nMerging dataframes on 'date' column...")
    # Start with the first dataframe
    merged_df = df_list[0]
    # Iteratively merge the rest using an outer join to keep all data
    for df_to_merge in df_list[1:]:
        merged_df = pd.merge(merged_df, df_to_merge, on='date', how='outer')

    # Drop any fully duplicate rows that might have been created
    merged_df.drop_duplicates(inplace=True)

    print(f"Merge complete. Shape of merged data: {merged_df.shape}")

    # 4. Simplify all column names
    merged_df.columns = [simplify_column_name(col) for col in merged_df.columns]
    print(f"\nSimplified column names: {merged_df.columns.tolist()}")

    # 5. Handle duplicate STATE columns that might result from the merge
    # Set 'date' as index to preserve it, then group by column names and sum.
    if 'date' in merged_df.columns:
        merged_df = merged_df.set_index('date')

    merged_df = merged_df.groupby(level=0, axis=1).sum()
    merged_df = merged_df.reset_index()
    print(f"\nConsolidated duplicate columns. Final columns: {merged_df.columns.tolist()}")

    # 6. Sum states into regional columns based on the provided criteria
    print("Aggregating states into regional sums...")
    regions_map = {
        "texas": ["TX"], "florida": ["FL"], "carolina": ["NC", "SC"], "california": ["CA"],
        "newengland": ["ME", "CT", "MA", "NH", "RI", "VT"],
        "newyork": ["NY"],
        "midatlantic": ["MD", "DE", "PA", "VA", "WV"],
        "midwest": ["IL", "IN", "MO", "MI", "MN", "WI", "IA", "OH", "KS", "KY"],
        "southeast": ["AL", "AR", "GA", "MS", "LA"],
        "southwest": ["AZ", "NM", "NV", "UT", "CO"],
        "northwest": ["ID", "OR", "WA", "WY", "MT"],
        "central": ["NE", "NJ", "ND", "SD", "OK"], "tennessee": ["TN"]
    }

    for region_name, states in regions_map.items():
        # Find which of the region's states are actually present in our data
        states_in_df = [state for state in states if state in merged_df.columns]
        if states_in_df:
            print(f"  - Creating '{region_name.upper()}' column from: {states_in_df}")
            merged_df[region_name.upper()] = merged_df[states_in_df].sum(axis=1)

    # 7. Keep only the date and the new regional columns for the final output
    print("\nDropping individual state columns to keep the final output clean...")
    # Also include 'ALL' if it exists, in case it's needed for other analysis, but drop it for this request.
    # The 'date' column is essential.
    columns_to_keep = ['date'] + [region.upper() for region in regions_map.keys()]
    
    # Filter the DataFrame to only include columns that actually exist in it
    final_columns = [col for col in columns_to_keep if col in merged_df.columns]
    final_df = merged_df[final_columns]
    print(f"Final columns in output file: {final_df.columns.tolist()}")

    # Drop any duplicate date rows that may have been created during merges before reindexing
    if 'date' in final_df.columns:
        final_df.drop_duplicates(subset=['date'], keep='first', inplace=True)
        print(f"\nDropped duplicate dates. Shape before reindexing: {final_df.shape}")

    # 8. Ensure date continuity by filling in missing dates
    print("\nEnsuring continuous daily dates and forward-filling data...")
    if not final_df.empty and 'date' in final_df.columns:
        # Set date as index to perform time-series operations
        final_df = final_df.set_index('date')
        
        # Create a full daily date range from the first to the last date
        full_date_range = pd.date_range(start=final_df.index.min(), end=final_df.index.max(), freq='D')
        
        # Reindex the dataframe to the full date range, this will create NaNs for missing dates
        final_df = final_df.reindex(full_date_range)
        
        # Forward-fill the missing values and reset the index to bring 'date' back as a column
        final_df = final_df.ffill().reset_index().rename(columns={'index': 'date'})
        print(f"Date continuity applied. New shape: {final_df.shape}")

    # 9. Save the final DataFrame
    output_path = os.path.join(base_dir, 'DataQuery_Merged.csv')
    print(f"\nSaving final merged and cleaned data to: {output_path}")
    final_df.to_csv(output_path, index=False, date_format='%Y-%m-%d %H:%M:%S')
    print("--- Process complete. ---")

if __name__ == '__main__':
    # Set the directory where your CSV files are located
    eia_directory = r'C:\EIA'
    merge_and_clean_data_queries(eia_directory)
