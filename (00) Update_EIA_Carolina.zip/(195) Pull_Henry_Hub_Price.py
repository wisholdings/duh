"""
Henry Hub Data Puller - Price Data Only
"""

import pandas as pd
import sqlalchemy
import pyodbc
from datetime import datetime, timedelta
import numpy as np
import os

# Database configuration
DB_SERVER = ""
DB_NAME = ""
DB_USER = ""
DB_PASSWORD = ""

class HenryHubDataPuller:
    """Pull Henry Hub price data only"""
    
    def __init__(self):
        self.sql_connection = None
        self.setup_database_connection()
        
        # Define the Henry Hub symbol
        self.henry_hub_symbol = '#DG.GAS.HH.NYMEX.U.FWD.MONTHLY.TRADER.CURVE'
        
        # Set output directory
        self.output_dir = r'D:\EIA_STACK\Pricing_RL'
        self.daily_curves_output_dir = os.path.join(self.output_dir, 'daily_curves')
        self.ensure_output_directory()
    
    def ensure_output_directory(self):
        """Create output directories if they don't exist"""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            print(f"✓ Created output directory: {self.output_dir}")
        else:
            print(f"✓ Output directory exists: {self.output_dir}")

        if not os.path.exists(self.daily_curves_output_dir):
            os.makedirs(self.daily_curves_output_dir)
            print(f"✓ Created daily curves directory: {self.daily_curves_output_dir}")
        else:
            print(f"✓ Daily curves directory exists: {self.daily_curves_output_dir}")
    
    def setup_database_connection(self):
        """Setup SQL Server database connection"""
        print("Setting up database connection...")
        
        try:
            drivers = [x for x in pyodbc.drivers() if 'SQL Server' in x]
            driver = drivers[0]
            
            sql_connection_string = (
                "Driver={" + str([i for i in drivers if "SQL Server" in i][0]) + "};"
                "Server=\{DB_SERVER},1433;"
                "Database=\{DB_NAME};"
                "Uid=\{DB_USER};"
                f"Pwd={{DB_PASSWORD}};"
                "TrustServerCertificate=yes;"
                "Connection Timeout=60;"
            )
            
            connection_url = sqlalchemy.engine.URL.create(
                "mssql+pyodbc", 
                query={"odbc_connect": sql_connection_string}
            )
            self.sql_connection = sqlalchemy.create_engine(connection_url)
            
            print("✓ Database connection established")
            
        except Exception as e:
            print(f"❌ Database connection failed: {str(e)}")
            raise
    
    def get_henry_hub_prices(self):
        """Get Henry Hub price data only"""
        print(f"\n🔥 PULLING HENRY HUB PRICE DATA...")
        
        try:
            # Get only close prices for Henry Hub
            query = f"""
            SELECT 
                publisheddate,
                contractdate,
                value as [close],
                unit,
                description
            FROM [dbo].[tbl_marketview_futures_daily]
            WHERE datacode = '{self.henry_hub_symbol}'
            AND variable = 'close'
            AND value IS NOT NULL
            ORDER BY publisheddate DESC, contractdate
            """
            
            data = pd.read_sql(query, self.sql_connection)
            
            if len(data) > 0:
                print(f"✓ Henry Hub price records: {len(data):,}")
                
                data['symbol'] = 'HENRY_HUB'
                data['data_type'] = 'forward_curve'
                
                # Convert dates
                data['publisheddate'] = pd.to_datetime(data['publisheddate'])
                data['contractdate'] = pd.to_datetime(data['contractdate'])
                
                # Show statistics
                print(f"  - Date range: {data['publisheddate'].min().date()} to {data['publisheddate'].max().date()}")
                print(f"  - Contract range: {data['contractdate'].min().date()} to {data['contractdate'].max().date()}")
                
                prices = data['close'].dropna()
                if len(prices) > 0:
                    print(f"  - Price range: ${prices.min():.3f} to ${prices.max():.3f}")
                
                return data
            else:
                print("❌ No Henry Hub data found")
                return None
                
        except Exception as e:
            print(f"❌ Failed to get Henry Hub data: {str(e)}")
            return None

def export_daily_curves(data, output_dir):
    """
    Groups data by 'publisheddate' and saves each group to a separate CSV file.
    """
    if data is None or data.empty:
        print("No data provided to export.")
        return

    print("\n📁 Exporting daily curves to individual CSV files...")
    grouped_by_day = data.groupby('publisheddate')
    
    for day, curve_data in grouped_by_day:
        # Format the date to be used as a filename
        file_date = day.strftime('%Y-%m-%d')
        filename = f"{file_date}.csv"
        filepath = os.path.join(output_dir, filename)
        
        # Save the daily curve to a CSV
        curve_data.to_csv(filepath, index=False)
        print(f"   ✓ Saved {filename}")

def main():
    """Main execution"""
    print("=" * 50)
    print("HENRY HUB DATA PULLER")
    print("=" * 50)
    
    try:
        puller = HenryHubDataPuller()
        
        # Get Henry Hub data
        hh_data = puller.get_henry_hub_prices()
        
        if hh_data is not None and len(hh_data) > 0:
            # Export all data to a single file (optional)
            all_data_filename = "HENRY_HUB_all_data.csv"
            all_data_filepath = os.path.join(puller.output_dir, all_data_filename)
            hh_data.to_csv(all_data_filepath, index=False)
            
            print(f"\n📁 All data saved to: {all_data_filepath}")
            
            # Export each day's curve to its own file
            export_daily_curves(hh_data, puller.daily_curves_output_dir)
            
            print("\n🎉 HENRY HUB DATA EXTRACTION COMPLETED!")
        else:
            print("❌ No data to export")
        
    except Exception as e:
        print(f"❌ Script failed: {str(e)}")

if __name__ == "__main__":
    main()