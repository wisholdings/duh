import os
import sys
import pandas as pd
import numpy as np
import traceback
import gc
from pathlib import Path
from typing import Dict, Optional, List, Any
import json

# --- Path Setup ---
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(script_dir, '..'))
except NameError:
    script_dir = os.getcwd()
    project_root = os.path.abspath(os.path.join(script_dir, '..'))

if project_root not in sys.path:
    sys.path.append(project_root)

print(f"Script directory: {script_dir}")
print(f"Project root: {project_root}")

# --- Configuration Loading ---
BASE_OUTPUT_DIR = None
regions = {}

try:
    from config.settings import BASE_OUTPUT_DIR
    print("Successfully imported BASE_OUTPUT_DIR from config.settings.")

    config_dir = os.path.join(project_root, 'config')
    regions_config_path = os.path.join(config_dir, 'regions.json')

    # Always use standard region names for column naming - ignore config file content
    regions = {
        'california': 'CALIFORNIA',
        'carolina': 'CAROLINA', 
        'central': 'CENTRAL',
        'florida': 'FLORIDA',
        'midatlantic': 'MIDATLANTIC',
        'midwest': 'MIDWEST',
        'newengland': 'NEWENGLAND',
        'newyork': 'NEWYORK',
        'northwest': 'NORTHWEST',
        'southeast': 'SOUTHEAST',
        'southwest': 'SOUTHWEST',
        'tennessee': 'TENNESSEE',
        'texas': 'TEXAS'
    }
    print("Using standard region configuration for column naming")

except ImportError as e:
    print(f"Error: Could not import BASE_OUTPUT_DIR from config.settings: {e}")
    # You can set a fallback path here if needed
    BASE_OUTPUT_DIR = input("Please enter the BASE_OUTPUT_DIR path: ").strip()
    if not BASE_OUTPUT_DIR:
        print("No BASE_OUTPUT_DIR provided. Exiting.")
        sys.exit(1)

if not BASE_OUTPUT_DIR or BASE_OUTPUT_DIR == ".":
    print("Error: BASE_OUTPUT_DIR is not properly configured. Cannot proceed.")
    sys.exit(1)

print(f"Using Base Output Directory: {BASE_OUTPUT_DIR}")

def find_finished_parquet_files(base_dir: str) -> List[tuple]:
    """
    Find all {region}_complete_finished.parquet files.
    
    Returns:
        List of tuples: (region_name, region_upper, file_path)
    """
    finished_files = []
    
    for region_lower, region_upper in regions.items():
        # Look for the finished parquet file
        file_path = os.path.join(base_dir, region_lower, "final", f"{region_lower}_complete_finished.parquet")
        
        if os.path.exists(file_path):
            finished_files.append((region_lower, region_upper, file_path))
            print(f"Found: {file_path}")
        else:
            print(f"Not found: {file_path}")
    
    return finished_files

def trim_oth_columns_for_region(region_lower: str, region_upper: str, file_path: str) -> bool:
    """
    Trim OTH columns to match NG column extent for a specific region.
    
    Returns:
        bool: True if file was modified and saved, False otherwise
    """
    print(f"\n--- Processing {region_upper} ---")
    
    try:
        # Load the parquet file
        print(f"Loading: {file_path}")
        df = pd.read_parquet(file_path, engine='pyarrow')
        print(f"Loaded {len(df)} rows and {len(df.columns)} columns")
        
        # Define column names
        ng_col = f"{region_upper}_NG_MW"
        oth_mw_col = f"{region_upper}_OTH_MW"
        oth_ratio_col = f"{region_upper}_OTH_RATIO"
        
        # Check which columns exist
        ng_exists = ng_col in df.columns
        oth_mw_exists = oth_mw_col in df.columns
        oth_ratio_exists = oth_ratio_col in df.columns
        
        print(f"Columns found: NG={ng_exists}, OTH_MW={oth_mw_exists}, OTH_RATIO={oth_ratio_exists}")
        
        if not ng_exists:
            print(f"Warning: {ng_col} column not found. Skipping {region_upper}.")
            return False
            
        if not oth_mw_exists and not oth_ratio_exists:
            print(f"No OTH columns found for {region_upper}. Skipping.")
            return False
        
        # Find the last valid index for the NG column
        ng_last_valid_idx = df[ng_col].last_valid_index()
        if ng_last_valid_idx is None:
            print(f"Warning: No valid data found in {ng_col}. Skipping {region_upper}.")
            return False
            
        ng_last_row = df.index.get_loc(ng_last_valid_idx)
        ng_last_date = df.loc[ng_last_valid_idx, 'date'] if 'date' in df.columns else 'N/A'
        print(f"Last valid {ng_col} at row {ng_last_row}, date: {ng_last_date}")
        
        modified = False
        
        # Process OTH_MW column
        if oth_mw_exists:
            oth_mw_last_valid_idx = df[oth_mw_col].last_valid_index()
            if oth_mw_last_valid_idx is not None:
                oth_mw_last_row = df.index.get_loc(oth_mw_last_valid_idx)
                oth_mw_last_date = df.loc[oth_mw_last_valid_idx, 'date'] if 'date' in df.columns else 'N/A'
                print(f"Last valid {oth_mw_col} at row {oth_mw_last_row}, date: {oth_mw_last_date}")
                
                if oth_mw_last_row > ng_last_row:
                    # OTH extends past NG, need to trim
                    trim_start_row = ng_last_row + 1
                    trim_indices = df.index[trim_start_row:oth_mw_last_row + 1]
                    
                    # Count non-null values that will be removed
                    values_to_remove = df.loc[trim_indices, oth_mw_col].notna().sum()
                    
                    if values_to_remove > 0:
                        print(f"Trimming {values_to_remove} values from {oth_mw_col} (rows {trim_start_row} to {oth_mw_last_row})")
                        df.loc[trim_indices, oth_mw_col] = np.nan
                        modified = True
                    else:
                        print(f"{oth_mw_col} extends past {ng_col} but only contains null values")
                else:
                    print(f"{oth_mw_col} does not extend past {ng_col}")
            else:
                print(f"No valid data found in {oth_mw_col}")
        
        # Process OTH_RATIO column
        if oth_ratio_exists:
            oth_ratio_last_valid_idx = df[oth_ratio_col].last_valid_index()
            if oth_ratio_last_valid_idx is not None:
                oth_ratio_last_row = df.index.get_loc(oth_ratio_last_valid_idx)
                oth_ratio_last_date = df.loc[oth_ratio_last_valid_idx, 'date'] if 'date' in df.columns else 'N/A'
                print(f"Last valid {oth_ratio_col} at row {oth_ratio_last_row}, date: {oth_ratio_last_date}")
                
                if oth_ratio_last_row > ng_last_row:
                    # OTH_RATIO extends past NG, need to trim
                    trim_start_row = ng_last_row + 1
                    trim_indices = df.index[trim_start_row:oth_ratio_last_row + 1]
                    
                    # Count non-null values that will be removed
                    values_to_remove = df.loc[trim_indices, oth_ratio_col].notna().sum()
                    
                    if values_to_remove > 0:
                        print(f"Trimming {values_to_remove} values from {oth_ratio_col} (rows {trim_start_row} to {oth_ratio_last_row})")
                        df.loc[trim_indices, oth_ratio_col] = np.nan
                        modified = True
                    else:
                        print(f"{oth_ratio_col} extends past {ng_col} but only contains null values")
                else:
                    print(f"{oth_ratio_col} does not extend past {ng_col}")
            else:
                print(f"No valid data found in {oth_ratio_col}")
        
        # Save the file if modifications were made
        if modified:
            print(f"Saving modified file: {file_path}")
            
            # Round numeric columns before saving
            numeric_cols = df.select_dtypes(include='number').columns
            numeric_cols = numeric_cols.drop(['is_analogous_forecast'], errors='ignore')
            
            if not numeric_cols.empty:
                df.loc[:, numeric_cols] = df[numeric_cols].round(6)
            
            df.to_parquet(file_path, index=False, engine='pyarrow')
            print(f"Successfully saved {region_upper} with trimmed OTH columns")
        else:
            print(f"No modifications needed for {region_upper}")
        
        # Cleanup
        del df
        gc.collect()
        
        return modified
        
    except Exception as e:
        print(f"Error processing {region_upper}: {e}")
        traceback.print_exc()
        return False

def main():
    """Main execution function."""
    print("===== Starting OTH Column Trimming Process =====")
    print(f"Base directory: {BASE_OUTPUT_DIR}")
    
    # Find all finished parquet files
    finished_files = find_finished_parquet_files(BASE_OUTPUT_DIR)
    
    if not finished_files:
        print("No finished parquet files found. Exiting.")
        return
    
    print(f"\nFound {len(finished_files)} finished parquet files to process")
    
    # Process each file
    modified_count = 0
    processed_count = 0
    
    for region_lower, region_upper, file_path in finished_files:
        processed_count += 1
        print(f"\n[{processed_count}/{len(finished_files)}] Processing {region_upper}...")
        
        if trim_oth_columns_for_region(region_lower, region_upper, file_path):
            modified_count += 1
    
    # Summary
    print(f"\n{'='*60}")
    print(f"=== OTH Column Trimming Complete ===")
    print(f"Processed: {processed_count} files")
    print(f"Modified: {modified_count} files")
    print(f"No changes needed: {processed_count - modified_count} files")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()