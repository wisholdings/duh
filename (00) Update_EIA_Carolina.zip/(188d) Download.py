# =============================================================================
# CONUS WEATHER DATA PIPELINE FOR AGGREGATE FOLDER
# =============================================================================
import pandas as pd
import os
import requests
from io import StringIO
from datetime import datetime, timedelta
import json
import time
import urllib3

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- CONFIGURATION ---
OUTPUT_BASE_PATH = r"D:\EIA_STACK\Pricing_RL"
AGGREGATE_PATH = os.path.join(OUTPUT_BASE_PATH, "AGGREGATE")
MONTH_MAPPING_FILE = r"C:\EIA\config\month_mapping.json"

# CONUS region identifier for WSI API
CONUS_REGION = 'CONUS'  # Continental United States

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================
def ensure_directory():
    """Create AGGREGATE directory if it doesn't exist"""
    if not os.path.exists(AGGREGATE_PATH):
        os.makedirs(AGGREGATE_PATH)
        print(f"✓ Created directory: {AGGREGATE_PATH}")
    else:
        print(f"✓ Directory exists: {AGGREGATE_PATH}")

# =============================================================================
# WEATHER DATA FUNCTIONS
# =============================================================================
def get_historical_weather_conus(start_date, end_date):
    """Fetch historical weather observations for CONUS"""
    print(f"  Fetching historical data from {start_date} to {end_date}...")
    
    base_url = "https://www.wsitrader.com/Services/CSVDownloadService.svc/GetHistoricalObservations"
    params = {
        'Account': 'suncor',
        'profile': '',
        'password': '',
        'TempUnits': 'F',
        'HistoricalProductID': 'HISTORICAL_WEIGHTED_DEGREEDAYS',
        'DataTypes[]': ['population_cdd', 'gas_hdd'],
        'StartDate': start_date,
        'EndDate': end_date,
        'IsDisplayDates': 'true',
        'IsDaily': 'true',
        'CityIds[]': CONUS_REGION
    }
    
    try:
        response = requests.get(base_url, params=params, verify=False)
        if response.status_code == 200:
            data_lines = response.text.split('\n')
            header_index = next((i for i, line in enumerate(data_lines) if "Daily Observed CDD/HDD" in line), -1)
            if header_index != -1:
                modified_data = '\n'.join(data_lines[header_index + 1:])
            else:
                modified_data = response.text
            
            data_io = StringIO(modified_data)
            df = pd.read_csv(data_io, skiprows=1)
            
            df['valid_time'] = pd.to_datetime(df['valid_time'], format='%m/%d/%Y')
            df.rename(columns={'valid_time': 'Date'}, inplace=True)
            df.set_index('Date', inplace=True)
            
            if 'site_id' in df.columns:
                df = df.drop(columns=['site_id'])
            
            print(f"    ✓ Historical data fetched: {len(df)} days")
            return df
        else:
            print(f"    ✗ Error fetching historical data: {response.status_code}")
            return None
    except Exception as e:
        print(f"    ✗ Exception fetching historical data: {e}")
        return None

def get_forecast_weather_conus():
    """Fetch forecast weather data for CONUS"""
    print(f"  Fetching forecast data...")
    
    base_url = "https://www.wsitrader.com/Services/CSVDownloadService.svc/GetWeightedDegreeDayForecast"
    params = {
        'Account': 'suncor',
        'Profile': '',
        'Password': '',
        'Region': 'NA',
        'ForecastType': 'Daily',
        'DataTypes[]': ['population_cdd', 'gas_hdd'],
        'Stations[]': CONUS_REGION,
        'Model': 'WSI',
        'Period': "Daily",
        'BiasCorrected': 'true'
    }
    
    try:
        response = requests.get(base_url, params=params, verify=False)
        if response.status_code == 200:
            df = pd.read_csv(StringIO(response.text), header=1)
            
            columns_to_keep = ['period_start', 'population_cdd', 'gas_hdd']
            df = df[[col for col in columns_to_keep if col in df.columns]]
            
            df.rename(columns={'period_start': 'Date'}, inplace=True)
            df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y')
            df.set_index('Date', inplace=True)
            
            if 'site_id' in df.columns:
                df = df.drop(columns=['site_id'])
            
            print(f"    ✓ Forecast data fetched: {len(df)} days")
            return df
        else:
            print(f"    ✗ Error fetching forecast data: {response.status_code}")
            return None
    except Exception as e:
        print(f"    ✗ Exception fetching forecast data: {e}")
        return None

def fill_weather_nans_with_analogues(weather_df, month_mapping):
    """Fill NaN values using historical analogues based on month mapping"""
    df = weather_df.copy()
    
    if not pd.api.types.is_datetime64_any_dtype(df.index):
        df.index = pd.to_datetime(df.index)
    
    weather_columns = df.columns.tolist()
    mask_has_nan = df[weather_columns].isna().any(axis=1)
    dates_with_nan = df[mask_has_nan].index
    
    if len(dates_with_nan) == 0:
        print(f"  No NaN values found in weather data")
        return df
    
    print(f"  Found {len(dates_with_nan)} dates with NaN values")
    print(f"  NaN date range: {dates_with_nan.min().date()} to {dates_with_nan.max().date()}")
    
    filled_count = 0
    unmapped_months = set()
    
    for future_date in dates_with_nan:
        future_month_key = future_date.strftime('%Y-%m')
        
        if future_month_key in month_mapping:
            historical_month = month_mapping[future_month_key]
            historical_year, historical_month_num = historical_month.split('-')
            historical_year = int(historical_year)
            historical_month_num = int(historical_month_num)
            
            data_found = False
            
            # Try exact date first
            try:
                historical_date = pd.Timestamp(year=historical_year, 
                                             month=historical_month_num, 
                                             day=future_date.day)
                
                if historical_date in df.index:
                    historical_data = df.loc[historical_date, weather_columns]
                    if not historical_data.isna().all():
                        df.loc[future_date, weather_columns] = historical_data
                        filled_count += 1
                        data_found = True
            except ValueError:
                pass
            
            # If exact date not found, try to find closest day in the historical month
            if not data_found:
                month_start = pd.Timestamp(year=historical_year, month=historical_month_num, day=1)
                if historical_month_num == 12:
                    month_end = pd.Timestamp(year=historical_year, month=12, day=31)
                else:
                    month_end = pd.Timestamp(year=historical_year, month=historical_month_num + 1, day=1) - timedelta(days=1)
                
                month_mask = (df.index >= month_start) & (df.index <= month_end)
                month_data = df[month_mask]
                month_data_valid = month_data[~month_data[weather_columns].isna().any(axis=1)]
                
                if not month_data_valid.empty:
                    target_day = future_date.day
                    same_day_data = month_data_valid[month_data_valid.index.day == target_day]
                    if not same_day_data.empty:
                        historical_date = same_day_data.index[0]
                    else:
                        day_diffs = abs(month_data_valid.index.day - target_day)
                        closest_idx = day_diffs.argmin()
                        historical_date = month_data_valid.index[closest_idx]
                    
                    df.loc[future_date, weather_columns] = df.loc[historical_date, weather_columns]
                    filled_count += 1
        else:
            if future_date >= pd.Timestamp('2025-08-01'):
                unmapped_months.add(future_month_key)
    
    if unmapped_months:
        print(f"  Warning: No mapping found for months: {sorted(unmapped_months)}")
    
    print(f"  ✓ Filled {filled_count} out of {len(dates_with_nan)} NaN dates with analogues")
    
    remaining_nans = df[weather_columns].isna().any(axis=1).sum()
    if remaining_nans > 0:
        print(f"  Warning: {remaining_nans} dates still have NaN values")
    
    return df

# =============================================================================
# MAIN PROCESSING FUNCTION
# =============================================================================
def process_conus_weather():
    """Main function to process CONUS weather data"""
    print("\n📊 Processing CONUS Weather Data for AGGREGATE folder...")
    
    # Load month mapping
    print(f"\n  Loading month mapping from: {MONTH_MAPPING_FILE}")
    try:
        with open(MONTH_MAPPING_FILE, 'r') as f:
            month_mapping = json.load(f)
        print(f"  ✓ Loaded {len(month_mapping)} month mappings")
        print(f"    Mapping range: {min(month_mapping.keys())} to {max(month_mapping.keys())}")
    except Exception as e:
        print(f"  ✗ Error loading month mapping: {e}")
        return False
    
    # Step 1: Fetch historical data
    print(f"\nStep 1: Fetching historical CONUS weather data...")
    start_date = '01/01/2012'
    end_date = (datetime.now() - timedelta(days=1)).strftime('%m/%d/%Y')
    
    historical_df = get_historical_weather_conus(start_date, end_date)
    if historical_df is None:
        print(f"  ✗ Failed to fetch historical data for CONUS")
        return False
    
    # Step 2: Fetch forecast data
    print(f"\nStep 2: Fetching forecast CONUS weather data...")
    forecast_df = get_forecast_weather_conus()
    
    # Step 3: Combine data
    print(f"\nStep 3: Combining historical and forecast data...")
    if forecast_df is not None:
        combined_df = pd.concat([historical_df, forecast_df])
        combined_df = combined_df[~combined_df.index.duplicated(keep='last')]
        combined_df = combined_df.sort_index()
        print(f"  Combined: {len(combined_df)} days total")
    else:
        print(f"  No forecast data available, using historical only")
        combined_df = historical_df
        print(f"  Total: {len(combined_df)} days")
    
    print(f"  Date range: {combined_df.index.min().date()} to {combined_df.index.max().date()}")
    
    # Step 4: Extend to 2027-12-31
    print(f"\nStep 4: Extending date range to 2027-12-31...")
    target_end_date = pd.Timestamp('2027-12-31')
    if combined_df.index.max() < target_end_date:
        future_dates = pd.date_range(
            start=combined_df.index.max() + timedelta(days=1),
            end=target_end_date,
            freq='D'
        )
        future_df = pd.DataFrame(index=future_dates, columns=combined_df.columns)
        combined_df = pd.concat([combined_df, future_df])
        print(f"  ✓ Extended with {len(future_dates)} empty dates to {target_end_date.date()}")
    
    # Step 5: Fill NaNs with historical analogues
    print(f"\nStep 5: Filling NaN values with historical analogues...")
    filled_df = fill_weather_nans_with_analogues(combined_df, month_mapping)
    
    # Step 6: Save to AGGREGATE folder
    print(f"\nStep 6: Saving to AGGREGATE folder...")
    
    # Reset index to make Date a regular column
    filled_df = filled_df.reset_index()
    filled_df.rename(columns={'index': 'Date'}, inplace=True)
    
    # Save the file
    output_file = os.path.join(AGGREGATE_PATH, "weather_conus.csv")
    filled_df.to_csv(output_file, index=False)
    
    # Verify and show summary
    if os.path.exists(output_file):
        file_size = os.path.getsize(output_file) / 1024  # KB
        print(f"  ✓ Data saved to: {output_file}")
        print(f"    File size: {file_size:.1f} KB")
        print(f"    Total records: {len(filled_df)}")
        print(f"    Date range: {filled_df['Date'].min().date()} to {filled_df['Date'].max().date()}")
        
        # Check for remaining NaNs
        filled_df.set_index('Date', inplace=True)
        weather_cols = [col for col in filled_df.columns if col in ['population_cdd', 'gas_hdd']]
        if weather_cols:
            nan_count = filled_df[weather_cols].isna().any(axis=1).sum()
            if nan_count > 0:
                print(f"    Warning: {nan_count} dates still have NaN values")
            else:
                print(f"    ✓ All NaN values successfully filled")
        
        return True
    else:
        print(f"  ✗ Failed to save file")
        return False

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the CONUS weather pipeline"""
    print("\n" + "=" * 80)
    print("CONUS WEATHER DATA PIPELINE")
    print("Downloading CONUS Weather Data to AGGREGATE Folder")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    
    # Create directory
    ensure_directory()
    
    # Process CONUS weather data
    success = process_conus_weather()
    
    # Final summary
    print("\n" + "=" * 80)
    if success:
        print("✅ CONUS WEATHER PIPELINE COMPLETE!")
    else:
        print("✗ CONUS WEATHER PIPELINE FAILED!")
    print("=" * 80)
    
    if success:
        print("\nSummary:")
        print(f"  Output folder: {AGGREGATE_PATH}")
        print(f"  File created: weather_conus.csv")
        print(f"  Features: population_cdd, gas_hdd")
        print(f"  Coverage: 2019-01-01 to 2027-12-31")
        print(f"  NaN filling: Historical analogues using month mapping")
    
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()