import pandas as pd
import os
import traceback

def organize_forecast_burns_by_region():
    """
    Reads forecast burn files (residential, commercial, industrial), disaggregates
    them by region, saves them into regional subfolders, and deletes the original
    source files upon successful completion.
    """
    # --- Configuration ---
    source_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    output_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    
    print("Starting forecast burns data organization process.")
    print(f"Source folder: '{os.path.abspath(source_folder)}'")
    print(f"Output folder: '{os.path.abspath(output_folder)}'")

    os.makedirs(output_folder, exist_ok=True)

    files_to_process = [
        'forecast_residential_burns.csv',
        'forecast_commercial_burns.csv',
        'forecast_industrial_burns.csv'
    ]

    # --- Processing Loop ---
    for filename in files_to_process:
        file_path = os.path.join(source_folder, filename)
        
        if not os.path.exists(file_path):
            print(f"\n[Info] File not found, skipping: {filename}")
            continue
            
        print(f"\n--- Processing file: {filename} ---")
        
        try:
            # Extract sector (e.g., 'residential') from the filename
            sector = filename.split('_')[1]
            
            df = pd.read_csv(file_path, parse_dates=['datetime'])
            
            # Iterate through each data column
            for column_name in df.columns:
                # Skip metadata and total columns
                if column_name in ['datetime', 'date_published', 'forecast_model'] or 'total_l48' in column_name:
                    continue
                
                # --- Extract Region from column name ---
                # Example: "california_bcf" -> "california"
                parts = column_name.split('_')
                if len(parts) < 2 or parts[1] != 'bcf':
                    print(f"  [Warning] Could not parse column name '{column_name}'. Skipping.")
                    continue
                
                region = parts[0]
                
                # --- Create Regional Subfolder ---
                region_folder_path = os.path.join(output_folder, region)
                os.makedirs(region_folder_path, exist_ok=True)
                
                # --- Create and Save the New DataFrame ---
                # Select only the datetime and the current regional data column
                regional_df = df[['datetime', column_name]].copy()
                
                # Rename the data column to a generic 'Value_BCF'
                regional_df.rename(columns={column_name: 'Value_BCF'}, inplace=True)
                
                # Define the output file path
                output_filename = f"forecast_{sector}_burns.csv"
                output_path = os.path.join(region_folder_path, output_filename)
                
                regional_df.to_csv(output_path, index=False)
                print(f"  - Saved data for '{region}' -> '{sector}' to {output_path}")

            # --- Delete the original file after successful processing ---
            os.remove(file_path)
            print(f"  ✓ Successfully processed and deleted original file: {filename}")

        except Exception as e:
            print(f"  [ERROR] Failed to process {filename}. The file will not be deleted. Reason: {e}")
            traceback.print_exc()

    print("\n--- Forecast burns data organization complete! ---")
    print(f"All disaggregated files have been saved and source files have been removed.")


# --- Run the script ---
if __name__ == "__main__":
    organize_forecast_burns_by_region()