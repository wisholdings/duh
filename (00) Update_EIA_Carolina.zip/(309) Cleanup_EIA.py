import pandas as pd
import os
import traceback

def organize_eia_actuals_by_region():
    """
    Reads EIA actuals (daily and monthly), disaggregates them by region and fuel type,
    saves them into regional subfolders, and deletes the original source files upon
    successful completion.
    """
    # --- Configuration ---
    source_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    output_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE\Update'
    
    print("Starting EIA actuals data organization process.")
    print(f"Source folder: '{os.path.abspath(source_folder)}'")
    print(f"Output folder: '{os.path.abspath(output_folder)}'")

    os.makedirs(output_folder, exist_ok=True)

    files_to_process = [
        'eia_actuals_daily_by_type.csv',
        'eia_actuals_monthly_by_type.csv'
    ]

    # --- Processing Loop ---
    for filename in files_to_process:
        file_path = os.path.join(source_folder, filename)
        
        if not os.path.exists(file_path):
            print(f"\n[Info] File not found, skipping: {filename}")
            continue
            
        print(f"\n--- Processing file: {filename} ---")
        
        try:
            # Determine if the file is daily or monthly for naming the output
            time_period = 'daily' if 'daily' in filename else 'monthly'
            
            df = pd.read_csv(file_path, parse_dates=['date'])
            
            # Iterate through each data column (skip the 'date' column)
            for column_name in df.columns:
                if column_name.lower() == 'date':
                    continue
                
                # --- Extract Region and Fuel Type from column name ---
                # Example: "California_NG_MW"
                parts = column_name.split('_')
                if len(parts) < 2:
                    print(f"  [Warning] Could not parse column name '{column_name}'. Skipping.")
                    continue
                
                region = parts[0]
                fuel_and_unit = '_'.join(parts[1:]) # e.g., 'NG_MW'
                
                # --- Create Regional Subfolder ---
                region_folder_path = os.path.join(output_folder, region)
                os.makedirs(region_folder_path, exist_ok=True)
                
                # --- Create and Save the New DataFrame ---
                regional_df = df[['date', column_name]].copy()
                
                # Rename the data column to a generic 'Value'
                regional_df.rename(columns={column_name: 'Value'}, inplace=True)
                
                # Define the output file path
                output_filename = f"actuals_{fuel_and_unit}_{time_period}.csv"
                output_path = os.path.join(region_folder_path, output_filename)
                
                regional_df.to_csv(output_path, index=False)
                print(f"  - Saved data for '{region}' -> '{fuel_and_unit}' to {output_path}")

            # --- Delete the original file after successful processing ---
            os.remove(file_path)
            print(f"  ✓ Successfully processed and deleted original file: {filename}")

        except Exception as e:
            print(f"  [ERROR] Failed to process {filename}. The file will not be deleted. Reason: {e}")
            traceback.print_exc()

    print("\n--- EIA actuals data organization complete! ---")
    print(f"All disaggregated files have been saved and source files have been removed.")


# --- Run the script ---
if __name__ == "__main__":
    organize_eia_actuals_by_region()