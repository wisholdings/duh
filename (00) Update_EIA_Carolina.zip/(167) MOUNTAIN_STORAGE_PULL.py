import pandas as pd
import psycopg2
import logging
import sys
import os
import re

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# PostgreSQL Database Connection Details
DB_CONFIG = {
    "host": "",
    "database": "",
    "user": "",
    "password": "",
    "port": 443
}

# Mountain Region States (based on typical EIA Mountain region definition)
MOUNTAIN_REGION_STATES = ["AZ", "CO", "ID", "MT", "NV", "NM", "UT", "WY","OK","WA","OR"]

def clean_folder_name(name):
    """Cleans up a string to be used as a folder name."""
    if not isinstance(name, str):
        name = str(name)
    
    # Replace spaces with underscores
    name = name.replace(' ', '_')
    # Remove any characters that are not alphanumeric, underscores, or hyphens
    name = re.sub(r'[^\w-]+', '', name)
    return name

def fetch_and_save_pipeline_data_to_csv(tickers_to_fetch: list, output_csv_name: str, facility_name: str):
    """
    Connects to the PostgreSQL database, fetches pipeline nomination data for
    specified tickers in the Mountain region, and saves it to a CSV file.

    Args:
        tickers_to_fetch (list): A list of ticker strings.
        output_csv_name (str): The name of the CSV file to save the data to.
        facility_name (str): The name of the storage facility for logging purposes.
    """
    if not tickers_to_fetch:
        logging.warning(f"No tickers provided for '{facility_name}'. Skipping data fetch.")
        return

    # Format the Python list of tickers and states for the SQL 'IN' clause
    formatted_tickers = ",".join(f"'{ticker}'" for ticker in tickers_to_fetch)
    formatted_states = ",".join(f"'{state}'" for state in MOUNTAIN_REGION_STATES)

    # Construct the SQL query for Mountain region states
    SQL_QUERY = f"""
    select
        meta.pipeline_name, meta.tsp, meta.tsp_short, meta.ticker, meta.loc_name, meta.loc, meta.loc_qti_id
        , meta.loc_qti_short, meta.loc_purp_desc, meta.rec_del_sign, meta.loc_zone, meta.category_short, meta.sub_category_desc
        , meta.sub_category_2_desc, meta.country_name, meta.state_name, meta.state_abb, meta.province_name, meta.offshore_block_name
        , meta.county_name, meta.latitude, meta.longitude, meta.connecting_pipeline, meta.connecting_entity, meta.storage_name, meta.storage_calc_flag
        , meta.units, noms.cycle_id, noms.cycle_desc, noms.hourly_cycle_id, noms.eff_gas_day, noms.end_eff_gas_day, noms.design_capacity
        , noms.operating_capacity, noms.scheduled_quantity, noms.scheduled_quantity * meta.rec_del_sign as scheduled_quantity_sign_adj
        , noms.operationally_available, reg.region_name as regions_criterion, reg.eia_ng_regions
    from pipelines.nomination_points noms
    inner join pipelines.metadata meta on meta.metadata_id = noms.metadata_id
    left join pipelines.regions reg on reg.state_name = meta.state_name
    where  (noms.eff_gas_day <= current_date and noms.eff_gas_day >= '1/1/2019')
    and meta.ticker in ({formatted_tickers})
    and meta.state_abb in ({formatted_states})
    order by meta.tsp_short, noms.eff_gas_day, meta.ticker;
    """

    cnxn = None
    try:
        logging.info(f"Attempting to connect to the database for '{facility_name}', file: {output_csv_name}...")
        logging.info(f"Filtering by Mountain region states: {MOUNTAIN_REGION_STATES}")

        cnxn = psycopg2.connect(**DB_CONFIG)
        logging.info("Database connection successful.")

        logging.info(f"Executing SQL query for {facility_name} with tickers: {tickers_to_fetch}...")

        df = pd.read_sql(SQL_QUERY, cnxn)
        logging.info(f"Successfully loaded {len(df)} rows for {facility_name}.")

        if len(df) == 0:
            logging.warning(f"No data fetched for '{facility_name}'. Skipping CSV creation.")
            return

        # Create the Mountain region directory
        folder_name = "mountain"
        os.makedirs(folder_name, exist_ok=True)
        logging.info(f"Ensured directory '{folder_name}' exists.")

        # Construct the full output path
        full_output_path = os.path.join(folder_name, output_csv_name)

        df.to_csv(full_output_path, index=False)
        logging.info(f"Data successfully saved to {full_output_path}")

    except psycopg2.Error as e:
        logging.error(f"Database error while processing {facility_name}: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred while processing {facility_name}: {e}")
    finally:
        if cnxn:
            cnxn.close()
            logging.info(f"Database connection closed for {facility_name}.")

if __name__ == "__main__":
    # Mountain Region Storage Facilities Configuration
    # Based on the data you provided, here are all the Mountain region facilities
    mountain_storage_configs = [
        {
            "facility_name": "Chalk Creek",
            "tickers": ["PLNM.129.97.8"],
            "output_filename": "Chalk_Creek.csv"
        },
        {
            "facility_name": "CIG",
            "tickers": ["PLNM.041.800715.7", "PLNM.041.800715.8"],
            "output_filename": "CIG.csv"
        },
        {
            "facility_name": "Clay Basin",
            "tickers": [
                "PLNM.129.152.8", "PLNM.129.66.8",
                "PLNM.129.852.7", "PLNM.129.866.7"
            ],
            "output_filename": "Clay_Basin.csv"
        },
        {
            "facility_name": "Coalville",
            "tickers": ["PLNM.129.98.8"],
            "output_filename": "Coalville.csv"
        },
        {
            "facility_name": "East Cheyenne",
            "tickers": [
                "PLNM.011.2973446R.7", "PLNM.011.2973446R.8",
                "PLNM.011.2973446T.7", "PLNM.011.2973446T.8",
                "PLNM.011.45401.8", "PLNM.011.TBD.7", "PLNM.011.TBD.8"
            ],
            "output_filename": "East_Cheyenne.csv"
        },
        {
            "facility_name": "Grama Ridge",
            "tickers": [
                "PLNM.042.301560.7", "PLNM.042.301641.7", "PLNM.042.301641.8",
                "PLNM.042.53912.7", "PLNM.049.45373.7", "PLNM.049.45373.8"
            ],
            "output_filename": "Grama_Ridge.csv"
        },
        {
            "facility_name": "Kiowa Creek",
            "tickers": ["PLNM.041.800338.7", "PLNM.041.800338.8"],
            "output_filename": "Kiowa_Creek.csv"
        },
        {
            "facility_name": "Leroy",
            "tickers": ["PLNM.129.82.8"],
            "output_filename": "Leroy.csv"
        },
        {
            "facility_name": "Williston Basin",
            "tickers": ["PLNM.149.5800.7", "PLNM.149.5801.8"],
            "output_filename": "Williston_Basin.csv"
        },
        {
            "facility_name": "Young",
            "tickers": ["PLNM.057.800826.7", "PLNM.057.800826.8"],
            "output_filename": "Young.csv"
        },
        {
            "facility_name": "Spire Storage West",
            "tickers": [
                "PLNM.030.1252410.8", "PLNM.030.1252411.7", "PLNM.030.1252413.8",
                "PLNM.030.1252414.7", "PLNM.030.278840.8", "PLNM.030.278841.7",
                "PLNM.030.801215.8", "PLNM.030.KERNRIV.7", "PLNM.030.KERNWD.8",
                "PLNM.030.NWPLINJ.7", "PLNM.030.NWPLWD.8", "PLNM.030.OTPLINJ.7",
                "PLNM.030.OTPLWD.8", "PLNM.030.OVERTHR.7", "PLNM.030.OVERTHR.8",
                "PLNM.030.QPLWD.8", "PLNM.030.RUBYINJ.7", "PLNM.030.RUBYWD.8"
            ],
            "output_filename": "Spire_Storage_West.csv"
        }
    ]

    logging.info("--- Starting Mountain Region Pipeline Data Processing ---")
    
    for config in mountain_storage_configs:
        facility_name = config.get('facility_name', 'Unknown')
        output_name = config.get('output_filename', 'default.csv')
        tickers = config.get('tickers', [])

        logging.info(f"\nProcessing {facility_name}...")
        logging.info(f"Tickers: {tickers}")
        logging.info(f"Output file: {output_name}")
        
        fetch_and_save_pipeline_data_to_csv(
            tickers,
            output_name,
            facility_name
        )
        
        logging.info(f"Finished processing {facility_name}.\n")

    logging.info("--- Mountain Region Processing Completed ---")