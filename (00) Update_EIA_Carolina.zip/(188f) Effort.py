# =============================================================================
# FINAL CLEANUP SCRIPT - Clean AGGREGATE Folder and Trim Master File
# =============================================================================
import pandas as pd
import os
from datetime import datetime

# --- CONFIGURATION ---
AGGREGATE_PATH = r"D:\EIA_STACK\Pricing_RL\AGGREGATE"
MASTER_FILE = "master_aggregate_data.csv"
START_DATE = "2021-01-01"
END_DATE = "2026-12-31"

# =============================================================================
# CLEANUP AND TRIM FUNCTIONS
# =============================================================================
def cleanup_aggregate_folder():
    """Delete all files except master_aggregate_data.csv"""
    print("\n📊 Cleaning up AGGREGATE folder...")
    
    if not os.path.exists(AGGREGATE_PATH):
        print(f"  ✗ Directory not found: {AGGREGATE_PATH}")
        return False
    
    # Get all files in the directory
    all_files = [f for f in os.listdir(AGGREGATE_PATH) if os.path.isfile(os.path.join(AGGREGATE_PATH, f))]
    
    # Count files
    csv_files = [f for f in all_files if f.endswith('.csv')]
    print(f"  Found {len(csv_files)} CSV files in directory")
    
    deleted_count = 0
    kept_count = 0
    errors = []
    
    for filename in all_files:
        file_path = os.path.join(AGGREGATE_PATH, filename)
        
        if filename == MASTER_FILE:
            print(f"  ✓ Keeping: {filename}")
            kept_count += 1
        else:
            try:
                os.remove(file_path)
                print(f"  ✓ Deleted: {filename}")
                deleted_count += 1
            except Exception as e:
                print(f"  ✗ Error deleting {filename}: {e}")
                errors.append((filename, str(e)))
    
    print(f"\n  Summary:")
    print(f"    Files deleted: {deleted_count}")
    print(f"    Files kept: {kept_count}")
    if errors:
        print(f"    Errors: {len(errors)}")
        for file, error in errors:
            print(f"      - {file}: {error}")
    
    return True

def trim_master_file():
    """Trim master file to date range 2019-01-01 to 2026-12-31 and adjust values"""
    print("\n📊 Trimming master file to specified date range...")
    
    master_path = os.path.join(AGGREGATE_PATH, MASTER_FILE)
    
    # Check if file exists
    if not os.path.exists(master_path):
        print(f"  ✗ Master file not found: {master_path}")
        return False
    
    try:
        # Load the master file
        print(f"  Loading {MASTER_FILE}...")
        df = pd.read_csv(master_path)
        original_records = len(df)
        
        # Check for Date column
        if 'Date' not in df.columns:
            print(f"  ✗ No 'Date' column found in master file")
            return False
        
        # Convert to datetime
        df['Date'] = pd.to_datetime(df['Date'])
        
        # Show original date range
        original_start = df['Date'].min()
        original_end = df['Date'].max()
        print(f"  Original date range: {original_start.date()} to {original_end.date()}")
        print(f"  Original records: {original_records:,}")
        
        # Filter to specified date range
        start_dt = pd.to_datetime(START_DATE)
        end_dt = pd.to_datetime(END_DATE)
        
        print(f"\n  Filtering to: {START_DATE} to {END_DATE}...")
        df_filtered = df[(df['Date'] >= start_dt) & (df['Date'] <= end_dt)].copy()
        
        # Sort by date
        df_filtered = df_filtered.sort_values('Date')
        
        # Show new statistics
        new_records = len(df_filtered)
        new_start = df_filtered['Date'].min()
        new_end = df_filtered['Date'].max()
        
        print(f"  New date range: {new_start.date()} to {new_end.date()}")
        print(f"  New records: {new_records:,}")
        print(f"  Records removed: {original_records - new_records:,}")
        
        # Make specified columns negative
        print(f"\n  Converting specified columns to negative values...")
        columns_to_negate = [
            'LNG_EXPORTS_BCF',
            'MEX_EXPORTS_BCF',
            'commercial_bcf',
            'industrial_bcf',
            'residential_bcf',
            'L48_Power_Burns',  # This is the L48_Power_Burns column after merging
            'pipe_loss_bcf',
            'lease_plant_loss_bcf'
        ]
        
        for col in columns_to_negate:
            if col in df_filtered.columns:
                # Make values negative (take absolute value first to ensure they're negative)
                df_filtered[col] = -abs(df_filtered[col])
                print(f"    ✓ Made {col} negative")
            else:
                print(f"    ⚠ Column {col} not found in dataset")
        
        # Calculate size reduction
        original_size = os.path.getsize(master_path) / (1024 * 1024)  # MB
        
        # Generate filename with today's date
        today_date = datetime.now().strftime('%Y%m%d')
        new_filename = f"L48_{today_date}.csv"
        new_path = os.path.join(AGGREGATE_PATH, new_filename)
        
        # Save the trimmed file with new name
        print(f"\n  Saving as {new_filename}...")
        df_filtered.to_csv(new_path, index=False)
        
        # Delete the original master file
        print(f"  Deleting original {MASTER_FILE}...")
        os.remove(master_path)
        
        new_size = os.path.getsize(new_path) / (1024 * 1024)  # MB
        size_reduction = original_size - new_size
        
        print(f"  ✓ File saved successfully as {new_filename}")
        print(f"    Original size: {original_size:.2f} MB")
        print(f"    New size: {new_size:.2f} MB")
        print(f"    Size reduction: {size_reduction:.2f} MB ({(size_reduction/original_size*100):.1f}%)")
        
        # Show column statistics for the trimmed data
        print(f"\n  Column statistics (trimmed data):")
        total_rows = len(df_filtered)
        
        # Count non-null values for each column
        completeness_stats = []
        for col in df_filtered.columns:
            if col != 'Date':
                non_null = df_filtered[col].notna().sum()
                pct_complete = (non_null / total_rows) * 100
                completeness_stats.append((col, pct_complete, non_null))
        
        # Sort by completeness
        completeness_stats.sort(key=lambda x: x[1], reverse=True)
        
        # Show most complete columns
        print(f"\n  Most complete columns:")
        for col, pct, count in completeness_stats[:5]:
            print(f"    - {col}: {pct:.1f}% ({count:,}/{total_rows:,})")
        
        # Show least complete columns
        print(f"\n  Least complete columns:")
        for col, pct, count in completeness_stats[-5:]:
            print(f"    - {col}: {pct:.1f}% ({count:,}/{total_rows:,})")
        
        # Show sample of negated values to confirm
        print(f"\n  Sample of negated values (first 5 non-null):")
        for col in columns_to_negate:
            if col in df_filtered.columns:
                sample_values = df_filtered[col].dropna().head()
                if len(sample_values) > 0:
                    print(f"    {col}: {sample_values.values[:3]}")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error processing master file: {e}")
        import traceback
        traceback.print_exc()
        return False

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    """Execute the final cleanup and trim operations"""
    print("\n" + "=" * 80)
    print("FINAL CLEANUP AND TRIM OPERATIONS")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    print(f"Working directory: {AGGREGATE_PATH}")
    print(f"Target date range: {START_DATE} to {END_DATE}")
    
    # Step 1: Clean up folder
    print("\n" + "=" * 60)
    print("STEP 1: DELETE ALL FILES EXCEPT MASTER")
    print("=" * 60)
    cleanup_success = cleanup_aggregate_folder()
    
    # Step 2: Trim master file
    print("\n" + "=" * 60)
    print("STEP 2: TRIM MASTER FILE")
    print("=" * 60)
    trim_success = trim_master_file()
    
    # Final summary
    print("\n" + "=" * 80)
    if cleanup_success and trim_success:
        print("✅ ALL OPERATIONS COMPLETE!")
    else:
        print("⚠ OPERATIONS COMPLETED WITH WARNINGS")
    print("=" * 80)
    
    print("\nFinal Summary:")
    print(f"  Folder cleanup: {'Success' if cleanup_success else 'Failed'}")
    print(f"  File trimming: {'Success' if trim_success else 'Failed'}")
    
    # List final contents of folder
    print(f"\nFinal contents of AGGREGATE folder:")
    if os.path.exists(AGGREGATE_PATH):
        files = os.listdir(AGGREGATE_PATH)
        if files:
            for file in files:
                file_path = os.path.join(AGGREGATE_PATH, file)
                if os.path.isfile(file_path):
                    size = os.path.getsize(file_path) / (1024 * 1024)  # MB
                    print(f"  - {file} ({size:.2f} MB)")
        else:
            print(f"  (Empty)")
    
    print(f"\nCompleted: {datetime.now()}")

if __name__ == "__main__":
    main()