import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
from datetime import datetime, timedelta

# --- Configuration ---
# The base directory where all the regional folders (CONUS, EAST, etc.) are located.
BASE_DIR = r"D:\EIA_STACK\Pricing_RL\AGGREGATE\Update"
# List of regions to include in the report. The script will look for a folder with each name.
REGIONS_TO_PROCESS = ["CONUS", "EAST", "SOUTHCENTRAL", "MOUNTAIN", "PACIFIC","midwest"] 
# The final output file will be saved in the base directory.
OUTPUT_HTML_FILE = os.path.join(BASE_DIR, "Regional_Weather_Report.html")

TODAY = datetime.now().date()

# --- Data Loading and Processing ---

def load_data(region_name):
    """Loads and prepares historical and forecast weather data for a specific region."""
    print(f"\nLoading data for region: {region_name}...")
    region_path = os.path.join(BASE_DIR, region_name)
    historical_file = os.path.join(region_path, "weather_historical.csv")
    forecast_file = os.path.join(region_path, "weather_forecast.csv")

    if not os.path.exists(historical_file) or not os.path.exists(forecast_file):
        print(f"  ✗ WARNING: Missing 'weather_historical.csv' or 'weather_forecast.csv' in '{region_path}'. Skipping region.")
        return None, None

    try:
        df_hist = pd.read_csv(historical_file, parse_dates=['DATE'])
        df_fore = pd.read_csv(forecast_file, parse_dates=['DATE', 'DATE_PUBLISHED'])
        
        df_hist['DATE'] = df_hist['DATE'].dt.date
        df_fore['DATE'] = df_fore['DATE'].dt.date
        df_fore['DATE_PUBLISHED'] = df_fore['DATE_PUBLISHED'].dt.date
        
        print(f"  ✓ Loaded {len(df_hist)} historical and {len(df_fore)} forecast records.")
        return df_hist, df_fore
    except Exception as e:
        print(f"  ✗ ERROR loading data for {region_name}: {e}")
        return None, None

# --- Plotting and Table Functions (Modified to accept region name for titles) ---

def create_forecast_evolution_plot(df_fore, region_name):
    """Creates forecast evolution plots for a specific region."""
    latest_pub_dates = sorted(df_fore['DATE_PUBLISHED'].unique(), reverse=True)[:3]
    if not latest_pub_dates: return None, None
    fig_hdd = go.Figure()
    fig_cdd = go.Figure()
    forecast_end_date = latest_pub_dates[0] + timedelta(days=14)
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
    for i, pub_date in enumerate(latest_pub_dates):
        df_subset = df_fore[(df_fore['DATE_PUBLISHED'] == pub_date) & (df_fore['DATE'] >= pub_date) & (df_fore['DATE'] <= forecast_end_date)].sort_values('DATE')
        if not df_subset.empty:
            fig_hdd.add_trace(go.Scatter(x=df_subset['DATE'].tolist(), y=df_subset['GW_HDD'].tolist(), mode='lines+markers', name=f'HDD ({pub_date.strftime("%Y-%m-%d")})', line=dict(color=colors[i], dash=('solid' if i == 0 else 'dash'))))
            fig_cdd.add_trace(go.Scatter(x=df_subset['DATE'].tolist(), y=df_subset['PW_CDD'].tolist(), mode='lines+markers', name=f'CDD ({pub_date.strftime("%Y-%m-%d")})', line=dict(color=colors[i], dash=('solid'if i == 0 else 'dash'))))
    fig_hdd.update_layout(height=450, title=f'{region_name}: GW-HDD Forecast Evolution', yaxis_title='GW-HDD', template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
    fig_cdd.update_layout(height=450, title=f'{region_name}: PW-CDD Forecast Evolution', yaxis_title='PW-CDD', template='plotly_white', legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
    return fig_hdd, fig_cdd

def create_comparison_tables(df_hist, df_fore, region_name):
    """
    Creates tables comparing the next 14-day forecast to last year and the 5-year average
    for the same calendar period.
    """
    print(f"  Generating 14-day comparison tables for {region_name}...")
    latest_pub_date = df_fore['DATE_PUBLISHED'].max()
    df_current_forecast = df_fore[df_fore['DATE_PUBLISHED'] == latest_pub_date].copy()

    # 1. Define the 14-day forecast window
    forecast_start_date = df_current_forecast['DATE'].min()
    forecast_end_date = forecast_start_date + timedelta(days=13)
    
    df_forecast_window = df_current_forecast[
        (df_current_forecast['DATE'] >= forecast_start_date) &
        (df_current_forecast['DATE'] <= forecast_end_date)
    ]
    
    # Ensure we have a full 14 days of forecast data
    if len(df_forecast_window) < 14:
        print(f"  ✗ Not enough forecast data for a full 14-day comparison in {region_name}. Skipping tables.")
        return None, None

    # 2. Calculate totals for the current forecast
    forecast_total_hdd = df_forecast_window['GW_HDD'].sum()
    forecast_total_cdd = df_forecast_window['PW_CDD'].sum()

    # 3. Calculate totals for the same period in previous years
    df_hist['DATE'] = pd.to_datetime(df_hist['DATE']) # Ensure it's a datetime object for comparison
    
    ly_total_hdd = 0
    ly_total_cdd = 0
    avg_5y_hdd_list = []
    avg_5y_cdd_list = []

    for year in range(TODAY.year - 5, TODAY.year):
        # Define the same calendar date range for the historical year
        try:
            period_start = forecast_start_date.replace(year=year)
            period_end = forecast_end_date.replace(year=year)
        except ValueError: # Handles leap years where Feb 29 doesn't exist
            period_start = forecast_start_date.replace(year=year, day=28)
            period_end = forecast_end_date.replace(year=year, day=28)

        df_hist_period = df_hist[
            (df_hist['DATE'] >= pd.to_datetime(period_start)) &
            (df_hist['DATE'] <= pd.to_datetime(period_end))
        ]
        
        if not df_hist_period.empty:
            year_total_hdd = df_hist_period['GW_HDD'].sum()
            year_total_cdd = df_hist_period['PW_CDD'].sum()

            # Add to 5-year average list
            avg_5y_hdd_list.append(year_total_hdd)
            avg_5y_cdd_list.append(year_total_cdd)

            # Capture last year's total
            if year == TODAY.year - 1:
                ly_total_hdd = year_total_hdd
                ly_total_cdd = year_total_cdd

    # Calculate the 5-year average
    avg_5y_hdd = sum(avg_5y_hdd_list) / len(avg_5y_hdd_list) if avg_5y_hdd_list else 0
    avg_5y_cdd = sum(avg_5y_cdd_list) / len(avg_5y_cdd_list) if avg_5y_cdd_list else 0

    # 4. Create the HTML tables
    hdd_data = {
        'Period': ['14-Day Forecast', 'Last Year', '5-Year Average'],
        'Total GW-HDD': [forecast_total_hdd, ly_total_hdd, avg_5y_hdd]
    }
    df_hdd = pd.DataFrame(hdd_data)
    hdd_html = df_hdd.to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

    cdd_data = {
        'Period': ['14-Day Forecast', 'Last Year', '5-Year Average'],
        'Total PW-CDD': [forecast_total_cdd, ly_total_cdd, avg_5y_cdd]
    }
    df_cdd = pd.DataFrame(cdd_data)
    cdd_html = df_cdd.to_html(index=False, float_format='%.1f', classes='styled-table', border=0)

    return hdd_html, cdd_html

# --- Main Execution ---

def main():
    """Main function to generate the multi-region HTML report."""
    print("===== Starting Regional Weather Report Generation =====")
    
    all_region_html = {}
    for region in REGIONS_TO_PROCESS:
        df_hist, df_fore = load_data(region)
        if df_hist is None or df_fore is None:
            continue

        fig_hdd_evo, fig_cdd_evo = create_forecast_evolution_plot(df_fore, region)
        hdd_table_html, cdd_table_html = create_comparison_tables(df_hist, df_fore, region)
        
        region_content = ""
        if fig_hdd_evo: region_content += fig_hdd_evo.to_html(full_html=False, include_plotlyjs=False)
        if fig_cdd_evo: region_content += fig_cdd_evo.to_html(full_html=False, include_plotlyjs=False)
        if hdd_table_html and cdd_table_html:
            region_content += '<div class="table-container">'
            region_content += f'<div class="table-wrapper"><h2>{region}: 14-Day GW-HDD Comparison</h2>{hdd_table_html}</div>'
            region_content += f'<div class="table-wrapper"><h2>{region}: 14-Day PW-CDD Comparison</h2>{cdd_table_html}</div>'
            region_content += '</div>'
        
        all_region_html[region] = region_content

    # --- Assemble the final HTML with Tabs ---
    print("\nAssembling final HTML report with tabs...")
    
    # Define the plotly javascript CDN link directly to avoid creating an extra empty plot.
    plotly_js = '<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>'

    html_template = """
    <html>
    <head>
        <title>Regional Weather Report</title>
        {plotly_js}
        <style>
            body {{ font-family: Arial, sans-serif; display: flex; }}
            .tab {{ overflow: hidden; border-right: 1px solid #ccc; background-color: #f1f1f1; width: 15%; min-width: 150px; height: 100vh; }}
            .tab button {{ background-color: inherit; display: block; width: 100%; border: none; outline: none; text-align: left; padding: 22px 16px; transition: 0.3s; font-size: 17px; cursor: pointer; }}
            .tab button:hover {{ background-color: #ddd; }}
            .tab button.active {{ background-color: #ccc; }}
            .tabcontent {{ flex-grow: 1; padding: 0px 12px; border: none; }}
            .table-container {{ display: flex; justify-content: center; gap: 40px; margin-top: 40px; margin-bottom: 40px; }}
            .styled-table {{ border-collapse: collapse; margin: 25px 0; font-size: 0.9em; min-width: 400px; box-shadow: 0 0 20px rgba(0, 0, 0, 0.15); }}
            .styled-table thead tr {{ background-color: #009879; color: #ffffff; text-align: left; }}
            .styled-table th, .styled-table td {{ padding: 12px 15px; text-align: right; }}
            .styled-table tbody tr {{ border-bottom: 1px solid #dddddd; }}
            .styled-table tbody tr:nth-of-type(even) {{ background-color: #f3f3f3; }}
            .styled-table tbody tr:last-of-type {{ border-bottom: 2px solid #009879; }}
            .table-wrapper {{ text-align: center; }}
        </style>
    </head>
    <body>
        <div class="tab">
            <h2 style="padding: 0 16px;">Regions</h2>
            {tab_buttons}
        </div>
        {tab_contents}
        <script>
            function openRegion(evt, regionName) {{
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {{
                    tabcontent[i].style.display = "none";
                }}
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {{
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }}
                var activeTab = document.getElementById(regionName);
                activeTab.style.display = "block";
                evt.currentTarget.className += " active";

                // Find all plotly graphs in the active tab and resize them
                var plotlyGraphs = activeTab.getElementsByClassName('plotly-graph-div');
                for (i = 0; i < plotlyGraphs.length; i++) {{
                    Plotly.Plots.resize(plotlyGraphs[i]);
                }}
            }}
            if (document.getElementsByClassName("tablinks").length > 0) {{
                document.getElementsByClassName("tablinks")[0].click(); // Automatically open the first tab
            }}
        </script>
    </body>
    </html>
    """

    tab_buttons = "".join([f'<button class="tablinks" onclick="openRegion(event, \'{r}\')">{r}</button>' for r in all_region_html.keys()])
    tab_contents = "".join([f'<div id="{r}" class="tabcontent">{content}</div>' for r, content in all_region_html.items()])

    final_html = html_template.format(
        plotly_js=plotly_js,
        tab_buttons=tab_buttons,
        tab_contents=tab_contents
    )

    with open(OUTPUT_HTML_FILE, 'w') as f:
        f.write(final_html)
    
    print(f"\n✓ Report successfully saved to: {OUTPUT_HTML_FILE}")
    print("======================================================")

if __name__ == "__main__":
    main()