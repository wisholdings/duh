import pandas as pd
import glob
import os
import sys

# --- Configuration ---
# The base directory containing all region subdirectories.
BASE_PATH = r'D:\EIA_STACK'

# The column used to link the main data with the weights data.
LINKING_COLUMN = 'date'

# List of directories to ignore during processing.
FOLDERS_TO_IGNORE = [
    'granular_storage',
    'Historical_Files',
    'HYBRID_RESULTS',
    'L48_Power_Burn',
    'us_total',
    'storage_consolidated',
    'Nuke_Hourly_CSVs',
    'Historical_Files',
    'HYBRID_RESULTS',
    'L48_Power_Burn',
    'granular_storage',
    'Pricing_RL'
]


def restore_columns_from_weights_files():
    """
    Finds all train.parquet and predict.parquet files, restores columns from
    their corresponding _weights.parquet files, and saves as CSV files with
    '_staging' suffix.
    """
    print("--- Starting Column Restoration Process ---")
    print(f"Restoring columns from weights files and saving as CSV")

    # Find all region directories within the base path
    region_dirs = [d for d in glob.glob(os.path.join(BASE_PATH, '')) if os.path.isdir(d)]

    if not region_dirs:
        print(f"Error: No region directories found in {BASE_PATH}. Exiting.", file=sys.stderr)
        return

    total_files_processed = 0
    total_files_failed = 0

    # Iterate over each region's directory
    for region_dir in region_dirs:
        region_name = os.path.basename(region_dir)

        # Check if the current region should be ignored
        if region_name in FOLDERS_TO_IGNORE:
            print(f"\nSkipping ignored region: {region_name}")
            continue

        print(f"\nProcessing region: {region_name}")
        final_dir = os.path.join(region_dir, 'final')

        # Process both 'train' and 'predict' file types
        for file_type in ['train', 'predict']:
            source_file = os.path.join(final_dir, f'{file_type}.parquet')
            weights_file = os.path.join(final_dir, f'{file_type}_weights.parquet')
            dest_csv_file = os.path.join(final_dir, f'{file_type}_staging.csv')

            print(f"  - Processing {file_type}.parquet...")

            # --- Step 1: Check if both source and weights files exist ---
            if not os.path.exists(source_file):
                print(f"    - ⚠️ Source file NOT FOUND: {os.path.basename(source_file)}")
                total_files_failed += 1
                continue

            if not os.path.exists(weights_file):
                print(f"    - ⚠️ Weights file NOT FOUND: {os.path.basename(weights_file)}")
                total_files_failed += 1
                continue

            # --- Step 2: Read both files ---
            try:
                print(f"    - Reading {os.path.basename(source_file)}...")
                main_df = pd.read_parquet(source_file)
                
                print(f"    - Reading {os.path.basename(weights_file)}...")
                weights_df = pd.read_parquet(weights_file)
                
            except Exception as e:
                print(f"    - ⚠️ Error reading files: {e}", file=sys.stderr)
                total_files_failed += 1
                continue

            # --- Step 3: Validate linking column exists in both files ---
            if LINKING_COLUMN not in main_df.columns:
                print(f"    - ⚠️ Linking column '{LINKING_COLUMN}' not found in main file.")
                total_files_failed += 1
                continue

            if LINKING_COLUMN not in weights_df.columns:
                print(f"    - ⚠️ Linking column '{LINKING_COLUMN}' not found in weights file.")
                total_files_failed += 1
                continue

            # --- Step 4: Merge the dataframes ---
            try:
                # Get columns from weights file (excluding the linking column)
                columns_to_restore = [col for col in weights_df.columns if col != LINKING_COLUMN]
                
                if not columns_to_restore:
                    print(f"    - ⚠️ No columns to restore from weights file.")
                    total_files_failed += 1
                    continue

                print(f"    - Restoring {len(columns_to_restore)} columns: {columns_to_restore}")

                # Merge main dataframe with weights dataframe
                # Use 'left' join to preserve all rows from main_df
                merged_df = pd.merge(
                    main_df, 
                    weights_df, 
                    on=LINKING_COLUMN, 
                    how='left',
                    suffixes=('', '_from_weights')
                )

                # Check if merge was successful
                if len(merged_df) != len(main_df):
                    print(f"    - ⚠️ Warning: Row count changed after merge. Original: {len(main_df)}, Merged: {len(merged_df)}")

                # Check for any columns that got suffixed (indicating duplicates)
                suffixed_cols = [col for col in merged_df.columns if col.endswith('_from_weights')]
                if suffixed_cols:
                    print(f"    - ⚠️ Warning: Found duplicate columns that were suffixed: {suffixed_cols}")
                    # For duplicates, keep the weights version and drop the original
                    for suffixed_col in suffixed_cols:
                        original_col = suffixed_col.replace('_from_weights', '')
                        if original_col in merged_df.columns:
                            print(f"      - Replacing {original_col} with version from weights file")
                            merged_df[original_col] = merged_df[suffixed_col]
                            merged_df = merged_df.drop(columns=[suffixed_col])

            except Exception as e:
                print(f"    - ⚠️ Error merging dataframes: {e}", file=sys.stderr)
                total_files_failed += 1
                continue

            # --- Step 5: Save as CSV ---
            try:
                print(f"    - Saving as CSV: {os.path.basename(dest_csv_file)}...")
                merged_df.to_csv(dest_csv_file, index=False)
                
                print(f"    - ✅ Successfully created {os.path.basename(dest_csv_file)}")
                print(f"      - Original columns: {len(main_df.columns)}")
                print(f"      - Restored columns: {len(columns_to_restore)}")
                print(f"      - Final columns: {len(merged_df.columns)}")
                print(f"      - Total rows: {len(merged_df)}")
                
                total_files_processed += 1
                
            except Exception as e:
                print(f"    - ⚠️ Error saving CSV file: {e}", file=sys.stderr)
                total_files_failed += 1

    # --- Final Summary ---
    print(f"\n{'='*60}")
    print(f"RESTORATION PROCESS COMPLETE")
    print(f"{'='*60}")
    print(f"Files successfully processed: {total_files_processed}")
    print(f"Files failed: {total_files_failed}")
    
    if total_files_failed > 0:
        print(f"\n⚠️ {total_files_failed} files failed to process. Check the error messages above.")
        return False
    else:
        print(f"\n✅ All files processed successfully!")
        return True


if __name__ == "__main__":
    success = restore_columns_from_weights_files()
    if not success:
        sys.exit(1)
    else:
        print("\nProcess completed successfully!")