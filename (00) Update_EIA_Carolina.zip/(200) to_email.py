import requests
import pandas as pd
import json

def call_email_logic_app(
        url: str,
        html_table_string: str,
        email_recipients: list[str],
        email_subject: str,
        attachments_dict: dict[str, str] | None = None,
        timeout_value: int = 4,
    ) -> None:
        """
        Sends an HTTP POST request to a Logic App endpoint to trigger an email workflow.
 
        Args:
            url (str): The endpoint URL of the Logic App.
            html_table_string (str): The HTML content for the email body.
            email_recipients (list[str]): List of email recipient addresses.
            email_subject (str): Subject of the email.
            attachments_dict (dict[str, str] | None, optional): Dictionary containing attachment names and data.
                Defaults to None.
            timeout_value (int, optional): Timeout value for the HTTP request in seconds. Defaults to 4.
 
        Returns:
            None
        """
        if attachments_dict is None:
            attachments_dict = {}  # Initialize the dictionary if it is None
 
        default_keys = [
            "attachment1_name",
            "attachment1_data",
            "attachment2_name",
            "attachment2_data",
            "attachment3_name",
            "attachment3_data",
            "attachment4_name",
            "attachment4_data",
            "attachment5_name",
            "attachment5_data",
        ]
        for key in default_keys:
            attachments_dict.setdefault(key, "null")
 
        headers = {"Content-Type": "application/json"}
        data = {
            "email_body": str(html_table_string),
            "email_subject": str(email_subject),
            "email_recipient_addresses": str(",".join(email_recipients)),
        }
        for i in range(1, 6):
            data[f"attachment{i}_name"] = attachments_dict.get(f"attachment{i}_name", "null")
            data[f"attachment{i}_data"] = attachments_dict.get(f"attachment{i}_data", "null")
        data_json = json.dumps(data)
        response = requests.post(
            url, headers=headers, data=data_json, verify=False, timeout=timeout_value
        )
        if response.status_code == 202:
            print("Successfully called Logic App")
        else:
            print(f"Failed to call Logic App: {response.status_code}, {response.text}")
 
 
EMAIL_LOGIC_APP_URL = (
    "https://prod-16.westus2.logic.azure.com:443/"
    "workflows/eb5b1e6cdb2447bbbf87fa634dbfa84a/triggers/"
    "When_a_HTTP_request_is_received/paths/invoke?"
    "api-version=2016-10-01&sp=%2Ftriggers%2F"
    "When_a_HTTP_request_is_received%2Frun&"
    "sv=1.0&sig=JbBpMtnO4VX4emOt06Gx5OLTmMKidd9kSzC8fQICZTA"
)
 
with open("D:\\EIA_STACK\\Pricing_RL\\AGGREGATE\\natural_gas_forecast.html", "r", encoding="utf-8") as file:
    html_content = file.read()
 
call_email_logic_app(
    EMAIL_LOGIC_APP_URL,
    html_table_string = '',
    email_recipients=["","rgebauer@Suncor.com","ruparekh@suncor.com","tyoconnell@suncor.com","chdorland@Suncor.com"],
    email_subject="Magic Mick L48 (IMPLIED & PIPE MODEL)",
    attachments_dict={
        "attachment1_name": 'Lower 48.html',
        "attachment1_data": html_content,
    },
    timeout_value=15,
)