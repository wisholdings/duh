import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX
from datetime import timedelta, datetime
import warnings
import json
import os
import numpy as np

# Suppress warnings from statsmodels for cleaner output
warnings.filterwarnings("ignore")

def generate_forecast_html():
    """
    Reads natural gas data, generates short-term forecasts, and creates a comprehensive HTML report.
    Includes a storage trajectory with a secondary modelling trace, a companion delta chart, supply/demand balance,
    and a dispersion model. Also includes regional storage analysis and historical distribution plots.
    """
    try:
        # --- DYNAMICALLY SETTING PATHS AND DATES ---
        today = datetime.now()
        current_date = today.strftime('%Y-%m-%d')
        
        base_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE'
        file_name = f'L48_{today.strftime("%Y%m%d")}.csv'
        file_path = os.path.join(base_folder, file_name)

        print(f"Attempting to load data from: {file_path}")

        # --- 1. Load Full Data ---
        df_full = pd.read_csv(file_path)
        df_full['Date'] = pd.to_datetime(df_full['Date'])
        df_full.set_index('Date', inplace=True)
        df_full.sort_index(inplace=True)
        
        # --- Load Pipe Modelling Data ---
        try:
            pipe_file_path = os.path.join(base_folder, 'lower_48_combined_pipe.csv')
            df_pipe = pd.read_csv(pipe_file_path)
            df_pipe['datetime'] = pd.to_datetime(df_pipe['datetime'])
            df_pipe.set_index('datetime', inplace=True)
            df_pipe.sort_index(inplace=True)
            print("Successfully loaded lower_48_combined_pipe.csv")
            pipe_data_loaded = True
        except FileNotFoundError:
            print("WARNING: lower_48_combined_pipe.csv not found. Skipping 'Storage_Modelling' trace.")
            pipe_data_loaded = False
            df_pipe = None

        # --- RENAME COLUMNS ON THE MAIN DATAFRAME ---
        df_full.rename(columns={
            'gas_hdd': 'HDD', 'population_cdd': 'CDD',
            'L48_Power_Burns': 'Power Burns (Bcf/d)',
            'Storage_Corrected': 'Storage Level (Bcf)',
            'storage_delta': 'Storage Injection/Withdrawal (Bcf/d)'
        }, inplace=True)

        # --- 2. Prepare Data for FORECASTING MODEL (for L48 only) ---
        df_model = df_full.loc[:current_date].copy()
        df_model.drop(columns=['Implied_Storage', 'storage_lower_48_bcf'], inplace=True, errors='ignore')
        df_model.ffill(inplace=True)
        df_model.bfill(inplace=True)

        consumption_cols = [
            'commercial_bcf', 'industrial_bcf', 'residential_bcf',
            'Power Burns (Bcf/d)', 'LNG_EXPORTS_BCF', 'MEX_EXPORTS_BCF'
        ]
        df_model['Total Consumption'] = df_model[consumption_cols].sum(axis=1).abs()
        df_model['Total Supply'] = df_model['production_bcf'] + df_model['LNG_IMPORTS_BCF'] + df_model['CAD_NET_FLOW_BCF']

        # --- 3. Generate Short-Term Forecasts (for L48 only) ---
        metrics_to_forecast_short = [
            'Total Consumption', 'Total Supply', 'CDD', 'HDD',
            'Power Burns (Bcf/d)', 'Storage Level (Bcf)'
        ]
        forecast_horizon_short = 14
        last_date = df_model.index[-1]
        forecast_dates_short = pd.date_range(start=last_date + timedelta(days=1), periods=forecast_horizon_short)
        forecast_df_short = pd.DataFrame(index=forecast_dates_short)

        print("Generating short-term (14-day) forecasts for L48...")
        for metric in metrics_to_forecast_short:
            series_to_forecast = df_model[metric].abs() if metric in ['Power Burns (Bcf/d)'] else df_model[metric]
            model = SARIMAX(series_to_forecast, order=(1, 1, 1), seasonal_order=(1, 1, 1, 7),
                            enforce_stationarity=False, enforce_invertibility=False)
            try:
                results = model.fit(disp=False)
                forecast = results.get_forecast(steps=forecast_horizon_short)
                forecast_df_short[metric] = forecast.predicted_mean
            except Exception as e:
                last_known_value = series_to_forecast.iloc[-1]
                forecast_df_short[metric] = [last_known_value] * forecast_horizon_short
        
        last_known_storage = df_model['Storage Level (Bcf)'].dropna().iloc[-1]
        full_storage_path = pd.concat([pd.Series([last_known_storage], index=[last_date]), forecast_df_short['Storage Level (Bcf)']])
        forecast_df_short['Storage Injection/Withdrawal (Bcf/d)'] = full_storage_path.diff().dropna().values

        # --- 4. LOAD AND PROCESS REGIONAL DATA ---
        print("\nLoading regional data...")
        regional_files = {
            'East': {'file': 'east_combined.csv', 'column': 'East', 'stats': 'east_historical_weekly_avg.csv'},
            'Midwest': {'file': 'midwest_combined.csv', 'column': 'Midwest', 'stats': 'midwest_historical_weekly_avg.csv'},
            'Mountain': {'file': 'mountain_combined.csv', 'column': 'Mountain', 'stats': 'mountain_historical_weekly_avg.csv'},
            'Pacific': {'file': 'pacific_combined.csv', 'column': 'Pacific', 'stats': 'pacific_historical_weekly_avg.csv'},
            'South Central Salt': {'file': 'south_central_salt_combined.csv', 'column': 'South Central Salt', 'stats': 'south_central_salt_historical_weekly_avg.csv'},
            'South Central Nonsalt': {'file': 'south_central_nonsalt_combined.csv', 'column': 'South Central Nonsalt', 'stats': 'south_central_nonsalt_historical_weekly_avg.csv'}
        }
        
        regional_chart_data, regional_stats_data = {}, {}
        one_year_back = pd.Timestamp(current_date) - pd.DateOffset(years=1)
        one_year_forward = pd.Timestamp(current_date) + pd.DateOffset(years=1)
        
        for region, file_info in regional_files.items():
            try:
                regional_path = os.path.join(base_folder, file_info['file'])
                print(f"\n  Loading {region} forecast data from {file_info['file']}...")
                df_region = pd.read_csv(regional_path); df_region['datetime'] = pd.to_datetime(df_region['datetime']); df_region.set_index('datetime', inplace=True); df_region.sort_index(inplace=True)
                storage_column_name = file_info['column']
                if storage_column_name not in df_region.columns or 'Delta_Change' not in df_region.columns: continue
                time_window_mask = (df_region.index >= one_year_back) & (df_region.index <= one_year_forward)
                df_window = df_region.loc[time_window_mask]
                historical_data = df_window[df_window.index <= pd.Timestamp(current_date)][storage_column_name].dropna()
                forecast_data = df_window[df_window.index > pd.Timestamp(current_date)][storage_column_name].dropna()
                delta_data = df_window['Delta_Change'].dropna()
                all_dates, hist_values, fore_values, delta_values = [], [], [], []
                for date, value in historical_data.items():
                    all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(float(value)); fore_values.append(None)
                if not historical_data.empty and hist_values: fore_values[-1] = hist_values[-1]
                for date, value in forecast_data.items():
                    all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(None); fore_values.append(float(value))
                for date_str in all_dates:
                    delta_values.append(float(delta_data[pd.Timestamp(date_str)]) if pd.Timestamp(date_str) in delta_data.index else None)
                regional_chart_data[region] = {'labels': json.dumps(all_dates), 'historical': json.dumps(hist_values), 'forecast': json.dumps(fore_values), 'delta': json.dumps(delta_values)}
                print(f"    Forecast chart created for {region}.")
            except Exception as e: print(f"    Error processing forecast data for {region}: {e}")
            try:
                stats_path = os.path.join(base_folder, file_info['stats'])
                print(f"  Loading {region} historical stats from {file_info['stats']}...")
                df_stats = pd.read_csv(stats_path)
                required_cols = ['Week', 'Delta_Avg', 'Delta_Min', 'Delta_Max']
                if not all(col in df_stats.columns for col in required_cols): continue
                regional_stats_data[region] = {'labels': json.dumps(df_stats['Week'].tolist()), 'avg': json.dumps(df_stats['Delta_Avg'].tolist()), 'min': json.dumps(df_stats['Delta_Min'].tolist()), 'max': json.dumps(df_stats['Delta_Max'].tolist())}
                print(f"    Historical stats chart created for {region}.")
            except FileNotFoundError: print(f"    WARNING: Historical stats file not found for {region} at {stats_path}. Skipping stats plot.")
            except Exception as e: print(f"    Error processing historical stats for {region}: {e}")

        # --- 5. Prepare Data for HTML ---
        print("\nPreparing data for HTML report...")
        
        # Date ranges for summaries
        last_date = df_model.index[-1]
        current_week_start = last_date - timedelta(days=6)
        w1_start, w1_end = last_date + timedelta(days=1), last_date + timedelta(days=7)
        w2_start, w2_end = last_date + timedelta(days=8), last_date + timedelta(days=14)

        # --- Current/Forecast Summary ---
        pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current = "N/A", "N/A", "N/A"
        pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1 = "N/A", "N/A", "N/A"
        pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2 = "N/A", "N/A", "N/A"

        if pipe_data_loaded and df_pipe is not None:
            # Since df_pipe is weekly, we find the closest date on or before the period end
            def get_pipe_week_data(end_date, df_pipe):
                try:
                    # Find the last available data point on or before the end_date
                    row = df_pipe.loc[df_pipe.index <= end_date].iloc[-1]
                    storage = row['Lower_48_Total']
                    delta = row['Delta_Change']
                    return f"{storage:.2f} (End of Week)", f"{delta/7:.2f} (Avg)", f"{delta:.2f} (Sum)"
                except (IndexError, KeyError):
                    return "N/A", "N/A", "N/A"

            pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current = get_pipe_week_data(last_date, df_pipe)
            pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1 = get_pipe_week_data(w1_end, df_pipe)
            pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2 = get_pipe_week_data(w2_end, df_pipe)

        summary_df = pd.DataFrame({
            'Metric': ['Total Consumption', 'Total Supply', 'CDD', 'HDD', 'Power Burns (Bcf/d)', 'Storage Level (Bcf)', 'Storage Injection/Withdrawal (Bcf/d)', 'Pipe Model Delta (Bcf)'],
            'Current Week': [
                f"{df_model['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{df_model['Total Supply'].tail(7).mean():.2f} (Avg)",
                f"{df_model['CDD'].tail(7).sum():.2f} (Sum)", f"{df_model['HDD'].tail(7).sum():.2f} (Sum)",
                f"{df_model['Power Burns (Bcf/d)'].abs().tail(7).mean():.2f} (Avg)",
                pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current
            ],
            'Week 1 Forecast': [
                f"{forecast_df_short['Total Consumption'].head(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].head(7).mean():.2f} (Avg)",
                f"{forecast_df_short['CDD'].head(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].head(7).sum():.2f} (Sum)",
                f"{forecast_df_short['Power Burns (Bcf/d)'].head(7).mean():.2f} (Avg)",
                pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1
            ],
            'Week 2 Forecast': [
                f"{forecast_df_short['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].tail(7).mean():.2f} (Avg)",
                f"{forecast_df_short['CDD'].tail(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].tail(7).sum():.2f} (Sum)",
                f"{forecast_df_short['Power Burns (Bcf/d)'].tail(7).mean():.2f} (Avg)",
                pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2
            ]
        })
        forecast_display_df = forecast_df_short.round(2); forecast_display_df.index = forecast_display_df.index.strftime('%Y-%m-%d')
        
        # --- 5b. Prepare Data for LAST YEAR'S Summary Table ---
        summary_df_ly = pd.DataFrame()
        try:
            print("Preparing last year's summary data...")
            last_year_date = last_date - pd.DateOffset(years=1)
            ly_current_start = last_year_date - timedelta(days=6)
            ly_w1_start, ly_w1_end = last_year_date + timedelta(days=1), last_year_date + timedelta(days=7)
            ly_w2_start, ly_w2_end = last_year_date + timedelta(days=8), last_year_date + timedelta(days=14)

            # Add Total Consumption and Total Supply to df_full if not present
            if 'Total Consumption' not in df_full.columns:
                df_full['Total Consumption'] = df_full[consumption_cols].sum(axis=1).abs()
            if 'Total Supply' not in df_full.columns:
                df_full['Total Supply'] = df_full['production_bcf'] + df_full['LNG_IMPORTS_BCF'] + df_full['CAD_NET_FLOW_BCF']

            df_ly_current = df_full.loc[ly_current_start:last_year_date]
            df_ly_w1 = df_full.loc[ly_w1_start:ly_w1_end]
            df_ly_w2 = df_full.loc[ly_w2_start:ly_w2_end]

            ly_pipe_storage_current, ly_pipe_delta_avg_current, ly_pipe_delta_sum_current = get_pipe_week_data(last_year_date, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
            ly_pipe_storage_w1, ly_pipe_delta_avg_w1, ly_pipe_delta_sum_w1 = get_pipe_week_data(ly_w1_end, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
            ly_pipe_storage_w2, ly_pipe_delta_avg_w2, ly_pipe_delta_sum_w2 = get_pipe_week_data(ly_w2_end, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")

            summary_df_ly = pd.DataFrame({
                'Metric': summary_df['Metric'].tolist(),
                f'Same Week Last Year ({ly_current_start.strftime("%Y-%m-%d")} to {last_year_date.strftime("%Y-%m-%d")})': [
                    f"{df_ly_current['Total Consumption'].mean():.2f} (Avg)", f"{df_ly_current['Total Supply'].mean():.2f} (Avg)",
                    f"{df_ly_current['CDD'].sum():.2f} (Sum)", f"{df_ly_current['HDD'].sum():.2f} (Sum)",
                    f"{df_ly_current['Power Burns (Bcf/d)'].abs().mean():.2f} (Avg)",
                    ly_pipe_storage_current, ly_pipe_delta_avg_current, ly_pipe_delta_sum_current
                ],
                f'Equivalent Week 1 ({ly_w1_start.strftime("%Y-%m-%d")} to {ly_w1_end.strftime("%Y-%m-%d")})': [
                    f"{df_ly_w1['Total Consumption'].mean():.2f} (Avg)", f"{df_ly_w1['Total Supply'].mean():.2f} (Avg)",
                    f"{df_ly_w1['CDD'].sum():.2f} (Sum)", f"{df_ly_w1['HDD'].sum():.2f} (Sum)",
                    f"{df_ly_w1['Power Burns (Bcf/d)'].abs().mean():.2f} (Avg)",
                    ly_pipe_storage_w1, ly_pipe_delta_avg_w1, ly_pipe_delta_sum_w1
                ],
                f'Equivalent Week 2 ({ly_w2_start.strftime("%Y-%m-%d")} to {ly_w2_end.strftime("%Y-%m-%d")})': [
                    f"{df_ly_w2['Total Consumption'].mean():.2f} (Avg)", f"{df_ly_w2['Total Supply'].mean():.2f} (Avg)",
                    f"{df_ly_w2['CDD'].sum():.2f} (Sum)", f"{df_ly_w2['HDD'].sum():.2f} (Sum)",
                    f"{df_ly_w2['Power Burns (Bcf/d)'].abs().mean():.2f} (Avg)",
                    ly_pipe_storage_w2, ly_pipe_delta_avg_w2, ly_pipe_delta_sum_w2
                ]
            })
        except Exception as e:
            print(f"Could not generate last year's summary. Data might be missing for the period. Error: {e}")

        # --- 6. Prepare L48 Chart Data ---
        start_plot_date = datetime.strptime('2024-04-01', '%Y-%m-%d'); end_plot_date = datetime.strptime('2026-11-01', '%Y-%m-%d')
        df_plot = df_full.loc[start_plot_date:end_plot_date].copy()
        storage_plot_series = df_plot['Storage Level (Bcf)']
        chart_labels = storage_plot_series.index.strftime('%Y-%m-%d').tolist()
        chart_data = json.dumps([val if pd.notna(val) else None for val in storage_plot_series.round(2)])
        
        pipe_chart_data = "[]"; pipe_delta_chart_data = "[]"
        if pipe_data_loaded:
            pipe_plot_series = df_pipe['Lower_48_Total'].loc[start_plot_date:end_plot_date]
            aligned_pipe_series = pipe_plot_series.reindex(storage_plot_series.index, method='ffill')
            pipe_chart_data = json.dumps([val if pd.notna(val) else None for val in aligned_pipe_series.round(2)])
            pipe_delta_series = df_pipe['Delta_Change']
            aligned_pipe_deltas = pipe_delta_series.reindex(storage_plot_series.index, method='ffill')
            pipe_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in aligned_pipe_deltas.round(2)])

        main_storage_series = df_full['Storage Level (Bcf)'].dropna()
        main_weekly_deltas = main_storage_series.resample('W-FRI').last().diff()
        aligned_main_deltas = main_weekly_deltas.reindex(storage_plot_series.index, method='ffill')
        main_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in aligned_main_deltas.round(2)])
            
        plot_consumption_cols = ['commercial_bcf', 'industrial_bcf', 'residential_bcf', 'Power Burns (Bcf/d)', 'LNG_EXPORTS_BCF', 'MEX_EXPORTS_BCF']
        df_plot['Total Consumption'] = df_plot[plot_consumption_cols].sum(axis=1).abs()
        df_plot['Total Supply'] = df_plot['production_bcf'] + df_plot['LNG_IMPORTS_BCF'] + df_plot['CAD_NET_FLOW_BCF']
        df_plot['Surplus/Deficit'] = df_plot['Total Supply'] - df_plot['Total Consumption']
        surplus_plot_series = df_plot['Surplus/Deficit']
        surplus_chart_data = json.dumps([val if pd.notna(val) else None for val in surplus_plot_series.round(2)])
        start_summer_date = datetime.strptime('2025-04-01', '%Y-%m-%d'); end_summer_date = datetime.strptime('2025-10-31', '%Y-%m-%d')
        df_summer = df_plot.loc[start_summer_date:end_summer_date].copy()
        df_summer['power_intensity_CDD'] = df_summer['Power Burns (Bcf/d)'] / df_summer['CDD'].replace(0, np.nan)
        intensity_plot_series = df_summer['power_intensity_CDD']
        intensity_chart_labels = intensity_plot_series.index.strftime('%Y-%m-%d').tolist()
        intensity_chart_data = json.dumps([val if pd.notna(val) and np.isfinite(val) else None for val in intensity_plot_series.round(2)])
        dispersion_data = []; dispersion_forecast_data = []
        for index, row in df_summer.iterrows():
            if pd.notna(row['CDD']) and pd.notna(row['Power Burns (Bcf/d)']): dispersion_data.append({'x': round(row['CDD'], 2), 'y': round(row['Power Burns (Bcf/d)'], 2)})
        for index, row in forecast_df_short.iterrows():
            if start_summer_date <= index <= end_summer_date:
                if pd.notna(row['CDD']) and pd.notna(row['Power Burns (Bcf/d)']): dispersion_forecast_data.append({'x': round(row['CDD'], 2), 'y': -round(row['Power Burns (Bcf/d)'], 2)})
        dispersion_chart_data = json.dumps(dispersion_data); dispersion_forecast_chart_data = json.dumps(dispersion_forecast_data)

        # --- 7. Generate HTML Report ---
        print("Generating HTML report...")
        regional_charts_html, regional_scripts = "", ""
        for idx, region in enumerate(regional_files.keys()):
            regional_charts_html += f"<h2>{region} Analysis</h2>"
            if region in regional_chart_data: regional_charts_html += f'<h4>Storage Level & Weekly Change (Forecast)</h4><div class="chart-container"><canvas id="regionalChart{idx}"></canvas></div>'
            if region in regional_stats_data: regional_charts_html += f'<h4>Historical Weekly Change Distribution (5-Year)</h4><div class="chart-container"><canvas id="regionalStatsChart{idx}"></canvas></div>'
            if region in regional_chart_data:
                data = regional_chart_data[region]
                regional_scripts += f"""const deltaData{idx} = {data['delta']}; const deltaColors{idx} = deltaData{idx}.map(v => v === null ? 'rgba(0,0,0,0)' : v >= 0 ? 'rgba(46, 204, 113, 0.7)' : 'rgba(231, 76, 60, 0.7)'); new Chart(document.getElementById('regionalChart{idx}'), {{ data: {{ labels: {data['labels']}, datasets: [ {{ type: 'line', label: 'Historical Storage (Bcf)', data: {data['historical']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'line', label: 'Forecast Storage (Bcf)', data: {data['forecast']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, borderDash: [6, 6], pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'bar', label: 'Weekly Delta (Bcf)', data: deltaData{idx}, backgroundColor: deltaColors{idx}, yAxisID: 'y1', barThickness: 8 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Storage Level and Weekly Change' }}, legend: {{ display: true, position: 'top' }} }}, scales: {{ x: {{ ticks: {{ maxRotation: 45, minRotation: 45, maxTicksLimit: 12 }} }}, y: {{ type: 'linear', display: true, position: 'left', title: {{ display: true, text: 'Storage Level (Bcf)' }} }}, y1: {{ type: 'linear', display: true, position: 'right', title: {{ display: true, text: 'Weekly Change (Bcf)' }}, grid: {{ drawOnChartArea: false }} }} }} }} }});"""
            if region in regional_stats_data:
                stats = regional_stats_data[region]
                regional_scripts += f"""new Chart(document.getElementById('regionalStatsChart{idx}'), {{ type: 'line', data: {{ labels: {stats['labels']}, datasets: [ {{ label: 'Max Change', data: {stats['max']}, borderColor: 'rgba(189, 195, 199, 0.5)', pointRadius: 0, borderWidth: 1, fill: false }}, {{ label: 'Min/Max Range', data: {stats['min']}, borderColor: 'rgba(189, 195, 199, 0.5)', backgroundColor: 'rgba(189, 195, 199, 0.2)', pointRadius: 0, borderWidth: 1, fill: '-1' }}, {{ label: 'Avg Change', data: {stats['avg']}, borderColor: 'rgb(44, 62, 80)', borderWidth: 2.5, pointRadius: 0, fill: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Historical Range of Weekly Changes (Bcf)' }}, legend: {{ labels: {{ filter: function(item, chart) {{ return !item.text.includes('Max Change'); }} }} }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Week of Year' }} }}, y: {{ title: {{ display: true, text: 'Weekly Change (Bcf)' }} }} }} }} }});"""
        
        html_content = f"""
        <html>
        <head>
            <title>Natural Gas Market Update</title>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f8f9fa; color: #333; }}
                h1, h2 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px;}}
                h3, h4 {{ color: #34495e; margin-top: 25px; }}
                table {{ border-collapse: collapse; width: 100%; margin-bottom: 30px; box-shadow: 0 2px 3px rgba(0,0,0,0.1); }}
                th, td {{ border: 1px solid #dddddd; text-align: left; padding: 12px; }}
                th {{ background-color: #3498db; color: white; }}
                tr:nth-child(even) {{ background-color: #f2f2f2; }}
                .container {{ max-width: 1400px; margin: auto; background-color: white; padding: 25px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }}
                .header {{ text-align: center; margin-bottom: 20px; }}
                .note {{ font-style: italic; color: #555; margin-top: -15px; margin-bottom: 20px;}}
                .chart-container {{ position: relative; height:50vh; width:100%; margin-top: 15px; margin-bottom: 40px; }}
                .regional-section {{ margin-top: 50px; padding-top: 20px; border-top: 3px solid #3498db; }}
                .footer {{ margin-top: 30px; font-size: 0.8em; color: #7f8c8d; text-align: center; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header"><h1>Natural Gas Market Update</h1><h2>A Two-Week Forward Look with Regional Analysis</h2></div>
                <p><b>Report Generated For Date:</b> {pd.to_datetime(current_date).strftime('%Y-%m-%d')}</p>
                <p>This report provides a two-week forecast for key U.S. natural gas fundamentals. The forecast begins the day after the last known data point ({last_date.strftime('%Y-%m-%d')}).</p>
                
                <h2>Key Projections Summary</h2>{summary_df.to_html(index=False, justify='left', classes='table table-striped')}
                {'<h2>Last Year Comparison</h2>' + summary_df_ly.to_html(index=False, justify='left', classes='table table-striped') if not summary_df_ly.empty else ''}
                <h2>Detailed Daily Forecast (14 Days)</h2>{forecast_display_df.to_html(justify='left', classes='table table-striped')}
                
                <h2>U.S. Lower 48 Analysis</h2>
                <h4>Storage Trajectory</h4><div class="chart-container"><canvas id="storageChart"></canvas></div>
                <h4>Weekly Storage Change</h4><div class="chart-container"><canvas id="storageDeltaChart"></canvas></div>
                <h4>Supply/Demand Balance (Surplus/Deficit)</h4><div class="chart-container"><canvas id="surplusChart"></canvas></div>
                <h4>Power Burn Intensity (vs. CDD)</h4><p class="note">This chart shows Power Burns divided by CDD for the cooling season (Apr 1 - Oct 31).</p><div class="chart-container"><canvas id="intensityChart"></canvas></div>
                <h4>Power Burn Dispersion Model</h4><p class="note">This scatter plot shows the relationship between daily CDDs and Power Burns for the summer season (Apr 1 - Oct 31, 2025).</p><div class="chart-container"><canvas id="dispersionChart"></canvas></div>
                
                <div class="regional-section">
                    <h1>Regional Analysis</h1>
                    <p class="note">Each region includes a forward-looking storage forecast and a historical view of the 5-year range for weekly storage changes.</p>
                    {regional_charts_html}
                </div>
                
                <div class="footer"><p><b>Disclaimer:</b> This forecast is generated programmatically for informational purposes only and is not investment advice.</p></div>
            </div>
            <script>
                const chartLabels = {json.dumps(chart_labels)};
                new Chart(document.getElementById('storageChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [ {{ label: 'Storage Level (Bcf)', data: {chart_data}, borderColor: 'rgb(52, 152, 219)', backgroundColor: 'rgba(52, 152, 219, 0.1)', borderWidth: 2.5, pointRadius: 1.5, spanGaps: false }}, {{ label: 'Storage_Modelling', data: {pipe_chart_data}, borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'U.S. Natural Gas Storage Levels (Bcf)' }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Date' }} }}, y: {{ title: {{ display: true, text: 'Storage Level (Bcf)' }} }} }} }} }});
                
                new Chart(document.getElementById('storageDeltaChart'), {{
                    type: 'line',
                    data: {{
                        labels: chartLabels,
                        datasets: [
                            {{
                                label: 'Storage Level Change (Bcf)', data: {main_delta_chart_data},
                                borderColor: 'rgb(52, 152, 219)', backgroundColor: 'rgba(52, 152, 219, 0.1)',
                                borderWidth: 2, pointRadius: 1.5, tension: 0.1
                            }},
                            {{
                                label: 'Storage_Modelling Change (Bcf)', data: {pipe_delta_chart_data},
                                borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)',
                                borderWidth: 2, pointRadius: 1.5, tension: 0.1
                            }}
                        ]
                    }},
                    options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Weekly Storage Change (Bcf)' }} }}, scales: {{ x: {{ ticks: {{ maxTicksLimit: 12, maxRotation: 45, minRotation: 45 }} }}, y: {{ title: {{ display: true, text: 'Change (Bcf)' }} }} }} }}
                }});

                new Chart(document.getElementById('surplusChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [{{ label: 'Daily Surplus/Deficit (Bcf/d)', data: {surplus_chart_data}, borderColor: 'rgb(46, 204, 113)', backgroundColor: 'rgba(46, 204, 113, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }}] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Daily Market Balance (Supply - Consumption)' }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Date' }} }}, y: {{ title: {{ display: true, text: 'Bcf/d' }} }} }} }} }});
                new Chart(document.getElementById('intensityChart'), {{ type: 'line', data: {{ labels: {json.dumps(intensity_chart_labels)}, datasets: [{{ label: 'Power Intensity (Burns/CDD)', data: {intensity_chart_data}, borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }}] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Power Burn Intensity (Power Burns / CDD)' }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Date' }} }}, y: {{ title: {{ display: true, text: 'Bcf per CDD' }} }} }} }} }});
                new Chart(document.getElementById('dispersionChart'), {{ type: 'scatter', data: {{ datasets: [ {{ label: 'Historical Daily Power Burn vs. CDD', data: {dispersion_chart_data}, backgroundColor: 'rgba(155, 89, 182, 0.6)', borderColor: 'rgb(155, 89, 182)', pointRadius: 5 }}, {{ label: 'Forecast Power Burn vs. CDD (14-Day)', data: {dispersion_forecast_chart_data}, backgroundColor: 'rgba(231, 76, 60, 0.9)', borderColor: 'rgb(231, 76, 60)', pointStyle: 'triangle', radius: 8, rotation: 0 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Power Burns vs. CDD (Summer 2025)' }}, tooltip: {{ callbacks: {{ label: function(context) {{ return `(CDD: ${{context.raw.x}}, Burns: ${{context.raw.y}} Bcf)`; }} }} }} }}, scales: {{ x: {{ type: 'linear', position: 'bottom', title: {{ display: true, text: 'Cooling Degree Days (CDD)' }} }}, y: {{ title: {{ display: true, text: 'Power Burns (Bcf/d)' }} }} }} }} }});
                
                {regional_scripts}
            </script>
        </body>
        </html>
        """
        
        output_filename = os.path.join(base_folder, "natural_gas_forecast.html")
        
        with open(output_filename, "w", encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"\nSuccessfully generated '{output_filename}'. You can open this file in a web browser.")

    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found. Please ensure the file for today's date exists.")
    except IndexError as e:
        print(f"Error processing data. Check if files have sufficient rows. Details: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    generate_forecast_html()

import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX
from datetime import timedelta, datetime
import warnings
import json
import os
import numpy as np

# Suppress warnings from statsmodels for cleaner output
warnings.filterwarnings("ignore")

def generate_forecast_html():
    """
    Reads natural gas data, generates short-term forecasts, and creates a comprehensive HTML report.
    Includes a storage trajectory with a secondary modelling trace, a companion delta chart, supply/demand balance,
    and a dispersion model. Also includes regional storage analysis and historical distribution plots.
    """
    try:
        # --- DYNAMICALLY SETTING PATHS AND DATES ---
        today = datetime.now()
        current_date = today.strftime('%Y-%m-%d')
        
        base_folder = r'D:\EIA_STACK\Pricing_RL\AGGREGATE'
        file_name = f'L48_{today.strftime("%Y%m%d")}.csv'
        file_path = os.path.join(base_folder, file_name)

        print(f"Attempting to load data from: {file_path}")

        # --- 1. Load Full Data ---
        df_full = pd.read_csv(file_path)
        df_full['Date'] = pd.to_datetime(df_full['Date'])
        df_full.set_index('Date', inplace=True)
        df_full.sort_index(inplace=True)
        
        # --- Load Pipe Modelling Data ---
        try:
            pipe_file_path = os.path.join(base_folder, 'lower_48_combined_pipe.csv')
            df_pipe = pd.read_csv(pipe_file_path)
            df_pipe['datetime'] = pd.to_datetime(df_pipe['datetime'])
            df_pipe.set_index('datetime', inplace=True)
            df_pipe.sort_index(inplace=True)
            print("Successfully loaded lower_48_combined_pipe.csv")
            pipe_data_loaded = True
        except FileNotFoundError:
            print("WARNING: lower_48_combined_pipe.csv not found. Skipping 'Storage_Modelling' trace.")
            pipe_data_loaded = False
            df_pipe = None

        # --- RENAME COLUMNS ON THE MAIN DATAFRAME ---
        df_full.rename(columns={
            'gas_hdd': 'HDD', 'population_cdd': 'CDD',
            'L48_Power_Burns': 'Power Burns (Bcf/d)',
            'Storage_Corrected': 'Storage Level (Bcf)',
            'storage_delta': 'Storage Injection/Withdrawal (Bcf/d)'
        }, inplace=True)

        # --- 2. Prepare Data for FORECASTING MODEL (for L48 only) ---
        df_model = df_full.loc[:current_date].copy()
        df_model.drop(columns=['Implied_Storage', 'storage_lower_48_bcf'], inplace=True, errors='ignore')
        df_model.ffill(inplace=True)
        df_model.bfill(inplace=True)

        consumption_cols = [
            'commercial_bcf', 'industrial_bcf', 'residential_bcf',
            'Power Burns (Bcf/d)', 'LNG_EXPORTS_BCF', 'MEX_EXPORTS_BCF'
        ]
        df_model['Total Consumption'] = df_model[consumption_cols].sum(axis=1).abs()
        df_model['Total Supply'] = df_model['production_bcf'] + df_model['LNG_IMPORTS_BCF'] + df_model['CAD_NET_FLOW_BCF']

        # --- 3. Generate Short-Term Forecasts (for L48 only) ---
        metrics_to_forecast_short = [
            'Total Consumption', 'Total Supply', 'CDD', 'HDD',
            'Power Burns (Bcf/d)', 'Storage Level (Bcf)'
        ]
        forecast_horizon_short = 14
        last_date = df_model.index[-1]
        forecast_dates_short = pd.date_range(start=last_date + timedelta(days=1), periods=forecast_horizon_short)
        forecast_df_short = pd.DataFrame(index=forecast_dates_short)

        print("Generating short-term (14-day) forecasts for L48...")
        for metric in metrics_to_forecast_short:
            series_to_forecast = df_model[metric].abs() if metric in ['Power Burns (Bcf/d)'] else df_model[metric]
            model = SARIMAX(series_to_forecast, order=(1, 1, 1), seasonal_order=(1, 1, 1, 7),
                            enforce_stationarity=False, enforce_invertibility=False)
            try:
                results = model.fit(disp=False)
                forecast = results.get_forecast(steps=forecast_horizon_short)
                forecast_df_short[metric] = forecast.predicted_mean
            except Exception as e:
                last_known_value = series_to_forecast.iloc[-1]
                forecast_df_short[metric] = [last_known_value] * forecast_horizon_short
        
        last_known_storage = df_model['Storage Level (Bcf)'].dropna().iloc[-1]
        full_storage_path = pd.concat([pd.Series([last_known_storage], index=[last_date]), forecast_df_short['Storage Level (Bcf)']])
        forecast_df_short['Storage Injection/Withdrawal (Bcf/d)'] = full_storage_path.diff().dropna().values

        # --- 4. LOAD AND PROCESS REGIONAL DATA ---
        print("\nLoading regional data...")
        regional_files = {
            'East': {'file': 'east_combined.csv', 'column': 'East', 'stats': 'east_historical_weekly_avg.csv'},
            'Midwest': {'file': 'midwest_combined.csv', 'column': 'Midwest', 'stats': 'midwest_historical_weekly_avg.csv'},
            'Mountain': {'file': 'mountain_combined.csv', 'column': 'Mountain', 'stats': 'mountain_historical_weekly_avg.csv'},
            'Pacific': {'file': 'pacific_combined.csv', 'column': 'Pacific', 'stats': 'pacific_historical_weekly_avg.csv'},
            'South Central Salt': {'file': 'south_central_salt_combined.csv', 'column': 'South Central Salt', 'stats': 'south_central_salt_historical_weekly_avg.csv'},
            'South Central Nonsalt': {'file': 'south_central_nonsalt_combined.csv', 'column': 'South Central Nonsalt', 'stats': 'south_central_nonsalt_historical_weekly_avg.csv'}
        }
        
        regional_chart_data, regional_stats_data = {}, {}
        one_year_back = pd.Timestamp(current_date) - pd.DateOffset(years=1)
        one_year_forward = pd.Timestamp(current_date) + pd.DateOffset(years=1)
        
        for region, file_info in regional_files.items():
            try:
                regional_path = os.path.join(base_folder, file_info['file'])
                print(f"\n  Loading {region} forecast data from {file_info['file']}...")
                df_region = pd.read_csv(regional_path); df_region['datetime'] = pd.to_datetime(df_region['datetime']); df_region.set_index('datetime', inplace=True); df_region.sort_index(inplace=True)
                storage_column_name = file_info['column']
                if storage_column_name not in df_region.columns or 'Delta_Change' not in df_region.columns: continue
                time_window_mask = (df_region.index >= one_year_back) & (df_region.index <= one_year_forward)
                df_window = df_region.loc[time_window_mask]
                historical_data = df_window[df_window.index <= pd.Timestamp(current_date)][storage_column_name].dropna()
                forecast_data = df_window[df_window.index > pd.Timestamp(current_date)][storage_column_name].dropna()
                delta_data = df_window['Delta_Change'].dropna()
                all_dates, hist_values, fore_values, delta_values = [], [], [], []
                for date, value in historical_data.items():
                    all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(float(value)); fore_values.append(None)
                if not historical_data.empty and hist_values: fore_values[-1] = hist_values[-1]
                for date, value in forecast_data.items():
                    all_dates.append(date.strftime('%Y-%m-%d')); hist_values.append(None); fore_values.append(float(value))
                for date_str in all_dates:
                    delta_values.append(float(delta_data[pd.Timestamp(date_str)]) if pd.Timestamp(date_str) in delta_data.index else None)
                regional_chart_data[region] = {'labels': json.dumps(all_dates), 'historical': json.dumps(hist_values), 'forecast': json.dumps(fore_values), 'delta': json.dumps(delta_values)}
                print(f"    Forecast chart created for {region}.")
            except Exception as e: print(f"    Error processing forecast data for {region}: {e}")
            try:
                stats_path = os.path.join(base_folder, file_info['stats'])
                print(f"  Loading {region} historical stats from {file_info['stats']}...")
                df_stats = pd.read_csv(stats_path)
                required_cols = ['Week', 'Delta_Avg', 'Delta_Min', 'Delta_Max']
                if not all(col in df_stats.columns for col in required_cols): continue
                regional_stats_data[region] = {'labels': json.dumps(df_stats['Week'].tolist()), 'avg': json.dumps(df_stats['Delta_Avg'].tolist()), 'min': json.dumps(df_stats['Delta_Min'].tolist()), 'max': json.dumps(df_stats['Delta_Max'].tolist())}
                print(f"    Historical stats chart created for {region}.")
            except FileNotFoundError: print(f"    WARNING: Historical stats file not found for {region} at {stats_path}. Skipping stats plot.")
            except Exception as e: print(f"    Error processing historical stats for {region}: {e}")

        # --- 5. Prepare Data for HTML ---
        print("\nPreparing data for HTML report...")
        
        # Date ranges for summaries
        last_date = df_model.index[-1]
        current_week_start = last_date - timedelta(days=6)
        w1_start, w1_end = last_date + timedelta(days=1), last_date + timedelta(days=7)
        w2_start, w2_end = last_date + timedelta(days=8), last_date + timedelta(days=14)

        # --- Current/Forecast Summary ---
        pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current = "N/A", "N/A", "N/A"
        pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1 = "N/A", "N/A", "N/A"
        pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2 = "N/A", "N/A", "N/A"

        if pipe_data_loaded and df_pipe is not None:
            # Since df_pipe is weekly, we find the closest date on or before the period end
            def get_pipe_week_data(end_date, df_pipe):
                try:
                    # Find the last available data point on or before the end_date
                    row = df_pipe.loc[df_pipe.index <= end_date].iloc[-1]
                    storage = row['Lower_48_Total']
                    delta = row['Delta_Change']
                    return f"{storage:.2f} (End of Week)", f"{delta/7:.2f} (Avg)", f"{delta:.2f} (Sum)"
                except (IndexError, KeyError):
                    return "N/A", "N/A", "N/A"

            pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current = get_pipe_week_data(last_date, df_pipe)
            pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1 = get_pipe_week_data(w1_end, df_pipe)
            pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2 = get_pipe_week_data(w2_end, df_pipe)

        summary_df = pd.DataFrame({
            'Metric': ['Total Consumption', 'Total Supply', 'CDD', 'HDD', 'Power Burns (Bcf/d)', 'Storage Level (Bcf)', 'Storage Injection/Withdrawal (Bcf/d)', 'Pipe Model Delta (Bcf)'],
            'Current Week': [
                f"{df_model['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{df_model['Total Supply'].tail(7).mean():.2f} (Avg)",
                f"{df_model['CDD'].tail(7).sum():.2f} (Sum)", f"{df_model['HDD'].tail(7).sum():.2f} (Sum)",
                f"{df_model['Power Burns (Bcf/d)'].abs().tail(7).mean():.2f} (Avg)",
                pipe_storage_current, pipe_delta_avg_current, pipe_delta_sum_current
            ],
            'Week 1 Forecast': [
                f"{forecast_df_short['Total Consumption'].head(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].head(7).mean():.2f} (Avg)",
                f"{forecast_df_short['CDD'].head(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].head(7).sum():.2f} (Sum)",
                f"{forecast_df_short['Power Burns (Bcf/d)'].head(7).mean():.2f} (Avg)",
                pipe_storage_w1, pipe_delta_avg_w1, pipe_delta_sum_w1
            ],
            'Week 2 Forecast': [
                f"{forecast_df_short['Total Consumption'].tail(7).mean():.2f} (Avg)", f"{forecast_df_short['Total Supply'].tail(7).mean():.2f} (Avg)",
                f"{forecast_df_short['CDD'].tail(7).sum():.2f} (Sum)", f"{forecast_df_short['HDD'].tail(7).sum():.2f} (Sum)",
                f"{forecast_df_short['Power Burns (Bcf/d)'].tail(7).mean():.2f} (Avg)",
                pipe_storage_w2, pipe_delta_avg_w2, pipe_delta_sum_w2
            ]
        })
        forecast_display_df = forecast_df_short.round(2); forecast_display_df.index = forecast_display_df.index.strftime('%Y-%m-%d')
        
        # --- 5b. Prepare Data for LAST YEAR'S Summary Table ---
        summary_df_ly = pd.DataFrame()
        try:
            print("Preparing last year's summary data...")
            last_year_date = last_date - pd.DateOffset(years=1)
            ly_current_start = last_year_date - timedelta(days=6)
            ly_w1_start, ly_w1_end = last_year_date + timedelta(days=1), last_year_date + timedelta(days=7)
            ly_w2_start, ly_w2_end = last_year_date + timedelta(days=8), last_year_date + timedelta(days=14)

            # Add Total Consumption and Total Supply to df_full if not present
            if 'Total Consumption' not in df_full.columns:
                df_full['Total Consumption'] = df_full[consumption_cols].sum(axis=1).abs()
            if 'Total Supply' not in df_full.columns:
                df_full['Total Supply'] = df_full['production_bcf'] + df_full['LNG_IMPORTS_BCF'] + df_full['CAD_NET_FLOW_BCF']

            df_ly_current = df_full.loc[ly_current_start:last_year_date]
            df_ly_w1 = df_full.loc[ly_w1_start:ly_w1_end]
            df_ly_w2 = df_full.loc[ly_w2_start:ly_w2_end]

            ly_pipe_storage_current, ly_pipe_delta_avg_current, ly_pipe_delta_sum_current = get_pipe_week_data(last_year_date, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
            ly_pipe_storage_w1, ly_pipe_delta_avg_w1, ly_pipe_delta_sum_w1 = get_pipe_week_data(ly_w1_end, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")
            ly_pipe_storage_w2, ly_pipe_delta_avg_w2, ly_pipe_delta_sum_w2 = get_pipe_week_data(ly_w2_end, df_pipe) if pipe_data_loaded else ("N/A", "N/A", "N/A")

            summary_df_ly = pd.DataFrame({
                'Metric': summary_df['Metric'].tolist(),
                f'Same Week Last Year ({ly_current_start.strftime("%Y-%m-%d")} to {last_year_date.strftime("%Y-%m-%d")})': [
                    f"{df_ly_current['Total Consumption'].mean():.2f} (Avg)", f"{df_ly_current['Total Supply'].mean():.2f} (Avg)",
                    f"{df_ly_current['CDD'].sum():.2f} (Sum)", f"{df_ly_current['HDD'].sum():.2f} (Sum)",
                    f"{df_ly_current['Power Burns (Bcf/d)'].abs().mean():.2f} (Avg)",
                    ly_pipe_storage_current, ly_pipe_delta_avg_current, ly_pipe_delta_sum_current
                ],
                f'Equivalent Week 1 ({ly_w1_start.strftime("%Y-%m-%d")} to {ly_w1_end.strftime("%Y-%m-%d")})': [
                    f"{df_ly_w1['Total Consumption'].mean():.2f} (Avg)", f"{df_ly_w1['Total Supply'].mean():.2f} (Avg)",
                    f"{df_ly_w1['CDD'].sum():.2f} (Sum)", f"{df_ly_w1['HDD'].sum():.2f} (Sum)",
                    f"{df_ly_w1['Power Burns (Bcf/d)'].abs().mean():.2f} (Avg)",
                    ly_pipe_storage_w1, ly_pipe_delta_avg_w1, ly_pipe_delta_sum_w1
                ],
                f'Equivalent Week 2 ({ly_w2_start.strftime("%Y-%m-%d")} to {ly_w2_end.strftime("%Y-%m-%d")})': [
                    f"{df_ly_w2['Total Consumption'].mean():.2f} (Avg)", f"{df_ly_w2['Total Supply'].mean():.2f} (Avg)",
                    f"{df_ly_w2['CDD'].sum():.2f} (Sum)", f"{df_ly_w2['HDD'].sum():.2f} (Sum)",
                    f"{df_ly_w2['Power Burns (Bcf/d)'].abs().mean():.2f} (Avg)",
                    ly_pipe_storage_w2, ly_pipe_delta_avg_w2, ly_pipe_delta_sum_w2
                ]
            })
        except Exception as e:
            print(f"Could not generate last year's summary. Data might be missing for the period. Error: {e}")

        # --- 6. Prepare L48 Chart Data ---
        start_plot_date = datetime.strptime('2024-04-01', '%Y-%m-%d'); end_plot_date = datetime.strptime('2026-11-01', '%Y-%m-%d')
        df_plot = df_full.loc[start_plot_date:end_plot_date].copy()
        storage_plot_series = df_plot['Storage Level (Bcf)']
        chart_labels = storage_plot_series.index.strftime('%Y-%m-%d').tolist()
        chart_data = json.dumps([val if pd.notna(val) else None for val in storage_plot_series.round(2)])
        
        pipe_chart_data = "[]"; pipe_delta_chart_data = "[]"
        if pipe_data_loaded:
            pipe_plot_series = df_pipe['Lower_48_Total'].loc[start_plot_date:end_plot_date]
            aligned_pipe_series = pipe_plot_series.reindex(storage_plot_series.index, method='ffill')
            pipe_chart_data = json.dumps([val if pd.notna(val) else None for val in aligned_pipe_series.round(2)])
            pipe_delta_series = df_pipe['Delta_Change']
            aligned_pipe_deltas = pipe_delta_series.reindex(storage_plot_series.index, method='ffill')
            pipe_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in aligned_pipe_deltas.round(2)])

        main_storage_series = df_full['Storage Level (Bcf)'].dropna()
        main_weekly_deltas = main_storage_series.resample('W-FRI').last().diff()
        aligned_main_deltas = main_weekly_deltas.reindex(storage_plot_series.index, method='ffill')
        main_delta_chart_data = json.dumps([val if pd.notna(val) else None for val in aligned_main_deltas.round(2)])
            
        plot_consumption_cols = ['commercial_bcf', 'industrial_bcf', 'residential_bcf', 'Power Burns (Bcf/d)', 'LNG_EXPORTS_BCF', 'MEX_EXPORTS_BCF']
        df_plot['Total Consumption'] = df_plot[plot_consumption_cols].sum(axis=1).abs()
        df_plot['Total Supply'] = df_plot['production_bcf'] + df_plot['LNG_IMPORTS_BCF'] + df_plot['CAD_NET_FLOW_BCF']
        df_plot['Surplus/Deficit'] = df_plot['Total Supply'] - df_plot['Total Consumption']
        surplus_plot_series = df_plot['Surplus/Deficit']
        surplus_chart_data = json.dumps([val if pd.notna(val) else None for val in surplus_plot_series.round(2)])
        start_summer_date = datetime.strptime('2025-04-01', '%Y-%m-%d'); end_summer_date = datetime.strptime('2025-10-31', '%Y-%m-%d')
        df_summer = df_plot.loc[start_summer_date:end_summer_date].copy()
        df_summer['power_intensity_CDD'] = df_summer['Power Burns (Bcf/d)'] / df_summer['CDD'].replace(0, np.nan)
        intensity_plot_series = df_summer['power_intensity_CDD']
        intensity_chart_labels = intensity_plot_series.index.strftime('%Y-%m-%d').tolist()
        intensity_chart_data = json.dumps([val if pd.notna(val) and np.isfinite(val) else None for val in intensity_plot_series.round(2)])
        dispersion_data = []; dispersion_forecast_data = []
        for index, row in df_summer.iterrows():
            if pd.notna(row['CDD']) and pd.notna(row['Power Burns (Bcf/d)']): dispersion_data.append({'x': round(row['CDD'], 2), 'y': round(row['Power Burns (Bcf/d)'], 2)})
        for index, row in forecast_df_short.iterrows():
            if start_summer_date <= index <= end_summer_date:
                if pd.notna(row['CDD']) and pd.notna(row['Power Burns (Bcf/d)']): dispersion_forecast_data.append({'x': round(row['CDD'], 2), 'y': -round(row['Power Burns (Bcf/d)'], 2)})
        dispersion_chart_data = json.dumps(dispersion_data); dispersion_forecast_chart_data = json.dumps(dispersion_forecast_data)

        # --- 7. Generate HTML Report ---
        print("Generating HTML report...")
        regional_charts_html, regional_scripts = "", ""
        for idx, region in enumerate(regional_files.keys()):
            regional_charts_html += f"<h2>{region} Analysis</h2>"
            if region in regional_chart_data: regional_charts_html += f'<h4>Storage Level & Weekly Change (Forecast)</h4><div class="chart-container"><canvas id="regionalChart{idx}"></canvas></div>'
            if region in regional_stats_data: regional_charts_html += f'<h4>Historical Weekly Change Distribution (5-Year)</h4><div class="chart-container"><canvas id="regionalStatsChart{idx}"></canvas></div>'
            if region in regional_chart_data:
                data = regional_chart_data[region]
                regional_scripts += f"""const deltaData{idx} = {data['delta']}; const deltaColors{idx} = deltaData{idx}.map(v => v === null ? 'rgba(0,0,0,0)' : v >= 0 ? 'rgba(46, 204, 113, 0.7)' : 'rgba(231, 76, 60, 0.7)'); new Chart(document.getElementById('regionalChart{idx}'), {{ data: {{ labels: {data['labels']}, datasets: [ {{ type: 'line', label: 'Historical Storage (Bcf)', data: {data['historical']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'line', label: 'Forecast Storage (Bcf)', data: {data['forecast']}, borderColor: 'rgb(52, 152, 219)', borderWidth: 3, borderDash: [6, 6], pointRadius: 0, yAxisID: 'y', spanGaps: false }}, {{ type: 'bar', label: 'Weekly Delta (Bcf)', data: deltaData{idx}, backgroundColor: deltaColors{idx}, yAxisID: 'y1', barThickness: 8 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Storage Level and Weekly Change' }}, legend: {{ display: true, position: 'top' }} }}, scales: {{ x: {{ ticks: {{ maxRotation: 45, minRotation: 45, maxTicksLimit: 12 }} }}, y: {{ type: 'linear', display: true, position: 'left', title: {{ display: true, text: 'Storage Level (Bcf)' }} }}, y1: {{ type: 'linear', display: true, position: 'right', title: {{ display: true, text: 'Weekly Change (Bcf)' }}, grid: {{ drawOnChartArea: false }} }} }} }} }});"""
            if region in regional_stats_data:
                stats = regional_stats_data[region]
                regional_scripts += f"""new Chart(document.getElementById('regionalStatsChart{idx}'), {{ type: 'line', data: {{ labels: {stats['labels']}, datasets: [ {{ label: 'Max Change', data: {stats['max']}, borderColor: 'rgba(189, 195, 199, 0.5)', pointRadius: 0, borderWidth: 1, fill: false }}, {{ label: 'Min/Max Range', data: {stats['min']}, borderColor: 'rgba(189, 195, 199, 0.5)', backgroundColor: 'rgba(189, 195, 199, 0.2)', pointRadius: 0, borderWidth: 1, fill: '-1' }}, {{ label: 'Avg Change', data: {stats['avg']}, borderColor: 'rgb(44, 62, 80)', borderWidth: 2.5, pointRadius: 0, fill: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, interaction: {{ mode: 'index', intersect: false }}, plugins: {{ title: {{ display: true, text: '{region} Historical Range of Weekly Changes (Bcf)' }}, legend: {{ labels: {{ filter: function(item, chart) {{ return !item.text.includes('Max Change'); }} }} }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Week of Year' }} }}, y: {{ title: {{ display: true, text: 'Weekly Change (Bcf)' }} }} }} }} }});"""
        
        html_content = f"""
        <html>
        <head>
            <title>Natural Gas Market Update</title>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f8f9fa; color: #333; }}
                h1, h2 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px;}}
                h3, h4 {{ color: #34495e; margin-top: 25px; }}
                table {{ border-collapse: collapse; width: 100%; margin-bottom: 30px; box-shadow: 0 2px 3px rgba(0,0,0,0.1); }}
                th, td {{ border: 1px solid #dddddd; text-align: left; padding: 12px; }}
                th {{ background-color: #3498db; color: white; }}
                tr:nth-child(even) {{ background-color: #f2f2f2; }}
                .container {{ max-width: 1400px; margin: auto; background-color: white; padding: 25px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }}
                .header {{ text-align: center; margin-bottom: 20px; }}
                .note {{ font-style: italic; color: #555; margin-top: -15px; margin-bottom: 20px;}}
                .chart-container {{ position: relative; height:50vh; width:100%; margin-top: 15px; margin-bottom: 40px; }}
                .regional-section {{ margin-top: 50px; padding-top: 20px; border-top: 3px solid #3498db; }}
                .footer {{ margin-top: 30px; font-size: 0.8em; color: #7f8c8d; text-align: center; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header"><h1>Natural Gas Market Update</h1><h2>A Two-Week Forward Look with Regional Analysis</h2></div>
                <p><b>Report Generated For Date:</b> {pd.to_datetime(current_date).strftime('%Y-%m-%d')}</p>
                <p>This report provides a two-week forecast for key U.S. natural gas fundamentals. The forecast begins the day after the last known data point ({last_date.strftime('%Y-%m-%d')}).</p>
                
                <h2>Key Projections Summary</h2>{summary_df.to_html(index=False, justify='left', classes='table table-striped')}
                {'<h2>Last Year Comparison</h2>' + summary_df_ly.to_html(index=False, justify='left', classes='table table-striped') if not summary_df_ly.empty else ''}
                <h2>Detailed Daily Forecast (14 Days)</h2>{forecast_display_df.to_html(justify='left', classes='table table-striped')}
                
                <h2>U.S. Lower 48 Analysis</h2>
                <h4>Storage Trajectory</h4><div class="chart-container"><canvas id="storageChart"></canvas></div>
                <h4>Weekly Storage Change</h4><div class="chart-container"><canvas id="storageDeltaChart"></canvas></div>
                <h4>Supply/Demand Balance (Surplus/Deficit)</h4><div class="chart-container"><canvas id="surplusChart"></canvas></div>
                <h4>Power Burn Intensity (vs. CDD)</h4><p class="note">This chart shows Power Burns divided by CDD for the cooling season (Apr 1 - Oct 31).</p><div class="chart-container"><canvas id="intensityChart"></canvas></div>
                <h4>Power Burn Dispersion Model</h4><p class="note">This scatter plot shows the relationship between daily CDDs and Power Burns for the summer season (Apr 1 - Oct 31, 2025).</p><div class="chart-container"><canvas id="dispersionChart"></canvas></div>
                
                <div class="regional-section">
                    <h1>Regional Analysis</h1>
                    <p class="note">Each region includes a forward-looking storage forecast and a historical view of the 5-year range for weekly storage changes.</p>
                    {regional_charts_html}
                </div>
                
                <div class="footer"><p><b>Disclaimer:</b> This forecast is generated programmatically for informational purposes only and is not investment advice.</p></div>
            </div>
            <script>
                const chartLabels = {json.dumps(chart_labels)};
                new Chart(document.getElementById('storageChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [ {{ label: 'Storage Level (Bcf)', data: {chart_data}, borderColor: 'rgb(52, 152, 219)', backgroundColor: 'rgba(52, 152, 219, 0.1)', borderWidth: 2.5, pointRadius: 1.5, spanGaps: false }}, {{ label: 'Storage_Modelling', data: {pipe_chart_data}, borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'U.S. Natural Gas Storage Levels (Bcf)' }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Date' }} }}, y: {{ title: {{ display: true, text: 'Storage Level (Bcf)' }} }} }} }} }});
                
                new Chart(document.getElementById('storageDeltaChart'), {{
                    type: 'line',
                    data: {{
                        labels: chartLabels,
                        datasets: [
                            {{
                                label: 'Storage Level Change (Bcf)', data: {main_delta_chart_data},
                                borderColor: 'rgb(52, 152, 219)', backgroundColor: 'rgba(52, 152, 219, 0.1)',
                                borderWidth: 2, pointRadius: 1.5, tension: 0.1
                            }},
                            {{
                                label: 'Storage_Modelling Change (Bcf)', data: {pipe_delta_chart_data},
                                borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)',
                                borderWidth: 2, pointRadius: 1.5, tension: 0.1
                            }}
                        ]
                    }},
                    options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Weekly Storage Change (Bcf)' }} }}, scales: {{ x: {{ ticks: {{ maxTicksLimit: 12, maxRotation: 45, minRotation: 45 }} }}, y: {{ title: {{ display: true, text: 'Change (Bcf)' }} }} }} }}
                }});

                new Chart(document.getElementById('surplusChart'), {{ type: 'line', data: {{ labels: chartLabels, datasets: [{{ label: 'Daily Surplus/Deficit (Bcf/d)', data: {surplus_chart_data}, borderColor: 'rgb(46, 204, 113)', backgroundColor: 'rgba(46, 204, 113, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }}] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Daily Market Balance (Supply - Consumption)' }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Date' }} }}, y: {{ title: {{ display: true, text: 'Bcf/d' }} }} }} }} }});
                new Chart(document.getElementById('intensityChart'), {{ type: 'line', data: {{ labels: {json.dumps(intensity_chart_labels)}, datasets: [{{ label: 'Power Intensity (Burns/CDD)', data: {intensity_chart_data}, borderColor: 'rgb(231, 76, 60)', backgroundColor: 'rgba(231, 76, 60, 0.1)', borderWidth: 2, pointRadius: 1.5, spanGaps: false }}] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Power Burn Intensity (Power Burns / CDD)' }} }}, scales: {{ x: {{ title: {{ display: true, text: 'Date' }} }}, y: {{ title: {{ display: true, text: 'Bcf per CDD' }} }} }} }} }});
                new Chart(document.getElementById('dispersionChart'), {{ type: 'scatter', data: {{ datasets: [ {{ label: 'Historical Daily Power Burn vs. CDD', data: {dispersion_chart_data}, backgroundColor: 'rgba(155, 89, 182, 0.6)', borderColor: 'rgb(155, 89, 182)', pointRadius: 5 }}, {{ label: 'Forecast Power Burn vs. CDD (14-Day)', data: {dispersion_forecast_chart_data}, backgroundColor: 'rgba(231, 76, 60, 0.9)', borderColor: 'rgb(231, 76, 60)', pointStyle: 'triangle', radius: 8, rotation: 0 }} ] }}, options: {{ responsive: true, maintainAspectRatio: false, plugins: {{ title: {{ display: true, text: 'Power Burns vs. CDD (Summer 2025)' }}, tooltip: {{ callbacks: {{ label: function(context) {{ return `(CDD: ${{context.raw.x}}, Burns: ${{context.raw.y}} Bcf)`; }} }} }} }}, scales: {{ x: {{ type: 'linear', position: 'bottom', title: {{ display: true, text: 'Cooling Degree Days (CDD)' }} }}, y: {{ title: {{ display: true, text: 'Power Burns (Bcf/d)' }} }} }} }} }});
                
                {regional_scripts}
            </script>
        </body>
        </html>
        """
        
        output_filename = os.path.join(base_folder, "natural_gas_forecast.html")
        
        with open(output_filename, "w", encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"\nSuccessfully generated '{output_filename}'. You can open this file in a web browser.")

    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found. Please ensure the file for today's date exists.")
    except IndexError as e:
        print(f"Error processing data. Check if files have sufficient rows. Details: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    generate_forecast_html()