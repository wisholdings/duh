import os
import sys
import logging
import numpy as np
import pandas as pd
from datetime import date, datetime, timedelta
import calendar
import httpx
import ssl

# ==============================================================================
# WARNING: MONKEY-PATCH TO DISABLE SSL VERIFICATION
# This is insecure and should only be used in a trusted environment for debugging.
# This code overrides the default behavior of httpx to disable SSL checks.
# ==============================================================================
_original_httpx_client_init = httpx.Client.__init__

def new_httpx_client_init(self, *args, **kwargs):
    kwargs['verify'] = False
    _original_httpx_client_init(self, *args, **kwargs)

httpx.Client.__init__ = new_httpx_client_init
# ==============================================================================


# Import the correct Synmax Hyperion v4 client
try:
    from synmax.hyperion.v4 import HyperionApiClient
except ImportError:
    print("Error: synmax.hyperion.v4 not found.")
    print("Please ensure the Synmax Hyperion API client is installed.")
    print("You can install it using: pip install synmax-api-python-client")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Constants
ACCESS_TOKEN = (
"5be59ebb-784e-4603-84ff-aa7c04481c3a"
)

# Output directory base path
OUTPUT_BASE_PATH = r"D:\EIA_STACK\Pricing_RL"

# Date range for historical data
START_DATE = '2022-01-01'
END_DATE = date.today().strftime('%Y-%m-%d')
FORECAST_END_DATE = (date.today() + timedelta(days=700)).strftime('%Y-%m-%d')


def expand_monthly_to_daily(df, value_column='DRY_GAS_BCF_DAY'):
    """
    Expand monthly data to daily data.
    Assumes the DATE column represents the month (first day of month).
    Preserves all other columns including REGION and SUB_REGION.
    """
    if df.empty:
        return df
    
    logging.info(f"Expanding {len(df)} monthly records to daily...")
    
    daily_records = []
    
    for _, row in df.iterrows():
        # Get the month date
        month_date = pd.to_datetime(row['DATE'])
        year = month_date.year
        month = month_date.month
        
        # Get number of days in this month
        days_in_month = calendar.monthrange(year, month)[1]
        
        # The value is already BCF/day, so keep it as is for each day
        daily_value = row[value_column]
        
        # Create a record for each day in the month
        for day in range(1, days_in_month + 1):
            daily_record = row.copy()
            daily_record['DATE'] = datetime(year, month, day)
            daily_record[value_column] = daily_value
            daily_records.append(daily_record)
    
    expanded_df = pd.DataFrame(daily_records)
    logging.info(f"Expanded to {len(expanded_df)} daily records")
    
    return expanded_df


def fetch_daily_production(client):
    """
    Fetch daily production data from 2022-01-01 to present.
    """
    try:
        logging.info(f"Fetching daily production data from {START_DATE} to {END_DATE}...")
        
        # Call the API
        result = client.daily_production()
        
        # Convert the generator/iterator to a list
        data_list = []
        record_count = 0
        
        for record in result:
            data_list.append(record)
            record_count += 1
            if record_count <= 2:
                logging.info(f"Sample record {record_count}: {record}")
        
        logging.info(f"Total records collected: {record_count}")
        
        if not data_list:
            logging.warning("No records found in result")
            return pd.DataFrame()
        
        # Convert to DataFrame
        df = pd.DataFrame(data_list)
        logging.info(f"Created DataFrame with shape: {df.shape}")
        logging.info(f"Columns: {df.columns.tolist()}")
        
        # Filter for date range
        if 'date_prod' in df.columns:
            df['date_prod'] = pd.to_datetime(df['date_prod'])
            start_dt = pd.to_datetime(START_DATE)
            end_dt = pd.to_datetime(END_DATE)
            df = df[(df['date_prod'] >= start_dt) & (df['date_prod'] <= end_dt)]
            logging.info(f"Filtered to {len(df)} records between {START_DATE} and {END_DATE}")
        
        # Rename columns
        rename_map = {
            'date_prod': 'DATE',
            'prod_dry_gas_bcf_day': 'DRY_GAS_BCF_DAY',
            'region_natgas': 'REGION',
            'sub_region_natgas': 'SUB_REGION'
        }
        
        df.rename(columns=rename_map, inplace=True)
        df['DATA_SOURCE'] = 'historical'
        
        return df
        
    except Exception as e:
        logging.error(f"Error in fetch_daily_production: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()


def fetch_production_forecast(client):
    """
    Fetch long-term production forecast data and expand to daily if needed.
    """
    try:
        logging.info("Fetching long-term production forecast...")
        
        # Set date range
        today = date.today()
        date_min = today.strftime('%Y-%m-%d')
        date_max = FORECAST_END_DATE
        
        logging.info(f"Requesting forecast from {date_min} to {date_max}")
        
        # Call the longtermforecast endpoint
        try:
            if hasattr(client, 'long_term_forecast'):
                result = client.long_term_forecast(
                    date_prod_min=date_min,
                    date_prod_max=date_max
                )
            elif hasattr(client, 'longtermforecast'):
                result = client.longtermforecast(
                    date_prod_min=date_min,
                    date_prod_max=date_max
                )
            else:
                logging.warning("longtermforecast method not found on client")
                return pd.DataFrame()
                
        except Exception as e:
            logging.error(f"Error calling longtermforecast: {e}")
            return pd.DataFrame()
        
        # Process result
        data_list = []
        record_count = 0
        
        for record in result:
            data_list.append(record)
            record_count += 1
            if record_count <= 2:
                logging.info(f"Sample forecast record {record_count}: {record}")
        
        logging.info(f"Total forecast records: {record_count}")
        
        if not data_list:
            logging.warning("No forecast records found")
            return pd.DataFrame()
        
        # Convert to DataFrame
        df = pd.DataFrame(data_list)
        logging.info(f"Forecast DataFrame shape: {df.shape}")
        logging.info(f"Forecast columns: {df.columns.tolist()}")
        
        # Rename columns
        rename_map = {
            'date_prod': 'DATE',
            'prod_dry_gas_bcf_day': 'DRY_GAS_BCF_DAY',
            'region_natgas': 'REGION',
            'sub_region_natgas': 'SUB_REGION'
        }
        
        df.rename(columns=rename_map, inplace=True)
        
        # Convert date
        if 'DATE' in df.columns:
            df['DATE'] = pd.to_datetime(df['DATE'])
            
            # Check if data is monthly (only has first day of each month)
            dates = df['DATE'].dt.day.unique()
            if len(dates) == 1 and dates[0] == 1:
                logging.info("Forecast data appears to be monthly - expanding to daily...")
                df = expand_monthly_to_daily(df)
            
            # Filter for future only
            df = df[df['DATE'] > pd.Timestamp(today)]
            logging.info(f"Filtered to {len(df)} future records")
        
        df['DATA_SOURCE'] = 'forecast'
        
        return df
        
    except Exception as e:
        logging.error(f"Error in fetch_production_forecast: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()


def ensure_continuous_dates_by_region(df):
    """
    Ensure continuous daily dates for each region/sub-region combination.
    """
    if df.empty:
        return df
    
    logging.info("Ensuring continuous daily dates by region...")
    
    # Get unique combinations of region and sub_region
    if 'SUB_REGION' in df.columns:
        group_cols = ['REGION', 'SUB_REGION']
    else:
        group_cols = ['REGION']
    
    all_dfs = []
    
    for group_values, group_df in df.groupby(group_cols):
        # Get date range for this group
        min_date = group_df['DATE'].min()
        max_date = group_df['DATE'].max()
        
        # Create complete date range
        date_range = pd.date_range(start=min_date, end=max_date, freq='D')
        
        # Create base dataframe with all dates
        df_complete = pd.DataFrame({'DATE': date_range})
        
        # Add the group columns
        if len(group_cols) == 2:
            df_complete['REGION'] = group_values[0]
            df_complete['SUB_REGION'] = group_values[1]
        else:
            df_complete['REGION'] = group_values
        
        # Merge with actual data
        df_merged = pd.merge(df_complete, group_df.drop(columns=group_cols), on='DATE', how='left')
        
        # Forward fill missing values
        df_merged['DRY_GAS_BCF_DAY'] = df_merged['DRY_GAS_BCF_DAY'].ffill()
        df_merged['DATA_SOURCE'] = df_merged['DATA_SOURCE'].ffill()
        
        # Backfill if needed
        if df_merged['DRY_GAS_BCF_DAY'].isna().any():
            df_merged['DRY_GAS_BCF_DAY'] = df_merged['DRY_GAS_BCF_DAY'].bfill()
            df_merged['DATA_SOURCE'] = df_merged['DATA_SOURCE'].bfill()
        
        all_dfs.append(df_merged)
    
    # Combine all groups
    df_final = pd.concat(all_dfs, ignore_index=True)
    
    gaps_filled = len(df_final) - len(df)
    if gaps_filled > 0:
        logging.info(f"Filled {gaps_filled} gaps across all regions")
    
    return df_final


def aggregate_by_region(df):
    """
    Aggregate the sub-region data to region level.
    """
    if df.empty:
        return df
    
    required_cols = ['DATE', 'REGION', 'DRY_GAS_BCF_DAY']
    if not all(col in df.columns for col in required_cols):
        logging.warning(f"Missing required columns. Have: {df.columns.tolist()}")
        return df
    
    logging.info("Aggregating by region...")
    
    # Group by date, region, and data source if present
    group_cols = ['DATE', 'REGION']
    if 'DATA_SOURCE' in df.columns:
        group_cols.append('DATA_SOURCE')
    
    df_agg = df.groupby(group_cols).agg({
        'DRY_GAS_BCF_DAY': 'sum'
    }).reset_index()
    
    logging.info(f"Aggregated from {len(df)} to {len(df_agg)} records")
    
    # Show summary
    if 'REGION' in df_agg.columns:
        summary = df_agg.groupby('REGION')['DRY_GAS_BCF_DAY'].mean().round(3)
        logging.info("Regional averages (BCF/day):")
        for region, avg in summary.items():
            logging.info(f"  {region}: {avg}")
    
    return df_agg


def save_to_folder(df_to_save, folder_name, filename="synmax_production_with_forecast.csv"):
    """
    Helper function to save data to a specific folder.
    """
    region_dir = os.path.join(OUTPUT_BASE_PATH, folder_name)
    os.makedirs(region_dir, exist_ok=True)
    
    # Ensure continuous dates
    date_range = pd.date_range(start=df_to_save['DATE'].min(), end=df_to_save['DATE'].max(), freq='D')
    df_continuous = pd.DataFrame({'DATE': date_range})
    df_continuous = pd.merge(df_continuous, df_to_save, on='DATE', how='left')
    
    # Fill missing values
    df_continuous['DRY_GAS_BCF_DAY'] = df_continuous['DRY_GAS_BCF_DAY'].ffill().bfill()
    if 'DATA_SOURCE' in df_continuous.columns:
        df_continuous['DATA_SOURCE'] = df_continuous['DATA_SOURCE'].ffill().bfill()
    if 'REGION' in df_to_save.columns:
        df_continuous['REGION'] = df_to_save['REGION'].iloc[0]
    
    # Select columns
    save_cols = ['DATE', 'DRY_GAS_BCF_DAY']
    if 'DATA_SOURCE' in df_continuous.columns:
        save_cols.append('DATA_SOURCE')
    
    # Save file
    file_path = os.path.join(region_dir, filename)
    df_continuous[save_cols].to_csv(file_path, index=False)
    
    return len(df_continuous), file_path


def save_regional_data(df_historical, df_forecast):
    """
    Save production data to regional CSV files with continuous daily dates.
    Special handling for SOUTHCENTRAL to save to both SOUTHCENTRAL and SOUTHCENTRAL_SALTS.
    """
    # Combine data
    if not df_historical.empty and not df_forecast.empty:
        df_combined = pd.concat([df_historical, df_forecast], ignore_index=True)
        logging.info(f"Combined {len(df_historical)} historical + {len(df_forecast)} forecast records")
    elif not df_historical.empty:
        df_combined = df_historical
        logging.info("Using historical data only")
    elif not df_forecast.empty:
        df_combined = df_forecast
        logging.info("Using forecast data only")
    else:
        logging.warning("No data to save")
        return []
    
    # Ensure continuous dates BEFORE aggregation
    df_combined = ensure_continuous_dates_by_region(df_combined)
    
    # Aggregate
    df_region = aggregate_by_region(df_combined)
    
    if df_region.empty:
        logging.warning("No aggregated data to save")
        return []
    
    # Region mapping - now maps to lists to support multiple destinations
    region_folder_map = {
        'midwest': ['MIDWEST'],
        'west': ['PACIFIC'],
        'gulf': ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS'],  # Save to both folders
        'northeast': ['EAST'],
        'southeast': ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS']  # Also save to both folders
    }
    
    regions = df_region['REGION'].unique()
    logging.info(f"Saving {len(regions)} regions...")
    
    folders_saved = set()
    southcentral_data = {}  # Track SOUTHCENTRAL data for combining
    
    for region in regions:
        region_df = df_region[df_region['REGION'] == region].copy()
        region_df = region_df.sort_values('DATE')
        
        folder_list = region_folder_map.get(region.lower(), [region.upper()])
        
        # Handle regions that contribute to SOUTHCENTRAL
        if region.lower() in ['gulf', 'southeast']:
            # Store data for later combining
            southcentral_data[region.lower()] = region_df
            
            # If we have both gulf and southeast, combine them
            if len(southcentral_data) == 2:
                logging.info("Combining gulf and southeast data for SOUTHCENTRAL...")
                
                # Get both dataframes
                gulf_df = southcentral_data['gulf']
                southeast_df = southcentral_data['southeast']
                
                # Create date range covering both
                all_dates = pd.date_range(
                    start=min(gulf_df['DATE'].min(), southeast_df['DATE'].min()),
                    end=max(gulf_df['DATE'].max(), southeast_df['DATE'].max()),
                    freq='D'
                )
                
                df_dates = pd.DataFrame({'DATE': all_dates})
                
                # Merge both datasets
                df_merged = pd.merge(df_dates, gulf_df, on='DATE', how='left', suffixes=('', '_gulf'))
                df_merged = pd.merge(df_merged, southeast_df, on='DATE', how='left', suffixes=('', '_southeast'))
                
                # Combine values
                df_merged['DRY_GAS_BCF_DAY'] = (
                    df_merged['DRY_GAS_BCF_DAY'].fillna(0) + 
                    df_merged['DRY_GAS_BCF_DAY_southeast'].fillna(0)
                )
                
                # Combine data sources
                if 'DATA_SOURCE' in df_merged.columns:
                    df_merged['DATA_SOURCE'] = df_merged['DATA_SOURCE'].combine_first(
                        df_merged.get('DATA_SOURCE_southeast', pd.Series())
                    )
                
                # Keep only needed columns
                keep_cols = ['DATE', 'DRY_GAS_BCF_DAY']
                if 'DATA_SOURCE' in df_merged.columns:
                    keep_cols.append('DATA_SOURCE')
                df_merged = df_merged[keep_cols]
                
                # Save to both SOUTHCENTRAL folders
                for folder_name in ['SOUTHCENTRAL', 'SOUTHCENTRAL_SALTS']:
                    n_records, file_path = save_to_folder(df_merged, folder_name)
                    logging.info(f"Saved combined gulf+southeast to {folder_name}/ ({n_records} records)")
                    folders_saved.add(folder_name)
            else:
                # Only have one region so far, save it to both folders
                for folder_name in folder_list:
                    n_records, file_path = save_to_folder(region_df, folder_name)
                    logging.info(f"Saved {region} to {folder_name}/ ({n_records} records)")
                    folders_saved.add(folder_name)
        else:
            # Non-SOUTHCENTRAL regions - save normally
            for folder_name in folder_list:
                n_records, file_path = save_to_folder(region_df, folder_name)
                logging.info(f"Saved {region} to {folder_name}/ ({n_records} records)")
                
                # Verify continuity
                expected_days = (region_df['DATE'].max() - region_df['DATE'].min()).days + 1
                if n_records == expected_days:
                    logging.info(f"  ✓ Continuous daily data confirmed")
                else:
                    logging.warning(f"  ⚠ Gaps detected: expected {expected_days} days, got {n_records}")
                
                folders_saved.add(folder_name)
    
    return list(folders_saved)


def main():
    """
    Main execution function.
    """
    try:
        logging.info("="*60)
        logging.info("Synmax Production Data Pipeline")
        logging.info(f"Historical: {START_DATE} to {END_DATE}")
        logging.info(f"Forecast: Today to {FORECAST_END_DATE}")
        logging.info("Note: SOUTHCENTRAL data will be saved to both SOUTHCENTRAL and SOUTHCENTRAL_SALTS")
        logging.info("="*60)
        
        # Initialize client
        logging.info("Initializing Synmax API client...")
        client = HyperionApiClient(access_token=ACCESS_TOKEN)
        
        # Fetch historical
        logging.info("\n--- HISTORICAL DATA ---")
        df_historical = fetch_daily_production(client)
        
        # Fetch forecast
        logging.info("\n--- FORECAST DATA ---")
        df_forecast = fetch_production_forecast(client)
        
        # Summary
        logging.info("\n" + "="*60)
        logging.info("DATA SUMMARY")
        logging.info("="*60)
        
        if not df_historical.empty:
            logging.info(f"Historical: {len(df_historical)} records")
            if 'DATE' in df_historical.columns:
                logging.info(f"  Date range: {df_historical['DATE'].min().date()} to {df_historical['DATE'].max().date()}")
        else:
            logging.info("No historical data")
        
        if not df_forecast.empty:
            logging.info(f"Forecast: {len(df_forecast)} records")
            if 'DATE' in df_forecast.columns:
                logging.info(f"  Date range: {df_forecast['DATE'].min().date()} to {df_forecast['DATE'].max().date()}")
        else:
            logging.info("No forecast data")
        
        if df_historical.empty and df_forecast.empty:
            logging.error("No data retrieved")
            return
        
        # Save
        logging.info("\n--- SAVING DATA ---")
        regions_saved = save_regional_data(df_historical, df_forecast)
        
        logging.info("\n" + "="*60)
        logging.info("COMPLETE")
        logging.info("="*60)
        logging.info(f"Saved to: {OUTPUT_BASE_PATH}")
        logging.info(f"Regions: {', '.join(sorted(set(regions_saved)))}")
        
        if 'SOUTHCENTRAL' in regions_saved and 'SOUTHCENTRAL_SALTS' in regions_saved:
            logging.info("\n✓ SOUTHCENTRAL data saved to both:")
            logging.info("  • SOUTHCENTRAL/synmax_production_with_forecast.csv")
            logging.info("  • SOUTHCENTRAL_SALTS/synmax_production_with_forecast.csv")
        
        logging.info("\nEach file contains continuous daily data")
        
    except Exception as e:
        logging.error(f"Critical error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()