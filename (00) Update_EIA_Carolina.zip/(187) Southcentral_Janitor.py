import pandas as pd
import os
from datetime import datetime

# Define file paths for the South Central region
southcentral_dir = r'D:\EIA_STACK\Pricing_RL\SOUTHCENTRAL_SALTS'
input_file = os.path.join(southcentral_dir, 'SOUTHCENTRAL_SALTS_merged_all_outer_with_totals.csv')
output_file = os.path.join(southcentral_dir, 'SOUTHCENTRAL_SALTS_filtered.csv')

# Conversion factor: 1 dekatherm = 0.001 BCF (approximately)
# More precisely: 1 dekatherm ≈ 1 MMBtu ≈ 0.001 BCF
DEKATHERM_TO_BCF = 0.001

# List of columns to convert from dekatherms to BCF
columns_to_convert = [
    'southcentralsal_Bistineau',
    'southcentralsal_Egan',
    'southcentralsal_Jefferson Island',
    'southcentralsal_Moss Bluff',
    'southcentralsal_Napoleonville',
    'southcentralsal_Petal',
    'southcentralsal_Pine Prairie',
    'southcentralsal_Tres Palacios'

]

# Primary columns to drop (before conversion)
columns_to_drop_primary = [
    'texascommercial_TEXAS_Commercial_hourly_MMcf',
    'texasindustrial_TEXAS_Industrial_hourly_MMcf',
    'texasresidentia_TEXAS_Residential_hourly_MMcf',
    'texaspowerburnp_TEXAS_Power_Burn',
    'synmaxproductio_DATA_SOURCE'
]

# Secondary columns that might exist after conversion (safety check)
columns_to_drop_secondary = [
    # 'texascommercial_TEXAS_Commercial_hourly_MMcf_BCF',
    # 'texasindustrial_TEXAS_Industrial_hourly_MMcf_BCF',
    # 'texaspowerburnp_TEXAS_Power_Burn_BCF'
]

print("="*60)
print("FILTER SOUTHCENTRAL MERGED DATA BY DATE RANGE")
print("AND CONVERT DEKATHERMS TO BCF")
print("="*60)
print(f"Input file: {input_file}")
print(f"Date range: 2022-01-01 to 2026-12-31")
print(f"Conversion: Dekatherms to BCF (factor: {DEKATHERM_TO_BCF})")
print("="*60)

# Load the data
print("\nLoading data...")
try:
    df = pd.read_csv(input_file)
    print(f"✓ Loaded {len(df):,} rows")
    
    # Check if 'date' column exists
    if 'date' not in df.columns:
        print("Error: 'date' column not found in the file")
        print(f"Available columns: {list(df.columns)[:10]}")
        exit()
    
    # Convert date column to datetime
    print("\nConverting date column to datetime...")
    df['date'] = pd.to_datetime(df['date'], errors='coerce')
    
    # Check for invalid dates
    invalid_dates = df['date'].isna().sum()
    if invalid_dates > 0:
        print(f"⚠️ Warning: {invalid_dates} invalid dates found and will be removed")
        df = df.dropna(subset=['date'])
    
    # Show original date range
    print(f"\nOriginal date range:")
    print(f"  Start: {df['date'].min().date()}")
    print(f"  End: {df['date'].max().date()}")
    print(f"  Total rows: {len(df):,}")
    
    # Define filter dates
    start_date = pd.Timestamp('2022-01-01')
    end_date = pd.Timestamp('2026-12-31')
    
    # Apply date filter
    print(f"\nApplying date filter...")
    print(f"  Keeping dates from {start_date.date()} to {end_date.date()}")
    
    # Filter the dataframe
    df_filtered = df[(df['date'] >= start_date) & (df['date'] <= end_date)].copy()
    
    # Sort by date
    df_filtered = df_filtered.sort_values('date')
    
    # Show results
    rows_removed = len(df) - len(df_filtered)
    print(f"\n✓ Filter applied successfully")
    print(f"  Rows removed: {rows_removed:,}")
    print(f"  Rows kept: {len(df_filtered):,}")
    print(f"  Percentage kept: {len(df_filtered)/len(df)*100:.1f}%")
    
    # Show new date range
    print(f"\nFiltered date range:")
    print(f"  Start: {df_filtered['date'].min().date()}")
    print(f"  End: {df_filtered['date'].max().date()}")
    
    # Drop unwanted columns FIRST (before any conversions)
    print(f"\n" + "="*60)
    print("DROPPING UNWANTED COLUMNS")
    print("="*60)
    
    print("Dropping primary columns (before conversion)...")
    dropped_count = 0
    not_found_cols = []
    
    for col_to_drop in columns_to_drop_primary:
        if col_to_drop in df_filtered.columns:
            df_filtered = df_filtered.drop(columns=[col_to_drop])
            print(f"✓ Dropped: {col_to_drop}")
            dropped_count += 1
        else:
            not_found_cols.append(col_to_drop)
    
    print(f"\nDropped {dropped_count}/{len(columns_to_drop_primary)} primary columns")
    
    if not_found_cols:
        print(f"\n⚠️ Primary columns not found:")
        for col in not_found_cols:
            print(f"  • {col}")
    
    # Convert dekatherms to BCF
    print("\n" + "="*60)
    print("CONVERTING DEKATHERMS TO BCF")
    print("="*60)
    
    converted_count = 0
    missing_columns = []
    
    for col in columns_to_convert:
        if col in df_filtered.columns:
            # Store original values for comparison
            original_mean = df_filtered[col].mean()
            
            # Convert to BCF
            df_filtered[col] = df_filtered[col] * DEKATHERM_TO_BCF
            
            # Rename column to indicate BCF units
            new_col_name = col.replace('southcentralnon_', 'southcentralnon_BCF_')
            df_filtered.rename(columns={col: new_col_name}, inplace=True)
            
            converted_count += 1
            new_mean = df_filtered[new_col_name].mean()
            
            print(f"✓ Converted: {col}")
            print(f"  Original mean: {original_mean:.2f} dekatherms")
            print(f"  New mean: {new_mean:.6f} BCF")
            print(f"  Renamed to: {new_col_name}")
            print()
        else:
            missing_columns.append(col)
    
    print(f"\nConversion Summary:")
    print(f"  Columns converted: {converted_count}/{len(columns_to_convert)}")
    
    if missing_columns:
        print(f"\n⚠️ Warning: {len(missing_columns)} columns not found:")
        for col in missing_columns[:10]:  # Show first 10 missing
            print(f"    • {col}")
        if len(missing_columns) > 10:
            print(f"    ... and {len(missing_columns) - 10} more")
    
    # Final cleanup - check for any BCF versions of Texas columns that might have been created
    print("\nChecking for any remaining Texas columns...")
    secondary_dropped = 0
    for col_to_drop in columns_to_drop_secondary:
        if col_to_drop in df_filtered.columns:
            df_filtered = df_filtered.drop(columns=[col_to_drop])
            print(f"✓ Also dropped: {col_to_drop}")
            secondary_dropped += 1
    
    if secondary_dropped > 0:
        print(f"Dropped {secondary_dropped} additional Texas BCF columns")
    else:
        print("✓ No additional Texas columns found")
    
    print(f"\nFinal shape: {df_filtered.shape[0]:,} rows × {df_filtered.shape[1]} columns")
    
    # Check for date gaps
    date_range = pd.date_range(start=df_filtered['date'].min(), end=df_filtered['date'].max(), freq='D')
    missing_dates = date_range.difference(df_filtered['date'])
    if len(missing_dates) > 0:
        print(f"\n⚠️ Warning: {len(missing_dates)} dates are missing in the range")
        if len(missing_dates) <= 10:
            print("  Missing dates:")
            for d in missing_dates:
                print(f"    • {d.date()}")
        else:
            print(f"  First 5 missing: {[d.date() for d in missing_dates[:5]]}")
            print(f"  Last 5 missing: {[d.date() for d in missing_dates[-5:]]}")
    else:
        print("\n✓ No date gaps found - continuous daily data")
    
    # Save the filtered data
    print(f"\nSaving filtered and converted data...")
    df_filtered.to_csv(output_file, index=False)
    
    # Check file size
    file_size = os.path.getsize(output_file)
    if file_size < 1024 * 1024:
        size_str = f"{file_size/1024:.1f} KB"
    else:
        size_str = f"{file_size/(1024*1024):.1f} MB"
    
    print(f"✓ Filtered data saved to: {output_file}")
    print(f"  File size: {size_str}")
    
    # Show sample of data with BCF columns
    print("\n" + "="*60)
    print("DATA PREVIEW (WITH BCF CONVERSION)")
    print("="*60)
    
    # Show first few rows with BCF columns
    bcf_cols = [col for col in df_filtered.columns if 'BCF' in col]
    if bcf_cols:
        display_cols = ['date'] + bcf_cols[:5]  # Show date and first 5 BCF columns
        print("\nFirst 3 rows (sample BCF columns):")
        print("-"*40)
        print(df_filtered[display_cols].head(3).to_string())
        
        print("\nLast 3 rows (sample BCF columns):")
        print("-"*40)
        print(df_filtered[display_cols].tail(3).to_string())
    
    # Show column summary for BCF columns
    print("\n" + "="*60)
    print("BCF COLUMN SUMMARY")
    print("="*60)
    
    bcf_total_col = 'southcentralnon_BCF_TOTAL_NONSALT'
    if bcf_total_col in df_filtered.columns:
        print(f"\nTotal Non-Salt Storage (BCF):")
        print(f"  Column: {bcf_total_col}")
        print(f"  Mean: {df_filtered[bcf_total_col].mean():.6f} BCF")
        print(f"  Min: {df_filtered[bcf_total_col].min():.6f} BCF")
        print(f"  Max: {df_filtered[bcf_total_col].max():.6f} BCF")
        print(f"  Std Dev: {df_filtered[bcf_total_col].std():.6f} BCF")
    
    print(f"\nTotal BCF columns in filtered data: {len(bcf_cols)}")
    
    # Verify all conversions
    print("\n" + "="*60)
    print("VERIFICATION")
    print("="*60)
    
    # Check that no original dekatherm columns remain
    remaining_original = [col for col in columns_to_convert if col in df_filtered.columns]
    if remaining_original:
        print(f"⚠️ Warning: {len(remaining_original)} original dekatherm columns still present:")
        for col in remaining_original:
            print(f"  • {col}")
    else:
        print("✓ All specified dekatherm columns have been converted and renamed")
    
    # Check for any remaining Texas columns
    all_texas_patterns = ['texas', 'TEXAS']
    remaining_texas = [col for col in df_filtered.columns if any(pattern in col for pattern in all_texas_patterns)]
    if remaining_texas:
        print(f"\n⚠️ Warning: Found {len(remaining_texas)} Texas-related columns still in data:")
        for col in remaining_texas:
            print(f"  • {col}")
    else:
        print("✓ All Texas columns have been removed")
    
    # List all BCF columns
    print(f"\n✓ BCF columns in output file: {len(bcf_cols)}")
    if bcf_cols and len(bcf_cols) <= 30:
        print("\nAll BCF columns:")
        for col in sorted(bcf_cols):
            print(f"  • {col}")
    
except FileNotFoundError:
    print(f"✗ Error: File not found at {input_file}")
    print("Please ensure the file exists and the path is correct")
except Exception as e:
    print(f"✗ Error loading or processing file: {str(e)}")
    import traceback
    print("\nFull error traceback:")
    print(traceback.format_exc())

print("\n" + "="*60)
print("Filtering and conversion complete!")
print("="*60)