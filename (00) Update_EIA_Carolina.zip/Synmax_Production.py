import streamlit as st
import pandas as pd
from datetime import datetime, date, timedelta
from sqlalchemy import create_engine, text
import plotly.graph_objects as go

# --- AZURE SQL DATABASE CONFIGURATION ---
AZURE_DB_CONNECTION_STRING = (
)

# --- Database Connection ---
@st.cache_resource
def get_db_engine():
    """Create and cache database engine for Azure SQL connection."""
    try:
        engine = create_engine(AZURE_DB_CONNECTION_STRING, echo=False, pool_recycle=3600)
        with engine.connect() as connection:
            connection.execute(text("SELECT 1")).scalar()
        return engine
    except Exception as e:
        st.error(f"❌ Database Connection Error: {e}")
        return None

@st.cache_data(ttl=1800)
def load_synmax_data():
    """Load SYNMAX daily production data."""
    engine = get_db_engine()
    if not engine: return None
    try:
        query = text("""
        SELECT 
            [Date],
            [Date_Published],
            [Gas_Value]
        FROM [dbo].[PRODUCTION_SYNMAX_DAILY_PRODUCTION]
        WHERE [Gas_Value] IS NOT NULL
        ORDER BY [Date_Published] DESC, [Date] ASC
        """)
        df = pd.read_sql_query(query, engine)
        if not df.empty:
            df['Date'] = pd.to_datetime(df['Date']).dt.date
            df['Date_Published'] = pd.to_datetime(df['Date_Published']).dt.date
            return df
        return None
    except Exception as e:
        st.error(f"Error loading SYNMAX data: {e}")
        return None

# --- Page Configuration & Title ---
st.set_page_config(page_title="SYNMAX Production", page_icon="⛽", layout="wide")
st.title("⛽ SYNMAX Daily Production Analysis")
st.markdown("Comparing production data from the last three publication dates.")

# --- Load and Process Data ---
with st.spinner("Loading SYNMAX production data..."):
    full_data = load_synmax_data()

if full_data is None or full_data.empty:
    st.error("❌ No SYNMAX data could be loaded from the database.")
    st.stop()

# --- Filter to the last three publication dates ---
latest_pub_dates = sorted(full_data['Date_Published'].unique(), reverse=True)[:3]

if len(latest_pub_dates) < 3:
    st.warning("Fewer than three publication dates were found in the dataset.")
else:
    st.info(f"Analyzing data published on: **{latest_pub_dates[0]}**, **{latest_pub_dates[1]}**, and **{latest_pub_dates[2]}**.")

filtered_df = full_data[full_data['Date_Published'].isin(latest_pub_dates)]

st.markdown("---")

# --- Revision Chart with Trimmed Date Range ---
st.markdown("### 📈 Production Revisions (Last 14 / Next 30 Days)")

# Define the date window for the chart
TODAY = date.today()
start_date = TODAY - timedelta(days=14)
end_date = TODAY + timedelta(days=30)

# Filter the data specifically for the chart
chart_df = filtered_df[(filtered_df['Date'] >= start_date) & (filtered_df['Date'] <= end_date)]

fig = go.Figure()
colors = ['royalblue', 'darkorange', 'seagreen']

if not chart_df.empty:
    for i, pub_date in enumerate(latest_pub_dates):
        plot_data = chart_df[chart_df['Date_Published'] == pub_date]
        
        label = f"Published {pub_date.strftime('%b %d, %Y')}"
        if i == 0:
            label += " (Most Recent)"

        fig.add_trace(go.Scatter(
            x=plot_data['Date'],
            y=plot_data['Gas_Value'],
            mode='lines+markers',
            name=label,
            line=dict(width=3.5 if i == 0 else 2, color=colors[i]),
            marker=dict(size=5, color=colors[i])
        ))

    # Add a vertical line for Today for context
    fig.add_vline(x=TODAY, line_width=1.5, line_dash="dash", line_color="black")
    fig.add_annotation(
        x=TODAY, y=chart_df['Gas_Value'].max(), text="Today", showarrow=False,
        xshift=15, font=dict(color="black", size=12)
    )

    fig.update_layout(
        title_text="Gas Production Value by Gas Date, Colored by Publication Date",
        xaxis_title="Gas Production Date",
        yaxis_title="Gas Value (BCF/d)",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        template='plotly_white',
        hovermode='x unified'
    )
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info("No SYNMAX production data available within the -14/+30 day window.")

st.markdown("---")

# --- MODIFICATION: The summary statistics table has been removed ---

# --- Raw Data Expander (shows all data for the three publication dates) ---
with st.expander("View Full Raw Data for these Publications"):
    st.dataframe(
        filtered_df[['Date', 'Date_Published', 'Gas_Value']].sort_values(by=['Date', 'Date_Published'], ascending=[True, False]),
        use_container_width=True
    )