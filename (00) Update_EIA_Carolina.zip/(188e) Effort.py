# =============================================================================
# COMPREHENSIVE MERGE SCRIPT - All Aggregate Files
# =============================================================================
import pandas as pd
import os
from datetime import datetime

# --- CONFIGURATION ---
AGGREGATE_PATH = r"D:\EIA_STACK\Pricing_RL\AGGREGATE"

# =============================================================================
# MAIN MERGE FUNCTION
# =============================================================================
def merge_all_aggregate_files():
    """Merge all aggregate files into a single master dataset"""
    
    print("\n" + "=" * 80)
    print("COMPREHENSIVE AGGREGATE DATA MERGE")
    print("=" * 80)
    print(f"Started: {datetime.now()}")
    print(f"Working directory: {AGGREGATE_PATH}")
    
    # Step 1: Delete unnecessary files
    print("\n" + "=" * 60)
    print("STEP 1: CLEANUP")
    print("=" * 60)
    
    files_to_delete = [
        "supply_demand_forecast.csv",
        "supply_demand_historical.csv"
    ]
    
    for filename in files_to_delete:
        file_path = os.path.join(AGGREGATE_PATH, filename)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                print(f"  ✓ Deleted: {filename}")
            except Exception as e:
                print(f"  ✗ Error deleting {filename}: {e}")
        else:
            print(f"  ⚠ File not found (skipping): {filename}")
    
    # Step 2: Define all files to merge
    print("\n" + "=" * 60)
    print("STEP 2: MERGING ALL FILES")
    print("=" * 60)
    
    # List all files to merge in order
    files_to_merge = [
        "weather_conus.csv",
        "supply_demand_combined.csv",
        "commercial_burns_aggregate.csv",
        "industrial_burns_aggregate.csv",
        "residential_burns_aggregate.csv",
        "power_burns_aggregate.csv",
        "pipe_lease_losses.csv",
        "synmax_production_aggregate.csv",
        "eia_storage_lower48.csv",
        "lower_48_states.csv"
    ]
    
    # Initialize with None - will be set with first valid file
    master_df = None
    successfully_merged = []
    failed_files = []
    
    for filename in files_to_merge:
        file_path = os.path.join(AGGREGATE_PATH, filename)
        
        if not os.path.exists(file_path):
            print(f"\n  ⚠ File not found: {filename}")
            failed_files.append(filename)
            continue
        
        try:
            print(f"\n  Processing {filename}...")
            
            # Load the file
            df = pd.read_csv(file_path)
            print(f"    Loaded: {len(df)} records")
            
            # Standardize date column
            date_col = None
            if 'Date' in df.columns:
                date_col = 'Date'
            elif 'date' in df.columns:
                date_col = 'date'
                df.rename(columns={'date': 'Date'}, inplace=True)
            elif 'datetime' in df.columns:
                date_col = 'datetime'
                df.rename(columns={'datetime': 'Date'}, inplace=True)
            else:
                print(f"    ✗ No date column found - skipping")
                failed_files.append(filename)
                continue
            
            # Convert to datetime
            df['Date'] = pd.to_datetime(df['Date'])
            
            # Show info
            print(f"    Date range: {df['Date'].min().date()} to {df['Date'].max().date()}")
            cols = [col for col in df.columns if col != 'Date']
            print(f"    Columns ({len(cols)}): {cols[:5]}..." if len(cols) > 5 else f"    Columns: {cols}")
            
            # Merge or initialize
            if master_df is None:
                # First file becomes the base
                master_df = df.copy()
                print(f"    ✓ Initialized master dataset with {filename}")
            else:
                # Merge with existing master
                records_before = len(master_df)
                master_df = pd.merge(
                    master_df,
                    df,
                    on='Date',
                    how='outer',
                    suffixes=('', '_dup')
                )
                records_after = len(master_df)
                print(f"    ✓ Merged - total records now: {records_after} (added {records_after - records_before})")
            
            successfully_merged.append(filename)
            
        except Exception as e:
            print(f"    ✗ Error processing {filename}: {e}")
            failed_files.append(filename)
    
    # Check if we have any data
    if master_df is None:
        print("\n✗ ERROR: No files could be loaded!")
        return False
    
    # Sort by date
    master_df = master_df.sort_values('Date')
    
    # Remove any duplicate columns (those ending with _dup)
    dup_cols = [col for col in master_df.columns if col.endswith('_dup')]
    if dup_cols:
        print(f"\n  Removing {len(dup_cols)} duplicate columns...")
        master_df = master_df.drop(columns=dup_cols)
    
    # Save the master file
    print("\n" + "=" * 60)
    print("STEP 3: SAVING MASTER FILE")
    print("=" * 60)
    
    output_file = "master_aggregate_data.csv"
    output_path = os.path.join(AGGREGATE_PATH, output_file)
    master_df.to_csv(output_path, index=False)
    
    file_size = os.path.getsize(output_path) / (1024 * 1024)  # MB
    print(f"  ✓ Saved to: {output_file}")
    print(f"  File size: {file_size:.2f} MB")
    print(f"  Total records: {len(master_df):,}")
    print(f"  Date range: {master_df['Date'].min().date()} to {master_df['Date'].max().date()}")
    print(f"  Total columns: {len(master_df.columns)}")
    
    # Summary statistics
    print("\n" + "=" * 60)
    print("SUMMARY STATISTICS")
    print("=" * 60)
    
    print(f"\nFiles processed:")
    print(f"  ✓ Successfully merged: {len(successfully_merged)}")
    for f in successfully_merged:
        print(f"    - {f}")
    
    if failed_files:
        print(f"\n  ✗ Failed/Skipped: {len(failed_files)}")
        for f in failed_files:
            print(f"    - {f}")
    
    # Column analysis
    print(f"\nColumn completeness:")
    total_rows = len(master_df)
    
    # Group columns by data type
    weather_cols = [col for col in master_df.columns if 'cdd' in col.lower() or 'hdd' in col.lower()]
    burns_cols = [col for col in master_df.columns if 'burns' in col.lower() or '_bcf' in col.lower()]
    supply_cols = [col for col in master_df.columns if any(x in col.lower() for x in ['lng', 'mex', 'cad'])]
    storage_cols = [col for col in master_df.columns if 'storage' in col.lower()]
    production_cols = [col for col in master_df.columns if 'production' in col.lower()]
    loss_cols = [col for col in master_df.columns if 'loss' in col.lower()]
    
    col_groups = [
        ("Weather", weather_cols),
        ("Burns", burns_cols),
        ("Supply/Demand", supply_cols),
        ("Storage", storage_cols),
        ("Production", production_cols),
        ("Losses", loss_cols)
    ]
    
    for group_name, cols in col_groups:
        if cols:
            print(f"\n  {group_name} columns:")
            for col in cols[:10]:  # Show max 10 per group
                non_null = master_df[col].notna().sum()
                pct_complete = (non_null / total_rows) * 100
                print(f"    - {col}: {pct_complete:.1f}% complete ({non_null:,}/{total_rows:,})")
            if len(cols) > 10:
                print(f"    ... and {len(cols)-10} more")
    
    # Save a data quality report
    print("\n" + "=" * 60)
    print("DATA QUALITY REPORT")
    print("=" * 60)
    
    quality_report = []
    for col in master_df.columns:
        if col != 'Date':
            non_null = master_df[col].notna().sum()
            null_count = master_df[col].isna().sum()
            pct_complete = (non_null / total_rows) * 100
            quality_report.append({
                'Column': col,
                'Non_Null': non_null,
                'Null': null_count,
                'Pct_Complete': pct_complete
            })
    
    quality_df = pd.DataFrame(quality_report)
    quality_df = quality_df.sort_values('Pct_Complete', ascending=False)
    
    quality_file = "data_quality_report.csv"
    quality_path = os.path.join(AGGREGATE_PATH, quality_file)
    quality_df.to_csv(quality_path, index=False)
    print(f"  ✓ Data quality report saved to: {quality_file}")
    
    # Show top and bottom completeness
    print(f"\n  Most complete columns:")
    for _, row in quality_df.head(5).iterrows():
        print(f"    - {row['Column']}: {row['Pct_Complete']:.1f}%")
    
    print(f"\n  Least complete columns:")
    for _, row in quality_df.tail(5).iterrows():
        print(f"    - {row['Column']}: {row['Pct_Complete']:.1f}%")
    
    print("\n" + "=" * 80)
    print("✅ MERGE COMPLETE!")
    print("=" * 80)
    print(f"Completed: {datetime.now()}")
    
    return True

# =============================================================================
# MAIN EXECUTION
# =============================================================================
if __name__ == "__main__":
    success = merge_all_aggregate_files()
    if not success:
        print("\n⚠ WARNING: Merge completed with errors!")